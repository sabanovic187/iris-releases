# Removes World Monitor: stops its containers, deletes its Docker images and its folder.
param([Parameter(Mandatory = $true)][string]$Root)
$ErrorActionPreference = "Continue"
$folder = Join-Path $Root "worldmonitor"
if (Test-Path $folder) {
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        Push-Location $folder
        "Stopping World Monitor..."
        docker compose down --rmi local --volumes *> $null
        Pop-Location
    }
    "Deleting its folder..."
    Remove-Item -Recurse -Force $folder
}
"World Monitor is removed."
exit 0
