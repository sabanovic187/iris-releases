"""Small web server for the Command Center. It answers only this computer."""
from __future__ import annotations

import asyncio
import time
import hmac
import ipaddress
import json
import webbrowser
import zipfile
from http import HTTPStatus
from pathlib import Path, PurePosixPath
from typing import Any
import urllib.request
from urllib.parse import parse_qs, unquote, urlencode, urlsplit

from iris.connectors.base import ConnectorError
from iris.routines import RoutineError
from iris.ui.hub import COMPUTER_ONLY_TOOLS, Busy, Hub
from iris.worldmonitor import reachable

STATIC = Path(__file__).parent / "static"
FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/iris.js": ("iris.js", "text/javascript; charset=utf-8"),
    "/presence.js": ("presence.js", "text/javascript; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/material.js": ("material.js", "text/javascript; charset=utf-8"),
    "/alcantara.png": ("alcantara.png", "image/png"),
    "/fonts/manrope.woff2": ("fonts/manrope.woff2", "font/woff2"),
    "/fonts/manrope-ext.woff2": ("fonts/manrope-ext.woff2", "font/woff2"),
    "/fonts/cormorant-300.woff2": ("fonts/cormorant-300.woff2", "font/woff2"),
    "/fonts/cormorant-300-ext.woff2": ("fonts/cormorant-300-ext.woff2", "font/woff2"),
    "/fonts/cormorant-400.woff2": ("fonts/cormorant-400.woff2", "font/woff2"),
    "/fonts/cormorant-400-ext.woff2": ("fonts/cormorant-400-ext.woff2", "font/woff2"),
    "/situation.js": ("situation.js", "text/javascript; charset=utf-8"),
    "/cards.js": ("cards.js", "text/javascript; charset=utf-8"),
    "/cipher.js": ("cipher.js", "text/javascript; charset=utf-8"),
    "/pair": ("pair.html", "text/html; charset=utf-8"),
    "/pair.js": ("pair.js", "text/javascript; charset=utf-8"),
    "/satellite.js": ("satellite.bundle.js", "text/javascript; charset=utf-8"),
}
CESIUM_TYPES = {
    ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json",
    ".png": "image/png", ".jpg": "image/jpeg", ".xml": "application/xml", ".wasm": "application/wasm",
    ".svg": "image/svg+xml", ".ktx2": "image/ktx2",
}
SECURITY_HEADERS = (
    "Content-Security-Policy: default-src 'none'; script-src 'self' 'wasm-unsafe-eval' blob:; style-src 'self'; "
    "font-src 'self'; connect-src 'self' https://server.arcgisonline.com; worker-src 'self' blob:; "
    "img-src 'self' data: blob: https:; frame-src https://www.youtube-nocookie.com{frames}; base-uri 'none'; "
    "form-action 'none'; frame-ancestors 'none'\r\n"
    "X-Content-Type-Options: nosniff\r\n"
    "Referrer-Policy: no-referrer\r\n"
    "Cache-Control: no-store\r\n"
)
COOKIE = "iris_session"
PANEL_COOKIE = "iris_panel"
# What a paired tablet may do. Settings, accounts, memory and taking control stay on the computer.
PANEL_ACTIONS = {
    "message", "approval", "stop", "talk", "speak", "cards", "spotify", "brain", "quiet",
    "world", "world_monitor", "refresh_situation",  # Situation, open to any paired screen
    "settings_unlock", "job_report", "scene",
}
# Settings a paired screen may change after the PIN unlocks them for a while. Pairing new
# screens and taking control stay on the computer.
PANEL_SETTINGS_ACTIONS = {
    "security_check", "connect_openai", "remove_openai", "connect_unbound", "remove_unbound", "unbound_pin", "new", "backup",
}
SETTINGS_UNLOCK_SECONDS = 600
PANEL_OPEN_FILES = {"/pair", "/pair.js", "/style.css", "/material.js", "/alcantara.png"}
MAX_HEADER = 16 * 1024
MAX_BODY = 64 * 1024
MAX_MESSAGE = 8000
KEEP_ALIVE_SECONDS = 15


PLACE_SEARCH = "https://geocoding-api.open-meteo.com/v1/search"


def find_places(query: str) -> list[dict[str, Any]]:
    """Cities by name from Open-Meteo's free place search (no key, public data only)."""
    url = f"{PLACE_SEARCH}?{urlencode({'name': query, 'count': 6, 'language': 'en', 'format': 'json'})}"
    request = urllib.request.Request(url, headers={"User-Agent": "IRIS"})
    with urllib.request.urlopen(request, timeout=8) as response:
        found = json.loads(response.read(200_000)).get("results") or []
    places = []
    for item in found:
        name = ", ".join(part for part in (item.get("name"), item.get("admin1"), item.get("country")) if part)
        places.append({"label": name, "place": item.get("name", ""), "lat": item.get("latitude"), "lon": item.get("longitude")})
    return places


class Request:
    def __init__(self, method: str, target: str, headers: dict[str, str], body: bytes) -> None:
        parts = urlsplit(target)
        self.method = method
        self.path = parts.path
        self.query = parse_qs(parts.query)
        self.headers = headers
        self.body = body

    def cookie(self, name: str) -> str:
        for piece in self.headers.get("cookie", "").split(";"):
            key, _, value = piece.strip().partition("=")
            if key == name:
                return value
        return ""


async def read_request(reader: asyncio.StreamReader) -> Request | None:
    try:
        head = await reader.readuntil(b"\r\n\r\n")
    except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, ConnectionError):
        return None
    lines = head.decode("latin-1").split("\r\n")
    pieces = lines[0].split(" ")
    if len(pieces) != 3:
        return None
    headers = {}
    for line in lines[1:]:
        name, sep, value = line.partition(":")
        if sep:
            headers[name.strip().lower()] = value.strip()
    try:
        length = int(headers.get("content-length", "0"))
    except ValueError:
        return None
    if length < 0 or length > MAX_BODY:
        return None
    try:
        body = await reader.readexactly(length) if length else b""
    except (asyncio.IncompleteReadError, ConnectionError):
        return None
    return Request(pieces[0], pieces[1], headers, body)


def cesium_file(name: str) -> bytes | None:
    with zipfile.ZipFile(STATIC / "cesium.zip") as archive:
        return archive.read(name) if name in archive.namelist() else None


class Server:
    def __init__(self, hub: Hub, token: str, panel: bool = False) -> None:
        self.hub = hub
        self.token = token
        self.panel = panel
        port = hub.settings.worldmonitor_port
        if panel:  # the tablet shows World Monitor through the pass-through on the next port
            frames = f" http://*:{hub.settings.tablet_port + 1}" if port > 0 else ""
        else:
            frames = f" http://127.0.0.1:{port}" if port > 0 else ""
        self.security_headers = SECURITY_HEADERS.replace("{frames}", frames)
        self.unlocked: dict[str, float] = {}  # tablet id -> time its Settings lock again
        self.port = 0
        self.background: set[asyncio.Task[Any]] = set()

    async def start(self, port: int) -> asyncio.Server:
        if self.panel:
            # The tablet listener needs a fixed address, so a busy port is reported instead of moved.
            server = await asyncio.start_server(self._serve, "0.0.0.0", port, limit=MAX_HEADER)
            self.port = server.sockets[0].getsockname()[1]
            return server
        try:
            server = await asyncio.start_server(self._serve, "127.0.0.1", port, limit=MAX_HEADER)
        except OSError:
            server = await asyncio.start_server(self._serve, "127.0.0.1", 0, limit=MAX_HEADER)
        self.port = server.sockets[0].getsockname()[1]
        return server

    @property
    def origin(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def open_url(self) -> str:
        return f"{self.origin}/open?t={self.token}"

    # Responses

    def _write(
        self,
        writer: asyncio.StreamWriter,
        status: int,
        body: bytes = b"",
        kind: str = "text/plain; charset=utf-8",
        extra: str = "",
    ) -> None:
        phrase = HTTPStatus(status).phrase
        writer.write(
            (
                f"HTTP/1.1 {status} {phrase}\r\nContent-Type: {kind}\r\n"
                f"Content-Length: {len(body)}\r\nConnection: close\r\n{self.security_headers}{extra}\r\n"
            ).encode("latin-1")
            + body
        )

    def _json(self, writer: asyncio.StreamWriter, data: Any, status: int = 200) -> None:
        self._write(writer, status, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json")

    # Checks

    def _valid_host(self, request: Request) -> bool:
        host = request.headers.get("host", "")
        if not self.panel:
            return host == f"127.0.0.1:{self.port}"
        # Only a home-network address typed as numbers, so another website's name cannot point here.
        address, _, port = host.rpartition(":")
        try:
            return port == str(self.port) and ipaddress.IPv4Address(address).is_private
        except ValueError:
            return False

    def _request_origin(self, request: Request) -> str:
        return f"http://{request.headers.get('host', '')}" if self.panel else self.origin

    def _signed_in(self, request: Request) -> bool:
        if self.panel:
            return self.hub.devices.check(request.cookie(PANEL_COOKIE)) is not None
        return hmac.compare_digest(request.cookie(COOKIE).encode(), self.token.encode())

    def _same_site_post(self, request: Request) -> bool:
        return (
            request.headers.get("origin") == self._request_origin(request)
            and request.headers.get("x-iris") == "1"
            and request.headers.get("content-type", "").startswith("application/json")
        )

    # Requests

    async def _serve(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            request = await read_request(reader)
            if request is None:
                self._write(writer, 400, b"Bad request")
            elif not self._valid_host(request):
                self._write(writer, 403, b"Wrong address")
            elif self.panel and request.method == "GET" and (request.path in PANEL_OPEN_FILES or request.path.startswith("/fonts/")):
                self._get(writer, request)
            elif self.panel and request.method == "POST" and request.path == "/api/pair" and self._same_site_post(request):
                await self._pair(writer, request)
            elif self.panel and not self._signed_in(request):
                self._write(writer, 303, extra="Location: /pair\r\n") if request.method == "GET" else self._write(writer, 403, b"Pair this screen first.")
            elif request.method == "GET" and request.path == "/open" and not self.panel:
                self._open(writer, request)
            elif not self._signed_in(request):
                self._write(writer, 403, b"Open IRIS from the link in its start window.")
            elif request.method == "GET" and request.path == "/api/events":
                await self._events(writer)
                return
            elif request.method == "GET" and request.path.startswith("/cesium/"):
                await self._cesium(writer, request.path)
            elif request.method == "GET":
                self._get(writer, request)
            elif request.method == "POST" and self._same_site_post(request):
                await self._post(writer, request)
            else:
                self._write(writer, 403, b"Refused")
            await writer.drain()
        except (ConnectionError, asyncio.CancelledError):
            pass
        finally:
            writer.close()

    def _open(self, writer: asyncio.StreamWriter, request: Request) -> None:
        offered = request.query.get("t", [""])[0]
        if not hmac.compare_digest(offered.encode(), self.token.encode()):
            self._write(writer, 403, b"This link has expired. Use the one in the IRIS start window.")
            return
        cookie = f"Set-Cookie: {COOKIE}={self.token}; HttpOnly; SameSite=Strict; Path=/\r\n"
        self._write(writer, 303, extra=f"Location: /\r\n{cookie}")

    def _get(self, writer: asyncio.StreamWriter, request: Request) -> None:
        if request.path == "/api/state":
            state = self.hub.snapshot()
            if self.panel:
                state["device"] = "tablet"
                state.pop("tablet", None)
                state.pop("pod", None)
                state.pop("setup", None)
                state.pop("update", None)
            self._json(writer, state)
        elif request.path in FILES:
            name, kind = FILES[request.path]
            self._write(writer, 200, (STATIC / name).read_bytes(), kind)
        else:
            self._write(writer, 404, b"Not found")

    async def _cesium(self, writer: asyncio.StreamWriter, path: str) -> None:
        """Serve the globe library from its bundled archive. Only names inside it can be reached."""
        name = unquote(path.removeprefix("/cesium/"))
        kind = CESIUM_TYPES.get(PurePosixPath(name).suffix.lower())
        content = await asyncio.to_thread(cesium_file, name) if kind else None
        if content is None:
            self._write(writer, 404, b"Not found")
        else:
            self._write(writer, 200, content, kind)

    async def _events(self, writer: asyncio.StreamWriter) -> None:
        writer.write(
            (
                "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
                f"Connection: close\r\n{self.security_headers}\r\n"
            ).encode("latin-1")
        )
        queue = self.hub.subscribe()
        try:
            while True:
                try:
                    text = await asyncio.wait_for(queue.get(), KEEP_ALIVE_SECONDS)
                except asyncio.TimeoutError:
                    text = ": still here\n\n"
                writer.write(text.encode("utf-8"))
                await writer.drain()
        except (ConnectionError, asyncio.CancelledError):
            pass
        finally:
            self.hub.unsubscribe(queue)
            writer.close()

    async def _post(self, writer: asyncio.StreamWriter, request: Request) -> None:
        try:
            data = json.loads(request.body or b"{}")
            if not isinstance(data, dict):
                raise ValueError
        except ValueError:
            self._json(writer, {"error": "Bad request."}, 400)
            return
        action = request.path.removeprefix("/api/").replace("-", "_")
        if self.panel and action not in PANEL_ACTIONS | PANEL_SETTINGS_ACTIONS:
            self._json(writer, {"error": "Do this on the computer."}, 403)
            return
        if self.panel and (action in PANEL_SETTINGS_ACTIONS or action == "settings_unlock"):
            device = self.hub.devices.check(request.cookie(PANEL_COOKIE)) or {}
            now = time.monotonic()
            if action == "settings_unlock":
                problem = self.hub.check_pin(str(data.get("pin", "")))
                if not problem:
                    self.unlocked[device.get("id", "")] = now + SETTINGS_UNLOCK_SECONDS
                    self.hub.audit.write("tablet_settings_unlocked", device=device.get("name", ""))
                self._json(writer, {"error": problem} if problem else {"ok": True}, 409 if problem else 200)
                return
            if self.unlocked.get(device.get("id", ""), 0) < now:
                self._json(writer, {"error": "Settings are locked. Open them again with the PIN.", "locked": True}, 403)
                return
            self.unlocked[device.get("id", "")] = now + SETTINGS_UNLOCK_SECONDS
        handler = getattr(self, "_post_" + action, None)
        if handler is None or not request.path.startswith("/api/"):
            self._write(writer, 404, b"Not found")
            return
        result = await handler(data)
        status = 200 if "error" not in result else 409
        self._json(writer, result, status)

    async def _post_message(self, data: dict[str, Any]) -> dict[str, Any]:
        text = str(data.get("text", ""))[:MAX_MESSAGE]
        if self.hub.busy:
            return {"error": "IRIS is still working on the last request."}

        async def run() -> None:
            try:
                speak = self.hub.speak_replies and self.hub.voice_status == "on"
                reply = await self.hub.send(text, live_speech=speak)
                if speak:
                    self.hub.voice.speak(reply or self.hub.last_spoken)
                    self.hub.last_spoken = ""
            except Busy:
                pass

        task = asyncio.create_task(run())
        self.background.add(task)
        task.add_done_callback(self.background.discard)
        return {"ok": True}

    async def _pair(self, writer: asyncio.StreamWriter, request: Request) -> None:
        try:
            data = json.loads(request.body or b"{}")
        except ValueError:
            data = {}
        if not isinstance(data, dict):
            data = {}
        token = await asyncio.to_thread(self.hub.devices.pair, str(data.get("code", ""))[:12], str(data.get("name", ""))[:60])
        if token is None:
            self.hub.audit.write("tablet_pairing", ok=False)
            self._json(writer, {"error": "That code is wrong or has expired. Make a new one in IRIS Settings."}, 403)
            return
        self.hub.audit.write("tablet_pairing", ok=True)
        self.hub.publish("tablet", self.hub.tablet_state())
        cookie = f"Set-Cookie: {PANEL_COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=31536000\r\n"
        body = json.dumps({"ok": True}).encode()
        self._write(writer, 200, body, "application/json", extra=cookie)

    async def _post_pair_start(self, _data: dict[str, Any]) -> dict[str, Any]:
        if not self.hub.settings.tablet_enabled:
            return {"error": "Turn on [tablet] in config\\settings.toml and restart IRIS first."}
        code = self.hub.devices.start_pairing()
        self.hub.audit.write("tablet_pairing_started")
        return {"ok": True, "code": code, "address": self.hub.tablet_address()}

    async def _post_security_check(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.security.running:
            return {"error": "The security check is already running."}

        async def run() -> None:
            await self.hub.run_security_check(announce=False)

        task = asyncio.create_task(run())
        self.background.add(task)
        task.add_done_callback(self.background.discard)
        self.hub.publish("security", {"summary": "Checking now. The first check downloads Trivy's vulnerability list and can take several minutes."})
        return {"ok": True}

    async def _post_pair_stop(self, _data: dict[str, Any]) -> dict[str, Any]:
        self.hub.devices.stop_pairing()
        return {"ok": True}

    async def _post_device_remove(self, data: dict[str, Any]) -> dict[str, Any]:
        removed = self.hub.devices.remove(str(data.get("id", "")))
        if removed:
            self.hub.audit.write("tablet_removed")
            self.hub.publish("tablet", self.hub.tablet_state())
        return {"ok": True} if removed else {"error": "That screen is already removed."}

    async def _post_job_report(self, data: dict[str, Any]) -> dict[str, Any]:
        try:
            job = self.hub.jobs.get(int(data.get("id", 0)))
        except (TypeError, ValueError):
            job = None
        if job is None:
            return {"error": "There is no such job."}
        return {"ok": True, "text": self.hub.jobs.report(job["id"]) or job["summary"]}

    async def _post_job_stop(self, data: dict[str, Any]) -> dict[str, Any]:
        try:
            stopped = self.hub.jobs.cancel(int(data.get("id", 0)))
        except (TypeError, ValueError):
            stopped = False
        return {"ok": True} if stopped else {"error": "That job is not running."}

    async def _post_health_check(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.health is None:
            return {"error": "Self-care has not started yet."}
        await self.hub.health.check()
        return {"ok": True, **self.hub.health.state()}

    async def _post_update_check(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.update_state()["development"]:
            return {"error": "This computer runs IRIS from Git. Update it with git pull."}
        await self.hub.check_update()
        state = self.hub.update_state()
        return {"error": state["problem"]} if state["problem"] else {"ok": True, **state}

    async def _post_update_install(self, _data: dict[str, Any]) -> dict[str, Any]:
        if not self.hub.update_state()["available"]:
            return {"error": "There is no update to install. Check for updates first."}
        task = asyncio.create_task(self.hub.install_update())
        self.background.add(task)
        task.add_done_callback(self.background.discard)
        return {"ok": True}

    async def _post_setup_places(self, data: dict[str, Any]) -> dict[str, Any]:
        query = str(data.get("query", "")).strip()[:80]
        if len(query) < 2:
            return {"error": "Type the name of your city."}
        try:
            places = await asyncio.to_thread(find_places, query)
        except OSError:
            return {"error": "The place search could not be reached. Check the internet connection."}
        return {"ok": True, "places": places} if places else {"error": "No place by that name was found."}

    async def _post_setup_save(self, data: dict[str, Any]) -> dict[str, Any]:
        address = " ".join(str(data.get("address", "")).split())[:40]
        key = str(data.get("key", "")).strip()
        try:
            place = {
                "place": " ".join(str(data.get("place", "")).split())[:80],
                "lat": round(float(data.get("lat")), 4),
                "lon": round(float(data.get("lon")), 4),
            }
        except (TypeError, ValueError):
            return {"error": "Pick your city from the list."}
        if not address:
            return {"error": "Tell IRIS how to address you."}
        if not place["place"] or not (-90 <= place["lat"] <= 90 and -180 <= place["lon"] <= 180):
            return {"error": "Pick your city from the list."}
        if key and (not key.startswith("sk-ant-") or len(key) < 30 or any(ch.isspace() for ch in key)):
            return {"error": "That does not look like a Claude API key. It starts with sk-ant-."}
        await self.hub.apply_setup(address, place, key)
        return {"ok": True}

    async def _post_scene(self, data: dict[str, Any]) -> dict[str, Any]:
        name = str(data.get("name", ""))[:40]
        if self.hub.scenes.get(name) is None:
            return {"error": "There is no scene by that name."}
        reply = await self.hub.run_scene(name)
        self.hub.publish("notice", {"text": reply})
        return {"ok": True, "reply": reply}

    async def _post_pod_pair(self, data: dict[str, Any]) -> dict[str, Any]:
        code = "".join(ch for ch in str(data.get("code", "")) if ch.isdigit())
        if len(code) != 6:
            return {"error": "Type the six digits the Pod shows."}
        pod = self.hub.pair_pod(code, str(data.get("name", "")).strip())
        if not pod:
            return {"error": "That code is not one a Pod is showing now. Check the Pod's screen and try again."}
        self.hub.publish("pod", self.hub.pod_state())
        return {"ok": True}

    async def _post_pod_remove(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.remove_pod(str(data.get("device", "")))
        self.hub.publish("pod", self.hub.pod_state())
        return {"ok": True}

    async def _post_approval(self, data: dict[str, Any]) -> dict[str, Any]:
        if data.get("allow") is not True and data.get("allow") is not False:
            return {"error": "Choose Allow or Deny."}
        if self.panel:
            item = self.hub.pending.get(str(data.get("id", "")))
            if data["allow"] and item and item["public"]["tool"].startswith(COMPUTER_ONLY_TOOLS):
                return {"error": "Allow this one on the computer. You can deny it here."}
            if item:
                self.hub.audit.write("tablet_decision", tool=item["public"]["tool"], allowed=data["allow"])
        done = self.hub.decide(str(data.get("id", "")), data["allow"])
        return {"ok": True} if done else {"error": "That request is no longer waiting."}

    async def _post_stop(self, _data: dict[str, Any]) -> dict[str, Any]:
        self.hub.emergency_stop("Command Center")
        return {"ok": True}

    async def _post_resume(self, _data: dict[str, Any]) -> dict[str, Any]:
        self.hub.clear_stop()
        return {"ok": True}

    async def _post_control(self, data: dict[str, Any]) -> dict[str, Any]:
        if data.get("take"):
            self.hub.take_control()
        else:
            self.hub.give_back_control()
        return {"ok": True}

    async def _post_new(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.busy:
            return {"error": "Wait for the current reply to finish."}
        await self.hub.new_conversation()
        return {"ok": True}

    async def _post_voice(self, data: dict[str, Any]) -> dict[str, Any]:
        problem = self.hub.switch_voice(bool(data.get("on")))
        return {"error": problem} if problem else {"ok": True}

    async def _post_voice_screen(self, _data: dict[str, Any]) -> dict[str, Any]:
        cloud = await asyncio.to_thread(self.hub.connectors.elevenlabs.screen) if self.hub.connectors else {"connected": False}
        return {"ok": True, **await self.hub.voice_screen(), "cloud": cloud}

    async def _post_connect_elevenlabs(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await asyncio.to_thread(self.hub.connectors.elevenlabs.connect, str(data.get("key", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        except OSError:
            return {"error": "The key could not be stored safely."}
        return {"ok": True}

    async def _post_voice_cloud(self, data: dict[str, Any]) -> dict[str, Any]:
        cloud = self.hub.connectors.elevenlabs
        try:
            if data.get("remove"):
                cloud.disconnect()
            else:
                cloud.choose(str(data["voice"]) if data.get("voice") else None, data.get("on"))
        except ConnectorError as error:
            return {"error": str(error)}
        return {"ok": True}

    async def _post_voice_change(self, data: dict[str, Any]) -> dict[str, Any]:
        problem = await self.hub.change_voice(data)
        return {"error": problem} if problem else {"ok": True}

    async def _post_test_microphone(self, _data: dict[str, Any]) -> dict[str, Any]:
        self.hub.voice.test_microphone()
        return {"ok": True}

    async def _post_test_speech(self, _data: dict[str, Any]) -> dict[str, Any]:
        self.hub.voice.test_speech()
        return {"ok": True}

    async def _post_talk(self, _data: dict[str, Any]) -> dict[str, Any]:
        problem = self.hub.talk()
        return {"error": problem} if problem else {"ok": True}

    async def _post_world_monitor(self, _data: dict[str, Any]) -> dict[str, Any]:
        port = self.hub.settings.worldmonitor_port
        ready = await asyncio.to_thread(reachable, port)
        if self.panel:  # the page builds the address from the tablet's own view of this computer
            return {"ready": ready, "url": "", "proxy": self.hub.settings.tablet_port + 1 if ready else 0}
        return {"ready": ready, "url": f"http://127.0.0.1:{port}/" if ready else ""}

    async def _post_cards(self, data: dict[str, Any]) -> dict[str, Any]:
        if "on" in data:
            on = bool(data.get("on"))
            self.hub.memory.set_state("cards_off", None if on else "1")
            if not on:
                self.hub.cards.clear()
            self.hub.publish("cards_setting", {"on": on})
        if data.get("clear"):
            self.hub.cards.clear()
        return {"ok": True}

    async def _post_speak(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.speak_replies = bool(data.get("on"))
        self.hub.memory.set_state("speak_replies", "1" if self.hub.speak_replies else "0")
        self.hub.publish("voice", self.hub.voice_state())
        return {"ok": True}

    async def _post_quiet(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.set_quiet(bool(data.get("on")))
        return {"ok": True}

    async def _post_remember(self, data: dict[str, Any]) -> dict[str, Any]:
        text = str(data.get("text", "")).strip()[:MAX_MESSAGE]
        if not text:
            return {"error": "Write something to remember."}
        self.hub.memory.remember(text)
        self.hub.publish("panels", self.hub.panels())
        return {"ok": True}

    async def _post_forget(self, data: dict[str, Any]) -> dict[str, Any]:
        try:
            fact_id = int(data.get("id", 0))
        except (TypeError, ValueError):
            return {"error": "Unknown item."}
        self.hub.memory.forget(fact_id)
        self.hub.publish("panels", self.hub.panels())
        return {"ok": True}

    async def _post_connect_google(self, data: dict[str, Any]) -> dict[str, Any]:
        connectors = self.hub.connectors
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await connectors.google.begin_sign_in(
                str(data.get("client_id", "")),
                str(data.get("client_secret", "")),
                webbrowser.open,
                self.hub.connection_changed,
            )
        except ConnectorError as error:
            return {"error": str(error)}
        return {"ok": True}

    async def _post_connect_openai(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await asyncio.to_thread(self.hub.connectors.openai.connect, str(data.get("key", "")), str(data.get("model", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        except OSError:
            return {"error": "The key could not be stored safely."}
        self.hub.publish("brain", {})
        return {"ok": True}

    async def _post_remove_openai(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.settings.openai_brain:
            return {"error": "Choose another brain first."}
        self.hub.connectors.openai.disconnect()
        self.hub.publish("brain", {})
        return {"ok": True}

    async def _post_connect_unbound(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await asyncio.to_thread(self.hub.connectors.abliteration.connect, str(data.get("key", "")), str(data.get("model", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        except OSError:
            return {"error": "The key could not be stored safely."}
        self.hub.publish("brain", {})
        return {"ok": True}

    async def _post_unbound_pin(self, data: dict[str, Any]) -> dict[str, Any]:
        problem = self.hub.set_pin(str(data.get("pin", "")), str(data.get("current", "")))
        if problem:
            return {"error": problem}
        self.hub.publish("brain", {})
        return {"ok": True}

    async def _post_remove_unbound(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.settings.brain == "abliteration":
            return {"error": "Choose another brain first."}
        self.hub.connectors.abliteration.disconnect()
        self.hub.publish("brain", {})
        return {"ok": True}

    async def _post_connect_outlook(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}

        def finished(problem: str | None) -> None:
            self.hub.loop.call_soon_threadsafe(self.hub.connection_changed, problem)

        try:
            await asyncio.to_thread(self.hub.connectors.outlook.begin_sign_in, str(data.get("client_id", "")), webbrowser.open, finished)
        except ConnectorError as error:
            return {"error": str(error)}
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_connect_spotify(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await self.hub.connectors.spotify.begin_sign_in(
                str(data.get("client_id", "")), webbrowser.open, self.hub.connection_changed
            )
        except ConnectorError as error:
            return {"error": str(error)}
        return {"ok": True}

    async def _post_connect_github(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await asyncio.to_thread(self.hub.connectors.github.connect, str(data.get("token", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        except OSError:
            return {"error": "The token could not be stored safely."}
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_connect_home(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await asyncio.to_thread(self.hub.connectors.home.connect, str(data.get("url", "")), str(data.get("token", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        except OSError:
            return {"error": "The token could not be stored safely."}
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_add_folder(self, data: dict[str, Any]) -> dict[str, Any]:
        try:
            self.hub.connectors.files.add(str(data.get("path", "")))
        except (ConnectorError, OSError) as error:
            return {"error": str(error) if isinstance(error, ConnectorError) else "That folder cannot be used."}
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_remove_folder(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.connectors.files.remove(str(data.get("path", "")))
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_add_watch(self, data: dict[str, Any]) -> dict[str, Any]:
        try:
            await asyncio.to_thread(self.hub.connectors.watches.add, str(data.get("url", "")), str(data.get("words", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_remove_watch(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.connectors.watches.remove(str(data.get("url", "")))
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_disconnect(self, data: dict[str, Any]) -> dict[str, Any]:
        found = {item.id: item for item in self.hub.connectors.items}.get(str(data.get("id", "")))
        if found is None or not hasattr(found, "disconnect"):
            return {"error": "Unknown connection."}
        found.disconnect()
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_brain(self, data: dict[str, Any]) -> dict[str, Any]:
        problem = await self.hub.set_brain(str(data.get("name", "")), str(data.get("pin", "")))
        return {"error": problem} if problem else {"ok": True}

    async def _post_world(self, data: dict[str, Any]) -> dict[str, Any]:
        layer = str(data.get("layer", ""))
        world = self.hub.world
        world.looked_at()
        if layer not in world.sources:
            return {"error": "Unknown layer."}
        return world.snapshot(layer)

    async def _post_spotify(self, data: dict[str, Any]) -> dict[str, Any]:
        return await self.hub.spotify_action(data)

    async def _post_refresh_situation(self, _data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.lock.active:
            return {"error": "IRIS is paused."}
        self.hub.start_situation_refresh()
        return {"ok": True}

    async def _post_backup(self, _data: dict[str, Any]) -> dict[str, Any]:
        return {"ok": True, "file": await self.hub.make_backup()}

    async def _post_replay(self, _data: dict[str, Any]) -> dict[str, Any]:
        return {"ok": True, "turns": self.hub.replay()}

    async def _post_search(self, data: dict[str, Any]) -> dict[str, Any]:
        words = str(data.get("words", "")).strip()[:200]
        return {"ok": True, "found": self.hub.memory.journal_search(words, "local") if words else []}

    async def _post_knowledge_update(self, _data: dict[str, Any]) -> dict[str, Any]:
        connectors = self.hub.connectors
        if self.hub.lock.active:
            return {"error": "IRIS is paused."}
        if connectors.knowledge.running:
            return {"error": "The index is already updating."}

        async def run() -> None:
            try:
                note = await asyncio.to_thread(connectors.knowledge.update)
            except (ConnectorError, OSError) as error:
                note = str(error) if isinstance(error, ConnectorError) else "The index could not be updated."
            self.hub.publish("notice", {"text": note})
            self.hub.publish("panels", self.hub.panels())

        task = asyncio.create_task(run())
        self.background.add(task)
        task.add_done_callback(self.background.discard)
        self.hub.publish("panels", self.hub.panels())
        return {"ok": True}

    async def _post_routine_add(self, data: dict[str, Any]) -> dict[str, Any]:
        days = data.get("days")
        try:
            self.hub.routines.add(
                str(data.get("name", "")),
                str(data.get("time", "")),
                [int(day) for day in days] if isinstance(days, list) else [],
                str(data.get("request", "")),
            )
        except RoutineError as error:
            return {"error": str(error)}
        except (TypeError, ValueError):
            return {"error": "Choose at least one day."}
        self.hub.publish("panels", self.hub.panels())
        return {"ok": True}

    async def _post_routine_remove(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.routines.remove(str(data.get("id", "")))
        self.hub.publish("panels", self.hub.panels())
        return {"ok": True}

    async def _post_connect_telegram(self, data: dict[str, Any]) -> dict[str, Any]:
        if self.hub.stop.active:
            return {"error": "Clear the emergency stop first."}
        try:
            await asyncio.to_thread(self.hub.connectors.telegram.connect, str(data.get("token", "")))
        except ConnectorError as error:
            return {"error": str(error)}
        except OSError:
            return {"error": "The token could not be stored safely."}
        self.hub.connection_changed()
        return {"ok": True}

    async def _post_suggestion(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.answer_suggestion(str(data.get("fact", "")), data.get("keep") is True)
        return {"ok": True}

    async def _post_profile(self, data: dict[str, Any]) -> dict[str, Any]:
        self.hub.save_profile(str(data.get("text", "")))
        return {"ok": True}

    async def _post_verify(self, _data: dict[str, Any]) -> dict[str, Any]:
        intact, count = await asyncio.to_thread(self.hub.audit.verify)
        return {"ok": True, "intact": intact, "count": count}
