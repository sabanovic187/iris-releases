"""Connects the screen to IRIS. All of this runs on one event loop."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import secrets
import time
import threading
import dataclasses
import json
import re
import platform
import uuid
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from iris.pod.pods import Pods
from iris.agent import Agent, budget_problem, forget_session, idle_too_long, wants_smart
from iris.audit import AuditLog, redact
from iris.backup import make_backup
from iris.cards import TopicCards
from iris import security
from iris.devices import PairedDevices
from iris.connectors.network import local_address
from iris.cli import handle_command
from iris.config import Settings, read_raw, save_api_key, save_owner, setup_needed
from iris.update import CHANNEL, UpdateError, Updater, current_version, is_development
from iris.connectors.telegram import SAFE_COMMANDS
from iris.connectors.base import READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, call_json, require_text
from iris.connectors.registry import Connectors
from iris.gate import ToolGate, approval_preview
from iris.memory import Memory
from iris.openai_bridge import Bridge
from iris.monitors import Monitors
from iris.monitor import Monitor, build_briefing, build_checks, recent_alerts
from iris.policy import CONNECTOR_PREFIX, Policy
from iris.usage import estimate, price_table
from iris.proactive import DEFAULTS as PROACTIVE_DEFAULTS, Notice, Proactive, add_alert, in_quiet_hours, overview_text, parse_clock
from iris.projects import TaskManager
from iris.routines import RoutineError, Routines
from iris import quick
from iris.situation import build_situation
from iris.world import World
from iris.skills import Skills
from iris.stop import ControlLock, EmergencyStop
from iris.jobs import Jobs, job_tools
from iris.scenes import SceneError, Scenes
from iris.task_tools import BackgroundTasks, build_task_server
from iris.voice.shared import SpeechTools, decode_audio, encode_voice_note
from iris.ui.metrics import SystemReader
from iris.ui.voice_options import STATE_KEY, clean_change

APPROVAL_TIMEOUT_SECONDS = 3000
MAX_HISTORY = 200
SCHEDULE_REFRESH_SECONDS = 300
BRAINS = ("claude", "local", "openai", "abliteration")
UNBOUND = "abliteration"  # conversation only: no tools, no memory, never picked by Auto
UNBOUND_ONLY_TALK = "Unbound mode is conversation only. Choose another brain for that."
PIN_TRIES = 5
PIN_LOCK_SECONDS = 300
PIN_ROUNDS = 200_000
UNBOUND_IDLE_MINUTES = 20  # Unbound locks itself after this long without a message
BRAIN_CHOICES = (*BRAINS, "auto")
FASTEST_FIRST = ("claude", "openai", "local")
ACK_SECONDS = 1.5
SECURITY_CHECK_SECONDS = 3600
SECURITY_EVERY_SECONDS = 7 * 24 * 3600
COMPUTER_ONLY_TOOLS = ("Bash", "mcp__windows__")
MIN_SPOKEN_LINE = 18
MAX_LIVE_SPEECH = 1200
LOCAL_KEEP_SECONDS = 600
LOCAL_TOOLS = frozenset({
    "spotify_now", "spotify_search", "spotify_play", "spotify_control", "situation_read", "situation_show",
    "memory_search", "memory_remember", "memory_suggest", "journal_search", "journal_day", "scene_list", "scene_run",
    "knowledge_search", "document_read", "files_list",
    "files_search", "files_read", "calendar_upcoming", "gmail_search", "gmail_read", "currency_convert",
    "home_devices", "home_control", "skill_list", "skill_read", "ask_openai",
})
GLOBE_LAYERS = ("flights", "military", "satellites", "cables", "quakes", "events", "news")
GLOBE_MODES = ("normal", "night", "thermal", "crt")
WORLD_CHECK_SECONDS = 15
MUSIC_SETTLE_SECONDS = 0.3
MUSIC_RETRY_SECONDS = 0.7
WATCH_CHECK_SECONDS = 300
ROUTINE_CHECK_SECONDS = 30
TELEGRAM_IDLE_SECONDS = 5
VOICE_NOTE_SECONDS = 300
VOICE_REPLY_CHARACTERS = 1500
MAX_SUGGESTIONS = 50
MAX_PROFILE = 4000
PROACTIVE_CHECK_SECONDS = 120
OVERVIEW_AFTER_START_SECONDS = 20  # time for the weather to load first
SITUATION_REFRESH_SECONDS = 900
IMAGE_CHECK_SECONDS = 60
DEFAULT_PLACE = {"place": "", "lat": 0.0, "lon": 0.0, "news_feeds": []}
TEST_COMMAND = {"command": "echo approval test"}

LABELS = {
    "user_message": "You sent a message",
    "turn_finished": "Finished a reply",
    "session_start": "Conversation opened",
    "session_end": "Conversation closed",
    "emergency_stop": "Emergency stop interrupted the work",
    "emergency_stop_set": "Emergency stop turned on",
    "emergency_stop_cleared": "Emergency stop cleared",
    "connection_changed": "A connection changed",
    "brain_changed": "The brain changed",
    "backup_made": "Backup made",
    "control_taken": "You took control",
    "control_returned": "You gave back control",
    "suspicious_content": "Suspicious outside text was flagged",
    "profile_changed": "Your profile changed",
    "control_interrupted": "Taking control interrupted the work",
}



def _day(value: Any) -> str:
    """A date like 2026-11-24, or "" when none was given or it does not look like one."""
    text = str(value or "").strip()[:10]
    return text if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text) else ""

class Busy(Exception):
    """IRIS is already answering."""


class LiveAudit(AuditLog):
    """Writes the audit log and tells the screen about each entry."""

    listener: Callable[[str, dict[str, Any]], None] | None = None

    def write(self, event: str, **fields: Any) -> None:
        super().write(event, **fields)
        if self.listener:
            self.listener(event, fields)


def describe(entry: dict[str, Any]) -> dict[str, Any] | None:
    """Turn an audit entry into one line for the screen."""
    event = entry.get("event", "")
    if event == "tool_decision":
        tool = str(entry.get("tool", "a tool")).removeprefix("mcp__").replace("__", " ")
        allowed = bool(entry.get("allowed"))
        return {
            "time": entry.get("time"),
            "text": f"{'Allowed' if allowed else 'Refused'}: {tool}",
            "detail": str(entry.get("reason", "")),
            "tone": "ok" if allowed else "warn",
        }
    if event in LABELS:
        detail = ""
        if event == "turn_finished" and entry.get("cost_usd") is not None:
            detail = f"${float(entry['cost_usd']):.4f}"
        tone = "bad" if event.startswith("emergency_stop") else "plain"
        return {"time": entry.get("time"), "text": LABELS[event], "detail": detail, "tone": tone}
    return None


class Hub:
    def __init__(
        self,
        settings: Settings,
        memory: Memory,
        audit: LiveAudit,
        stop: EmergencyStop,
        connectors: Connectors | None = None,
    ) -> None:
        self.connectors = connectors
        self.routines = Routines(settings.data_dir / "routines.json")
        self.situation: dict[str, Any] = {}
        self.world = World(settings.data_dir / "world")
        self.refreshing = False
        self.schedule: list[dict[str, str]] = []
        saved_brain = memory.get_state("brain")
        if saved_brain == UNBOUND:  # Unbound always needs the PIN again after a restart
            saved_brain = memory.get_state("before_unbound") or "auto"
            memory.set_state("brain", saved_brain)
        self.auto_brain = saved_brain == "auto"
        if saved_brain in BRAINS:
            settings = dataclasses.replace(settings, brain=saved_brain)
        self.bridge: Bridge | None = None
        if connectors:
            self.bridge = Bridge(lambda: connectors.vault.load("openai"), connectors.openai.api)
            settings = dataclasses.replace(settings, bridge_url=self.bridge.url, bridge_token=self.bridge.token)
        self.settings = settings
        self.memory = memory
        self.connectors = connectors
        if self.auto_brain:
            self.settings = dataclasses.replace(settings, brain=self._fastest_brain())
            settings = self.settings
        self.audit = audit
        self.stop = stop
        self.lock = ControlLock(stop)
        self.loop = asyncio.get_running_loop()
        self.started = self.loop.time()
        self.subscribers: set[asyncio.Queue[str]] = set()
        self.pending: dict[str, dict[str, Any]] = {}
        self.history: deque[dict[str, Any]] = deque(maxlen=MAX_HISTORY)
        self.busy = False
        self.turn_phase: str | None = None
        self.voice_phase: str | None = None
        self.voice_status = "off"
        self.voice_note = ""
        self.speak_replies = False
        self.voice: Any = None
        self.agent: Agent | None = None
        self.agent_tools: tuple[str, ...] = ()
        self.last_spoken = ""
        self.live_speech = False
        self.phone_messages: set[asyncio.Task[None]] = set()
        self.was_stopped = stop.active
        self.devices = PairedDevices(settings.data_dir / "devices.json")
        self.pods = Pods(settings.data_dir / "pods.json")
        self.yara = security.YaraGuard(settings.root / "tools" / "yara-rules", settings.data_dir / "security")
        self.security = security.SecurityCheck(settings.root, settings.data_dir, settings.workspace, self.yara)
        self.cards = TopicCards(self.publish, lambda: self.memory.get_state("cards_off") != "1")
        self.scenes = Scenes(settings.data_dir / "scenes.json")
        if connectors:
            self.skills = Skills(settings.root / "skills")
            connectors.extra_tools = (
                self.cards.tools()
                + security.tools(self.security)
                + self._memory_tools()
                + self._globe_tools()
                + self._routine_tools()
                + self._scene_tools()
                + self.skills.tools()
                + Monitors(settings.data_dir / "monitors").tools()
            )
        self.speech = SpeechTools(self)
        self.tasks = TaskManager(settings, memory, audit, self.lock, self._approve)
        self.jobs = Jobs(
            settings, memory, audit, self.lock, self._approve, self._job_finished,
            servers=lambda: self.connectors.server() if self.connectors else {},
            risks=lambda: self.connectors.risks() if self.connectors else None,
        )
        self.runner = BackgroundTasks(self.tasks, self._announce)
        self.gate = self._new_gate()
        raw = read_raw(settings.root)
        self.monitor_config = raw["monitor"]
        self.place = {**DEFAULT_PLACE, **raw.get("situation", {})}
        self.proactive_config = {**PROACTIVE_DEFAULTS, **raw.get("proactive", {})}
        self.prices = price_table(raw.get("prices", {}))
        self.unbound_idle = float(raw.get("unbound", {}).get("idle_minutes", UNBOUND_IDLE_MINUTES)) * 60
        self.unbound_last = 0.0
        self.restart_wanted = asyncio.Event()
        self.updater = Updater(settings.root, str(raw.get("update", {}).get("channel", CHANNEL)))
        self.update = {"available": None, "notes": "", "busy": False, "problem": "", "checked": ""}
        self.pending_release: Any = None
        self.restart_wanted = asyncio.Event()
        self.updater = Updater(settings.root, str(raw.get("update", {}).get("channel", CHANNEL)))
        self.update = {"available": None, "notes": "", "busy": False, "problem": "", "checked": ""}
        self.pin_failures = 0
        self.pin_locked_until = 0.0
        self.quiet = memory.get_state("quiet") == "1"
        self.overview_task: asyncio.Task[None] | None = None
        self.reader = SystemReader(list(self.monitor_config["disks"]))
        self.reader.read()
        self.readings: dict[str, Any] = {}
        self.monitor = Monitor(
            build_checks(self.monitor_config),
            settings.data_dir / "alerts.jsonl",
            lambda _text: self.loop.call_soon_threadsafe(self._publish_panels),
        )
        self.proactive: Proactive | None = None
        if connectors:
            connectors.media.blocked = lambda: self.lock.active
            connectors.images.blocked = lambda: self.lock.active
            connectors.network.blocked = lambda: self.lock.active
            connectors.browser.blocked = lambda: self.lock.active
            connectors.openai.blocked = lambda: self.lock.active
            connectors.local_agent.blocked = lambda: self.lock.active
            connectors.local_agent.url = settings.ollama_url
            connectors.local_agent.model = settings.ollama_model
            connectors.knowledge.blocked = lambda: self.lock.active
            connectors.knowledge.refresh_count()
            connectors.on_suspicious = self._note_suspicious
            connectors.openai.on_usage = lambda model, i, o: self._usage_from_thread("openai", model, i, o)
            connectors.abliteration.on_usage = lambda model, i, o: self._usage_from_thread("unbound", model, i, o)
            if self.bridge:
                self.bridge.on_usage = lambda model, i, o: self._usage_from_thread("openai", model, i, o)
            self.proactive = Proactive(
                connectors.google,
                settings.data_dir / "connectors" / "seen.json",
                settings.data_dir / "alerts.jsonl",
                remind=timedelta(minutes=float(self.proactive_config["remind_minutes"])),
            )
        for role, text, created in memory.recent_messages():
            self.history.append({"id": uuid.uuid4().hex, "role": role, "text": text, "time": created})
        audit.listener = self._on_audit

    def _new_gate(self) -> ToolGate:
        risks = self.connectors.risks() if self.connectors else None
        if risks and self.settings.openai_brain:
            risks["ask_openai"] = "read"  # the conversation is already with OpenAI
        policy = Policy(
            self.settings.workspace,
            self.settings.level,
            self.settings.allowed_apps,
            connector_risks=risks,
            mcp_servers=self.settings.mcp_servers,
        )
        return ToolGate(policy, self.audit, self.lock, self._approve, file_check=self._file_rules)

    def _file_rules(self, tool: str, args: dict[str, Any]) -> list[str]:
        path = security.file_in_call(tool, args, self.settings.workspace)
        return self.yara.scan(path) if path else []

    async def run_security_check(self, announce: bool = True) -> dict[str, Any]:
        report = await asyncio.to_thread(self.security.check)
        self.publish("security", {"summary": security.summary(report)})
        serious = [item for item in report["findings"] if item["severity"] == "CRITICAL" or item["fixed"]]
        if announce and (serious or report["files"]):
            self._tell([f"Security check: {len(serious)} known vulnerabilities to look at, and {len(report['files'])} suspicious files. Details are in Settings."])
        return report

    def _security_due(self) -> bool:
        if self.security.running or not (self.yara.available() or security.find_trivy(self.settings.root)):
            return False
        last = self.security.last()
        return not last or time.time() - float(last.get("time", 0)) > SECURITY_EVERY_SECONDS

    # Screen updates

    def subscribe(self) -> asyncio.Queue[str]:
        queue: asyncio.Queue[str] = asyncio.Queue(maxsize=500)
        self.subscribers.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue[str]) -> None:
        self.subscribers.discard(queue)

    def publish(self, kind: str, data: Any) -> None:
        text = f"event: {kind}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
        for queue in list(self.subscribers):
            try:
                queue.put_nowait(text)
            except asyncio.QueueFull:
                self.subscribers.discard(queue)

    def _publish_phase(self) -> None:
        self.publish("phase", {"phase": self.phase()})

    def _publish_panels(self) -> None:
        self.publish("panels", self.panels())

    def _on_audit(self, event: str, fields: dict[str, Any]) -> None:
        def update() -> None:
            if event == "tool_decision" and fields.get("allowed") and self.turn_phase:
                self.turn_phase = "working"
                self._publish_phase()
            self._publish_panels()

        self.loop.call_soon_threadsafe(update)

    def phase(self) -> str:
        if self.stop.active:
            return "stopped"
        if self.lock.owner_has_control:
            return "owner"
        if self.pending:
            return "needs_you"
        return self.voice_phase or self.turn_phase or "waiting"

    def set_voice(self, phase: str | None) -> None:
        self.voice_phase = phase
        self._publish_phase()

    def set_voice_status(self, status: str, note: str = "") -> None:
        self.voice_status = status
        self.voice_note = note
        if status != "on":
            self.voice_phase = None
        self.publish("voice", self.voice_state())
        self._publish_phase()

    def switch_voice(self, on: bool) -> str | None:
        if not on:
            self.voice.shut_down()
            return None
        problem = self._voice_blocked()
        if problem:
            return problem
        self.voice.turn_on()
        return None

    def _voice_blocked(self) -> str | None:
        if self.stop.active:
            return "Clear the emergency stop first."
        if self.lock.owner_has_control:
            return "Give back control first."
        return None

    def talk(self) -> str | None:
        problem = self._voice_blocked()
        if problem:
            return problem
        self.voice.turn_on(listen=True)
        return None

    async def voice_screen(self) -> dict[str, Any]:
        return await asyncio.to_thread(self.voice.options)

    async def change_voice(self, data: dict[str, Any]) -> str | None:
        current = await self.voice_screen()
        try:
            change = clean_change(data, current["microphones"], current["voices"])
        except ValueError as error:
            return str(error)
        self.voice.saved = {**self.voice.saved, **change}
        self.memory.set_state(STATE_KEY, json.dumps(self.voice.saved))
        return None

    def voice_state(self) -> dict[str, Any]:
        return {"status": self.voice_status, "note": self.voice_note, "speak": self.speak_replies}

    def _say_in_chat(self, role: str, text: str, message_id: str | None = None) -> None:
        message = {
            "id": message_id or uuid.uuid4().hex,
            "role": role,
            "text": text,
            "time": datetime.now(timezone.utc).isoformat(),
        }
        if self.settings.brain == UNBOUND:
            message["unbound"] = True  # shown while Unbound is open, never written to memory
        else:
            self.memory.add_message(role, text, self.settings.brain)
        self.history.append(message)
        self.publish("message", message)

    def _job_finished(self, job: dict[str, Any]) -> None:
        if job["status"] == "done":
            text = f"Background job {job['id']} is done. {job['summary']}"
        elif job["status"] == "stopped":
            text = f"Background job {job['id']} was stopped."
        else:
            text = f"Background job {job['id']} did not finish. {job['summary']}"
        self._announce(text)
        telegram = self.connectors.telegram if self.connectors else None
        if telegram and telegram.status().get("connected"):
            report = self.jobs.report(job["id"]) if job["status"] == "done" else ""
            message = f"{text}\n\n{report}".strip()[:3900]
            threading.Thread(target=telegram.send, args=(message,), daemon=True).start()

    def _announce(self, text: str) -> None:
        self._say_in_chat("iris", text)
        self._publish_panels()
        if self.voice and self.voice_status == "on":
            self.voice.speak(text)

    # Brain

    @property
    def test_mode(self) -> bool:
        if self.settings.brain == UNBOUND:
            return not self._unbound_connected()
        if self.settings.openai_brain:
            return not self._openai_connected()
        return not self.settings.brain_ready

    def _unbound_connected(self) -> bool:
        return bool(self.connectors and self.connectors.abliteration.status()["connected"])

    def _openai_connected(self) -> bool:
        return bool(self.connectors and self.connectors.openai.status()["connected"])

    def _brain_label(self) -> str:
        settings = self.settings
        if settings.brain == UNBOUND:
            return f"Unbound: {self.connectors.abliteration.status()['account']}" if self._unbound_connected() else "Unbound"
        if settings.local_brain:
            return f"Local: {settings.ollama_model}"
        if settings.openai_brain:
            return f"OpenAI: {self.connectors.openai.status()['account']}" if self._openai_connected() else "OpenAI"
        return settings.model

    def _check_local_brain(self) -> str | None:
        try:
            found = call_json("GET", f"{self.settings.ollama_url}/api/tags")
        except ConnectorError:
            return "Ollama is not running. Start it, then try again."
        names = {item.get("name", "") for item in found.get("models", [])}
        wanted = self.settings.ollama_model
        if wanted not in names and f"{wanted}:latest" not in names:
            return "The local model is missing. Run scripts\\setup-ollama.ps1."
        return None

    def _brain_ready(self, name: str) -> bool:
        if name == "claude":
            return bool(self.settings.api_key)
        if name == UNBOUND:
            return self._unbound_connected()
        return self._openai_connected() if name == "openai" else True

    def _fastest_brain(self) -> str:
        return next(name for name in FASTEST_FIRST if self._brain_ready(name))

    def _next_brain(self) -> str | None:
        order = [name for name in FASTEST_FIRST if self._brain_ready(name)]
        place = order.index(self.settings.brain) + 1 if self.settings.brain in order else 0
        return order[place] if place < len(order) else None

    async def _use_brain(self, name: str) -> None:
        await self._drop_agent()
        self.settings = dataclasses.replace(self.settings, brain=name)
        self.tasks.settings = self.settings
        self.audit.write("brain_changed", brain=name)
        self.publish("brain", {})

    def _keep_local_loaded(self) -> None:
        """A loaded model answers many seconds sooner than one that must first fill the graphics card."""
        try:
            call_json("POST", f"{self.settings.ollama_url}/api/generate", data={"model": self.settings.ollama_model, "keep_alive": "30m"}, timeout=60)
        except ConnectorError:
            pass

    async def set_brain(self, name: str, pin: str = "") -> str | None:
        if name not in BRAIN_CHOICES:
            return "Unknown brain."
        if self.busy:
            return "Wait for the current reply to finish."
        if name == UNBOUND and self.settings.brain != UNBOUND:
            problem = self.check_pin(pin)
            if problem:
                return problem
        if self.settings.brain == UNBOUND and name != UNBOUND:
            self._close_unbound()
        if name == "auto":
            self.auto_brain = True
            self.memory.set_state("brain", "auto")
            await self._use_brain(self._fastest_brain())
            return None
        if name == "local":
            problem = await asyncio.to_thread(self._check_local_brain)
            if problem:
                return problem
        if name == "openai" and not self._openai_connected():
            return "Add an OpenAI key in Settings first."
        if name == "claude" and not self.settings.api_key:
            return "Add a Claude key to the .env file first."
        if name == UNBOUND and not self._unbound_connected():
            return "Add the Unbound key in Settings first."
        if name == UNBOUND and self.settings.brain != UNBOUND:
            self.memory.set_state("before_unbound", "auto" if self.auto_brain else self.settings.brain)
            self.unbound_last = self.loop.time()
        self.auto_brain = False
        self.memory.set_state("brain", name)
        await self._use_brain(name)
        if name == "local":
            self.background_keep = asyncio.create_task(asyncio.to_thread(self._keep_local_loaded))
        return None

    # Unbound PIN and lock

    @staticmethod
    def _pin_hash(pin: str, salt: bytes) -> str:
        return hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt, PIN_ROUNDS).hex()

    def has_pin(self) -> bool:
        return bool(self.memory.get_state("unbound_pin"))

    def check_pin(self, pin: str) -> str | None:
        """None when the PIN is right. Five wrong tries lock Unbound for five minutes."""
        saved = self.memory.get_state("unbound_pin")
        if not saved:
            return "Set an Unbound PIN in Settings on the computer first."
        now = self.loop.time()
        if now < self.pin_locked_until:
            return f"Too many wrong PINs. Try again in {int(self.pin_locked_until - now) // 60 + 1} minutes."
        if not pin:
            return "PIN needed."
        salt_hex, wanted = saved.split("$", 1)
        if hmac.compare_digest(self._pin_hash(str(pin), bytes.fromhex(salt_hex)), wanted):
            self.pin_failures = 0
            return None
        self.pin_failures += 1
        self.audit.write("unbound_pin_refused", tries=self.pin_failures)
        if self.pin_failures >= PIN_TRIES:
            self.pin_failures = 0
            self.pin_locked_until = now + PIN_LOCK_SECONDS
            return "Too many wrong PINs. Unbound is locked for five minutes."
        return "Wrong PIN."

    def set_pin(self, new: str, current: str = "") -> str | None:
        new = str(new).strip()
        if not new.isdigit() or not 4 <= len(new) <= 8:
            return "The PIN must be 4 to 8 digits."
        if self.has_pin():
            problem = self.check_pin(current)
            if problem:
                return "The current PIN is wrong." if problem == "Wrong PIN." else problem
        salt = secrets.token_bytes(16)
        self.memory.set_state("unbound_pin", f"{salt.hex()}${self._pin_hash(new, salt)}")
        self.audit.write("unbound_pin_set")
        return None

    def _close_unbound(self) -> None:
        """Leaving Unbound wipes its conversation from the screen and from the model's context."""
        if self.connectors:
            self.connectors.abliteration.forget()
        self.history = deque((item for item in self.history if not item.get("unbound")), maxlen=MAX_HISTORY)
        self.publish("cleared", {})

    async def lock_unbound(self, reason: str) -> None:
        if self.settings.brain != UNBOUND or self.busy:
            return
        back = self.memory.get_state("before_unbound") or "auto"
        self._close_unbound()
        if back == "auto" or not self._brain_ready(back):
            self.auto_brain = True
            self.memory.set_state("brain", "auto")
            await self._use_brain(self._fastest_brain())
        else:
            self.memory.set_state("brain", back)
            await self._use_brain(back)
        self.audit.write("unbound_locked", reason=reason)

    # Spending

    def _usage_from_thread(self, provider: str, model: str, input_tokens: int, output_tokens: int) -> None:
        cost = estimate(model, input_tokens, output_tokens, self.prices)
        def store() -> None:
            self.memory.add_usage(provider, model, input_tokens, output_tokens, cost)
            self._publish_panels()
        self.loop.call_soon_threadsafe(store)

    def spending(self) -> dict[str, Any]:
        return {
            "claude": {"usd": self.memory.month_spending(), "limit": self.settings.max_usd_per_month},
            "openai": self.memory.month_usage("openai"),
            "unbound": self.memory.month_usage("unbound"),
        }

    # What the screen shows

    def activity(self, limit: int = 60) -> list[dict[str, Any]]:
        path = self.audit.path
        if not path.exists():
            return []
        with path.open(encoding="utf-8") as handle:
            lines = deque(handle, maxlen=limit * 3)
        found = []
        for line in reversed(lines):
            try:
                item = describe(json.loads(line))
            except ValueError:
                continue
            if item:
                found.append(item)
        return found[:limit]

    def panels(self) -> dict[str, Any]:
        settings = self.settings
        return {
            "tasks": self.tasks.task_rows(8),
            "jobs": self.jobs.rows(6),
            "alerts": recent_alerts(settings.data_dir / "alerts.jsonl"),
            "activity": self.activity(30),
            "spent": self.memory.month_spending(),
            "limit": settings.max_usd_per_month,
            "spending": self.spending(),
            "approvals": [item["public"] for item in self.pending.values()],
            "facts": [{"id": fact[0], "text": fact[1]} for fact in self.memory.facts()],
            "connections": self.connectors.status() if self.connectors else [],
            "schedule": self.schedule,
            "routines": self.routines.items(),
            "suggestions": self.suggestions(),
            "profile": self.memory.get_state("profile") or "",
        }

    def snapshot(self) -> dict[str, Any]:
        settings = self.settings
        return {
            "phase": self.phase(),
            "test_mode": self.test_mode,
            "owner_has_control": self.lock.owner_has_control,
            "brain": {
                "name": "auto" if self.auto_brain else settings.brain,
                "label": f"Auto: {self._brain_label()}" if self.auto_brain else self._brain_label(),
            },
            "openai": self.connectors.openai.status() if self.connectors else {"connected": False},
            "unbound": {
                **(self.connectors.abliteration.status() if self.connectors else {"connected": False}),
                "pin": self.has_pin(),
            },
            "history": list(self.history),
            "cards": self.cards.current,
            "tablet": self.tablet_state(),
            "scenes": self.scenes.listing(),
            "setup": self.setup_state(),
            "update": self.update_state(),
            "pod": self.pod_state(),
            "security": {"summary": security.summary(self.security.last()), "running": self.security.running},
            "cards_on": self.memory.get_state("cards_off") != "1",
            "system": self.readings,
            "situation": self.situation,
            "world": self.world.summary(),
            "voice": self.voice_state(),
            "quiet": self.quiet_state(),
            "settings": {
                "model": settings.model,
                "smart_model": settings.smart_model,
                "ollama_model": settings.ollama_model,
                "level": settings.level,
                "max_usd_per_message": settings.max_usd_per_message,
                "max_usd_per_task": settings.max_usd_per_task,
                "workspace": str(settings.workspace),
                "allowed_apps": list(settings.allowed_apps),
                "skills": self.skills.names() if self.connectors else [],
                "mcp_servers": [server["name"] for server in settings.mcp_servers],
            },
            **self.panels(),
        }

    # Approvals

    async def _approve(self, tool: str, args: dict[str, Any], reason: str) -> bool:
        preview, cut = approval_preview(args)
        request_id = uuid.uuid4().hex
        future: asyncio.Future[bool] = self.loop.create_future()
        self.pending[request_id] = {
            "future": future,
            "public": {"id": request_id, "tool": tool, "reason": reason, "preview": preview, "cut": cut},
        }
        self._publish_panels()
        self._publish_phase()
        if self.voice and self.voice_status == "on":
            self.voice.speak("I need your approval on the screen.")
        phone = asyncio.create_task(self._ask_phone(request_id, tool, reason, preview))
        answer = False
        try:
            answer = await asyncio.wait_for(future, APPROVAL_TIMEOUT_SECONDS)
            return answer
        except asyncio.TimeoutError:
            return False  # no answer means no
        finally:
            self.pending.pop(request_id, None)
            self._publish_panels()
            self._publish_phase()
            self.phone_task = asyncio.create_task(self._close_phone(phone, tool, answer))

    async def _ask_phone(self, request_id: str, tool: str, reason: str, preview: str) -> int | None:
        """The owner may answer on the phone, but only the computer can allow commands and Windows control."""
        if not self.connectors:
            return None
        may_allow = not tool.startswith(COMPUTER_ONLY_TOOLS)
        where = "" if may_allow else "\n\nThis can be allowed only on your computer."
        text = f"IRIS needs your approval\n{redact(tool.removeprefix(CONNECTOR_PREFIX))}\n{redact(reason)}\n\n{redact(preview)}{where}"
        try:
            return await asyncio.to_thread(self.connectors.telegram.ask_approval, request_id, text, may_allow)
        except (ConnectorError, OSError):
            return None

    async def _close_phone(self, phone: asyncio.Task[int | None], tool: str, allowed: bool) -> None:
        """Take the buttons away once the request is settled, wherever it was answered."""
        message_id = await phone
        if message_id is None:
            return
        word = "Allowed" if allowed else "Declined"
        try:
            await asyncio.to_thread(self.connectors.telegram.close_approval, message_id, f"{word}: {redact(tool.removeprefix(CONNECTOR_PREFIX))}")
        except (ConnectorError, OSError):
            pass

    def decide(self, request_id: str, allow: bool) -> bool:
        item = self.pending.get(request_id)
        if item is None or item["future"].done():
            return False
        item["future"].set_result(bool(allow))
        return True

    def _decline_all(self) -> None:
        for item in self.pending.values():
            if not item["future"].done():
                item["future"].set_result(False)

    # Conversation

    async def send(self, text: str, live_speech: bool = False) -> str:
        """Handle one message and return the reply. With live_speech, sentences are spoken as they are written."""
        text = text.strip()
        if not text:
            return ""
        if self.busy:
            raise Busy()
        self.busy = True
        self.live_speech = live_speech
        self.turn_phase = "thinking"
        self._say_in_chat("you", text)
        self._publish_phase()
        try:
            reply = await self._reply(text)
        except Exception as error:
            await self._drop_agent()
            reply = f"I could not finish that: {type(error).__name__}."
        finally:
            self.busy = False
            self.turn_phase = None
        if reply:
            self._say_in_chat("iris", reply)
        self._publish_phase()
        self._publish_panels()
        if self.loop.time() - self.started > OVERVIEW_AFTER_START_SECONDS:
            self.start_overview()
        return reply

    async def _reply(self, line: str) -> str:
        if line == "/new":
            await self.new_conversation()
            return "New conversation started."
        if line == "/stop":
            self.emergency_stop("owner typed /stop")
            return ""
        if line in ("/quiet", "/quiet on", "/quiet off"):
            self.set_quiet(line != "/quiet off" and (line == "/quiet on" or not self.quiet))
            return "Quiet mode on. I will only speak up for meetings." if self.quiet else "Quiet mode off."
        if self.settings.brain == UNBOUND:
            return await self._ask_unbound(line)
        if line == "/today":
            return self._today()
        if line == "/digest":
            return await self._digest()
        if line == "/system":
            return await self._system_check()
        if line == "/briefing":
            return build_briefing(self.settings, self.memory, self.tasks)
        if line == "/test-approval":
            allowed, reason = await self.gate.check("Bash", dict(TEST_COMMAND), None)
            verdict = "allowed" if allowed else "refused"
            return f"Approval test {verdict}: {reason}. No command was run."
        if line.split(" ")[0] in ("/task", "/continue"):
            if self.lock.active:
                return "IRIS is paused. Give back control or clear the stop first."
            async def work() -> str:
                return await self.tasks.handle_command(line) or "The task ended without a report."

            return self.runner.launch(work)
        task_reply = await self.tasks.handle_command(line)
        if task_reply is not None:
            return task_reply
        if line.startswith("/"):
            return handle_command(line, self.memory, self.stop, self.settings)
        if self.stop.active:
            return "Emergency stop is active. Clear it before I continue."
        if self.lock.owner_has_control:
            return "You have control. Give it back before I continue."
        fast = await self._quick(line)
        if fast:
            return fast
        if self.test_mode:
            await asyncio.sleep(0.7)
            return f"Test mode, no Claude key yet. I received: {line}"
        problem = budget_problem(self.settings, self.memory)
        if problem:
            return problem
        return await self._ask_claude(line)

    async def _quick(self, line: str) -> str:
        """Everyday requests are answered here at once. Anything else goes to the brain."""
        scene = self.scenes.match(line) if len(line) <= 40 else None
        if scene:
            return await self.run_scene(scene)
        found = quick.find(line)
        if not found:
            return ""
        now = datetime.now()
        if found.action in ("quiet_on", "quiet_off"):
            self.set_quiet(found.action == "quiet_on")
            return "Quiet mode on. I will only speak up for meetings." if self.quiet else "Quiet mode off."
        if found.action == "time":
            return f"It is {now:%H:%M}, {self.settings.address}."
        if found.action == "date":
            return f"Today is {now:%A, %d %B %Y}."
        if found.action == "weather":
            data = self.situation or {}
            weather = data.get("weather")
            return f"{data['place']}: {round(weather['temperature'])} degrees, {weather['sky'].lower()}." if weather else ""
        spotify = self.connectors.spotify if self.connectors else None
        if not spotify or not spotify.status()["connected"]:
            return ""
        if found.action == "playing":
            state = await self.spotify_action({"action": "state"})
            if state.get("error"):
                return state["error"]
            return f"{state['title']} by {state['artist']}." if state.get("title") else "Nothing is playing."
        steps = {"pause": "pause", "resume": "resume", "next": "next", "previous": "previous"}
        if found.action in ("quieter", "louder", "volume"):
            level = found.value
            if found.action != "volume":
                state = await self.spotify_action({"action": "state"})
                now_level = state.get("volume")
                if now_level is None:
                    return "I cannot change the volume on that device."
                level = max(0, min(100, now_level + (10 if found.action == "louder" else -10)))
            result = await self.spotify_action({"action": "volume", "volume": level})
            return result.get("error") or f"Volume {level}."
        result = await self.spotify_action({"action": steps[found.action]})
        if result.get("error"):
            return result["error"]
        self.publish("music", result)
        return {"pause": "Paused.", "resume": "Playing.", "next": "Next.", "previous": "Going back."}[found.action]

    async def _start_agent(self) -> None:
        extra: dict[str, Any] = {}
        if self.settings.local_brain:
            if self.connectors:
                extra.update(self.connectors.server(LOCAL_TOOLS))
        else:
            self.jobs.settings = self.settings  # the brain or key may have changed
            extra = build_task_server(self.tasks, self.runner, job_tools(self.jobs))
            if self.connectors:
                extra.update(self.connectors.server())
        key = self._session_key()
        self.agent_tools = self.connectors.active_signature() if self.connectors else ()
        agent = Agent(
            self.settings, self.memory, self.audit, self.lock, self._new_gate(), session_key=key, extra_mcp=extra
        )
        await agent.start()
        self.agent = agent

    def tablet_address(self) -> str:
        try:
            return f"http://{local_address()}:{self.settings.tablet_port}/pair"
        except OSError:
            return ""

    # Updates from signed releases

    def update_state(self) -> dict[str, Any]:
        return {
            "version": current_version(self.settings.root),
            "development": is_development(self.settings.root),
            **self.update,
        }

    async def check_update(self) -> None:
        if is_development(self.settings.root) or self.update["busy"]:
            return
        try:
            release = await asyncio.to_thread(self.updater.available)
            self.pending_release = release
            self.update.update(
                available=release.version if release else None,
                notes=release.notes if release else "",
                problem="",
                checked=datetime.now().strftime("%d.%m. %H:%M"),
            )
        except UpdateError as error:
            self.update.update(problem=str(error))
        self.publish("update", self.update_state())

    async def install_update(self) -> None:
        release = self.pending_release
        if release is None or self.update["busy"] or is_development(self.settings.root):
            return
        self.update.update(busy=True, problem="")
        self.publish("update", self.update_state())
        try:
            package = await asyncio.to_thread(self.updater.download, release)
            await asyncio.to_thread(self.updater.install, package, release)
        except (UpdateError, OSError) as error:
            self.update.update(busy=False, problem=str(error))
            self.audit.write("update_failed", version=release.version, error=str(error)[:200])
            self.publish("update", self.update_state())
            return
        self.audit.write("update_installed", version=release.version)
        self.publish("notice", {"text": f"IRIS {release.version} is installed. Restarting."})
        self.loop.call_later(1.5, self.restart_wanted.set)

    async def run_update_checks(self) -> None:
        """Looks for a new version a minute after start, then twice a day."""
        await asyncio.sleep(60)
        while True:
            await self.check_update()
            await asyncio.sleep(12 * 3600)

    # First start: the owner tells IRIS how to address them and where they live

    def setup_state(self) -> dict[str, Any]:
        return {
            "needed": setup_needed(self.settings.root),
            "address": self.settings.address,
            "place": self.place.get("place", ""),
            "lat": self.place.get("lat"),
            "lon": self.place.get("lon"),
            "has_key": bool(self.settings.api_key),
        }

    async def apply_setup(self, address: str, place: dict[str, Any], key: str) -> None:
        root = self.settings.root
        save_owner(root, "identity", {"address_owner_as": address})
        save_owner(root, "situation", {"place": place["place"], "lat": place["lat"], "lon": place["lon"]})
        if key:
            save_api_key(root, key)
        self.settings = dataclasses.replace(self.settings, address=address, api_key=key or self.settings.api_key)
        self.place.update(place)
        self.audit.write("owner_setup", key_changed=bool(key))
        await self._drop_agent()  # the next reply uses the new name and key
        self.publish("setup", self.setup_state())
        self.start_situation_refresh()

    def pod_address(self) -> str:
        try:
            return f"http://{local_address()}:{self.settings.pod_port}/xiaozhi/ota/"
        except OSError:
            return ""

    def pod_state(self) -> dict[str, Any]:
        enabled = self.settings.pod_enabled
        return {
            "enabled": enabled,
            "address": self.pod_address() if enabled else "",
            "waiting": self.pods.waiting(),
            "pods": self.pods.listing(),
        }

    def pair_pod(self, code: str, name: str) -> dict[str, Any] | None:
        pod = self.pods.pair(code, name or "IRIS Pod")
        if pod:
            self.audit.write("pod_paired", pod=pod["name"])
        return pod

    def remove_pod(self, device: str) -> None:
        self.pods.remove(device)
        self.audit.write("pod_removed")

    def tablet_state(self) -> dict[str, Any]:
        enabled = self.settings.tablet_enabled
        return {
            "enabled": enabled,
            "address": self.tablet_address() if enabled else "",
            "pairing": self.devices.pairing_open(),
            "devices": self.devices.listing(),
        }

    def _session_key(self) -> str:
        return {"local": "local_session_id", "openai": "openai_session_id"}.get(self.settings.brain, "session_id")

    async def _ask_unbound(self, line: str) -> str:
        """Unbound only talks: no commands, no quick actions, no tools, nothing from memory."""
        if line.startswith("/"):
            return UNBOUND_ONLY_TALK
        if self.stop.active:
            return "Emergency stop is active. Clear it before I continue."
        if self.test_mode:
            return "Unbound has no key yet. Add it in Settings."
        self.unbound_last = self.loop.time()
        try:
            text = await asyncio.to_thread(self.connectors.abliteration.chat, line)
        except ConnectorError as error:
            return str(error)
        return text

    async def _ask_claude(self, line: str, may_switch: bool = True) -> str:
        if self.settings.brain == UNBOUND:
            return await self._ask_unbound(line)
        key = self._session_key()
        if idle_too_long(self.memory, key, self.settings.fresh_after_hours):
            await self._drop_agent()
            forget_session(self.memory, key)
            self.audit.write("fresh_conversation", reason="idle")
        elif self.agent is not None and self.connectors and self.connectors.active_signature() != self.agent_tools:
            await self._drop_agent()  # a service was connected or removed; the same conversation continues
        if self.agent is None:
            await self._start_agent()
        parts: list[str] = []
        live = {"id": uuid.uuid4().hex, "buffer": "", "spoken": 0}

        def acknowledge() -> None:
            if self.live_speech and self.voice:
                self.voice.speak(f"One moment, {self.settings.address}.")

        waiting = self.loop.call_later(ACK_SECONDS, acknowledge) if self.live_speech else None

        def speak_finished_lines(everything: bool = False) -> None:
            if not self.live_speech or not self.voice or live["spoken"] >= MAX_LIVE_SPEECH:
                return
            while True:
                found = re.search(r"[.!?:](\s)|\n+", live["buffer"][MIN_SPOKEN_LINE:])
                if not found:
                    break
                end = MIN_SPOKEN_LINE + found.end()
                sentence, live["buffer"] = live["buffer"][:end].strip(), live["buffer"][end:]
                live["spoken"] += len(sentence)
                self.voice.speak(sentence)
            if everything and live["buffer"].strip():
                self.voice.speak(live["buffer"].strip())
                live["buffer"] = ""

        def on_words(text: str) -> None:
            if waiting:
                waiting.cancel()
            live["buffer"] += text
            self.publish("words", {"id": live["id"], "text": text})
            speak_finished_lines()

        def on_text(text: str) -> None:
            parts.append(text)
            speak_finished_lines(everything=True)
            self._say_in_chat("iris", text, live["id"])
            live["id"] = uuid.uuid4().hex

        card_calls = self.cards.calls
        result = await self.agent.ask(line, on_text, on_words, smart=wants_smart(line))
        if parts and self.cards.calls == card_calls and self.cards.from_reply("\n".join(parts), line):
            self.audit.write("cards_from_reply", count=len(self.cards.current["cards"]))
        if waiting:
            waiting.cancel()
        if result and result.is_error:
            next_brain = self._next_brain() if may_switch and self.auto_brain else None
            if next_brain:
                self._say_in_chat("iris", f"That brain failed, so I am trying {next_brain}.")
                await self._use_brain(next_brain)
                return await self._ask_claude(line, may_switch=False)
            return "" if parts else f"I stopped before finishing ({result.subtype})."
        if not parts:
            return "I finished without a written reply."
        self.last_spoken = "" if self.live_speech else " ".join(parts)
        return ""

    async def _drop_agent(self) -> None:
        agent, self.agent = self.agent, None
        if agent:
            try:
                await agent.close()
            except Exception:
                pass

    async def new_conversation(self) -> None:
        await self._drop_agent()
        for key in ("session_id", "local_session_id", "openai_session_id"):
            forget_session(self.memory, key)
        if self.connectors:
            self.connectors.abliteration.forget()
        self.history.clear()
        self.cards.clear()
        self.publish("cleared", {})

    # Memory tools for IRIS

    def _globe_tools(self) -> list[Tool]:
        def show(args: dict[str, Any]) -> str:
            view: dict[str, Any] = {"label": str(args.get("label", ""))[:80]}
            if args.get("lat") is not None and args.get("lon") is not None:
                view["lat"] = max(-90.0, min(float(args["lat"]), 90.0))
                view["lon"] = max(-180.0, min(float(args["lon"]), 180.0))
                view["km"] = max(50.0, min(float(args.get("distance_km") or 4000), 30000.0))
            layers = str(args.get("layers", "")).lower().replace(" ", "")
            if layers:
                view["layers"] = [name for name in layers.split(",") if name in GLOBE_LAYERS]
            if str(args.get("mode", "")).lower() in GLOBE_MODES:
                view["mode"] = str(args["mode"]).lower()
            self.world.looked_at()
            self.publish("globe", view)
            return "The globe is showing that now."

        def read(args: dict[str, Any]) -> str:
            data = self.situation or {}
            word = str(args.get("topic", "")).lower()
            news = [item["title"] for item in data.get("news", []) if word in item["title"].lower()][:25]
            focus = [f"{item['country']}: {item['count']} headlines, {item['crisis']} about crises" for item in data.get("focus", [])[:10]]
            quakes = [f"M{item['mag']} {item['place']}" for item in data.get("quakes", [])[:8]]
            events = [f"{item['kind']}: {item['title']}" for item in data.get("events", [])[:10]]
            summary = self.world.summary()
            markets = [f"{item['name']}: {item['price']}" for item in summary["markets"]]
            parts = {
                "Headlines": news, "Most in the news": focus, "Earthquakes": quakes, "Natural events": events, "Markets": markets,
                "Tracked now": [f"{name}: {count}" for name, count in summary["counts"].items()],
                "Not available": summary["failed"] + data.get("failed", []),
            }
            body = "\n\n".join(f"{title}:\n" + "\n".join(rows) for title, rows in parts.items() if rows)
            return UNTRUSTED_NOTE + (body or "No world data yet.")

        return [
            Tool(
                "situation_show",
                "Control the owner's globe: fly to lat and lon, set distance_km, layers and mode. "
                f"layers is a comma list from {', '.join(GLOBE_LAYERS)}. mode is one of {', '.join(GLOBE_MODES)}. label is a short caption.",
                {"lat": float, "lon": float, "distance_km": float, "layers": str, "mode": str, "label": str},
                READ,
                show,
                on_loop=True,
            ),
            Tool("situation_read", "Read live world data: news, events, markets. topic narrows the headlines.", {"topic": str}, READ, read, on_loop=True),
        ]

    # Music

    async def spotify_action(self, data: dict[str, Any]) -> dict[str, Any]:
        spotify = self.connectors.spotify if self.connectors else None
        if not spotify or not spotify.status()["connected"]:
            return {"connected": False}
        action = str(data.get("action", "state"))
        if action != "state" and self.lock.active:
            return {"error": "IRIS is stopped."}
        tools = {item.name: item for item in spotify.tools()}
        steps: dict[str, Callable[[], Any]] = {
            "pause": lambda: tools["spotify_control"].run({"action": "pause"}),
            "resume": lambda: tools["spotify_control"].run({"action": "resume"}),
            "next": lambda: tools["spotify_control"].run({"action": "next"}),
            "previous": lambda: tools["spotify_control"].run({"action": "previous"}),
            "volume": lambda: tools["spotify_control"].run({"action": "volume", "volume": data.get("volume", 50)}),
            "play": lambda: tools["spotify_play"].run({"uri": data.get("uri", "")}),
            "device": lambda: spotify.use_device(str(data.get("device", ""))),
        }
        try:
            if action == "find":
                return {"found": await asyncio.to_thread(spotify.find, str(data.get("query", "")))}
            if action in steps:
                await asyncio.to_thread(steps[action])
                await asyncio.sleep(MUSIC_SETTLE_SECONDS)
            found = await asyncio.to_thread(spotify.state)
            if action != "state" and not found["title"]:  # Spotify can answer badly just after a command
                await asyncio.sleep(MUSIC_RETRY_SECONDS)
                found = await asyncio.to_thread(spotify.state)
            return found
        except ConnectorError as error:
            return {"connected": True, "error": str(error)}
        except (OSError, ValueError, KeyError):
            return {"connected": True, "error": "Spotify did not answer."}

    def _memory_tools(self) -> list[Tool]:
        def search(args: dict[str, Any]) -> str:
            found = self.memory.search(require_text(args, "words", 200), self.settings.brain)
            return "\n".join(found) or "Nothing found."

        def remember(args: dict[str, Any]) -> str:
            self.memory.remember(require_text(args, "fact", 1000))
            self._publish_panels()
            return "Saved."

        def journal(args: dict[str, Any]) -> str:
            since, until = (_day(args.get(key)) for key in ("since", "until"))
            found = self.memory.journal_search(require_text(args, "words", 300), self.settings.brain, since, until)
            return "\n".join(found) or "Nothing found in the journal."

        def day(args: dict[str, Any]) -> str:
            date = _day(args.get("date"))
            if not date:
                raise ConnectorError("date must look like 2026-11-24.")
            lines = self.memory.journal_day(date, self.settings.brain)
            text = "\n".join(lines)
            return text[-12000:] if text else f"Nothing was said on {date}."

        def decision(args: dict[str, Any]) -> str:
            self.memory.add_decision(require_text(args, "decision", 1000), self.settings.brain)
            return "Written in the journal."

        def suggest(args: dict[str, Any]) -> str:
            fact = redact(require_text(args, "fact", 1000))
            items = self.suggestions()
            if fact not in items and len(items) < MAX_SUGGESTIONS:
                self.memory.set_state("suggestions", json.dumps(items + [fact], ensure_ascii=False))
                self._publish_panels()
            return "Suggested. The owner will decide on the Memory screen."

        return [
            Tool("memory_suggest", "Suggest a fact for the owner to approve.", {"fact": str}, READ, suggest, on_loop=True),
            Tool("memory_search", "Search saved facts and past conversations.", {"words": str}, READ, search, on_loop=True),
            Tool("memory_remember", "Save a fact about the owner.", {"fact": str}, WRITE, remember, on_loop=True),
            Tool(
                "journal_search",
                "Search the journal: every past conversation word for word, decisions and their dates. Use it for "
                "'what did we say or decide about X'. Optional since and until are dates like 2026-11-01.",
                {"words": str, "since": str, "until": str},
                READ, journal, on_loop=True,
            ),
            Tool("journal_day", "Read everything said on one day, for example 2026-11-20.", {"date": str}, READ, day, on_loop=True),
            Tool(
                "journal_decision",
                "Write a decision the owner made, or an agreement you reached together, into the journal in one "
                "clear sentence, so it can be found later. Do this whenever the owner decides something lasting.",
                {"decision": str},
                READ, decision, on_loop=True,
            ),
        ]

    # Scenes

    async def run_scene(self, name: str) -> str:
        scene = self.scenes.get(name)
        if scene is None:
            return "There is no scene by that name."
        if self.lock.active:
            return "IRIS is stopped."
        home = self.connectors.home if self.connectors else None
        lights_ready = bool(home and home.status()["connected"])
        spotify = self.connectors.spotify if self.connectors else None
        music_ready = bool(spotify and spotify.status()["connected"])
        missed: list[str] = []
        said = ""
        for step in scene["steps"]:
            kind = step["do"]
            try:
                if kind == "quiet":
                    self.set_quiet(step["on"])
                elif kind == "say":
                    said = step["text"]
                elif kind == "overview":
                    said = (said + " " + await self.overview()).strip()
                elif kind in ("music", "volume"):
                    if not music_ready:
                        missed.append("music")
                        continue
                    if kind == "volume":
                        await self.spotify_action({"action": "volume", "volume": step["level"]})
                    elif step["action"] == "play":
                        found = await asyncio.to_thread(spotify.find, step["query"])
                        if found:
                            await self.spotify_action({"action": "play", "uri": found[0]["uri"]})
                    else:
                        await self.spotify_action({"action": step["action"]})
                elif kind == "lights":
                    entities = step.get("lights") or self.scenes.lights()
                    if not lights_ready or not entities:
                        missed.append("lights")
                        continue
                    await asyncio.to_thread(
                        home.set_lights, entities, step["state"] == "on", step.get("brightness"), step.get("kelvin")
                    )
            except (ConnectorError, OSError, ValueError, KeyError):
                missed.append(kind)
        self.audit.write("scene", scene=name, missed=sorted(set(missed)))
        self.publish("scene", {"name": name, "label": scene["label"]})
        reply = said or f"{scene['label']}."
        if missed:
            reply += f" I could not set: {', '.join(sorted(set(missed)))}."
        return reply

    def _scene_tools(self) -> list[Tool]:
        def listed(_args: dict[str, Any]) -> str:
            lines = [f"{item['name']} ({item['label']}): {json.dumps(item['steps'])}" for item in self.scenes.listing()]
            lights = ", ".join(self.scenes.lights()) or "none chosen yet"
            return "\n".join(lines) + f"\nScene lights: {lights}"

        def save(args: dict[str, Any]) -> str:
            try:
                steps = json.loads(str(args.get("steps", "[]")))
                scene = self.scenes.save(str(args.get("name", "")), str(args.get("label", "")), steps)
            except (ValueError, TypeError) as error:
                raise ConnectorError(str(error) or "The steps must be a JSON list.") from None
            self.publish("scenes", self.scenes.listing())
            return f"Scene {scene['label']} saved."

        def lights(args: dict[str, Any]) -> str:
            try:
                chosen = self.scenes.set_lights(str(args.get("entities", "")).split(","))
            except SceneError as error:
                raise ConnectorError(str(error)) from None
            return f"Scene lights: {', '.join(chosen) or 'none'}."

        async def run(args: dict[str, Any]) -> str:
            return await self.run_scene(require_text(args, "name", 40).lower())

        return [
            Tool("scene_list", "List the owner's scenes (Focus, Film, Goodnight...) and the lights they use.", {}, READ, listed, on_loop=True),
            Tool("scene_run", "Run one of the owner's scenes by name.", {"name": str}, READ, run, on_loop=True),
            Tool(
                "scene_save",
                "Create or change a scene. steps is a JSON list of objects with \"do\": quiet {on}, music {action: "
                "play|pause|resume, query}, volume {level}, lights {state: on|off, brightness 1-100, kelvin 2000-6500, "
                "optional lights: [entity ids]}, say {text}, overview.",
                {"name": str, "label": str, "steps": str},
                WRITE, save, on_loop=True,
            ),
            Tool("scene_lights", "Choose which Home Assistant lights scenes use: entity ids separated by commas.", {"entities": str}, WRITE, lights, on_loop=True),
        ]

    def _routine_tools(self) -> list[Tool]:
        def listed(_args: dict[str, Any]) -> str:
            lines = [f"{item['time']} {item['name']}: {item['request']}" for item in self.routines.items()]
            return "\n".join(lines) or "No routines."

        def add(args: dict[str, Any]) -> str:
            days = [int(day) for day in str(args.get("days", "0,1,2,3,4,5,6")).split(",") if day.strip().isdigit()]
            try:
                item = self.routines.add(str(args.get("name", "")), str(args.get("time", "")), days, str(args.get("request", "")))
            except RoutineError as error:
                raise ConnectorError(str(error)) from None
            self._publish_panels()
            return f"Routine saved: {item['name']} at {item['time']}."

        return [
            Tool("routine_list", "List scheduled routines.", {}, READ, listed, on_loop=True),
            Tool(
                "routine_add",
                "Schedule a request. Time is HH:MM, days are numbers from 0 Monday to 6 Sunday, separated by commas.",
                {"name": str, "time": str, "days": str, "request": str},
                WRITE,
                add,
                on_loop=True,
            ),
        ]

    async def run_due_routines(self, now: datetime | None = None) -> None:
        if self.lock.active or self.busy or self.test_mode or self.settings.brain == UNBOUND:
            return  # routines need tools, and Unbound only talks; they wait until another brain is chosen
        for item in self.routines.due(now or datetime.now()):
            self._say_in_chat("iris", f"Starting routine: {item['name']}")
            self.publish("alert", {"text": f"Routine started: {item['name']}"})
            try:
                reply = await self.send(item["request"])
            except Busy:
                continue
            spoken = reply or self.last_spoken
            self.last_spoken = ""
            if spoken and self.connectors:
                self._phone(spoken)
            if spoken and self.voice and self.voice_status == "on":
                self.voice.speak(spoken)

    def suggestions(self) -> list[str]:
        return json.loads(self.memory.get_state("suggestions") or "[]")

    def answer_suggestion(self, fact: str, keep: bool) -> None:
        items = self.suggestions()
        if fact in items:
            self.memory.set_state("suggestions", json.dumps([item for item in items if item != fact], ensure_ascii=False))
            if keep:
                self.memory.remember(fact)
        self._publish_panels()

    def save_profile(self, text: str) -> None:
        self.memory.set_state("profile", text.strip()[:MAX_PROFILE] or None)
        self.audit.write("profile_changed")
        self._publish_panels()

    def _note_suspicious(self, tool: str, findings: list[str]) -> None:
        text = f"Suspicious text from {tool}: {'; '.join(findings)}"
        self.audit.write("suspicious_content", tool=tool, findings=findings)
        add_alert(self.settings.data_dir / "alerts.jsonl", "warning", tool, text)

        def show() -> None:
            self.publish("alert", {"text": text})
            self._publish_panels()

        self.loop.call_soon_threadsafe(show)

    # Telegram

    async def run_telegram(self) -> None:
        """Runs apart from the other checks, because it waits for new messages."""
        while True:
            telegram = self.connectors.telegram if self.connectors else None
            if telegram is None or self.lock.stop.active or not telegram.status()["has_bot"]:
                await asyncio.sleep(TELEGRAM_IDLE_SECONDS)
                continue
            try:
                for text in await asyncio.to_thread(telegram.poll):
                    self._start_phone_message(text)
                self._apply_phone_decisions()
                self._publish_panels()
            except (ConnectorError, OSError):
                await asyncio.sleep(TELEGRAM_IDLE_SECONDS)

    def _apply_phone_decisions(self) -> None:
        telegram = self.connectors.telegram
        decisions, telegram.decisions = telegram.decisions, []
        for request_id, allow in decisions:
            item = self.pending.get(request_id)
            if item and (not allow or not item["public"]["tool"].startswith(COMPUTER_ONLY_TOOLS)):
                self.audit.write("phone_decision", tool=item["public"]["tool"], allowed=allow)
                self.decide(request_id, allow)

    def _start_phone_message(self, text: Any) -> None:
        """A message may need an approval, so the loop must keep listening for the answer."""
        task = asyncio.create_task(self._from_phone(text))
        self.phone_messages.add(task)
        task.add_done_callback(self.phone_messages.discard)

    async def _hear_phone(self, item: dict[str, Any]) -> str:
        """Text of a voice message from the phone, or "" if it could not be understood."""
        telegram = self.connectors.telegram
        if item.get("duration", 0) > VOICE_NOTE_SECONDS:
            await asyncio.to_thread(telegram.send, "That voice message is too long for me. Keep it under five minutes.")
            return ""
        try:
            data = await asyncio.to_thread(telegram.download, item["voice"])
            samples = await asyncio.to_thread(decode_audio, data)
            text = (await asyncio.to_thread(self.speech.transcribe, samples)).strip()
        except Exception as error:
            self.audit.write("phone_voice_failed", error=type(error).__name__)
            text = ""
        if not text:
            await asyncio.to_thread(telegram.send, "I could not make out that voice message.")
        return text

    async def _speak_to_phone(self, reply: str) -> bool:
        """Answers with a voice message. True if the reply should also go as text."""
        from iris.pod.server import speakable

        spoken = speakable(reply)[:VOICE_REPLY_CHARACTERS]
        try:
            audio = await asyncio.to_thread(lambda: encode_voice_note(self.speech.synthesize(spoken)))
            caption = reply if len(reply) <= 1000 else ""
            await asyncio.to_thread(self.connectors.telegram.send_voice, audio, caption)
            return not caption  # a long reply still goes as text
        except Exception as error:
            self.audit.write("phone_voice_reply_failed", error=type(error).__name__)
            return True

    async def _from_phone(self, text: Any) -> None:
        telegram = self.connectors.telegram
        by_voice = isinstance(text, dict)
        if by_voice:
            text = await self._hear_phone(text)
            if not text:
                return
        if text.startswith("/") and text.split(" ")[0] not in SAFE_COMMANDS:
            await asyncio.to_thread(telegram.send, "That command works only on this computer.")
            return
        try:
            reply = await self.send(text)
        except Busy:
            reply = "I am still working on the last request."
        reply = reply or self.last_spoken or "Done."
        self.last_spoken = ""
        if by_voice and not await self._speak_to_phone(reply):
            return  # the voice message carried the whole reply
        await asyncio.to_thread(telegram.send, reply)

    # Quick actions. These use no AI model.

    def _today(self) -> str:
        if not self.connectors or not self.connectors.google.status()["connected"]:
            return "Connect Gmail and Calendar to see your schedule."
        if not self.schedule:
            return "Nothing scheduled in the next 24 hours."
        return "\n".join(f"{item['start']}  {item['title']}" for item in self.schedule)

    async def _digest(self) -> str:
        """Build the morning summary from real data, with no AI model."""
        now = datetime.now()
        lines = [f"Good morning, {self.settings.address}. It is {now:%A, %d %B}."]
        weather = (self.situation or {}).get("weather")
        if weather:
            place = self.situation["place"]
            lines.append(f"{place}: {round(weather['temperature'])} degrees, {weather['sky'].lower()}.")
        google = self.connectors.google if self.connectors else None
        if google and google.status()["connected"]:
            try:
                events = await asyncio.to_thread(google.upcoming)
                mail = await asyncio.to_thread(google.important_mail)
            except ConnectorError:
                lines.append("I could not reach your mail and calendar.")
            else:
                lines.append(f"{len(events)} events in the next 24 hours." if events else "Nothing on your calendar.")
                lines += [f"{item['start'][11:16] or 'All day'}: {item['title']}" for item in events[:5]]
                if mail:
                    lines.append(f"{len(mail)} important unread messages. Latest from {mail[0]['from']}.")
        waiting = [task for task in self.tasks.task_rows() if task["status"] in ("needs review", "failed")]
        if waiting:
            lines.append(f"{len(waiting)} tasks wait for your review.")
        alerts = recent_alerts(self.settings.data_dir / "alerts.jsonl")
        if alerts:
            lines.append(f"{len(alerts)} alerts in the last 24 hours. Latest: {alerts[-1]}")
        news = (self.situation or {}).get("news") or []
        lines += [f"News: {item['title']}" for item in news[:3]]
        return "\n".join(lines)

    async def _system_check(self) -> str:
        intact, count = await asyncio.to_thread(self.audit.verify)
        lines = [f"Audit log: {'intact' if intact else 'DAMAGED'}, {count} entries."]
        if self.settings.local_brain:
            problem = await asyncio.to_thread(self._check_local_brain)
            lines.append(f"Local brain: {problem or 'ready'}")
        else:
            lines.append(f"Claude key: {'present' if self.settings.api_key else 'missing'}")
        for item in self.connectors.status() if self.connectors else []:
            lines.append(f"{item['name']}: {'connected' if item['connected'] else 'not connected'}")
        lines.append(f"Voice: {self.voice_status}")
        lines.append(f"Python: {platform.python_version()}")
        log = self.settings.data_dir / "claude-errors.log"
        if log.exists():
            lines.append(f"Claude error log: {log.stat().st_size // 1024} KB")
        return "\n".join(lines)

    async def make_backup(self) -> str:
        path = await asyncio.to_thread(make_backup, self.settings.data_dir, self.settings.root)
        self.audit.write("backup_made", file=path.name)
        return str(path)

    def replay(self, limit: int = 20) -> list[dict[str, Any]]:
        """Group the log into requests, each with the steps IRIS took."""
        path = self.audit.path
        if not path.exists():
            return []
        with path.open(encoding="utf-8") as handle:
            lines = deque(handle, maxlen=2000)
        turns: list[dict[str, Any]] = []
        current: dict[str, Any] | None = None
        for line in lines:
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            event = entry.get("event")
            if event == "user_message":
                current = {"time": entry.get("time"), "text": entry.get("text", ""), "steps": [], "done": False}
                turns.append(current)
            elif current and event == "tool_decision":
                step = describe(entry)
                arguments = json.dumps(entry.get("args", {}), ensure_ascii=False)[:300]
                current["steps"].append({**step, "args": arguments})
            elif current and event == "turn_finished":
                current["done"] = True
                current = None
        return turns[-limit:][::-1]

    # Connected apps

    async def refresh_schedule(self) -> None:
        schedule: list[dict[str, str]] = []
        if self.stop.active or not self.connectors:
            return
        if self.connectors.google.status()["connected"]:
            try:
                schedule = await asyncio.to_thread(self.connectors.google.upcoming)
            except ConnectorError:
                schedule = self.schedule
        self.schedule = schedule
        self._publish_panels()

    def connection_changed(self, problem: str | None = None, event: str = "connection_changed") -> None:
        self.audit.write(event, ok=problem is None)
        if problem:
            self.publish("notice", {"text": problem})

        async def update() -> None:
            await self.refresh_schedule()

        self.background = asyncio.create_task(update())

    def _tell(self, messages: list[str | Notice]) -> None:
        """Shown on screen always. In quiet mode only urgent notices are spoken or sent to the phone."""
        quiet = self.quiet_now()
        for item in messages:
            notice = item if isinstance(item, Notice) else Notice(item, True)
            self.publish("alert", {"text": notice.text})
            if quiet and not notice.urgent:
                continue
            if self.connectors:
                self._phone(notice.text)
            if self.voice and self.voice_status == "on":
                self.voice.speak(notice.text)
        if messages:
            self._publish_panels()

    # Quiet mode and the day overview

    def _quiet_hours(self) -> tuple[Any, Any]:
        config = self.proactive_config
        return (
            parse_clock(config["quiet_from"], PROACTIVE_DEFAULTS["quiet_from"]),
            parse_clock(config["quiet_to"], PROACTIVE_DEFAULTS["quiet_to"]),
        )

    def quiet_now(self) -> bool:
        start, end = self._quiet_hours()
        return self.quiet or in_quiet_hours(datetime.now().time(), start, end)

    def quiet_state(self) -> dict[str, Any]:
        start, end = self._quiet_hours()
        return {"on": self.quiet, "now": self.quiet_now(), "hours": f"{start:%H:%M}-{end:%H:%M}"}

    def set_quiet(self, on: bool) -> None:
        self.quiet = on
        self.memory.set_state("quiet", "1" if on else "0")
        self.audit.write("quiet_mode", on=on)
        self.publish("quiet", self.quiet_state())

    def overview_due(self) -> bool:
        now = datetime.now()
        start = parse_clock(self.proactive_config["overview_from"], PROACTIVE_DEFAULTS["overview_from"])
        return (
            now.time() >= start
            and self.memory.get_state("overview_day") != now.date().isoformat()
            and not self.quiet_now()
            and not self.lock.active
        )

    async def overview(self) -> str:
        """Once a day, the first time the owner is around: weather, what is left today and important mail."""
        events, mail = (None, None)
        if self.proactive:
            events, mail = await asyncio.to_thread(self.proactive.today)
        weather = (self.situation or {}).get("weather")
        place = (self.situation or {}).get("place", self.place.get("place", ""))
        line = f"In {place} it is {round(weather['temperature'])} degrees, {weather['sky'].lower()}." if weather else ""
        return overview_text(self.settings.address, datetime.now().hour, line, events, mail)

    def start_overview(self) -> None:
        if self.overview_task and not self.overview_task.done():
            return
        if self.overview_due():
            self.overview_task = asyncio.create_task(self._give_overview())

    async def _give_overview(self) -> None:
        if not self.overview_due():
            return
        self.memory.set_state("overview_day", datetime.now().date().isoformat())
        text = await self.overview()
        self.audit.write("day_overview")
        self._say_in_chat("iris", text)
        if self.voice and self.voice_status == "on":
            self.voice.speak(text)

    def _phone(self, text: str) -> None:
        async def deliver() -> None:
            try:
                await asyncio.to_thread(self.connectors.telegram.send, text)
            except (ConnectorError, OSError):
                pass

        self.phone_task = asyncio.create_task(deliver())

    def start_situation_refresh(self) -> None:
        if not self.refreshing:
            self.refreshing = True
            task = asyncio.create_task(self.refresh_situation())
            task.add_done_callback(self._refreshed)

    def _refreshed(self, _task: asyncio.Task[None]) -> None:
        self.refreshing = False

    async def refresh_situation(self) -> None:
        self.situation = await asyncio.to_thread(build_situation, self.place)
        self.publish("situation", self.situation)

    # Taking over

    def take_control(self) -> None:
        self.lock.owner_has_control = True
        self.audit.write("control_taken")
        self._decline_all()
        if self.voice:
            self.voice.quiet()
        self._publish_phase()

    def give_back_control(self) -> None:
        self.lock.owner_has_control = False
        self.audit.write("control_returned")
        self._publish_phase()

    # Emergency stop

    def emergency_stop(self, reason: str) -> None:
        self.stop.trigger(reason)
        self.audit.write("emergency_stop_set", reason=reason)
        self._after_stop()

    def _after_stop(self) -> None:
        self._decline_all()
        self.jobs.cancel_all()
        if self.connectors:
            threading.Thread(target=self.connectors.browser.close, daemon=True).start()
        if self.voice:
            self.voice.shut_down()
        self._publish_phase()

    def clear_stop(self) -> None:
        self.stop.clear()
        self.audit.write("emergency_stop_cleared")
        self.was_stopped = False
        self._publish_phase()

    # Background

    async def run_ticker(self) -> None:
        elapsed = 0
        while True:
            if self.stop.active and not self.was_stopped:
                self.was_stopped = True  # also catches the hotkey and stop script
                self._after_stop()
            elif not self.stop.active and self.was_stopped:
                self.was_stopped = False
                self._publish_phase()
            if elapsed % 2 == 0:
                self.readings = self.reader.read()
                self.publish("system", self.readings)
            elapsed += 1
            await asyncio.sleep(1)

    async def run_background(self) -> None:
        """Slow checks run apart from run_ticker, so a slow site can never delay a stop."""
        elapsed = 0
        interval = max(1, int(self.monitor_config["interval_seconds"]) // 2)
        while True:
            if elapsed % interval == 0:
                await asyncio.to_thread(self.monitor.tick)
            if elapsed % SCHEDULE_REFRESH_SECONDS == 0:
                await self.refresh_schedule()
            if elapsed % IMAGE_CHECK_SECONDS == 0 and self.connectors:
                await asyncio.to_thread(self.connectors.images.refresh)
            if elapsed % PROACTIVE_CHECK_SECONDS == 0 and self.proactive and not self.lock.active:
                self._tell(await asyncio.to_thread(self.proactive.check_all))
            if elapsed == OVERVIEW_AFTER_START_SECONDS:
                self.start_overview()
            if (
                elapsed % 15 == 0
                and self.settings.brain == UNBOUND
                and self.loop.time() - self.unbound_last > self.unbound_idle
            ):
                await self.lock_unbound("idle")
            if elapsed % SITUATION_REFRESH_SECONDS == 0 and not self.lock.active:
                await self.refresh_situation()
            if elapsed % LOCAL_KEEP_SECONDS == 0 and self.settings.local_brain and not self.lock.active:
                await asyncio.to_thread(self._keep_local_loaded)
            if elapsed % WORLD_CHECK_SECONDS == 0 and not self.lock.active and self.world.due(time.time()):
                self.publish("world", {"changed": await asyncio.to_thread(self.world.refresh), **self.world.summary()})
            if elapsed % SECURITY_CHECK_SECONDS == 0 and not self.lock.active and self._security_due():
                self.background = asyncio.create_task(self.run_security_check())
            if elapsed % ROUTINE_CHECK_SECONDS == 0:
                self.background = asyncio.create_task(self.run_due_routines())
            if elapsed % WATCH_CHECK_SECONDS == 0 and self.connectors and not self.lock.active:
                if await asyncio.to_thread(self.connectors.watches.check_due):
                    self._publish_panels()
            elapsed += 1
            await asyncio.sleep(1)

    async def close(self) -> None:
        self.audit.listener = None
        if self.bridge:
            await asyncio.to_thread(self.bridge.close)
            self.bridge = None
        self._decline_all()
        if self.connectors:
            await asyncio.to_thread(self.connectors.browser.close)
        if self.voice:
            self.voice.shut_down()
        await self._drop_agent()
