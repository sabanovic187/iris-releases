// Text from IRIS and tools is always placed as plain text, never as HTML.
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);

  const PHASES = {
    waiting: ["Waiting", "Type below or press Talk."],
    listening: ["Listening", "Speak now."],
    thinking: ["Thinking", "Working out the reply."],
    working: ["Working", "Using an approved tool."],
    speaking: ["Speaking", "Say the wake word to interrupt."],
    needs_you: ["Needs you", "Nothing runs until you choose."],
    owner: ["You have control", "IRIS is paused. Give back control to continue."],
    stopped: ["Stopped", "All tools are blocked. Press Resume to continue."],
  };

  const state = { phase: "waiting", voice: {}, messages: new Set() };

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  let settingsOpenUntil = 0;  // a tablet's Settings stay open this long after the PIN

  async function post(path, body = {}) {
    const background = path === "spotify" && body.action === "state";
    const pressed = !background && document.activeElement?.tagName === "BUTTON" ? document.activeElement : null;
    pressed?.classList.add("working");
    try {
      const response = await fetch(`/api/${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-IRIS": "1" },
        body: JSON.stringify(body),
      });
      const data = await response.json();
      if (data.error && !background) toast(data.error);
      if (data.locked) {
        settingsOpenUntil = 0;
        setTab("command");
      }
      return data;
    } catch {
      toast("IRIS is not answering. Check its start window.");
      return { error: true };
    } finally {
      pressed?.classList.remove("working");
    }
  }

  let toastTimer;
  function toast(text) {
    const box = $("toast");
    box.textContent = text;
    box.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { box.hidden = true; }, 5000);
  }

  function clockTime(iso) {
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? "" : date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
  }

  function fillList(list, items, emptyText, build) {
    const nodes = items.length ? items.map(build) : [element("li", "empty", emptyText)];
    list.replaceChildren(...nodes);
  }

  function setPhase(phase) {
    state.phase = phase;
    document.body.dataset.phase = phase;
    const [name, hint] = PHASES[phase] || PHASES.waiting;
    $("phase-name").textContent = name;
    $("presence-state").textContent = name;
    $("presence-needs").hidden = phase !== "needs_you";
    $("presence-stop").textContent = phase === "stopped" ? "Resume" : "Emergency stop";
    window.irisPresence.phase(phase);
    window.irisCards.phase(phase);
    window.irisSituation.status(phase === "waiting" ? "" : name);
    let note = hint;
    if (phase === "waiting" && state.voice.note) note = state.voice.note;
    $("phase-hint").textContent = note;
    window.irisEye.setPhase(phase);
    window.irisCipher.phase(phase);
    $("stop").textContent = phase === "stopped" ? "Resume" : "Emergency stop";
    const blocked = phase === "stopped" || phase === "owner";
    $("control").textContent = phase === "owner" ? "Give back control" : "Take control";
    $("control").disabled = phase === "stopped";
    $("talk").disabled = blocked;
    $("voice-toggle").disabled = blocked;
  }

  function setView(name) {
    document.body.dataset.view = name;
    window.irisPresence.show(name === "presence");
  }

  function addMessage(message) {
    if (message.role !== "you") window.irisSituation.reply(message.text);
    const live = liveMessages.get(message.id);
    if (live) {
      live.textContent = message.text;
      liveMessages.delete(message.id);
      state.messages.add(message.id);
      return;
    }
    if (state.messages.has(message.id)) return;
    state.messages.add(message.id);
    const chat = $("chat");
    chat.querySelector(".hello")?.remove();
    chat.append(element("div", `msg ${message.role}`, message.text));
    chat.scrollTop = chat.scrollHeight;
  }

  const liveMessages = new Map();
  function addWords(words) {
    window.irisPresence.sound(0.32);
    const chat = $("chat");
    let node = liveMessages.get(words.id);
    if (!node) {
      chat.querySelector(".hello")?.remove();
      node = element("div", "msg iris", "");
      liveMessages.set(words.id, node);
      chat.append(node);
    }
    node.textContent += words.text;
    chat.scrollTop = chat.scrollHeight;
  }

  function showHello() {
    if (!state.messages.size) $("chat").replaceChildren(element("p", "hello", "Ask IRIS something, or try an approval from the buttons on the left."));
  }

  function duration(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return days ? `${days}d ${hours}h` : `${hours}h ${minutes}m`;
  }

  function showSystem(system) {
    const rows = [];
    if (system.cpu_percent !== undefined) rows.push(["Processor", `${Math.round(system.cpu_percent)}%`]);
    if (system.memory_percent !== undefined) rows.push(["Memory", `${Math.round(system.memory_percent)}%`]);
    for (const disk of system.disks || []) rows.push([`Disk ${disk.path}`, `${Math.round(disk.used_percent)}% used`]);
    if (system.battery_percent !== undefined) rows.push(["Battery", `${system.battery_percent}%`]);
    if (system.uptime_seconds !== undefined) rows.push(["Running for", duration(system.uptime_seconds)]);
    fillPairs($("readings"), rows);
  }

  function fillPairs(list, rows) {
    list.replaceChildren(...rows.flatMap(([name, value]) => [element("dt", "", name), element("dd", "", value)]));
  }

  function approvalCard(item) {
    const card = element("div", "approval");
    card.append(element("strong", "", item.tool), element("p", "reason", item.reason), element("pre", "", item.preview));
    const choice = element("div", "choice");
    const allow = element("button", "allow", "Allow");
    const deny = element("button", "deny", "Deny");
    const answer = (value) => {
      allow.disabled = true;
      deny.disabled = true;
      post("approval", { id: item.id, allow: value });
    };
    allow.disabled = true;  // a second click cannot land on a new card
    if (!item.cut) setTimeout(() => { allow.disabled = false; }, 500);
    else card.append(element("p", "warn", "This request is too long to show in full, so it can only be denied."));
    allow.addEventListener("click", () => answer(true));
    deny.addEventListener("click", () => answer(false));
    choice.append(allow, deny);
    card.append(choice);
    return card;
  }

  function showApprovals(items) {
    const box = $("approvals");
    if (items.length && !box.querySelector(".approval")) desktopAlert("IRIS needs your approval.");
    const shown = [...box.querySelectorAll(".approval")].map((node) => node.dataset.id).join();
    if (shown && shown === items.map((item) => item.id).join()) return;
    box.closest(".panel").classList.toggle("active", items.length > 0);
    if (!items.length) {
      box.replaceChildren(element("p", "empty", "Nothing is waiting for you."));
      return;
    }
    box.replaceChildren(...items.map((item) => {
      const card = approvalCard(item);
      card.dataset.id = item.id;
      return card;
    }));
  }

  function feedRow(item) {
    const row = element("li", `tone-${item.tone}`);
    const line = element("div", "item-line");
    line.append(element("span", "feed-text", item.text), element("time", "", clockTime(item.time)));
    row.append(line);
    if (item.detail) row.append(element("div", "item-sub", item.detail));
    return row;
  }

  function taskRow(task) {
    const row = element("li");
    const line = element("div", "item-line");
    const kind = task.status.includes("fail") ? "failed" : task.status.includes("review") ? "ready" : task.status.includes("run") ? "running" : "";
    line.append(element("span", "", `#${task.id} ${task.project}`), element("span", `status ${kind}`, task.status));
    row.append(line, element("div", "item-sub", task.goal));
    if (task.status === "needs review") {
      const review = element("button", "", "Review");
      review.addEventListener("click", () => sendText(`/review ${task.id}`));
      row.append(review);
    }
    return row;
  }

  function jobRow(job) {
    const row = element("li");
    const line = element("div", "item-line");
    const kind = job.status === "done" ? "ready" : job.status === "running" ? "running" : "failed";
    line.append(element("span", "", `Job ${job.id}`), element("span", `status ${kind}`, job.status));
    row.append(line, element("div", "item-sub", job.goal));
    if (job.status === "done") {
      const read = element("button", "", "Report");
      read.type = "button";
      read.addEventListener("click", async () => {
        const data = await post("job-report", { id: job.id });
        if (data.text) window.irisCards.open({ kind: "text", title: `Job ${job.id}: ${job.goal}`, text: data.text, report: true });
      });
      row.append(read);
    } else if (job.status === "running") {
      const stop = element("button", "", "Stop");
      stop.type = "button";
      stop.addEventListener("click", () => post("job-stop", { id: job.id }));
      row.append(stop);
    }
    return row;
  }

  function factRow(fact) {
    const row = element("li");
    const forget = element("button", "", "Forget");
    forget.addEventListener("click", () => post("forget", { id: fact.id }));
    row.append(element("span", "", fact.text), forget);
    return row;
  }

  function field(label, type, placeholder) {
    const wrap = element("label", "field", label);
    const input = element("input");
    input.type = type;
    input.autocomplete = "off";
    input.spellcheck = false;
    if (placeholder) input.placeholder = placeholder;
    wrap.append(input);
    return { wrap, input };
  }

  function form(fields, buttonText, action) {
    const box = element("form", "connect-form");
    const button = element("button", "primary", buttonText);
    button.type = "submit";
    box.append(...fields.map((item) => item.wrap), button);
    box.addEventListener("submit", async (event) => {
      event.preventDefault();
      button.disabled = true;
      const result = await action();
      button.disabled = false;
      if (result.ok) fields.forEach((item) => { item.input.value = ""; });
    });
    return box;
  }

  function steps(lines) {
    const list = element("ol", "steps");
    list.append(...lines.map((line) => element("li", "", line)));
    return list;
  }

  function googleSetup() {
    const id = field("Client ID", "text");
    const secret = field("Client secret", "password");
    return [
      steps([
        "In Google Cloud Console, create a project and enable the Gmail, Google Calendar, People and Google Drive APIs.",
        "Under Google Auth Platform, choose External, then publish the app. Staying in Testing makes the sign-in expire every 7 days.",
        "Under Clients, create a client of type Desktop app and copy its ID and secret here.",
        "Google warns that the app is unverified, because it is your own. Choose Advanced, then continue.",
      ]),
      form([id, secret], "Sign in with Google", () => post("connect-google", { client_id: id.input.value, client_secret: secret.input.value })),
    ];
  }

  function outlookSetup(item) {
    if (item.pending) {
      return [steps([`Open ${item.pending.url}`, `Enter this code: ${item.pending.code}`, "Sign in and accept. This card updates by itself."])];
    }
    const id = field("Application (client) ID", "text");
    return [
      steps([
        "In the Microsoft Entra admin center, open App registrations and add a new registration.",
        "Choose accounts in any organization and personal Microsoft accounts.",
        "Under Authentication, turn on Allow public client flows.",
        "Copy the Application (client) ID here. There is no secret.",
      ]),
      form([id], "Sign in with Microsoft", () => post("connect-outlook", { client_id: id.input.value })),
    ];
  }

  function spotifySetup() {
    const id = field("Client ID", "text");
    return [
      steps([
        "Open developer.spotify.com/dashboard and create an app. Spotify requires Premium for this.",
        "Add this Redirect URI: http://127.0.0.1:8974/callback",
        "Choose Web API, then copy the Client ID here. IRIS does not need the secret.",
      ]),
      form([id], "Sign in with Spotify", () => post("connect-spotify", { client_id: id.input.value })),
    ];
  }

  function githubSetup() {
    const token = field("Personal access token", "password");
    return [
      steps([
        "On GitHub, open Settings, Developer settings, Fine-grained tokens.",
        "Choose only the repositories IRIS may use. Allow read access to Contents, and read and write to Issues and Pull requests.",
        "Paste the token here. It is stored encrypted for your Windows account.",
      ]),
      form([token], "Connect GitHub", () => post("connect-github", { token: token.input.value })),
    ];
  }

  function homeSetup() {
    const url = field("Address", "text", "http://homeassistant.local:8123");
    const token = field("Long-lived access token", "password");
    return [
      steps([
        "Install Home Assistant and add your devices there.",
        "Open your profile in Home Assistant, then Security, and create a long-lived access token.",
        "Enter the address and paste the token here. It is stored encrypted for your Windows account.",
      ]),
      form([url, token], "Connect Home Assistant", () => post("connect-home", { url: url.input.value, token: token.input.value })),
    ];
  }

  function telegramSetup(item) {
    if (item.has_bot) {
      return [steps([
        `Open your bot @${item.account} in Telegram.`,
        `Send this message to it: /start ${item.pair_code || "(the code appears in a moment)"}`,
      ])];
    }
    const token = field("Bot token", "password");
    return [
      steps([
        "In Telegram, open @BotFather and send /newbot.",
        "Choose a name and copy the token it gives you.",
        "Paste the token here. It is stored encrypted for your Windows account.",
      ]),
      form([token], "Connect Telegram", () => post("connect-telegram", { token: token.input.value })),
    ];
  }

  function folderSetup(item) {
    const path = field("Folder path", "text", "C:\\Users\\Korisnik\\Documents");
    const rows = (item.folders || []).map((folder) => {
      const row = element("li", "");
      const remove = element("button", "", "Remove");
      remove.addEventListener("click", () => post("remove-folder", { path: folder }));
      row.append(element("span", "", folder), remove);
      return row;
    });
    const list = element("ul", "plain-list facts");
    list.append(...rows);
    return [list, form([path], "Add folder", () => post("add-folder", { path: path.input.value }))];
  }

  function statusWord(item) {
    if (item.id === "knowledge") return item.running ? "Updating" : `${item.pieces} pieces indexed`;
    if (item.id === "rates") return "Ready";
    if (item.id === "browser") return item.open ? "Open" : item.connected ? "Ready" : "Not installed";
    if (item.id === "media" || item.id === "network" || item.id === "documents") return item.connected ? "Ready" : "Not installed";
    if (item.id === "images") return item.connected ? "ComfyUI running" : "ComfyUI not running";
    if (item.id === "watches") return item.connected ? `${item.pages.length} watched` : "Nothing watched";
    return item.connected ? "Connected" : "Not connected";
  }

  function watchSetup(item) {
    const url = field("Page address", "text", "https://example.com/news");
    const words = field("Only tell me if the page mentions (optional)", "text");
    const list = element("ul", "plain-list facts");
    list.append(...item.pages.map((page) => {
      const row = element("li", "");
      const remove = element("button", "", "Remove");
      remove.addEventListener("click", () => post("remove-watch", { url: page.url }));
      const text = element("span", "", page.url);
      if (page.note) text.append(element("div", "item-sub", page.note));
      row.append(text, remove);
      return row;
    }));
    return [list, form([url, words], "Watch page", () => post("add-watch", { url: url.input.value, words: words.input.value }))];
  }

  function connectionCard(item) {
    const card = element("article", "panel connection");
    const head = element("div", "item-line");
    head.append(element("h2", "", item.name), element("span", `status ${item.connected ? "ready" : ""}`, statusWord(item)));
    card.append(head, element("p", "item-sub", item.summary));
    if (item.account) card.append(element("p", "", item.account));
    if (item.problem) card.append(element("p", "warn", item.problem));
    if (item.id === "media") {
      if (!item.connected) card.append(element("p", "note", "Run scripts\\setup-tools.ps1, then restart IRIS."));
    } else if (item.id === "documents") {
      if (!item.connected) card.append(element("p", "note", "Run scripts\\setup-tools.ps1, then restart IRIS."));
    } else if (item.id === "knowledge") {
      const update = element("button", "", "Update index");
      update.disabled = item.running;
      update.addEventListener("click", () => post("knowledge-update"));
      card.append(element("p", "note", "Uses the folders added below and nomic-embed-text in Ollama."), update);
    } else if (item.id === "images") {
      if (!item.connected) card.append(element("p", "note", "Install ComfyUI and start it. IRIS finds it on this computer."));
    } else if (item.id === "network") {
      if (!item.connected) card.append(element("p", "note", "Install Nmap from nmap.org, then restart IRIS."));
    } else if (item.id === "rates") {
      card.append(element("p", "note", "Rates come from Frankfurter. No account is needed."));
    } else if (item.id === "browser") {
      card.append(element("p", "note", "No sign-ins are kept. IRIS will not enter passwords, card numbers or pay for anything."));
    } else if (item.id === "watches") {
      card.append(...watchSetup(item));
    } else if (item.id === "files") {
      card.append(...folderSetup(item));
    } else if (item.connected) {
      const leave = element("button", "", "Disconnect");
      leave.addEventListener("click", () => post("disconnect", { id: item.id }));
      card.append(leave);
    } else {
      const setups = { google: googleSetup, outlook: outlookSetup, spotify: spotifySetup, github: githubSetup, home: homeSetup, telegram: telegramSetup };
      card.append(...setups[item.id](item));
    }
    return card;
  }

  function whatsappCard() {
    const card = element("article", "panel connection");
    const head = element("div", "item-line");
    head.append(element("h2", "", "WhatsApp"), element("span", "status", "Not available"));
    card.append(head, element("p", "item-sub", "WhatsApp offers no approved way to link a personal account, and unofficial links can get a number banned."));
    return card;
  }

  function showConnections(items) {
    const key = JSON.stringify(items);
    if (key === state.connections) return;
    state.connections = key;
    showServices(items);
    $("connections").replaceChildren(...items.map(connectionCard), whatsappCard());
  }

  function scheduleRow(item) {
    const row = element("li", "item-line");
    const date = new Date(item.start);
    const timed = item.start.includes("T") && !Number.isNaN(date.getTime());
    row.append(element("span", "", item.title), element("time", "status", timed ? clockTime(item.start) : "All day"));
    return row;
  }

  const DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  function routineRow(item) {
    const row = element("li");
    const text = element("span", "", `${item.time} ${item.name}`);
    text.append(element("div", "item-sub", `${item.days.map((day) => DAY_NAMES[day]).join(", ")}: ${item.request}`));
    const remove = element("button", "", "Remove");
    remove.addEventListener("click", () => post("routine-remove", { id: item.id }));
    row.append(text, remove);
    return row;
  }

  function suggestionRow(fact) {
    const row = element("li");
    const actions = element("div", "choice");
    const keep = element("button", "", "Remember");
    const drop = element("button", "", "Dismiss");
    keep.addEventListener("click", () => post("suggestion", { fact, keep: true }));
    drop.addEventListener("click", () => post("suggestion", { fact, keep: false }));
    actions.append(keep, drop);
    row.append(element("span", "", fact), actions);
    return row;
  }

  function showPanels(panels) {
    $("suggest-title").hidden = !panels.suggestions.length;
    $("suggestions").replaceChildren(...panels.suggestions.map(suggestionRow));
    if (document.activeElement !== $("profile")) $("profile").value = panels.profile;
    fillList($("routines"), panels.routines, "No routines yet.", routineRow);
    showConnections(panels.connections);
    const google = panels.connections.find((item) => item.id === "google");
    fillList($("schedule"), panels.schedule, google?.connected ? "Nothing scheduled." : "Connect Google to see this.", scheduleRow);
    showApprovals(panels.approvals);
    fillList($("tasks"), [...(panels.jobs || []).slice(0, 4).map((job) => ({ ...job, job: true })), ...panels.tasks.slice(0, 3)],
      "No tasks yet. Ask IRIS to do something in the background.", (item) => (item.job ? jobRow(item) : taskRow(item)));
    fillList($("alerts"), panels.alerts, "No alerts in the last 24 hours.", (text) => element("li", "", text));
    fillList($("recent"), panels.activity.slice(0, 12), "Nothing yet.", feedRow);
    fillList($("activity"), panels.activity, "Nothing yet.", feedRow);
    fillList($("facts"), panels.facts, "Nothing saved yet.", factRow);
    $("spent").textContent = `$${panels.spent.toFixed(2)}`;
    $("limit").textContent = `of $${panels.limit.toFixed(2)} this month`;
    const used = Math.min(100, (panels.spent / panels.limit) * 100);
    $("spend-bar").firstElementChild.style.width = `${used}%`;
    $("spend-bar").classList.toggle("high", used >= 80);
    showSpending(panels.spending);
  }

  function tokens(count) {
    return count >= 1e6 ? `${(count / 1e6).toFixed(1)}M` : count >= 1e3 ? `${Math.round(count / 1e3)}k` : String(count);
  }

  function showSpending(spending) {
    if (!spending) return;
    const row = (name, item) => {
      const all = item.input + item.output;
      if (!all) return [element("dt", "", name), element("dd", "", "$0.00")];
      const dollars = item.usd > 0 && item.usd < 0.01 ? "<$0.01" : `~$${item.usd.toFixed(2)}`;
      const money = item.unpriced === all ? "price unknown" : `${dollars}${item.unpriced ? "+" : ""}`;
      const cell = element("dd", "", `${money} · ${tokens(all)} tokens`);
      if (item.unpriced) cell.title = "Some replies came from a model whose price IRIS does not know. Add it under [prices] in config\\settings.toml.";
      return [element("dt", "", name), cell];
    };
    $("spend-others").replaceChildren(...row("OpenAI", spending.openai));
    // Unbound's spending shows only inside Unbound, at the top of its screen.
    const unbound = spending.unbound, all = unbound.input + unbound.output;
    const dollars = unbound.usd > 0 && unbound.usd < 0.01 ? "<$0.01" : `$${unbound.usd.toFixed(2)}`;
    $("unbound-usage").textContent = all ? `This month ${dollars} · ${tokens(all)} tokens` : "This month $0.00";
  }

  function showVoice(voice) {
    state.voice = voice;
    const toggle = $("voice-toggle");
    toggle.checked = voice.status === "on" || voice.status === "loading";
    $("speak-toggle").checked = voice.speak;
    $("speak-toggle").disabled = voice.status !== "on";
    if (voice.status === "unavailable") toast(voice.note);
    setPhase(state.phase);
  }

  function showSettings(settings) {
    fillPairs($("skills"), [["Saved skills", settings.skills.join(", ") || "None yet. Add .md files to the skills folder."]]);
    fillPairs($("settings"), [
      ["Claude model", settings.model],
      ["For hard jobs", settings.smart_model],
      ["Local model", settings.ollama_model],
      ["Permission level", settings.level === 3 ? "3: changes need your approval" : "1: read only"],
      ["Limit per message", `$${settings.max_usd_per_message.toFixed(2)}`],
      ["Limit per task", `$${settings.max_usd_per_task.toFixed(2)}`],
      ["Workspace", settings.workspace],
      ["Apps IRIS may start", settings.allowed_apps.join(", ") || "None"],
      ["Extra tool servers", settings.mcp_servers.join(", ") || "None"],
    ]);
  }

  function sendText(text) {
    post("message", { text });
  }
  window.irisSend = sendText;

  function showMusic(data) {
    const connected = Boolean(data.connected);
    $("music-note").hidden = connected;
    $("music-connect").hidden = connected;
    $("music-player").hidden = !connected;
    $("music-problem").hidden = !data.error;
    $("music-problem").textContent = data.error || "";
    if (!connected || data.title === undefined) return;
    $("music-title").textContent = data.title || "Nothing playing";
    $("music-artist").textContent = data.artist;
    $("music-art").hidden = !data.image;
    if (data.image && $("music-art").src !== data.image) $("music-art").src = data.image;
    $("music-play").textContent = data.playing ? "⏸︎" : "▶︎";
    $("music-play").dataset.playing = String(data.playing);
    $("music-progress").firstElementChild.style.width = `${data.length ? (100 * data.position) / data.length : 0}%`;
    $("music-volume").disabled = data.volume === null || data.volume === undefined;
    if (document.activeElement !== $("music-volume") && data.volume !== null && data.volume !== undefined) $("music-volume").value = data.volume;
    const options = data.devices.map((item) => {
      const option = element("option", "", item.name);
      option.value = item.id;
      return option;
    });
    if (!options.length) options.push(element("option", "", "Open Spotify on a device"));
    $("music-device").replaceChildren(...options);
    $("music-device").value = data.device;
  }

  let musicWaiting = false;
  async function music(data) {
    if (data.action === "state" && musicWaiting) return;
    if (data.action === "pause" || data.action === "resume") {
      $("music-play").textContent = data.action === "pause" ? "▶︎" : "⏸︎";
      $("music-play").dataset.playing = String(data.action === "resume");
    }
    musicWaiting = true;
    const result = await post("spotify", data);
    musicWaiting = false;
    if (result.found) {
      $("music-found").replaceChildren(...result.found.map((item) => {
        const row = element("li");
        const button = element("button", "row-button", `${item.title} · ${item.artist}`);
        button.type = "button";
        button.addEventListener("click", () => {
          $("music-found").replaceChildren();
          music({ action: "play", uri: item.uri });
        });
        row.append(button);
        return row;
      }));
      return;
    }
    showMusic(result);
  }

  function showServices(items) {
    const shown = items.filter((item) => item.connected && !["rates", "documents", "knowledge", "files", "browser", "network", "media", "images", "watches"].includes(item.id));
    const buttons = shown.map((item) => {
      const button = element("button", "service", item.name);
      button.addEventListener("click", () => setTab("connections"));
      return button;
    });
    $("services").replaceChildren(...(buttons.length ? buttons : [element("p", "note", "Nothing connected yet.")]));
  }

  function showQuiet(quiet) {
    $("quiet-toggle").checked = quiet.on;
    $("quiet-switch").title = quiet.on ? "Quiet mode: only meeting reminders are spoken." : `Quiet hours ${quiet.hours}: only meeting reminders are spoken.${quiet.now ? " Quiet hours now." : ""}`;
  }

  async function load() {
    const response = await fetch("/api/state");
    if (!response.ok) {
      $("chat").replaceChildren(element("p", "hello", "This window is out of date. Open IRIS again from its start window."));
      return;
    }
    const data = await response.json();
    $("mode").hidden = !data.test_mode;
    $("brain-name").hidden = data.test_mode;
    $("brain-name").textContent = data.brain.label;
    for (const radio of document.querySelectorAll('input[name="brain"]')) radio.checked = radio.value === data.brain.name;
    $("brain-pick").value = data.brain.name;
    const unbound = data.brain.name === "abliteration";
    if (unbound) document.body.dataset.brain = "unbound";
    else delete document.body.dataset.brain;
    const onTab = document.querySelector("[data-tab][aria-selected=\"true\"]");
    if (unbound && onTab && onTab.dataset.tab !== "command" && document.body.dataset.view !== "presence") setTab("command");
    window.irisCipher.show(unbound);
    window.irisPresence.theme(unbound ? "unbound" : "");
    $("unbound-state").textContent = data.unbound.connected ? `Connected. Model: ${data.unbound.account}.` : "Key from abliteration.ai. It is stored encrypted for your Windows account and is used only for Unbound conversations.";
    $("unbound-form").hidden = data.unbound.connected;
    $("unbound-remove").hidden = !data.unbound.connected;
    $("unbound-pin-state").textContent = data.unbound.pin
      ? "A PIN is set. Unbound asks for it every time it is opened and locks itself after 20 minutes without a message. A tablet asks for it before Settings."
      : "Set a PIN before Unbound or a tablet's Settings can be opened. It is stored only as a hash on this computer.";
    $("unbound-pin-current-field").hidden = !data.unbound.pin;
    $("openai-state").textContent = data.openai.connected ? `Connected. Model: ${data.openai.account}.` : "On platform.openai.com, set a monthly limit and create a key just for IRIS. It is stored encrypted for your Windows account.";
    $("openai-form").hidden = data.openai.connected;
    $("openai-remove").hidden = !data.openai.connected;
    $("spend-note").textContent = data.brain.name === "local" ? "The local brain costs nothing." : "Claude is counted from real replies. OpenAI is estimated from tokens and list prices.";
    data.history.forEach(addMessage);
    showHello();
    showSystem(data.system);
    showPanels(data);
    showSettings(data.settings);
    showVoice(data.voice);
    showQuiet(data.quiet);
    setPhase(data.phase);
    window.irisSituation.show(data.situation);
    window.irisSituation.world(data.world);
    window.irisCards.show(data.cards);
    showScenes(data.scenes);
    showCardsSetting(data.cards_on);
    if (data.security) $("security-summary").textContent = data.security.summary;
    if (data.device === "tablet") {
      document.body.dataset.device = "tablet";
    } else {
      showTablet(data.tablet);
      showPod(data.pod);
      showSetup(data.setup);
      showUpdate(data.update);
    }
  }

  // First start: how IRIS addresses the owner, their city and the Claude key
  const setup = { state: null, places: [] };
  function showSetup(state, open = false) {
    if (!state) return;
    setup.state = state;
    $("you-state").textContent = state.needed
      ? "Not set yet."
      : `IRIS addresses you as "${state.address}". City: ${state.place}. ${state.has_key ? "Claude key saved." : "No Claude key: only the local brain works."}`;
    if (!state.needed && !open) return;
    $("setup-title").textContent = state.needed ? "Welcome to IRIS" : "You";
    $("setup-intro").textContent = state.needed
      ? "A few things so IRIS is yours. They stay on this computer."
      : "Change what IRIS knows about you. Leave the key empty to keep the saved one.";
    $("setup-address").value = state.address || "";
    $("setup-city").value = state.place || "";
    $("setup-key").value = "";
    $("setup-key-note").textContent = state.has_key
      ? "A key is saved. Type a new one only to replace it."
      : "IRIS's brain. Make a key with a spending limit at console.anthropic.com. It is saved only on this computer. Without it, only the local brain works.";
    $("setup-cancel").hidden = state.needed;
    $("setup-save").textContent = state.needed ? "Start IRIS" : "Save";
    $("setup-problem").hidden = true;
    setup.places = state.place ? [{ label: state.place, place: state.place, lat: null, lon: null, kept: true }] : [];
    fillPlaces();
    $("setup-dialog").hidden = false;
    $("setup-address").focus();
  }
  function fillPlaces() {
    const nodes = setup.places.filter((place) => !place.kept).map((place, index) => {
      const row = element("label");
      const radio = element("input");
      radio.type = "radio";
      radio.name = "setup-place";
      radio.value = String(index);
      radio.checked = index === 0;
      row.append(radio, element("span", "", place.label));
      return row;
    });
    $("setup-places").replaceChildren(...nodes);
  }
  function setupProblem(text) {
    $("setup-problem").textContent = text;
    $("setup-problem").hidden = !text;
  }
  async function findPlaces() {
    setupProblem("");
    const data = await post("setup-places", { query: $("setup-city").value });
    setup.places = data.places || [];
    fillPlaces();
    if (data.error) setupProblem(data.error);
  }

  function showUpdate(update) {
    if (!update) return;
    let text = `This is IRIS ${update.version}.`;
    if (update.development) text += " This computer runs IRIS from Git, so it is updated with git pull.";
    else if (update.busy) text += " Installing the update. IRIS restarts by herself when it is done.";
    else if (update.available) text += ` Version ${update.available} is ready.`;
    else if (update.checked) text += ` Up to date (checked ${update.checked}).`;
    if (update.problem) text += ` ${update.problem}`;
    $("version-state").textContent = text;
    $("version-notes").textContent = update.available && !update.busy ? update.notes : "";
    $("version-notes").hidden = !$("version-notes").textContent;
    $("version-check").hidden = update.development || update.busy;
    $("version-install").hidden = !update.available || update.busy || update.development;
  }

  function showScenes(scenes) {
    if (!scenes) return;
    const keys = scenes.map((scene) => {
      const key = element("button", "", scene.label);
      key.type = "button";
      key.dataset.scene = scene.name;
      key.title = scene.steps.map((step) => step.do).join(", ");
      key.addEventListener("click", () => post("scene", { name: scene.name }));
      return key;
    });
    $("scenes").replaceChildren(...keys);
  }

  function showPod(pod) {
    if (!pod) return;
    $("pod-state").textContent = !pod.enabled
      ? "Off. To use a Pod, set enabled = true under [pod] in config\\settings.toml and restart IRIS."
      : pod.waiting
        ? "A Pod is showing a code. Type it below to pair it."
        : "The Pod talks only to IRIS, over your home Wi-Fi. What you say goes through IRIS like typed messages.";
    $("pod-address").textContent = pod.address || "";
    $("pod-address-line").hidden = !pod.address;
    $("pod-pair").hidden = !pod.enabled;
    fillList($("pod-devices"), pod.pods, pod.enabled ? "No Pod paired yet." : "", (item) => {
      const row = element("li");
      const seen = item.seen ? new Date(item.seen * 1000).toLocaleString() : "";
      row.append(element("span", "", item.name), element("span", "status", seen ? `Last seen ${seen}` : ""));
      const remove = element("button", "", "Remove");
      remove.type = "button";
      remove.addEventListener("click", () => post("pod-remove", { device: item.device }));
      row.append(remove);
      return row;
    });
  }

  function showTablet(tablet) {
    if (!tablet) return;
    $("tablet-state").textContent = tablet.enabled
      ? "Paired screens show IRIS over your home Wi-Fi. Commands and Windows control are still approved only here."
      : "Off. To use a tablet, set enabled = true under [tablet] in config\\settings.toml and restart IRIS.";
    $("tablet-pair").disabled = !tablet.enabled;
    if (!tablet.pairing) $("tablet-code").hidden = true;
    fillList($("tablet-devices"), tablet.devices, tablet.enabled ? "No screens paired yet." : "", (device) => {
      const row = element("li");
      const seen = device.seen ? new Date(device.seen * 1000).toLocaleString() : "";
      row.append(element("span", "", device.name), element("span", "status", seen ? `Last seen ${seen}` : ""));
      const remove = element("button", "", "Remove");
      remove.type = "button";
      remove.addEventListener("click", () => post("device-remove", { id: device.id }));
      row.append(remove);
      return row;
    });
  }

  // World Monitor runs beside IRIS. When it is up, Situation shows it; the IRIS globe stays one click away.
  const worldMonitor = { ready: false, url: "", checked: 0 };
  function situationChoice() {
    try { return localStorage.getItem("iris.situation") || "wm"; } catch { return "wm"; }
  }
  function useSituation(choice, remember = true) {
    if (remember) { try { localStorage.setItem("iris.situation", choice); } catch { /* this visit only */ } }
    const showWm = choice === "wm" && worldMonitor.ready;
    const frame = $("wm-frame");
    if (showWm && frame.dataset.url !== worldMonitor.url) {
      frame.src = worldMonitor.url;
      frame.dataset.url = worldMonitor.url;
    }
    $("tab-situation").classList.toggle("wm-on", showWm);
    frame.hidden = !showWm;
    $("wm-credit").hidden = !showWm;
    $("wm-switch").hidden = !worldMonitor.ready;
    for (const button of document.querySelectorAll("[data-situation]")) {
      button.setAttribute("aria-pressed", String(button.dataset.situation === (showWm ? "wm" : "globe")));
    }
    if (!showWm) window.irisSituation.open();
  }
  async function openSituation() {
    if (Date.now() - worldMonitor.checked > 30000) {
      const data = await post("world-monitor");
      worldMonitor.checked = Date.now();
      worldMonitor.ready = Boolean(data.ready);
      worldMonitor.url = data.proxy ? `http://${location.hostname}:${data.proxy}/` : data.url || "";
    }
    useSituation(situationChoice(), false);
  }

  function showCardsSetting(on) {
    $("cards-on").setAttribute("aria-pressed", String(on !== false));
    $("cards-off").setAttribute("aria-pressed", String(on === false));
  }

  function showCards(data) {
    window.irisCards.show(data);
    if (!data.cards || !data.cards.length) return;
    if (document.body.dataset.view === "presence") return;
    const onCommand = !$("tab-command").hidden;
    if (onCommand) setView("presence");
    else toast("IRIS put cards on the core screen.");
  }

  function listen() {
    const events = new EventSource("/api/events");
    const on = (name, handler) => events.addEventListener(name, (event) => handler(JSON.parse(event.data)));
    on("phase", (data) => setPhase(data.phase));
    on("message", addMessage);
    on("words", addWords);
    on("sound", (data) => window.irisPresence.sound(data.level));
    on("music", showMusic);
    on("panels", showPanels);
    on("system", showSystem);
    on("voice", showVoice);
    on("notice", (data) => toast(data.text));
    on("alert", (data) => {
      toast(data.text);
      desktopAlert(data.text);
    });
    on("situation", (data) => window.irisSituation.show(data));
    on("world", (data) => window.irisSituation.world(data));
    on("globe", (data) => {
      setTab("situation");
      useSituation("globe", false);
      window.irisSituation.view(data);
    });
    on("brain", load);
    on("quiet", showQuiet);
    on("cards", showCards);
    on("tablet", showTablet);
    on("pod", showPod);
    on("scenes", showScenes);
    on("scene", (data) => {
      for (const key of document.querySelectorAll("[data-scene]")) key.classList.toggle("active", key.dataset.scene === data.name);
    });
    on("setup", (state) => showSetup(state));
    on("update", showUpdate);
    on("security", (data) => { $("security-summary").textContent = data.summary; });
    on("cards_setting", (data) => showCardsSetting(data.on));
    on("level", (data) => {
      window.irisEye.setLevel(data.level);
      showMeter(data.level);
    });
    on("cleared", () => {
      state.messages.clear();
      $("chat").replaceChildren();
      showHello();
    });
    events.addEventListener("open", load);
    events.addEventListener("error", () => {
      $("phase-hint").textContent = "IRIS is not answering. Check its start window.";
    });
  }

  function fillSelect(select, names, chosen, fallback) {
    const options = names.map((name) => {
      const option = element("option", "", name);
      option.value = name;
      return option;
    });
    if (fallback !== undefined) {
      const first = element("option", "", fallback);
      first.value = "";
      options.unshift(first);
    }
    select.replaceChildren(...options);
    select.value = chosen;
  }

  async function showVoiceScreen() {
    const data = await post("voice-screen");
    if (!data.ok) return;
    fillSelect($("v-mic"), data.microphones, data.microphone, "Windows default");
    fillSelect($("v-voice"), data.voices, data.voice_name);
    $("v-wake").textContent = `${data.wake_word.replaceAll("_", " ")}${data.wake_word === "hey_jarvis" ? " (temporary)" : ""}`;
    showCloud(data.cloud);
    $("v-sens").value = Math.round((1 - data.wake_threshold) * 100);
    $("v-pause").value = data.silence_seconds;
    $("v-follow").value = data.follow_up_seconds;
    labelVoice();
    const rows = [["Speech to text", data.stats.heard_ms], ["Reply", data.stats.reply_ms]]
      .filter(([, value]) => value !== undefined)
      .map(([name, value]) => [name, `${(value / 1000).toFixed(1)} s`]);
    if (rows.length) fillPairs($("v-stats"), rows);
    else $("v-stats").replaceChildren(element("dt", "", "Nothing measured yet."));
  }

  function showCloud(cloud) {
    $("cloud-form").hidden = cloud.connected;
    $("cloud-on").hidden = !cloud.connected;
    if (!cloud.connected) return;
    $("cloud-use").checked = cloud.on;
    const voices = cloud.voices || [];
    $("cloud-voice-row").hidden = !voices.length;
    $("cloud-voice").replaceChildren(...voices.map((item) => {
      const option = element("option", "", item.name);
      option.value = item.id;
      return option;
    }));
    $("cloud-voice").value = cloud.voice;
    $("cloud-used").textContent = cloud.limit ? `${cloud.used.toLocaleString("en-US")} of ${cloud.limit.toLocaleString("en-US")} credits used this month.` : "";
  }

  function labelVoice() {
    $("v-sens-text").textContent = `${$("v-sens").value}%`;
    $("v-pause-text").textContent = `${Number($("v-pause").value).toFixed(1)} s`;
    const follow = Number($("v-follow").value);
    $("v-follow-text").textContent = follow ? `${follow} s` : "Off, wake word every time";
  }

  function showMeter(level) {
    const bar = $("v-meter").firstElementChild;
    bar.style.width = `${Math.round(level * 100)}%`;
    clearTimeout(state.meterTimer);
    state.meterTimer = setTimeout(() => { bar.style.width = "0"; }, 400);
  }

  async function showReplay() {
    const data = await post("replay");
    if (!data.ok) return;
    const rows = data.turns.map((turn) => {
      const box = element("details", "turn");
      const line = element("summary", "");
      line.append(element("span", "", turn.text), element("time", "status", `${clockTime(turn.time)}, ${turn.steps.length} steps`));
      box.append(line);
      for (const step of turn.steps) {
        const row = element("div", `tone-${step.tone}`);
        row.append(element("div", "feed-text", step.text), element("div", "item-sub", step.args));
        box.append(row);
      }
      if (!turn.steps.length) box.append(element("p", "note", "No tools were used."));
      return box;
    });
    $("replay").replaceChildren(...(rows.length ? rows : [element("p", "note", "Nothing yet.")]));
  }

  const ACTIONS = [
    ["The core", () => setView("presence")],
    ["Command Center", () => setTab("command")],
    ["Situation", () => setTab("situation")],
    ["Voice", () => setTab("voice")],
    ["Connections", () => setTab("connections")],
    ["Routines", () => setTab("routines")],
    ["Activity", () => setTab("activity")],
    ["Memory", () => setTab("memory")],
    ["Settings", () => setTab("settings")],
    ["Today", () => sendText("/today")],
    ["Morning digest", () => sendText("/digest")],
    ["Daily briefing", () => sendText("/briefing")],
    ["System check", () => sendText("/system")],
    ["Make a backup", () => makeBackup()],
    ["Start a new conversation", () => post("new")],
    ["Take control", () => post("control", { take: true })],
    ["Give back control", () => post("control", { take: false })],
  ];

  function closeDialogs() {
    $("palette").hidden = true;
    $("keys").hidden = true;
  }

  function showActions(words) {
    const wanted = words.trim().toLowerCase();
    const rows = ACTIONS.filter(([name]) => name.toLowerCase().includes(wanted)).map(([name, run]) => {
      const button = element("button", "", name);
      button.addEventListener("click", () => {
        closeDialogs();
        run();
      });
      const row = element("li");
      row.append(button);
      return row;
    });
    $("palette-list").replaceChildren(...rows);
    return rows;
  }

  async function searchMemory(words) {
    const data = await post("search", { words });
    if (!data.ok) return;
    const rows = data.found.map((text) => element("li", "found", text));
    $("palette-list").replaceChildren(...(rows.length ? rows : [element("li", "found", "Nothing found.")]));
  }

  function openPalette() {
    closeDialogs();
    $("palette").hidden = false;
    $("palette-input").value = "";
    showActions("");
    $("palette-input").focus();
  }

  async function makeBackup() {
    const data = await post("backup");
    if (data.ok) {
      $("backup-result").textContent = `Saved to ${data.file}. Connection secrets are not included, so you would connect apps again.`;
      toast("Backup made.");
    }
  }

  function desktopAlert(text) {
    if (document.hidden && "Notification" in window && Notification.permission === "granted") {
      new Notification("IRIS", { body: text });
    }
  }

  function setTab(name) {
    if (document.body.dataset.device === "tablet") {
      if (!["command", "situation", "settings"].includes(name)) name = "command";
      if (name === "settings" && Date.now() > settingsOpenUntil) {
        askPin("settings");
        return;
      }
    }
    setView("dashboard");
    if (name === "voice") showVoiceScreen();
    if (name === "situation") setTimeout(openSituation, 0);
    if (name === "activity") showReplay();
    for (const button of document.querySelectorAll("[data-tab]")) {
      const chosen = button.dataset.tab === name;
      button.setAttribute("aria-selected", String(chosen));
      $(`tab-${button.dataset.tab}`).hidden = !chosen;
    }
  }

  function tick() {
    const now = new Date();
    $("clock").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
    $("date").textContent = now.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
  }

  function growInput() {
    const input = $("input");
    input.style.height = "auto";
    input.style.height = `${input.scrollHeight + 2}px`;
  }

  function submit() {
    const input = $("input");
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    growInput();
    sendText(text);
  }

  document.querySelectorAll("[data-tab]").forEach((button) => button.addEventListener("click", () => setTab(button.dataset.tab)));
  document.querySelectorAll("[data-send]").forEach((button) => button.addEventListener("click", () => {
    setTab("command");
    sendText(button.dataset.send);
  }));
  $("composer").addEventListener("submit", (event) => {
    event.preventDefault();
    submit();
  });
  $("input").addEventListener("input", growInput);
  $("input").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  });
  $("stop").addEventListener("click", () => post(state.phase === "stopped" ? "resume" : "stop"));
  $("control").addEventListener("click", () => post("control", { take: state.phase !== "owner" }));
  $("talk").addEventListener("click", () => post("talk"));
  $("voice-toggle").addEventListener("change", (event) => post("voice", { on: event.target.checked }));
  $("speak-toggle").addEventListener("change", (event) => post("speak", { on: event.target.checked }));
  $("quiet-toggle").addEventListener("change", (event) => post("quiet", { on: event.target.checked }));
  let pinFor = null;
  function askPin(name) {
    pinFor = name;
    const forSettings = name === "settings";
    $("pin-title").textContent = forSettings ? "Settings PIN" : "Unbound PIN";
    $("pin-open").textContent = forSettings ? "Open Settings" : "Open Unbound";
    $("pin-problem").hidden = true;
    $("pin-input").value = "";
    $("pin-dialog").hidden = false;
    setTimeout(() => $("pin-input").focus(), 30);
  }
  function closePin() {
    $("pin-dialog").hidden = true;
    pinFor = null;
    load();
  }
  $("pin-cancel").addEventListener("click", closePin);
  $("pin-dialog").addEventListener("keydown", (event) => { if (event.key === "Escape") closePin(); });
  $("pin-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const forSettings = pinFor === "settings";
    const pin = $("pin-input").value;
    const result = forSettings ? await post("settings-unlock", { pin }) : await post("brain", { name: pinFor, pin });
    $("pin-input").value = "";
    if (result.error) {
      $("pin-problem").textContent = result.error;
      $("pin-problem").hidden = false;
      return;
    }
    $("pin-dialog").hidden = true;
    pinFor = null;
    if (forSettings) {
      settingsOpenUntil = Date.now() + 9 * 60 * 1000;
      setTab("settings");
    }
  });

  async function chooseBrain(name) {
    if (name === "abliteration" && document.body.dataset.brain !== "unbound") {
      askPin(name);
      return;
    }
    const result = await post("brain", { name });
    if (result.error) {
      toast(result.error);
      load();
    }
  }
  for (const radio of document.querySelectorAll('input[name="brain"]')) {
    radio.addEventListener("change", () => chooseBrain(radio.value));
  }
  $("music-prev").addEventListener("click", () => music({ action: "previous" }));
  $("music-next").addEventListener("click", () => music({ action: "next" }));
  $("music-play").addEventListener("click", (event) => music({ action: event.currentTarget.dataset.playing === "true" ? "pause" : "resume" }));
  $("music-volume").addEventListener("change", (event) => music({ action: "volume", volume: Number(event.target.value) }));
  $("music-device").addEventListener("change", (event) => music({ action: "device", device: event.target.value }));
  $("music-connect").addEventListener("click", () => setTab("connections"));
  $("music-search").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && event.target.value.trim()) music({ action: "find", query: event.target.value });
  });
  music({ action: "state" });
  setInterval(() => {
    if (!document.hidden && !$("tab-command").hidden) music({ action: "state" });
  }, 5000);
  $("to-presence").addEventListener("click", () => setView("presence"));
  window.irisCards.init(post);
  $("security-check").addEventListener("click", () => post("security-check"));
  $("tablet-pair").addEventListener("click", async () => {
    const data = await post("pair-start");
    if (!data.code) return;
    $("tablet-code-number").textContent = data.code;
    $("tablet-address").textContent = data.address || "the address shown in the IRIS start window";
    $("tablet-code").hidden = false;
  });
  $("version-check").addEventListener("click", () => post("update-check"));
  $("version-install").addEventListener("click", () => post("update-install"));
  $("setup-find").addEventListener("click", findPlaces);
  $("setup-city").addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); findPlaces(); }
  });
  $("setup-cancel").addEventListener("click", () => { $("setup-dialog").hidden = true; });
  $("you-change").addEventListener("click", () => showSetup(setup.state, true));
  $("setup-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const fresh = setup.places.filter((place) => !place.kept);
    const picked = document.querySelector('input[name="setup-place"]:checked');
    let place = picked ? fresh[Number(picked.value)] : null;
    if (!place && setup.state && !setup.state.needed && $("setup-city").value === setup.state.place) {
      place = { place: setup.state.place, lat: setup.state.lat, lon: setup.state.lon };
    }
    if (!place) { setupProblem("Find your city and pick it from the list."); return; }
    const data = await post("setup-save", {
      address: $("setup-address").value, key: $("setup-key").value, place: place.place, lat: place.lat, lon: place.lon,
    });
    if (data.error) { setupProblem(data.error); return; }
    $("setup-key").value = "";
    $("setup-dialog").hidden = true;
    toast("Saved. IRIS is yours.");
  });
  $("pod-pair").addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = await post("pod-pair", { code: $("pod-code").value, name: $("pod-name").value });
    if (data.ok) {
      $("pod-code").value = "";
      $("pod-name").value = "";
      toast("The Pod is paired. It connects within a few seconds.");
    }
  });
  for (const button of document.querySelectorAll("[data-situation]")) {
    button.addEventListener("click", () => useSituation(button.dataset.situation));
  }
  $("cards-clear").addEventListener("click", () => post("cards", { clear: true }));
  $("cards-on").addEventListener("click", () => post("cards", { on: true }));
  $("cards-off").addEventListener("click", () => post("cards", { on: false }));
  $("presence-open").addEventListener("click", () => setTab("command"));
  $("presence-needs").addEventListener("click", () => setTab("command"));
  $("presence-talk").addEventListener("click", () => post("talk"));
  $("presence-stop").addEventListener("click", () => $("stop").click());
  $("presence-typing").addEventListener("click", () => {
    $("presence-type").hidden = !$("presence-type").hidden;
    if (!$("presence-type").hidden) $("presence-input").focus();
  });
  $("presence-type").addEventListener("submit", (event) => {
    event.preventDefault();
    const text = $("presence-input").value.trim();
    if (!text) return;
    $("presence-input").value = "";
    $("presence-type").hidden = true;
    sendText(text);
  });
  if (window.irisPresence.failed()) setTab("command");
  $("brain-pick").addEventListener("change", (event) => chooseBrain(event.target.value));
  function openaiProblem(text) {
    $("openai-problem").hidden = !text;
    $("openai-problem").textContent = text || "";
  }
  $("openai-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const result = await post("connect-openai", { key: $("openai-key").value, model: $("openai-model").value });
    openaiProblem(result.error);
    if (!result.error) $("openai-key").value = "";
  });
  $("openai-remove").addEventListener("click", async () => openaiProblem((await post("remove-openai")).error));
  function unboundProblem(text) {
    $("unbound-problem").hidden = !text;
    $("unbound-problem").textContent = text || "";
  }
  $("unbound-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const result = await post("connect-unbound", { key: $("unbound-key").value, model: $("unbound-model").value });
    unboundProblem(result.error);
    if (!result.error) $("unbound-key").value = "";
  });
  $("unbound-remove").addEventListener("click", async () => unboundProblem((await post("remove-unbound")).error));
  $("unbound-pin-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const result = await post("unbound-pin", { current: $("unbound-pin-current").value, pin: $("unbound-pin-new").value });
    $("unbound-pin-current").value = "";
    $("unbound-pin-new").value = "";
    $("unbound-pin-problem").hidden = !result.error;
    $("unbound-pin-problem").textContent = result.error || "";
    if (!result.error) {
      toast("Unbound PIN saved.");
      load();
    }
  });
  $("v-mic").addEventListener("change", (event) => post("voice-change", { microphone: event.target.value }));
  $("v-voice").addEventListener("change", (event) => post("voice-change", { voice_name: event.target.value }));
  $("v-sens").addEventListener("input", labelVoice);
  $("v-pause").addEventListener("input", labelVoice);
  $("v-sens").addEventListener("change", (event) => post("voice-change", { wake_threshold: 1 - event.target.value / 100 }));
  $("v-pause").addEventListener("change", (event) => post("voice-change", { silence_seconds: event.target.value }));
  $("v-follow").addEventListener("input", labelVoice);
  $("v-follow").addEventListener("change", (event) => post("voice-change", { follow_up_seconds: event.target.value }));
  $("cloud-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const result = await post("connect-elevenlabs", { key: $("cloud-key").value });
    $("cloud-key").value = "";
    if (!result.error) showVoiceScreen();
  });
  $("cloud-use").addEventListener("change", (event) => post("voice-cloud", { on: event.target.checked }));
  $("cloud-voice").addEventListener("change", (event) => post("voice-cloud", { voice: event.target.value }));
  $("cloud-remove").addEventListener("click", async () => {
    await post("voice-cloud", { remove: true });
    showVoiceScreen();
  });
  $("v-test-mic").addEventListener("click", () => post("test-microphone"));
  $("v-test-voice").addEventListener("click", () => post("test-speech"));
  $("situation-refresh").addEventListener("click", async () => {
    $("situation-refresh").textContent = "Refreshing";
    $("situation-refresh").disabled = true;
    const result = await post("refresh-situation");
    if (result.error) window.irisSituation.refreshed();
  });
  $("backup").addEventListener("click", makeBackup);
  $("desktop-alerts").addEventListener("click", async () => {
    const answer = "Notification" in window ? await Notification.requestPermission() : "denied";
    toast(answer === "granted" ? "Desktop alerts are on." : "Windows or the browser refused desktop alerts.");
  });
  $("palette-input").addEventListener("input", (event) => showActions(event.target.value));
  $("palette-input").addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    const words = event.target.value.trim();
    const first = $("palette-list").querySelector("button");
    if (first) first.click();
    else if (words) searchMemory(words);
  });
  for (const dialog of [$("palette"), $("keys")]) {
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) closeDialogs();
    });
  }
  document.addEventListener("keydown", (event) => {
    const command = event.ctrlKey || event.metaKey;
    if (event.key === "Escape") closeDialogs();
    else if (command && event.key.toLowerCase() === "k") {
      event.preventDefault();
      openPalette();
    } else if (command && event.key === "/") {
      event.preventDefault();
      const opening = $("keys").hidden;
      closeDialogs();
      $("keys").hidden = !opening;
    } else if (command && event.shiftKey && event.key.toLowerCase() === "p") {
      event.preventDefault();
      $("control").click();
    }
  });
  const PRESETS = {
    digest: ["Morning digest", "08:00", "/digest", [0, 1, 2, 3, 4]],
    weekly: ["Weekly review", "09:00", "Follow the weekly-review skill.", [0]],
    monitor: ["Follow a topic", "18:00", "Follow the topic-monitor skill for the topic: ", [0, 1, 2, 3, 4, 5, 6]],
  };
  document.querySelectorAll("[data-preset]").forEach((button) => button.addEventListener("click", () => {
    const [name, time, request, days] = PRESETS[button.dataset.preset];
    $("r-name").value = name;
    $("r-time").value = time;
    $("r-request").value = request;
    document.querySelectorAll(".days input").forEach((box) => { box.checked = days.includes(Number(box.value)); });
    $("r-request").focus();
  }));
  $("routine-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const days = [...document.querySelectorAll(".days input:checked")].map((box) => Number(box.value));
    const result = await post("routine-add", { name: $("r-name").value, time: $("r-time").value, days, request: $("r-request").value });
    if (result.ok) {
      $("r-name").value = "";
      $("r-request").value = "";
    }
  });
  $("profile-save").addEventListener("click", async () => {
    const result = await post("profile", { text: $("profile").value });
    if (result.ok) toast("Profile saved. It applies from the next conversation.");
  });
  $("new-chat").addEventListener("click", () => post("new"));
  $("verify").addEventListener("click", async () => {
    const result = await post("verify");
    if (result.ok) $("verify-result").textContent = result.intact ? `Intact, ${result.count} entries checked.` : `Damaged after ${result.count} entries.`;
  });
  $("remember").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = $("remember-text");
    const result = await post("remember", { text: input.value });
    if (result.ok) input.value = "";
  });

  setInterval(tick, 1000);
  tick();
  load().catch(() => toast("IRIS is not answering. Check its start window."));
  listen();
})();
