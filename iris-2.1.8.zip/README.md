# IRIS 2.0

Personal AI assistant with text and voice chat, a local Command Center, memory, permission checks, an audit log and an emergency stop.

## Setup (Windows, Python 3.11+)

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
notepad .env
powershell -ExecutionPolicy Bypass -File scripts\run.ps1
```

Put a dedicated Claude API key with a spending limit in `.env`. That file is ignored by Git.

## Installing IRIS on another computer

IRIS travels as a clean product: none of the owner's keys, connections, memory or paired devices go with it. Each new owner personalises it on first start.

1. On a computer with internet: `powershell -ExecutionPolicy Bypass -File scripts\make-usb.ps1 E:\` puts the newest signed IRIS on the drive (folder `IRIS`).
2. On the other computer open that folder and double-click **Install IRIS.cmd**. It checks the package, installs Python 3.13 if needed, IRIS's packages and voice, the firewall rules for the tablet and the Pod (one administrator prompt) and the desktop icon, then starts IRIS in `%USERPROFILE%\IRIS`.
3. IRIS asks how to address its owner, their city and the Claude key.

After that, **Settings, IRIS version, Update now** installs every new signed version. Ollama (local brain) and World Monitor are optional: `scripts\setup-ollama.ps1`, `scripts\setup-worldmonitor.ps1`.

## Command Center

```powershell
powershell -ExecutionPolicy Bypass -File scripts\run-ui.ps1
```

For a desktop icon instead, run once:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\make-shortcut.ps1
```

The **IRIS** icon on the desktop and in the Start menu starts Docker Desktop (for World Monitor), Ollama and IRIS with one click. The start window waits minimised in the taskbar; close it to close IRIS. Clicking the icon while IRIS runs opens her window again.

Opens IRIS in its own Edge window, for this computer only. Keep the start window open. It shows real readings, the conversation, tasks, alerts, spending, approvals and the audit log. The microphone stays off until you press Talk or turn on Voice. Without an API key it runs in test mode: it repeats your message, and **Test an approval** tries the approval flow without running anything.

**Take control** pauses IRIS and blocks its tools until you give control back. **Emergency stop** also closes voice and stays on until you resume, even after a restart.

The **Voice** screen chooses the microphone and speaking voice, tests both, and sets wake word sensitivity and the pause after you stop talking. After a reply IRIS keeps listening for a few seconds (5 by default), so a follow-up question needs no wake word; "thanks" or "that's all" ends it. Say the wake word while she talks to stop her and ask something new.

Run one IRIS at a time. Two copies writing to the audit log break its hash chain.

## Local brain

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup-ollama.ps1
```

Then choose **Local (Ollama)** in Settings. It is free and stays on this computer. It is slower and weaker than Claude and has no web search or web fetch, because those go through Anthropic. Claude cannot search conversations held with the local brain. Approvals work the same. `config\settings.toml` only accepts an Ollama address on this computer and refuses cloud models.

## Connections

The Connections screen in the Command Center links Gmail and Calendar, GitHub and chosen folders. Follow the steps on each card. Secrets are stored encrypted for your Windows account in `data\connectors`. IRIS can read what you connect. Sending mail, adding events and posting to GitHub ask for approval, and folders are read-only. Connected apps work in the Command Center, not in the terminal chat.

## Video and audio

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup-tools.ps1
```

Ask IRIS to transcribe a link or a file in the workspace. Downloads ask for approval, go to `workspace\media` and are limited to two hours and 500 MB. Transcripts run on this computer. Use this only for content you may download.

## Watched pages

Add pages on the Connections screen. IRIS checks them at most once an hour, follows each site's robots.txt and adds an alert when the text changes.

## Images

Install and start ComfyUI, and add a checkpoint model. IRIS asks before each image, frees the graphics card from Ollama, then saves to `workspace\images`.

## Home network

Install Nmap from nmap.org. IRIS can list devices and common open ports on your own /24 network only, with approval. It cannot choose another network.

## Situation Room

A world map with earthquakes (USGS), natural events (NASA EONET) and weather (Open-Meteo). Set your place and RSS news feeds under `[situation]` in `config\settings.toml`. It uses public data only and holds nothing about private people.

## Alerts

With Gmail and Calendar connected, IRIS speaks up on her own: 10 minutes before an event, and when new important mail arrives. Once a day, the first time you are around after 05:00 (when IRIS starts or after your first request), she gives a short overview: weather, what is left in your calendar today and how many important emails are unread. It uses no AI model, so it costs nothing. Watched pages and disk problems appear in the same list.

**Quiet** (the switch at the bottom, `/quiet`, or say "quiet mode on" / "quiet mode off") keeps everything on screen but only meeting reminders are spoken or sent to Telegram, and the day overview waits. Quiet hours do the same every night, 23:00 to 07:00. To change the times, add to `config\settings.toml`:

```toml
[proactive]
remind_minutes = 10
quiet_from = "23:00"
quiet_to = "07:00"
overview_from = "05:00"
```

## Skills

Put written procedures in `skills\` as `.md` files, with a first line saying when to use them. IRIS can read them but not change them.

## Backup

**Make a backup** in Settings saves a zip to `data\backups` and keeps the last ten. It has memory, conversation, logs and settings. Connection secrets stay out, so you would connect apps again after a restore.

## Shortcuts

`Ctrl+K` finds screens, actions and memories. `Ctrl+/` lists all shortcuts.

## Home Assistant

Connect it on the Connections screen with its local address and a long-lived access token. IRIS can read device states. Lights, plugs, fans, media and vacuums need approval. Locks, alarms, garage doors and cameras are not available to IRIS.

## Extra tool servers

To add an MCP server, edit `config\settings.toml`. Each of its tools asks for approval unless you list it in `read_tools`. Only add servers you trust.

```toml
[[mcp]]
name = "example"
command = "npx"
args = ["-y", "example-server"]
read_tools = ["list_items"]
```

## Documents

IRIS reads PDF, Word, Excel and PowerPoint files from the workspace and your added folders. It writes new Word and Excel files to `workspace\documents`, with approval, and never overwrites a file. `scripts\setup-tools.ps1` installs the PDF and Excel parts.

## Knowledge base

Add folders on the Connections screen, then press **Update index**. It uses `nomic-embed-text` in Ollama, so your documents stay on this computer while the index is made. With Claude as the brain, the pieces IRIS finds are sent to Claude when it answers.

## Routines

Set requests on the Routines screen, or ask IRIS to add one. A routine runs while IRIS is open, up to 30 minutes late, once a day. With Claude as the brain it uses credits within your limits. Actions that change something still wait for approval.

## Telegram

Create a bot with @BotFather, add its token on the Connections screen, then send the shown `/start` code to your bot. Only your paired chat is accepted. IRIS must be running. Messages pass through Telegram, so do not send secrets there. Actions that need approval still wait on this computer, and most slash commands work only here.

## Memory

Write what IRIS should always know under **About me**. IRIS can suggest facts, and they are saved only when you press **Remember**. Outside text is checked for attempts to give IRIS orders, but your approvals remain the real protection.

## Research and following topics

Ask IRIS to research something and it follows the deep-research skill. With the local brain it can use only your own documents, because web tools go through Claude. The Routines screen has ready routines for the morning digest, a weekly review and following a topic. Routine results also go to Telegram when it is connected.

## Approving from your phone

When IRIS needs approval and Telegram is connected, the request reaches your phone with Allow and Decline buttons, along with the Command Center. The first answer counts. Commands and Windows control can be allowed only on the computer, because someone who took over your Telegram could otherwise both ask for and approve them. They can still be declined from the phone.

## ElevenLabs voice

Add an ElevenLabs API key on the Voice screen for a more natural voice. The words IRIS says then go to ElevenLabs. Very short lines use the free local voice, and IRIS moves to the local voice when ElevenLabs refuses or cannot be reached.

## Hey IRIS

Train the word in the openWakeWord Colab notebook, then put hey_iris.onnx in the data\\wake folder. Until that file exists, IRIS listens for "Hey Jarvis".

## The core

IRIS opens on a living core of light. It changes shape and colour with what IRIS is doing, moves with your voice and its own, and reacts as words are written. Talk, Type, Open IRIS and Emergency stop stay on this screen, and a banner appears when an approval waits. Open IRIS shows the full interface, and the IRIS name at top left returns to the core. A slower computer simply draws fewer points.

## Speed

Everyday commands such as pause, next, volume, what's playing, the time and the weather are done at once with no AI model. Replies appear as they are written, and spoken replies start with the first finished sentence. With a voice request, IRIS says "One moment" if nothing has been written after about a second and a half.

## Brains and agents

Choose Auto, Claude, OpenAI or Ollama at the top of the screen or in Settings. Auto uses the fastest brain you have and moves to the next if one fails. Ollama gets a smaller set of tools, so it answers sooner, and it has no development tasks or Windows control. Tools, approvals and emergency stop work the same for all three. The OpenAI key goes in Settings. OpenAI spending shows on your OpenAI account, not in IRIS, so set a limit there.

**Unbound** is a separate brain for conversation only, using a model from abliteration.ai. Put its key in Settings under **Unbound key**, then choose Unbound at the top of the screen. IRIS changes its look: a black room with slow haze and film grain, a red particle core, white text and one red accent. Unbound gets no tools, no commands, no quick actions and nothing from IRIS memory, files or connected services, and routines wait while it is chosen. Auto never picks it. Choose another brain to get the usual IRIS back.

Unbound is locked with a PIN of 4 to 8 digits, set in Settings under **Unbound PIN** (only on the computer, stored as a hash). Choosing Unbound asks for it every time, on the computer and on the tablet. Five wrong tries lock it for five minutes. After 20 minutes without a message, or after IRIS restarts, Unbound closes itself and the brain chosen before it comes back. Its conversation is never saved: leaving Unbound wipes it from the screen and from the model. To change the 20 minutes, add `[unbound]` with `idle_minutes = 20` to `config\settings.toml`.

**Spending this month** shows Claude (counted from real replies), OpenAI and Unbound. OpenAI and Unbound are estimated from the tokens each reply reports and list prices. If a model's price is not known, its tokens show without dollars; add it to `config\settings.toml`:

```toml
[prices]
"gpt-6.1-sol" = [2.0, 10.0]   # US dollars per million tokens: input, output
```

Any brain can also hand a job to another AI. A job for OpenAI needs approval because the text leaves this computer, unless OpenAI is already the brain. A job for Ollama needs no approval. These agents see only the text they are given and have no tools.

## Accounts

Google adds Contacts and Drive, read only. If you connected Google earlier, enable the People and Drive APIs in your project, disconnect and sign in again. Outlook and Spotify connect on the Connections screen, with steps on each card. Spotify needs Premium, because Spotify requires it for developer apps. Spotify playback needs no approval, by the owner's choice. Currency rates need no account.

## Situation

The Situation screen is a live 3D globe with air traffic, military air, satellites, undersea cables, natural events and news by country. It uses public data only. Aircraft positions refresh about every 15 minutes because of OpenSky's free limit, and move on along their last heading in between. Data is fetched only while the screen has been used recently. "Most in the news" counts headlines. It does not measure real danger. IRIS can fly the globe and change layers when you ask.

The Music panel on the Command Center controls Spotify directly.

## World Monitor

Situation can show [World Monitor](https://github.com/koala73/worldmonitor) by Elie Habib (koala73), running on this computer. Install Docker Desktop, Git for Windows and Node.js 24, start Docker Desktop, then run `scripts\setup-worldmonitor.ps1`. The first run takes 20 to 30 minutes. Run it again to update. World Monitor stays in the `worldmonitor` folder with its own licence (AGPL-3.0, free for personal use) and is reachable only from this computer. The switch at the bottom right of Situation returns to the IRIS globe, and IRIS uses its globe when you ask her to show a place. Set `[worldmonitor] port = 0` in `config\settings.toml` to turn it off.

## Tablet

A tablet or another screen at home can show IRIS over your Wi-Fi while IRIS runs on this computer. Set `enabled = true` under `[tablet]` in `config\settings.toml` and restart IRIS; allow it on Private networks if Windows Firewall asks. In Settings, choose Pair a tablet, open the address it shows on the tablet and type the six-digit code within five minutes. A paired screen shows the core and the Command Center. It can talk, type, play music, choose the brain (Unbound included), turn Quiet on or off, deny anything and use Emergency stop. It also shows Situation, with the IRIS globe and World Monitor, which reaches the tablet through port 8771 and only for paired screens. Its Settings open with the PIN (the same one as Unbound) and stay open for ten minutes; pairing screens and taking control stay on this computer. Allow TCP 8771 on Private networks in Windows Firewall, as for 8770. Commands and Windows control are allowed only on this computer, and settings, accounts and memory stay here too. Remove a screen in Settings at any time. Traffic on your Wi-Fi is not encrypted, so use this only on your own home network. For a wall panel, open the address in Fully Kiosk Browser.

## IRIS Pod

The IRIS Pod is a 3.5" ESP32-S3 touch board with a speaker, running the open XiaoZhi firmware. IRIS is its server: nothing goes to XiaoZhi's own servers. IRIS listens for it on port 8772 on the home network (`[pod] port`, or `enabled = false` to turn it off).

1. Allow the port once, in PowerShell as administrator: `New-NetFirewallRule -DisplayName "IRIS Pod" -Direction Inbound -Protocol TCP -LocalPort 8772 -Profile Private -Action Allow`
2. On the Pod's Wi-Fi page (its own hotspot, `http://192.168.4.1`), choose the home Wi-Fi and set the custom OTA address to the one shown in Settings, IRIS Pod.
3. The Pod shows six digits. Type them in Settings, IRIS Pod, within 15 minutes.

Tap the screen to talk. What you say goes through IRIS like a typed message, with the same brain, approvals and limits. Replies are spoken by the ElevenLabs voice when it is on, otherwise by the local voice.

## Security check

Run `scripts\setup-security.ps1` once. It installs YARA with the community malware rules (github.com/Yara-Rules/rules) and Trivy. Before IRIS opens a file in the workspace or your added folders, YARA checks it. If it matches a malware rule, IRIS asks you first, because generic rules sometimes match ordinary files. Nothing is deleted. Once a week, and when you press Check now in Settings, Trivy looks for known vulnerabilities in IRIS's Python packages and World Monitor's Docker images, and YARA checks the workspace. IRIS tells you when something needs attention. Run the script again to update the rules.

## Topic cards

While IRIS talks about something she can put up to six cards around the core: articles, YouTube videos, numbers, small charts and notes about your own mail, events and files. Click a card to open it. Cards fade four minutes after IRIS goes quiet. Settings has a switch to turn them off.

## Browser and scans

IRIS has its own hidden Edge or Chrome window with no sign-ins. It can reach only public websites, so pages cannot touch this computer or the home network. Opening a page, clicking and typing each need approval. IRIS refuses to fill in passwords or card numbers and refuses to press buttons that spend money. Everything from a visit is deleted when the browser closes, after 10 idle minutes or on emergency stop.

Scanned PDFs (first 30 pages) and pictures of text use the OCR built into Windows. If a Bosnian or Croatian OCR language is installed, IRIS uses it.

## Voice

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup-voice.ps1
powershell -ExecutionPolicy Bypass -File scripts\run-voice.ps1
```

Without an API key, voice mode repeats what it heard. `scripts\setup-voices.ps1` adds more speaking voices to the Voice screen.

## Development tasks

```text
/project add NAME "C:\path\to\repo" python -m pytest
/task NAME Add a health check
/review 1
/merge 1
/continue NAME Fix the failing test
```

Each task runs on its own branch in `data\tasks`. The project folder changes only after `/merge`. Merging is refused if tests failed or the project has uncommitted changes.

You can also ask IRIS to start or check a task in chat or by voice. It asks for approval, runs the task in the background and tells you when it ends. Only `/merge` can merge.

## Monitoring

`scripts\run-monitor.ps1` watches disk space and chosen processes, logs changes to `data\alerts.jsonl` and writes a daily briefing. Configure it in `config\settings.toml`. It uses no API credits. `/briefing` shows the same summary in chat.

## Safety

- IRIS works only inside `workspace\`.
- Reading in the workspace and web search run without approval. Writes, edits, commands and web page fetches ask first.
- Paths outside the workspace, secret files and known destructive commands are refused.
- `Ctrl+Alt+Shift+X` or `scripts\stop.ps1` stops work from another window. `scripts\clear-stop.ps1` clears the stop.
- Actions are logged in `data\audit\audit.jsonl`. `python -m iris --verify-audit` checks the log.
- Each test run of a development task asks for approval, because tests execute code the task wrote. The stop ends a running test.
- Approved commands run with your Windows account and can reach beyond the workspace, so read each request before you approve it.
