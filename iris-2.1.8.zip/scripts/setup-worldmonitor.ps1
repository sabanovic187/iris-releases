# Installs or updates World Monitor beside IRIS, in the worldmonitor folder. Run it again to update.
# Needs Docker Desktop (running), Git for Windows and Node.js 24. World Monitor stays on this computer only.
param(
    [int]$Port = 3000,
    [switch]$NoSeed
)
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
$root = Get-Location
$folder = Join-Path $root "worldmonitor"

function Need($command, $hint) {
    if (-not (Get-Command $command -ErrorAction SilentlyContinue)) { throw "$command is missing. $hint" }
}
function Secret {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    -join ($bytes | ForEach-Object { $_.ToString("x2") })
}

Need git "Install Git for Windows from git-scm.com."
Need docker "Install Docker Desktop from docker.com and start it."
Need node "Install Node.js 24 LTS from nodejs.org."
docker info *> $null
if ($LASTEXITCODE -ne 0) { throw "Docker Desktop is not running. Start it, wait until it says Running, then try again." }
$nodeVersion = [version]((node --version).TrimStart("v"))
if ($nodeVersion -lt [version]"22.19") { throw "Node.js $nodeVersion is too old. Install Node.js 24 LTS." }

# Git for Windows turns line endings into Windows ones by default. That breaks World Monitor's
# Linux build and even damages some of its pictures, so its files are kept exactly as published.
if (Test-Path (Join-Path $folder ".git")) {
    "Updating World Monitor..."
    if ((git -C $folder config core.autocrlf) -ne "false") {
        "Restoring its files with their original line endings..."
        git -C $folder config core.autocrlf false
        git -C $folder rm -r --cached --quiet .
        git -C $folder reset --hard --quiet
    }
    git -C $folder pull --ff-only
} else {
    "Downloading World Monitor..."
    git -c core.autocrlf=false clone --depth 1 https://github.com/koala73/worldmonitor.git $folder
}
if ($LASTEXITCODE -ne 0) { throw "Git could not get World Monitor." }

$envFile = Join-Path $folder ".env"
if (-not (Test-Path $envFile)) {
    @(
        "RELAY_SHARED_SECRET=$(Secret)",
        "REDIS_PASSWORD=$(Secret)",
        "REDIS_TOKEN=$(Secret)",
        "WM_SESSION_SECRET=$(Secret)",
        "WM_PORT=$Port"
    ) | Set-Content -Path $envFile -Encoding ascii
    "Created its private settings file."
}

& ".venv\Scripts\python.exe" -m iris.worldmonitor --port $Port
if ($LASTEXITCODE -ne 0) { throw "IRIS could not prepare World Monitor." }

Push-Location $folder
try {
    "Installing its tools (a few minutes the first time)..."
    npm ci --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { throw "npm could not install World Monitor's tools." }
    "Building and starting it in Docker (10 to 20 minutes the first time)..."
    docker compose up -d --build
    if ($LASTEXITCODE -ne 0) { throw "Docker could not start World Monitor." }
    if (-not $NoSeed) {
        $bash = Join-Path ${env:ProgramFiles} "Git\bin\bash.exe"
        if (Test-Path $bash) {
            "Loading the first data..."
            & $bash scripts/run-seeders.sh
        } else {
            "Git Bash was not found, so the first data was not loaded. World Monitor fills in over time."
        }
    }
} finally {
    Pop-Location
}
"World Monitor is running at http://127.0.0.1:$Port. Restart IRIS and open Situation."
