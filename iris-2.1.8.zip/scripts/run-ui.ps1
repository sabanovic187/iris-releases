Set-Location (Split-Path $PSScriptRoot -Parent)
# Exit code 3 means IRIS installed an update and wants to start again.
do {
    & ".venv\Scripts\python.exe" -m iris.ui @args
    $code = $LASTEXITCODE
} while ($code -eq 3)
