# Adds more speaking voices. They appear on the Voice screen after this finishes.
Set-Location (Split-Path $PSScriptRoot -Parent)
$python = ".venv\Scripts\python.exe"
foreach ($voice in "en_GB-alba-medium", "en_GB-northern_english_male-medium", "en_US-amy-medium", "en_US-ryan-medium") {
    if (-not (Test-Path "data\voices\$voice.onnx")) {
        & $python -m piper.download_voices $voice --download-dir "data\voices"
    }
}
"Voices ready. Open the Voice screen in IRIS."
