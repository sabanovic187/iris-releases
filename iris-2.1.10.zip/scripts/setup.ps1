$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

if (Get-Command py -ErrorAction SilentlyContinue) { $py = "py"; $pyArgs = @("-3") } else { $py = "python"; $pyArgs = @() }
$version = & $py @pyArgs -c "import sys; print('%d.%d' % sys.version_info[:2])"
if ([version]$version -lt [version]"3.11") { throw "Python 3.11 or newer is required. Found $version." }

if (-not (Test-Path ".venv")) { & $py @pyArgs -m venv .venv }
& ".venv\Scripts\python.exe" -m pip install --upgrade pip
& ".venv\Scripts\python.exe" -m pip install -r requirements.txt pytest pytest-asyncio
if ($LASTEXITCODE -ne 0) { throw "Installation failed." }

if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }

if ((Get-Command git -ErrorAction SilentlyContinue) -and -not (Test-Path ".git")) {
    git init -b main
    git add .
    git -c user.name="IRIS Setup" -c user.email="iris@localhost" commit -m "Initial IRIS core"
}

& ".venv\Scripts\python.exe" -m pytest -q
if ($LASTEXITCODE -ne 0) { throw "Tests failed." }
Write-Host ""
Write-Host "Setup finished. Add your key to .env, then run scripts\run.ps1"
