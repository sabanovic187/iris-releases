# Installs or updates World Monitor. The usual way is IRIS Settings, Add-ons, World Monitor;
# this does the same from a terminal.
param([int]$Port = 3000, [switch]$NoSeed)
$root = Split-Path $PSScriptRoot -Parent
$script = @("data\addons\worldmonitor\install.ps1", "addons\worldmonitor\install.ps1") |
    ForEach-Object { Join-Path $root $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $script) { throw "Install World Monitor from IRIS Settings, Add-ons." }
& $script -Root $root -Port $Port -NoSeed:$NoSeed
exit $LASTEXITCODE
