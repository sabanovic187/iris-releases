# One-time setup for publishing IRIS updates. Run on the owner's computer only.
#
# Makes two keys and walks you through putting them where they belong:
#   1. the release signing key   -> GitHub secret IRIS_RELEASE_KEY in sabanovic187/IRIS
#   2. the publishing deploy key -> GitHub secret RELEASES_DEPLOY_KEY in sabanovic187/IRIS,
#                                   and its public half as a deploy key (write) in sabanovic187/iris-releases
# The private keys go only to your clipboard and then to GitHub; they are deleted from this computer
# at the end. Nothing secret is shown on screen. At the end you get the PUBLIC signing key, which is
# safe to share: it goes into IRIS's code so every IRIS can check that updates come from you.
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$python = Join-Path $root ".venv\Scripts\python.exe"
$work = Join-Path $env:TEMP ("iris-keys-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $work | Out-Null

function Step([string]$text, [string]$clip, [string]$url) {
    Set-Clipboard -Value $clip
    Write-Host ""
    Write-Host $text -ForegroundColor Cyan
    Start-Process $url
    Read-Host "Paste it there (Ctrl+V), save, then press Enter here"
}

try {
    & $python -m pip install -q cryptography
    $signing = & $python -c @"
import base64
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization as s
k = Ed25519PrivateKey.generate()
print(base64.b64encode(k.private_bytes(s.Encoding.Raw, s.PrivateFormat.Raw, s.NoEncryption())).decode())
print(base64.b64encode(k.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)).decode())
"@
    $private, $public = $signing -split "`r?`n" | Where-Object { $_ }

    $deploy = Join-Path $work "deploy"
    ssh-keygen -q -t ed25519 -N '""' -C "iris-releases publishing" -f $deploy
    if (-not (Test-Path $deploy)) { ssh-keygen -q -t ed25519 -N "" -C "iris-releases publishing" -f $deploy }

    Write-Host "First make the public repository sabanovic187/iris-releases (Public, add a README) if it does not exist yet." -ForegroundColor Yellow
    Start-Process "https://github.com/new?name=iris-releases&visibility=public"
    Read-Host "Press Enter when the repository exists"

    Step "1/3  New secret in IRIS: name IRIS_RELEASE_KEY, value is in your clipboard." $private "https://github.com/sabanovic187/IRIS/settings/secrets/actions/new"
    Step "2/3  New secret in IRIS: name RELEASES_DEPLOY_KEY, value is in your clipboard." ((Get-Content $deploy) -join "`n") "https://github.com/sabanovic187/IRIS/settings/secrets/actions/new"
    Step "3/3  New deploy key in iris-releases: title IRIS publishing, key is in your clipboard, tick Allow write access." (Get-Content "$deploy.pub") "https://github.com/sabanovic187/iris-releases/settings/keys/new"

    Set-Clipboard -Value $public
    Write-Host ""
    Write-Host "Done. The PUBLIC signing key is in your clipboard. Send it to Claude so IRIS can trust your updates:" -ForegroundColor Green
    Write-Host $public
} finally {
    Remove-Item -Recurse -Force $work -ErrorAction SilentlyContinue
    $private = $null
}
