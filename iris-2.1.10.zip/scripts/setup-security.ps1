# Installs the read-only security checks: YARA with community malware rules, and Trivy.
# Run it again to update the rules. Nothing here deletes or changes your files.
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
$tools = Join-Path (Get-Location) "tools"
New-Item -ItemType Directory -Force -Path $tools | Out-Null

"Installing YARA for IRIS..."
& ".venv\Scripts\python.exe" -m pip install --quiet yara-python==4.5.4
if ($LASTEXITCODE -ne 0) { throw "YARA could not be installed." }

$rules = Join-Path $tools "yara-rules"
if (Test-Path (Join-Path $rules ".git")) {
    "Updating the malware rules..."
    git -C $rules pull --ff-only
} else {
    "Downloading the malware rules (github.com/Yara-Rules/rules, GPL-2.0)..."
    git clone --depth 1 https://github.com/Yara-Rules/rules.git $rules
}
if ($LASTEXITCODE -ne 0) { throw "Git could not get the malware rules." }

if (Get-Command trivy -ErrorAction SilentlyContinue) {
    "Trivy is already installed."
} elseif (Get-Command winget -ErrorAction SilentlyContinue) {
    "Installing Trivy..."
    winget install --id AquaSecurity.Trivy --exact --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        "Trivy could not be installed with winget. Download trivy_*_windows-64bit.zip from github.com/aquasecurity/trivy/releases and put trivy.exe in tools\trivy."
    }
} else {
    "Download trivy_*_windows-64bit.zip from github.com/aquasecurity/trivy/releases and put trivy.exe in tools\trivy."
}
"Done. Restart IRIS, then press Check now under Security check in Settings."
