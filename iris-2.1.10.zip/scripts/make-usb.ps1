# Puts the newest signed IRIS on a USB drive (or any folder), ready for "Install IRIS.cmd".
# Usage: powershell -ExecutionPolicy Bypass -File scripts\make-usb.ps1 E:\
param([Parameter(Mandatory = $true)][string]$Destination)
$ErrorActionPreference = "Stop"
$channel = "https://raw.githubusercontent.com/sabanovic187/iris-releases/main"
$folder = Join-Path $Destination "IRIS"
New-Item -ItemType Directory -Force -Path $folder | Out-Null
Invoke-WebRequest "$channel/latest.json" -OutFile (Join-Path $folder "latest.json") -UseBasicParsing
$manifest = Get-Content (Join-Path $folder "latest.json") -Raw | ConvertFrom-Json
"Downloading IRIS $($manifest.version)..."
Get-ChildItem $folder -Filter "iris-*.zip" | Remove-Item -Force
Invoke-WebRequest "$channel/$($manifest.file)" -OutFile (Join-Path $folder $manifest.file) -UseBasicParsing
if ((Get-FileHash (Join-Path $folder $manifest.file) -Algorithm SHA256).Hash.ToLower() -ne $manifest.sha256) {
    throw "The download does not match the signed release."
}
Copy-Item (Join-Path $PSScriptRoot "usb\*") $folder -Force
"Ready: $folder. On the other computer open that folder and double-click 'Install IRIS.cmd'."
