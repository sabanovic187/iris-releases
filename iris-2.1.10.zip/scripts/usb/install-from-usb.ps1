# Unpacks the IRIS package from this drive into the user's IRIS folder and runs its installer.
# The package's checksum is checked against latest.json first. An IRIS that is already installed
# keeps its owner's data, keys and memory: only IRIS's own files are replaced.
$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
$manifest = Get-Content (Join-Path $here "latest.json") -Raw | ConvertFrom-Json
$package = Join-Path $here $manifest.file
if (-not (Test-Path $package)) { throw "$($manifest.file) is missing from this drive." }
$hash = (Get-FileHash $package -Algorithm SHA256).Hash.ToLower()
if ($hash -ne $manifest.sha256) { throw "The IRIS package on this drive is damaged or was changed. Make the drive again." }

$target = Join-Path $HOME "IRIS"
Write-Host "Installing IRIS $($manifest.version) into $target" -ForegroundColor Cyan
if ((Test-Path (Join-Path $target "data")) -or (Test-Path (Join-Path $target ".env"))) {
    Write-Host "IRIS is already here. Its owner's data and keys stay; only IRIS's own files are replaced."
}
New-Item -ItemType Directory -Force -Path $target | Out-Null
Expand-Archive -Path $package -DestinationPath $target -Force
Copy-Item (Join-Path $here "latest.json") (Join-Path $target "iris\release.json") -Force
& (Join-Path $target "scripts\install.ps1")

# The signature is checked with IRIS's own key once Python is there.
& (Join-Path $target ".venv\Scripts\python.exe") -c @"
import json, sys
from iris.update import check_manifest
check_manifest(json.load(open(sys.argv[1], encoding='utf-8')))
print('The package is signed by IRIS\'s publisher.')
"@ (Join-Path $target "iris\release.json")
