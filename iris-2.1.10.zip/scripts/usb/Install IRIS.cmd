@echo off
rem Installs IRIS from this drive. Double-click it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-from-usb.ps1"
pause
