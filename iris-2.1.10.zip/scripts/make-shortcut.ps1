# Puts an IRIS icon on the desktop and in the Start menu. One click starts Docker (World Monitor),
# Ollama and IRIS. Run once: powershell -ExecutionPolicy Bypass -File scripts\make-shortcut.ps1
$root = Split-Path $PSScriptRoot -Parent
$shell = New-Object -ComObject WScript.Shell
$places = @(
    [Environment]::GetFolderPath("Desktop"),
    (Join-Path ([Environment]::GetFolderPath("StartMenu")) "Programs")
)
foreach ($place in $places) {
    $link = $shell.CreateShortcut((Join-Path $place "IRIS.lnk"))
    $link.TargetPath = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $link.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $root 'scripts\start-iris.ps1')`""
    $link.WorkingDirectory = $root
    $link.IconLocation = Join-Path $root "scripts\iris.ico"
    $link.WindowStyle = 7  # the start window stays minimised in the taskbar
    $link.Description = "Start IRIS"
    $link.Save()
}
"IRIS icons made on the desktop and in the Start menu."
"Right-click the desktop icon and choose Pin to taskbar if you like."
