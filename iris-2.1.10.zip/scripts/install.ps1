# Installs IRIS on this computer from an unpacked IRIS package. Run by "Install IRIS.cmd" from a USB
# drive, or by hand. It never copies anyone's data or keys: IRIS starts clean and asks its new owner.
#
# What it does: Python 3.13 (with winget, if missing), IRIS's Python packages, the local voice,
# firewall rules for the tablet and the IRIS Pod (one administrator prompt), the desktop icon,
# and then it starts IRIS. Ollama (local brain) is optional: scripts\setup-ollama.ps1.
# Add-ons such as World Monitor are chosen later in IRIS Settings, Add-ons.
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root

function Step([string]$text) { Write-Host ""; Write-Host $text -ForegroundColor Cyan }

function Find-Python {
    foreach ($candidate in @(
        @("py", "-3.13"), @("py", "-3.12"), @("py", "-3.11"),
        @("python", $null),
        @((Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe"), $null)
    )) {
        $exe, $flag = $candidate
        if (-not (Get-Command $exe -ErrorAction SilentlyContinue) -and -not (Test-Path $exe)) { continue }
        $arguments = @($flag) | Where-Object { $_ }
        try {
            $version = & $exe @arguments -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
            if ($LASTEXITCODE -eq 0 -and [version]$version -ge [version]"3.11") { return ,@($exe, $arguments) }
        } catch { }
    }
    return $null
}

Step "1/6  Python"
$python = Find-Python
if (-not $python) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw "Python 3.13 is needed. Install it from python.org (tick 'Add to PATH') and run this again."
    }
    winget install -e --id Python.Python.3.13 --scope user --silent --accept-package-agreements --accept-source-agreements
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "User") + ";" + [Environment]::GetEnvironmentVariable("Path", "Machine")
    $python = Find-Python
    if (-not $python) { throw "Python was installed but cannot be found yet. Sign out and in, then run this again." }
}
$exe, $arguments = $python
"Using $(& $exe @arguments --version)"

Step "2/6  IRIS's Python packages (a few minutes)"
if (-not (Test-Path ".venv")) { & $exe @arguments -m venv .venv }
$venv = Join-Path $root ".venv\Scripts\python.exe"
& $venv -m pip install --upgrade --quiet pip
& $venv -m pip install --quiet -r requirements.txt -r requirements-voice.txt -r requirements-tools.txt
if ($LASTEXITCODE -ne 0) { throw "IRIS's packages could not be installed. Check the internet connection and run this again." }
& $venv -m pip install --quiet --no-deps -r requirements-nodeps.txt
if ($LASTEXITCODE -ne 0) { throw "The wake word package could not be installed." }

Step "3/6  IRIS's voice"
New-Item -ItemType Directory -Force -Path "data\voices" | Out-Null
if (-not (Test-Path "data\voices\en_GB-alan-medium.onnx")) {
    & $venv -m piper.download_voices en_GB-alan-medium --download-dir "data\voices"
}
& $venv -c "from iris.voice.wake import ensure_models; ensure_models()"

Step "4/6  Tablet and IRIS Pod on the home network (Windows asks for permission once)"
$rules = @'
foreach ($rule in @(@{n="IRIS tablet"; p="8770-8771"}, @{n="IRIS Pod"; p="8772"})) {
    if (-not (Get-NetFirewallRule -DisplayName $rule.n -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName $rule.n -Direction Inbound -Protocol TCP -LocalPort $rule.p -Profile Private -RemoteAddress LocalSubnet -Action Allow | Out-Null
    }
}
'@
try {
    Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList "-NoProfile", "-Command", $rules
    "Firewall rules are in place."
} catch {
    "Skipped. The tablet and the Pod need these rules; run this installer again to add them."
}

Step "5/6  The IRIS icon"
& (Join-Path $PSScriptRoot "make-shortcut.ps1")

Step "6/6  Starting IRIS"
"IRIS opens in a moment and asks how to address you, your city and your Claude key."
Start-Process powershell -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$(Join-Path $PSScriptRoot 'start-iris.ps1')`"" -WindowStyle Minimized
