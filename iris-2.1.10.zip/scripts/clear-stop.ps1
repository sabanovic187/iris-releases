Set-Location (Split-Path $PSScriptRoot -Parent)
& ".venv\Scripts\python.exe" -m iris --clear-stop
