# Creates the model IRIS uses for the local brain. Your other Ollama models are not changed.
param(
    [string]$BaseModel = "qwen3:8b",
    [int]$Context = 16384
)
Set-Location (Split-Path $PSScriptRoot -Parent)
$file = Join-Path $env:TEMP "iris-local.Modelfile"
"FROM $BaseModel`nPARAMETER num_ctx $Context" | Set-Content -Path $file -Encoding ascii
ollama create iris-local -f $file
Remove-Item $file
if ($LASTEXITCODE -eq 0) { "Ready. Choose Local (Ollama) in IRIS Settings." }
