$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
& ".venv\Scripts\python.exe" -m pip install "comtypes>=1.4,<2" "pillow>=13,<14"
if ($LASTEXITCODE -ne 0) { throw "Installation failed." }
& ".venv\Scripts\python.exe" -m pytest -q
if ($LASTEXITCODE -ne 0) { throw "Tests failed." }
& ".venv\Scripts\python.exe" -m iris.windows_test
