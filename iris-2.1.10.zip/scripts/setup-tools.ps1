Set-Location (Split-Path $PSScriptRoot -Parent)
& ".venv\Scripts\python.exe" -m pip install -r requirements-tools.txt
if ($LASTEXITCODE -eq 0) { "Ready. Restart IRIS." }
