$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
$python = ".venv\Scripts\python.exe"
& $python -m pip install --no-deps -r requirements-nodeps.txt
if ($LASTEXITCODE -ne 0) { throw "Installation failed." }
& $python -m pip install -r requirements-voice.txt
if ($LASTEXITCODE -ne 0) { throw "Installation failed." }
New-Item -ItemType Directory -Force -Path "data\voices" | Out-Null
if (-not (Test-Path "data\voices\en_GB-alan-medium.onnx")) {
    & $python -m piper.download_voices en_GB-alan-medium --download-dir "data\voices"
    if ($LASTEXITCODE -ne 0) { throw "Voice download failed." }
}
& $python -m pytest -q
if ($LASTEXITCODE -ne 0) { throw "Tests failed." }
Write-Host ""
Write-Host "Voice setup finished. Run scripts\run-voice.ps1"
