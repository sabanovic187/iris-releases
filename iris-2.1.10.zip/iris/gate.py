"""Every tool call passes through here before it runs."""
from __future__ import annotations

import asyncio
import json
from typing import Any, Awaitable, Callable

from iris.audit import AuditLog
from iris.policy import Decision, Policy
from iris.stop import EmergencyStop

MAX_PREVIEW = 20000

Approver = Callable[[str, dict[str, Any], str], Awaitable[bool]]


def approval_preview(args: dict[str, Any]) -> tuple[str, bool]:
    """Show short fields first, so a long field cannot push a recipient out of view."""
    ordered = dict(sorted(args.items(), key=lambda item: len(json.dumps(item[1], ensure_ascii=False, default=str))))
    text = json.dumps(ordered, ensure_ascii=False, indent=2, default=str)
    if len(text) > MAX_PREVIEW:
        return text[:MAX_PREVIEW] + "\n...[shortened]", True
    return text, False


class ToolGate:
    def __init__(
        self,
        policy: Policy,
        audit: AuditLog,
        stop: EmergencyStop,
        approver: Approver,
        file_check: Callable[[str, dict[str, Any]], list[str]] | None = None,
    ) -> None:
        self.file_check = file_check
        self.policy = policy
        self.audit = audit
        self.stop = stop
        self.approver = approver
        self._results: dict[str, tuple[bool, str]] = {}
        self._lock = asyncio.Lock()

    async def check(self, tool: str, args: dict[str, Any], tool_use_id: str | None) -> tuple[bool, str]:
        """Return (allowed, reason). Any failure counts as a refusal."""
        async with self._lock:
            if tool_use_id and tool_use_id in self._results:
                return self._results[tool_use_id]
            try:
                result = await self._decide(tool, args)
            except Exception as error:  # fail closed
                result = (False, f"permission check failed: {type(error).__name__}")
            self.audit.write(
                "tool_decision",
                tool=tool,
                args=args,
                tool_use_id=tool_use_id,
                allowed=result[0],
                reason=result[1],
            )
            if tool_use_id:
                self._results[tool_use_id] = result
            return result

    async def _decide(self, tool: str, args: dict[str, Any]) -> tuple[bool, str]:
        if self.stop.active:
            return False, self.stop.blocked_reason
        verdict = self.policy.evaluate(tool, args)
        if verdict.decision is Decision.DENY:
            return False, verdict.reason
        reason = verdict.reason
        rules = await asyncio.to_thread(self.file_check, tool, args) if self.file_check else []
        if rules:
            # A match may be a false alarm, so the owner decides instead of IRIS deleting or hiding anything.
            self.audit.write("malware_rule_match", tool=tool, rules=rules)
            reason = f"This file matches malware rules ({', '.join(rules[:5])}). Open it only if you trust it."
        elif verdict.decision is Decision.ALLOW:
            return True, verdict.reason
        approved = await self.approver(tool, args, reason)
        if self.stop.active:
            return False, self.stop.blocked_reason
        return (True, "approved by owner") if approved else (False, "declined by owner")
