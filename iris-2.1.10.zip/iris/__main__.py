from iris.cli import main

raise SystemExit(main())
