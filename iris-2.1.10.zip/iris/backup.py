"""Makes a zip of what IRIS has learned. Secrets stay out of it."""
from __future__ import annotations

import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

KEEP = 10
PLAIN_FILES = (
    "audit/audit.jsonl",
    "alerts.jsonl",
    "connectors/folders.json",
    "connectors/watches.json",
)


def make_backup(data_dir: Path, root: Path) -> Path:
    folder = data_dir / "backups"
    folder.mkdir(exist_ok=True)
    target = folder / f"iris-{datetime.now():%Y%m%d-%H%M%S}.zip"
    with tempfile.TemporaryDirectory() as temp:
        copy = Path(temp) / "iris.db"
        source = sqlite3.connect(data_dir / "iris.db")
        destination = sqlite3.connect(copy)
        with destination:
            source.backup(destination)
        source.close()
        destination.close()
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.write(copy, "data/iris.db")
            for name in PLAIN_FILES:
                path = data_dir / name
                if path.exists():
                    archive.write(path, f"data/{name}")
            archive.write(root / "config" / "settings.toml", "config/settings.toml")
            if (data_dir / "settings.toml").exists():
                archive.write(data_dir / "settings.toml", "data/settings.toml")
            for path in sorted((root / "skills").glob("*.md")):
                archive.write(path, f"skills/{path.name}")
    for old in sorted(folder.glob("iris-*.zip"))[:-KEEP]:
        old.unlink()
    return target
