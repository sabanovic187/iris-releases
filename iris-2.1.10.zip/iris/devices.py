"""Tablets and other screens the owner paired with IRIS over the home network.

Pairing needs a six-digit code that IRIS shows on the computer for five minutes. Five wrong
codes end it. Each paired screen gets its own long random key; only a hash of it is stored, so
the file cannot be used to sign in, and any screen can be removed at any time.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import threading
import time
from pathlib import Path
from typing import Any

CODE_SECONDS = 300
CODE_TRIES = 5
SEEN_EVERY_SECONDS = 60
MAX_DEVICES = 10


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class PairedDevices:
    def __init__(self, path: Path, clock: Any = time.time) -> None:
        self.path = path
        self.clock = clock
        self.lock = threading.Lock()
        self.code: dict[str, Any] | None = None

    def _load(self) -> list[dict[str, Any]]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        return [item for item in data if isinstance(item, dict) and "hash" in item] if isinstance(data, list) else []

    def _save(self, devices: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(devices, indent=1), encoding="utf-8")
        temporary.replace(self.path)

    def start_pairing(self) -> str:
        with self.lock:
            code = f"{secrets.randbelow(1_000_000):06d}"
            self.code = {"code": code, "until": self.clock() + CODE_SECONDS, "tries": CODE_TRIES}
            return code

    def stop_pairing(self) -> None:
        with self.lock:
            self.code = None

    def pairing_open(self) -> bool:
        with self.lock:
            return bool(self.code and self.clock() < self.code["until"])

    def pair(self, code: str, name: str) -> str | None:
        """Returns the new screen's key, or None for a wrong or expired code."""
        with self.lock:
            waiting = self.code
            if not waiting or self.clock() >= waiting["until"]:
                self.code = None
                return None
            if not hmac.compare_digest(str(code).strip().encode(), waiting["code"].encode()):
                waiting["tries"] -= 1
                if waiting["tries"] <= 0:
                    self.code = None
                return None
            self.code = None
            devices = self._load()
            if len(devices) >= MAX_DEVICES:
                return None
            token = secrets.token_urlsafe(32)
            label = " ".join(str(name or "").split())[:40] or "Tablet"
            devices.append({"id": secrets.token_hex(6), "name": label, "hash": _hash(token), "paired": self.clock(), "seen": self.clock()})
            self._save(devices)
            return token

    def check(self, token: str) -> dict[str, Any] | None:
        if not token or len(token) > 200:
            return None
        wanted = _hash(token)
        with self.lock:
            devices = self._load()
            for device in devices:
                if hmac.compare_digest(device["hash"], wanted):
                    if self.clock() - float(device.get("seen", 0)) > SEEN_EVERY_SECONDS:
                        device["seen"] = self.clock()
                        self._save(devices)
                    return {"id": device["id"], "name": device["name"]}
        return None

    def listing(self) -> list[dict[str, Any]]:
        with self.lock:
            return [{"id": d["id"], "name": d["name"], "paired": d.get("paired"), "seen": d.get("seen")} for d in self._load()]

    def remove(self, device_id: str) -> bool:
        with self.lock:
            devices = self._load()
            kept = [device for device in devices if device["id"] != device_id]
            if len(kept) == len(devices):
                return False
            self._save(kept)
            return True
