"""Checks Windows app control without Claude: python -m iris.windows_test"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time

from iris.config import load_settings


class Server:
    def __init__(self, root: str) -> None:
        self.process = subprocess.Popen(
            [sys.executable, "-m", "iris.windows_server"],
            cwd=root,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
            encoding="utf-8",
        )
        self.next_id = 0

    def call(self, method: str, params: dict | None = None) -> dict:
        self.next_id += 1
        message = {"jsonrpc": "2.0", "id": self.next_id, "method": method, "params": params or {}}
        self.process.stdin.write(json.dumps(message) + "\n")
        self.process.stdin.flush()
        reply = json.loads(self.process.stdout.readline())
        if "error" in reply and reply["error"]:
            raise RuntimeError(reply["error"])
        return reply["result"]

    def tool(self, name: str, **arguments: object) -> str:
        result = self.call("tools/call", {"name": name, "arguments": arguments})
        text = "\n".join(
            part.get("text") or part.get("data", "") for part in result.get("content", [])
        )
        if result.get("isError"):
            raise RuntimeError(text)
        return text

    def close(self) -> None:
        self.process.stdin.close()
        self.process.wait(timeout=10)


def handle_from(text: str) -> str:
    for line in text.splitlines():
        if line.startswith("Window handle:"):
            return line.split(":", 1)[1].strip()
    raise RuntimeError(f"No window handle in: {text}")


def find_ref(snapshot: str, kind: str, name: str) -> str:
    match = re.search(rf'{kind} "{re.escape(name)}" \[ref=(e\d+)\]', snapshot)
    if not match:
        raise RuntimeError(f'{kind} "{name}" was not found')
    return match.group(1)


def act(server: Server) -> None:
    """Click real Calculator buttons, then type in a real Notepad window."""
    handle = handle_from(server.tool("windows_launch", app="calc.exe"))
    for name in ("Clear", "Seven", "Plus", "Two", "Equals"):
        snapshot = server.tool("windows_snapshot", handle=handle)
        server.tool("windows_click", ref=find_ref(snapshot, "button", name))
        time.sleep(0.2)
    snapshot = server.tool("windows_snapshot", handle=handle)
    server.tool("windows_close", handle=handle)
    if "Display is 9" not in snapshot:
        raise RuntimeError("Calculator did not show 9")
    print("Clicks worked: 7 + 2 = 9")

    handle = handle_from(server.tool("windows_launch", app="notepad.exe"))
    snapshot = server.tool("windows_snapshot", handle=handle)
    match = re.search(r'(?:document|edit)[^\n]*\[ref=(e\d+)\]', snapshot)
    if not match:
        raise RuntimeError("Notepad text area was not found")
    server.tool("windows_type", ref=match.group(1), text="IRIS typing test")
    time.sleep(0.3)
    if "IRIS typing test" not in server.tool("windows_get_text", ref=match.group(1)):
        raise RuntimeError("Notepad did not receive the text")
    print("Typing worked. Close Notepad and do not save.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--act", action="store_true", help="click and type in real apps")
    options = parser.parse_args()
    settings = load_settings()
    server = Server(str(settings.root))
    try:
        if options.act:
            server.call("initialize", {"protocolVersion": "2024-11-05", "capabilities": {}})
            act(server)
            print("WINDOWS ACTION TEST PASSED")
            return 0
        server.call("initialize", {"protocolVersion": "2024-11-05", "capabilities": {}})
        tools = [tool["name"] for tool in server.call("tools/list")["tools"]]
        print(f"Tools found: {len(tools)}")
        launched = server.tool("windows_launch", app="calc.exe")
        print(launched)
        handle = handle_from(launched)
        snapshot = server.tool("windows_snapshot", handle=handle)
        print(f"Snapshot received: {len(snapshot.splitlines())} lines")
        print("\n".join(snapshot.splitlines()[:8]))
        image = server.tool("windows_screenshot", handle=handle)
        print(f"Screenshot received: {len(image) * 3 // 4 // 1024} KB, not saved")
        print(server.tool("windows_close", handle=handle))
        print("WINDOWS CONTROL TEST PASSED")
        return 0
    except Exception as error:
        print(f"WINDOWS CONTROL TEST FAILED: {error}", file=sys.stderr)
        return 1
    finally:
        server.close()


if __name__ == "__main__":
    raise SystemExit(main())
