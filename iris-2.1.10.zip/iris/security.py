"""Read-only security checks.

YARA: community malware rules (github.com/Yara-Rules/rules) look at files before IRIS opens them.
A match never deletes anything; IRIS asks the owner first, because generic rules also match some
ordinary files.

Trivy: a weekly scan of IRIS's installed Python packages and World Monitor's Docker images for
known vulnerabilities. It only reports.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import threading
import time
import warnings
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import READ, Tool

RULE_FOLDERS = ("malware", "maldocs", "webshells", "exploit_kits", "cve_rules")
# Rules that also match ordinary programs, fonts and libraries. Measured on about 50,000 clean files.
NOISY_RULES = frozenset({
    "powershell", "maldoc_getEIP_method_1", "Rooter", "RooterStrings", "spyeye", "spyeye_plugins",
    "PoetRat_Python", "ppaction", "with_sqlite", "Surtr", "SurtrStrings", "rootkit",
    "function_through_object", "possible_exploit", "header_evasion", "PM_Email_Sent_By_PHP_Script",
    "maldoc_indirect_function_call_3", "php_obf_malfunctions", "Warp", "WarpStrings",
})
TRIVY_MISSING = "Trivy is not installed, so packages were not checked. Run scripts\\setup-security.ps1."
MAX_SCAN_BYTES = 200 * 1024 * 1024
SCAN_SECONDS = 20
TRIVY_SECONDS = 1800
WORLD_MONITOR_IMAGES = ("worldmonitor:latest", "worldmonitor-ais-relay:latest", "worldmonitor-redis-rest:latest", "redis:7-alpine")
FILE_ARGS = {
    "Read": "file_path",
    "mcp__connectors__document_read": "path",
    "mcp__connectors__files_read": "path",
    "mcp__connectors__media_transcribe_file": "path",
}


class YaraGuard:
    def __init__(self, rules_dir: Path, cache_dir: Path) -> None:
        self.rules_dir = rules_dir
        self.cache_dir = cache_dir
        self.rules: Any = None
        self.lock = threading.Lock()
        self.checked: dict[tuple[str, int, int], list[str]] = {}

    def available(self) -> bool:
        try:
            import yara  # noqa: F401
        except ImportError:
            return False
        return self.rules_dir.is_dir()

    def _load(self) -> Any:
        import yara

        with self.lock:
            if self.rules is not None:
                return self.rules
            compiled = self.cache_dir / "yara-rules.bin"
            sources = [path for folder in RULE_FOLDERS for path in sorted((self.rules_dir / folder).rglob("*.yar"))]
            newest = max((path.stat().st_mtime for path in sources), default=0)
            if compiled.exists() and compiled.stat().st_mtime >= newest:
                self.rules = yara.load(str(compiled))
                return self.rules
            usable = {}
            for index, path in enumerate(sources):
                try:
                    yara.compile(filepath=str(path))
                except yara.Error:
                    continue  # some community rules need modules this build does not have
                usable[f"r{index}"] = str(path)
            self.rules = yara.compile(filepaths=usable)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self.rules.save(str(compiled))
            return self.rules

    def scan(self, path: Path) -> list[str]:
        """Names of the rules a file matches. Empty when clean, unreadable, too big or YARA is missing."""
        try:
            info = path.stat()
        except OSError:
            return []
        if not path.is_file() or info.st_size > MAX_SCAN_BYTES or not self.available():
            return []
        key = (str(path), int(info.st_mtime), info.st_size)
        if key in self.checked:
            return self.checked[key]
        import yara

        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                found = sorted({match.rule for match in self._load().match(str(path), timeout=SCAN_SECONDS)} - NOISY_RULES)
        except yara.Error:
            found = []
        self.checked[key] = found
        return found


def file_in_call(tool: str, args: dict[str, Any], workspace: Path) -> Path | None:
    key = FILE_ARGS.get(tool)
    raw = str(args.get(key) or "") if key else ""
    if not raw:
        return None
    path = Path(raw).expanduser()
    return path if path.is_absolute() else workspace / path


def find_trivy(root: Path) -> str | None:
    found = shutil.which("trivy")
    if found:
        return found
    for name in ("trivy.exe", "trivy"):
        local = root / "tools" / "trivy" / name
        if local.exists():
            return str(local)
    return None


def _run(command: list[str], timeout: int = TRIVY_SECONDS) -> subprocess.CompletedProcess[str]:
    flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    return subprocess.run(command, capture_output=True, text=True, errors="replace", timeout=timeout, creationflags=flags)


def read_findings(report: dict[str, Any], source: str) -> list[dict[str, Any]]:
    found = []
    for result in report.get("Results") or []:
        for item in result.get("Vulnerabilities") or []:
            found.append({
                "source": source,
                "id": str(item.get("VulnerabilityID", ""))[:40],
                "package": str(item.get("PkgName", ""))[:80],
                "installed": str(item.get("InstalledVersion", ""))[:40],
                "fixed": str(item.get("FixedVersion", ""))[:80],
                "severity": str(item.get("Severity", "UNKNOWN")),
                "title": " ".join(str(item.get("Title", "")).split())[:160],
            })
    return found


class SecurityCheck:
    def __init__(
        self,
        root: Path,
        data_dir: Path,
        workspace: Path,
        guard: YaraGuard,
        run: Callable[[list[str]], subprocess.CompletedProcess[str]] = _run,
        trivy: Callable[[Path], str | None] = find_trivy,
    ) -> None:
        self.root = root
        self.folder = data_dir / "security"
        self.workspace = workspace
        self.guard = guard
        self.run = run
        self.trivy = trivy
        self.running = False

    @property
    def report_file(self) -> Path:
        return self.folder / "report.json"

    def last(self) -> dict[str, Any] | None:
        try:
            return json.loads(self.report_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def _packages(self) -> Path | None:
        """Trivy needs exact versions, so list what is really installed in IRIS's own Python."""
        listing = self.run([sys.executable, "-m", "pip", "freeze", "--local"])
        if listing.returncode != 0 or not listing.stdout.strip():
            return None
        target = self.folder / "packages"
        target.mkdir(parents=True, exist_ok=True)
        (target / "requirements.txt").write_text(listing.stdout, encoding="utf-8")
        return target

    def _trivy(self) -> tuple[list[dict[str, Any]], list[str]]:
        trivy = self.trivy(self.root)
        if not trivy:
            return [], [TRIVY_MISSING]
        findings: list[dict[str, Any]] = []
        notes: list[str] = []
        base = [trivy, "--quiet", "--format", "json", "--severity", "HIGH,CRITICAL"]
        packages = self._packages()
        targets = [("IRIS Python packages", ["fs", "--scanners", "vuln", str(packages)])] if packages else []
        if not packages:
            notes.append("IRIS's Python packages could not be listed.")
        if shutil.which("docker"):
            targets += [(f"World Monitor image {image}", ["image", image]) for image in WORLD_MONITOR_IMAGES if self._image_exists(image)]
        for label, args in targets:
            try:
                result = self.run(base[:1] + args[:1] + base[1:] + args[1:])
            except (OSError, subprocess.SubprocessError):
                notes.append(f"{label}: Trivy did not finish.")
                continue
            if result.returncode != 0:
                notes.append(f"{label}: Trivy reported a problem.")
                continue
            try:
                findings += read_findings(json.loads(result.stdout or "{}"), label)
            except ValueError:
                notes.append(f"{label}: Trivy's answer could not be read.")
        return findings, notes

    def _image_exists(self, image: str) -> bool:
        try:
            return self.run(["docker", "image", "inspect", image]).returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False

    def _workspace_files(self) -> list[dict[str, Any]]:
        hits = []
        if not self.guard.available() or not self.workspace.is_dir():
            return hits
        for path in self.workspace.rglob("*"):
            found = self.guard.scan(path) if path.is_file() else []
            if found:
                hits.append({"file": str(path.relative_to(self.workspace)), "rules": found})
        return hits

    def check(self) -> dict[str, Any]:
        self.running = True
        try:
            findings, notes = self._trivy()
            if not self.guard.available():
                notes.append("YARA is not installed. Run scripts\\setup-security.ps1.")
            report = {
                "time": time.time(),
                "findings": findings,
                "files": self._workspace_files(),
                "notes": notes,
            }
        finally:
            self.running = False
        self.folder.mkdir(parents=True, exist_ok=True)
        self.report_file.write_text(json.dumps(report, indent=1), encoding="utf-8")
        return report


def summary(report: dict[str, Any] | None) -> str:
    if not report:
        return "No security check has run yet."
    findings = report.get("findings", [])
    critical = [item for item in findings if item["severity"] == "CRITICAL"]
    fixable = [item for item in findings if item["fixed"]]
    when = time.strftime("%Y-%m-%d %H:%M", time.localtime(report.get("time", 0)))
    if TRIVY_MISSING in report.get("notes", []):
        lines = [f"Security check of {when}: files only."]
    else:
        lines = [f"Security check of {when}: {len(critical)} critical and {len(findings) - len(critical)} high known vulnerabilities, {len(fixable)} with an update available."]
    for item in sorted(findings, key=lambda entry: (entry["severity"] != "CRITICAL", entry["package"]))[:12]:
        fix = f", fixed in {item['fixed']}" if item["fixed"] else ", no fix yet"
        lines.append(f"- {item['severity'].title()} {item['id']} in {item['package']} {item['installed']}{fix} ({item['source']})")
    for hit in report.get("files", []):
        lines.append(f"- File {hit['file']} matches malware rules: {', '.join(hit['rules'])}")
    lines += [f"- {note}" for note in report.get("notes", [])]
    return "\n".join(lines)


def tools(check: SecurityCheck) -> list[Tool]:
    def report(_args: dict[str, Any]) -> str:
        return summary(check.last())

    return [Tool("security_report", "Read the latest weekly security check: known vulnerabilities in IRIS's packages and World Monitor's images, and workspace files matching malware rules.", {}, READ, report)]
