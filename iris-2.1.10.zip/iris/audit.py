"""Append-only audit log. Each entry carries the hash of the previous one."""
from __future__ import annotations

import hashlib
import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

MAX_TEXT = 500
SECRET_PATTERNS = [
    re.compile(r"sk-ant-[A-Za-z0-9_\-]+"),
    re.compile(r"sk-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?(-----END [A-Z ]*PRIVATE KEY-----|$)", re.S),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._~+/=-]+"),
    re.compile(r"GOCSPX-[A-Za-z0-9_\-]+"),
    re.compile(r"eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*"),
    re.compile(r"(?i)[\w-]*(password|passwd|pwd|secret|token|api[_-]?key)[\"']?\s*[:=]\s*[\"']?[^\s\"',}]+"),
]
SECRET_KEY = re.compile(r"(?i)(password|passwd|pwd|secret|token|api[_-]?key)$")
GENESIS = "0" * 64


def redact(text: str) -> str:
    for pattern in SECRET_PATTERNS:
        text = pattern.sub("[REDACTED]", text)
    return text


def clean(value: Any) -> Any:
    """Redact secrets and shorten long text before it reaches the log."""
    if isinstance(value, str):
        value = redact(value)
        return value if len(value) <= MAX_TEXT else value[:MAX_TEXT] + "...[truncated]"
    if isinstance(value, dict):
        return {
            str(key): "[REDACTED]" if SECRET_KEY.search(str(key)) else clean(item) for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [clean(item) for item in value]
    return value


def _digest(body: dict[str, Any]) -> str:
    text = json.dumps(body, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class AuditLog:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._last = self._read_last_hash()

    def _read_last_hash(self) -> str:
        if not self.path.exists():
            return GENESIS
        last = GENESIS
        with self.path.open(encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    last = json.loads(line)["hash"]
        return last

    def write(self, event: str, **fields: Any) -> None:
        with self._lock:
            body = {
                "time": datetime.now(timezone.utc).isoformat(),
                "event": event,
                "prev": self._last,
                **clean(fields),
            }
            entry = {**body, "hash": _digest(body)}
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
            self._last = entry["hash"]

    def verify(self) -> tuple[bool, int]:
        """Return (intact, entries checked). Stops at the first bad entry."""
        if not self.path.exists():
            return True, 0
        previous = GENESIS
        count = 0
        with self.path.open(encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                    claimed = entry.pop("hash")
                except (ValueError, KeyError):
                    return False, count
                if entry.get("prev") != previous or _digest(entry) != claimed:
                    return False, count
                previous = claimed
                count += 1
        return True, count
