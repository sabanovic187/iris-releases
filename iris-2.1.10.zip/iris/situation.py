"""Public world data for the Situation Room. It holds no information about private people."""
from __future__ import annotations

import urllib.parse
import urllib.request
import xml.etree.ElementTree as ElementTree
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Callable

from iris.connectors.base import ConnectorError, call_json
from iris.world import news_focus

QUAKES = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"
EVENTS = "https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=40"
WEATHER = "https://api.open-meteo.com/v1/forecast"
MAX_QUAKES = 60
MAX_NEWS = 60
NEWS_PER_FEED = 15
DEFAULT_FEEDS = (
    "https://feeds.bbci.co.uk/news/world/rss.xml",
    "https://www.aljazeera.com/xml/rss/all.xml",
    "https://www.theguardian.com/world/rss",
    "https://rss.dw.com/rdf/rss-en-world",
)
WEATHER_WORDS = (
    (0, "Clear"), (3, "Cloudy"), (48, "Fog"), (67, "Rain"), (77, "Snow"), (82, "Showers"), (86, "Snow showers"), (99, "Thunderstorm"),
)


def weather_word(code: int) -> str:
    for limit, word in WEATHER_WORDS:
        if code <= limit:
            return word
    return "Unknown"


def read_quakes(fetch: Callable[..., Any] = call_json) -> list[dict[str, Any]]:
    found = []
    for item in fetch("GET", QUAKES).get("features", []):
        props = item.get("properties", {})
        lon, lat = item["geometry"]["coordinates"][:2]
        if props.get("mag") is not None:
            found.append({
                "lat": lat, "lon": lon, "mag": props["mag"], "place": props.get("place") or "Unknown place",
                "time": datetime.fromtimestamp(props.get("time", 0) / 1000, timezone.utc).isoformat(),
            })
    found.sort(key=lambda item: item["mag"], reverse=True)
    return found[:MAX_QUAKES]


def read_events(fetch: Callable[..., Any] = call_json) -> list[dict[str, Any]]:
    found = []
    for item in fetch("GET", EVENTS).get("events", []):
        points = [point for point in item.get("geometry", []) if point.get("type") == "Point"]
        if points:
            lon, lat = points[-1]["coordinates"][:2]
            kind = (item.get("categories") or [{}])[0].get("title", "Event")
            found.append({"lat": lat, "lon": lon, "title": item.get("title", "Event"), "kind": kind})
    return found


def read_weather(lat: float, lon: float, fetch: Callable[..., Any] = call_json) -> dict[str, Any]:
    query = urllib.parse.urlencode({
        "latitude": lat, "longitude": lon, "current": "temperature_2m,wind_speed_10m,weather_code",
    })
    current = fetch("GET", f"{WEATHER}?{query}")["current"]
    return {
        "temperature": current["temperature_2m"],
        "wind": current["wind_speed_10m"],
        "sky": weather_word(int(current["weather_code"])),
    }


def _get_text(url: str) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": "IRIS-personal"})
    with urllib.request.urlopen(request, timeout=10) as response:
        return response.read(2 * 1024 * 1024).decode("utf-8", errors="replace")


def _safe_link(link: str | None) -> str:
    link = (link or "").strip()
    return link if link.startswith(("https://", "http://")) else ""


def _items(root: ElementTree.Element) -> list[ElementTree.Element]:
    return [item for item in root.iter() if item.tag.rsplit("}", 1)[-1] == "item"]


def _field(item: ElementTree.Element, name: str) -> str | None:
    return next((child.text for child in item if child.tag.rsplit("}", 1)[-1] == name), None)


def read_news(feeds: list[str], fetch_text: Callable[[str], str] = _get_text) -> list[dict[str, str]]:
    def fetch_one(feed: str) -> ElementTree.Element | None:
        try:
            return ElementTree.fromstring(fetch_text(feed))
        except (ElementTree.ParseError, OSError, ValueError):
            return None

    found: list[dict[str, str]] = []
    with ThreadPoolExecutor(max_workers=max(1, len(feeds))) as pool:
        roots = list(pool.map(fetch_one, feeds))
    for feed, root in zip(feeds, roots):
        if root is None:
            continue
        for item in _items(root)[:NEWS_PER_FEED]:
            title = _field(item, "title")
            if title:
                entry = {"title": title.strip(), "source": urllib.parse.urlsplit(feed).hostname or ""}
                link = _safe_link(_field(item, "link"))
                if link:
                    entry["link"] = link
                found.append(entry)
    return found[:MAX_NEWS]


def build_situation(config: dict[str, Any], fetch: Callable[..., Any] = call_json) -> dict[str, Any]:
    """Each source can fail alone. A failed source is left out and named."""
    lat, lon = float(config["lat"]), float(config["lon"])
    result: dict[str, Any] = {
        "place": config["place"], "lat": lat, "lon": lon, "quakes": [], "events": [], "news": [], "weather": None, "failed": [],
    }
    sources: dict[str, Callable[[], Any]] = {
        "quakes": lambda: read_quakes(fetch),
        "events": lambda: read_events(fetch),
        "weather": lambda: read_weather(lat, lon, fetch),
        "news": lambda: read_news(list(config.get("news_feeds") or DEFAULT_FEEDS)),
    }
    with ThreadPoolExecutor(max_workers=len(sources)) as pool:
        running = {name: pool.submit(source) for name, source in sources.items()}
    for name, job in running.items():
        try:
            result[name] = job.result()
        except (ConnectorError, KeyError, IndexError, TypeError, ValueError, OSError):
            result["failed"].append(name)
    result["focus"] = news_focus(result["news"])
    result["updated"] = datetime.now(timezone.utc).isoformat()
    return result
