"""Everyday commands IRIS can carry out at once, with no AI model."""
from __future__ import annotations

import re
from dataclasses import dataclass

MAX_LENGTH = 60
FILLER = re.compile(r"^(hey |ok |okay )?(iris[, ]+)?(please |can you |could you )?|[ ,]*(please|thanks|thank you)?[.!?]*$", re.I)
MUSIC = r"(the )?(music|song|track|spotify|playback|player)"
RULES: tuple[tuple[str, str], ...] = (
    ("pause", rf"pause( {MUSIC})?|stop {MUSIC}"),
    ("resume", rf"(play|resume|continue|start) {MUSIC}|resume|unpause"),
    ("next", rf"next|skip( this| it)?|skip {MUSIC}|next {MUSIC}"),
    ("previous", rf"previous|go back|previous {MUSIC}|last {MUSIC}"),
    ("quieter", r"(turn it |turn the music |volume )(down|lower)|quieter|lower the volume|turn (the )?volume down"),
    ("louder", r"(turn it |turn the music |volume )up|louder|raise the volume|turn (the )?volume up"),
    ("playing", rf"what('s| is) playing|what('s| is) this song|which song is this|what {MUSIC} is this"),
    ("time", r"what('s| is) the time|what time is it|tell me the time"),
    ("date", r"what('s| is) (the date|today'?s date)|what day is (it|today)"),
    ("quiet_on", r"(turn on |start |enable )?quiet mode( on)?|be quiet( for now)?|do not disturb( me)?|don't disturb me"),
    ("quiet_off", r"(turn off |stop |end |disable )quiet mode|quiet mode off|you can (talk|speak) again"),
    ("weather", r"what('s| is) the weather( like)?( today)?( outside)?|how('s| is) the weather( today)?"),
)
VOLUME = re.compile(r"(set )?(the )?volume( to)? (\d{1,3})( percent|%)?$", re.I)


@dataclass(frozen=True)
class Quick:
    action: str
    value: int = 0


def clean(text: str) -> str:
    return FILLER.sub("", text.strip()).strip().replace("’", "'")


def find(text: str) -> Quick | None:
    """Only a whole short sentence counts, so a longer request always reaches the brain."""
    if len(text) > MAX_LENGTH:
        return None
    line = FILLER.sub("", clean(text)).strip()
    volume = VOLUME.fullmatch(line)
    if volume:
        return Quick("volume", min(int(volume.group(4)), 100))
    for action, rule in RULES:
        if re.fullmatch(rule, line, re.I):
            return Quick(action)
    return None
