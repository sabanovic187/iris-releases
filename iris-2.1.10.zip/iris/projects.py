"""Projects and development tasks. Each task runs on its own branch in a separate folder."""
from __future__ import annotations

import asyncio
import dataclasses
import os
import shlex
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from iris.agent import Agent, budget_problem
from iris.audit import AuditLog
from iris.config import Settings
from iris.gate import Approver, ToolGate
from iris.memory import Memory
from iris.policy import Policy
from iris.stop import EmergencyStop

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects(
    name TEXT PRIMARY KEY, path TEXT NOT NULL, test_command TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS tasks(
    id INTEGER PRIMARY KEY, project TEXT NOT NULL, goal TEXT NOT NULL, status TEXT NOT NULL,
    base TEXT NOT NULL, branch TEXT NOT NULL, folder TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '',
    tests TEXT NOT NULL DEFAULT 'not run', created TEXT NOT NULL);
"""
OPEN = ("failed", "needs review")
TEST_TIMEOUT_SECONDS = 600
TEST_POLL_SECONDS = 0.5
GIT_USER = ["-c", "user.name=IRIS", "-c", "user.email=iris@localhost"]


class ProjectError(Exception):
    pass


def git(folder: Path, *args: str) -> str:
    done = subprocess.run(
        ["git", *GIT_USER, *args],
        cwd=folder,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if done.returncode != 0:
        raise ProjectError((done.stderr or done.stdout).strip())
    return done.stdout.strip()


class TaskManager:
    def __init__(
        self,
        settings: Settings,
        memory: Memory,
        audit: AuditLog,
        stop: EmergencyStop,
        approver: Approver,
    ) -> None:
        self.settings = settings
        self.memory = memory
        self.audit = audit
        self.stop = stop
        self.approver = approver
        self.db = memory.db
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.db.commit()

    def add_project(self, name: str, path: str, test_command: str = "") -> str:
        folder = Path(path).expanduser().resolve()
        if not folder.is_dir():
            raise ProjectError(f"{folder} is not a folder")
        try:
            top = Path(git(folder, "rev-parse", "--show-toplevel")).resolve()
        except (ProjectError, OSError):
            raise ProjectError(f"{folder} is not a Git repository") from None
        if top != folder:
            raise ProjectError(f"Use the repository root: {top}")
        self.db.execute(
            "INSERT INTO projects(name, path, test_command) VALUES(?, ?, ?) "
            "ON CONFLICT(name) DO UPDATE SET path = excluded.path, test_command = excluded.test_command",
            (name, str(folder), test_command),
        )
        self.db.commit()
        return f"Project {name} registered."

    def list_projects(self) -> str:
        rows = self.db.execute("SELECT * FROM projects ORDER BY name").fetchall()
        return "\n".join(f"{row['name']}: {row['path']}" for row in rows) or "No projects."

    def _project(self, name: str) -> sqlite3.Row:
        row = self.db.execute("SELECT * FROM projects WHERE name = ?", (name,)).fetchone()
        if row is None:
            raise ProjectError(f"Unknown project {name}. Use /project add first.")
        return row

    def _task(self, task_id: int) -> sqlite3.Row:
        row = self.db.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if row is None:
            raise ProjectError(f"No task {task_id}.")
        return row

    def _update(self, task_id: int, **fields: str) -> None:
        names = ", ".join(f"{name} = ?" for name in fields)
        self.db.execute(f"UPDATE tasks SET {names} WHERE id = ?", (*fields.values(), task_id))
        self.db.commit()

    def list_tasks(self) -> str:
        rows = self.db.execute("SELECT * FROM tasks ORDER BY id DESC LIMIT 20").fetchall()
        lines = [f"#{row['id']} {row['project']} [{row['status']}] {row['goal']}" for row in rows]
        return "\n".join(lines) or "No tasks."

    def task_rows(self, limit: int = 20) -> list[dict[str, Any]]:
        rows = self.db.execute("SELECT * FROM tasks ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        fields = ("id", "project", "goal", "status", "tests", "created")
        return [{name: row[name] for name in fields} for row in rows]

    async def start_task(self, project_name: str, goal: str) -> str:
        project = self._project(project_name)
        repo = Path(project["path"])
        base = git(repo, "rev-parse", "--abbrev-ref", "HEAD")
        cursor = self.db.execute(
            "INSERT INTO tasks(project, goal, status, base, branch, folder, created) "
            "VALUES(?, ?, 'running', ?, '', '', ?)",
            (project_name, goal, base, datetime.now(timezone.utc).isoformat()),
        )
        task_id = int(cursor.lastrowid)
        branch = f"iris/task-{task_id}"
        folder = self.settings.data_dir / "tasks" / f"task-{task_id}"
        folder.parent.mkdir(exist_ok=True)
        git(repo, "worktree", "add", "-b", branch, str(folder), base)
        self._update(task_id, branch=branch, folder=str(folder))
        self.audit.write("task_started", task=task_id, project=project_name, goal=goal)
        return await self._run(task_id, f"Project: {project_name}\nGoal: {goal}\n{self._rules()}")

    async def continue_task(self, project_name: str, note: str) -> str:
        row = self.db.execute(
            "SELECT * FROM tasks WHERE project = ? AND status IN (?, ?) ORDER BY id DESC LIMIT 1",
            (project_name, *OPEN),
        ).fetchone()
        if row is None:
            raise ProjectError(f"{project_name} has no open task.")
        recent = git(Path(row["folder"]), "log", "--oneline", "-5")
        prompt = (
            f"Continue this task.\nGoal: {row['goal']}\nLast summary: {row['summary']}\n"
            f"Last test result: {row['tests']}\nRecent commits:\n{recent}\n"
            f"Owner's note: {note or '(none)'}\n{self._rules()}"
        )
        return await self._run(int(row["id"]), prompt)

    def _rules(self) -> str:
        return (
            "Work only in the current folder. Git branches are handled for you, so do not "
            "run git push, merge or checkout. Finish with what changed and what you verified."
        )

    async def _run(self, task_id: int, prompt: str) -> str:
        problem = budget_problem(self.settings, self.memory)
        if problem:
            self._update(task_id, status="failed", summary=problem)
            return problem
        row = self._task(task_id)
        folder = Path(row["folder"])
        settings = dataclasses.replace(
            self.settings,
            workspace=folder,
            windows_enabled=False,
            max_usd_per_message=self.settings.max_usd_per_task,
            max_turns=self.settings.max_turns_per_task,
        )
        policy = Policy(folder, self.settings.level, task_mode=True)
        gate = ToolGate(policy, self.audit, self.stop, self.approver)
        session = f"task:{task_id}:{self.settings.brain}"  # a local transcript never goes to Claude
        agent = Agent(settings, self.memory, self.audit, self.stop, gate, session)
        self._update(task_id, status="running")
        parts: list[str] = []
        succeeded = False
        try:
            await agent.start()
            try:
                result = await agent.ask(prompt, parts.append)
            finally:
                await agent.close()
            succeeded = bool(result) and not result.is_error and not self.stop.active
        except Exception as error:
            parts.append(f"Error: {type(error).__name__}: {error}")

        summary = "\n".join(parts)[-4000:]
        changed = self._commit(folder, task_id)
        tests = await self._approved_tests(row["project"], folder, task_id)
        status = "needs review" if succeeded and not tests.startswith("failed") else "failed"
        self._update(task_id, status=status, summary=summary, tests=tests)
        self.audit.write("task_finished", task=task_id, status=status, tests=tests, changed=changed)
        return f"Task #{task_id}: {status}. Tests: {tests}.\n{summary}\nUse /review {task_id}."

    def _commit(self, folder: Path, task_id: int) -> bool:
        if not git(folder, "status", "--porcelain"):
            return False
        git(folder, "add", "-A")
        git(folder, "commit", "-m", f"IRIS task {task_id}")
        return True

    async def _approved_tests(self, project_name: str, folder: Path, task_id: int) -> str:
        """Tests run code the task just wrote, so the owner approves each run."""
        command = self._project(project_name)["test_command"]
        if not command:
            return "not configured"
        if self.stop.active:
            return "failed: not run, work was stopped"
        changes = git(folder, "show", "--stat", "--format=", "HEAD")[:3000]
        args = {"command": command, "task": task_id, "changes": changes}
        if not await self.approver("run_tests", args, "runs code written by this task"):
            return "failed: not run, the owner declined"
        return await asyncio.to_thread(self._run_tests, project_name, folder)

    def _kill(self, process: subprocess.Popen[str]) -> None:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(process.pid)], capture_output=True)
        else:
            os.killpg(process.pid, signal.SIGKILL)

    def _run_tests(self, project_name: str, folder: Path) -> str:
        command = self._project(project_name)["test_command"]
        if not command:
            return "not configured"
        process = subprocess.Popen(
            command,
            shell=True,
            cwd=folder,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            start_new_session=sys.platform != "win32",
        )
        ends = time.monotonic() + TEST_TIMEOUT_SECONDS
        while True:
            try:
                output = process.communicate(timeout=TEST_POLL_SECONDS)[0]
                break
            except subprocess.TimeoutExpired:
                if self.stop.active:
                    self._kill(process)
                    process.communicate()
                    return "failed: stopped by the owner"
                if time.monotonic() >= ends:
                    self._kill(process)
                    process.communicate()
                    return "failed: timed out"
        if process.returncode == 0:
            return "passed"
        return f"failed: {output[-500:]}"

    def review(self, task_id: int) -> str:
        row = self._task(task_id)
        stat = git(Path(row["folder"]), "diff", "--stat", f"{row['base']}...HEAD")
        return (
            f"Task #{task_id} [{row['status']}]\nGoal: {row['goal']}\nTests: {row['tests']}\n"
            f"Branch: {row['branch']}\n{stat or 'No file changes.'}\n\nSummary:\n{row['summary']}"
        )

    def _remove_task_files(self, row: sqlite3.Row, repo: Path) -> None:
        git(repo, "worktree", "remove", "--force", row["folder"])
        git(repo, "branch", "-D", row["branch"])

    def merge(self, task_id: int) -> str:
        row = self._task(task_id)
        if row["status"] != "needs review":
            raise ProjectError(f"Task {task_id} is {row['status']}; only reviewed work can merge.")
        repo = Path(self._project(row["project"])["path"])
        if git(repo, "rev-parse", "--abbrev-ref", "HEAD") != row["base"]:
            raise ProjectError(f"Switch the project to {row['base']} first.")
        if git(repo, "status", "--porcelain"):
            raise ProjectError("The project has uncommitted changes. Commit them first.")
        if not git(repo, "log", "--oneline", f"{row['base']}..{row['branch']}"):
            raise ProjectError("This task has no changes to merge.")
        try:
            git(repo, "merge", "--no-ff", row["branch"], "-m", f"Merge IRIS task {task_id}")
        except ProjectError as error:
            git(repo, "merge", "--abort")
            raise ProjectError(f"Merge conflict. Nothing was changed. {error}") from None
        self._remove_task_files(row, repo)
        self._update(task_id, status="merged")
        self.audit.write("task_merged", task=task_id)
        return f"Task #{task_id} merged into {row['base']}."

    def discard(self, task_id: int) -> str:
        row = self._task(task_id)
        if row["status"] in ("merged", "discarded"):
            raise ProjectError(f"Task {task_id} is already {row['status']}.")
        repo = Path(self._project(row["project"])["path"])
        self._remove_task_files(row, repo)
        shutil.rmtree(row["folder"], ignore_errors=True)
        self._update(task_id, status="discarded")
        self.audit.write("task_discarded", task=task_id)
        return f"Task #{task_id} discarded."

    async def handle_command(self, line: str) -> str | None:
        """Return a reply for project commands, or None for anything else."""
        command, _, rest = line.partition(" ")
        if command not in (
            "/project", "/projects", "/task", "/continue", "/tasks", "/review", "/merge", "/discard"
        ):
            return None
        rest = rest.strip()
        try:
            if command == "/projects":
                return self.list_projects()
            if command == "/tasks":
                return self.list_tasks()
            if command == "/project":
                parts = shlex.split(rest, posix=False)
                if len(parts) < 3 or parts[0] != "add":
                    return "Use: /project add NAME PATH [TEST COMMAND]"
                return self.add_project(parts[1], parts[2].strip('"'), " ".join(parts[3:]))
            if command == "/task":
                name, _, goal = rest.partition(" ")
                return await self.start_task(name, goal.strip()) if goal.strip() else "Use: /task NAME GOAL"
            if command == "/continue":
                name, _, note = rest.partition(" ")
                return await self.continue_task(name, note.strip()) if name else "Use: /continue NAME [NOTE]"
            if not rest.isdigit():
                return f"Use: {command} ID"
            action: Any = {"/review": self.review, "/merge": self.merge, "/discard": self.discard}[command]
            return action(int(rest))
        except ProjectError as error:
            return str(error)
