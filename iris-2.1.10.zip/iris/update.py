"""Updates IRIS from signed releases, with no account on the computer.

Each release is a zip of IRIS itself (never anyone's data) plus latest.json, which names the
version, the zip's size and SHA-256, and carries an Ed25519 signature by the publisher. IRIS
accepts a release only if that signature matches the public key below, so nobody else can
push code to it. Development copies (a Git checkout) are updated with git pull instead.
"""
from __future__ import annotations

import base64
import hashlib
import json
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from iris.ed25519 import verify

CHANNEL = "https://raw.githubusercontent.com/sabanovic187/iris-releases/main"
PUBLIC_KEY = "HZzb8gPQHp0MlOBKbU8CW3W8pHL9lT1crCKxCeaSBHo="  # the publisher (sabanovic187); only its signatures are installed
MAX_PACKAGE = 200 * 1024 * 1024
# What a release may replace. The owner's data, keys, Python packages and tools are never touched.
KEEP = {"data", ".env", ".venv", "workspace", "tools", "worldmonitor", ".git"}
REQUIREMENTS = ("requirements.txt", "requirements-voice.txt", "requirements-tools.txt")
NO_DEPS = "requirements-nodeps.txt"  # installed without their own dependencies


class UpdateError(Exception):
    pass


@dataclass(frozen=True)
class Release:
    version: str
    file: str
    sha256: str
    size: int
    notes: str
    published: str


def current_version(root: Path) -> str:
    path = root / "iris" / "VERSION"
    return path.read_text(encoding="utf-8").strip() if path.exists() else "0"


def version_key(version: str) -> tuple[int, ...]:
    parts = []
    for piece in version.split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def is_development(root: Path) -> bool:
    return (root / ".git").exists()


def signed_bytes(manifest: dict[str, Any]) -> bytes:
    """The exact bytes that are signed: the manifest without its signature, keys sorted."""
    body = {key: value for key, value in manifest.items() if key != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def check_manifest(manifest: dict[str, Any], public_key: str = "") -> Release:
    key = public_key or PUBLIC_KEY
    if not key:
        raise UpdateError("This IRIS has no publisher key, so it cannot trust any update.")
    try:
        signature = base64.b64decode(manifest["signature"], validate=True)
        good = verify(base64.b64decode(key), signed_bytes(manifest), signature)
    except (KeyError, ValueError, TypeError):
        good = False
    if not good:
        raise UpdateError("The update is not signed by IRIS's publisher, so it was refused.")
    try:
        release = Release(
            version=str(manifest["version"]),
            file=str(manifest["file"]),
            sha256=str(manifest["sha256"]).lower(),
            size=int(manifest["size"]),
            notes=str(manifest.get("notes", "")),
            published=str(manifest.get("published", "")),
        )
    except (KeyError, ValueError, TypeError) as error:
        raise UpdateError("The update description is incomplete.") from error
    if "/" in release.file or "\\" in release.file or not release.file.endswith(".zip"):
        raise UpdateError("The update names an unexpected file.")
    if not 0 < release.size <= MAX_PACKAGE:
        raise UpdateError("The update has an unexpected size.")
    return release


def _fetch(url: str, limit: int) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "IRIS", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise UpdateError("The download is larger than expected.")
    return data


class Updater:
    def __init__(self, root: Path, channel: str = CHANNEL, public_key: str = "",
                 fetch: Callable[[str, int], bytes] = _fetch) -> None:
        self.root = root
        self.channel = channel.rstrip("/")
        self.public_key = public_key
        self.fetch = fetch
        self.work = root / "data" / "update"

    def latest(self) -> Release:
        try:
            manifest = json.loads(self.fetch(f"{self.channel}/latest.json", 64 * 1024))
        except (OSError, ValueError) as error:
            raise UpdateError("The update channel could not be reached.") from error
        return check_manifest(manifest, self.public_key)

    def available(self) -> Release | None:
        release = self.latest()
        return release if version_key(release.version) > version_key(current_version(self.root)) else None

    def download(self, release: Release) -> Path:
        try:
            data = self.fetch(f"{self.channel}/{release.file}", release.size)
        except OSError as error:
            raise UpdateError("The update could not be downloaded.") from error
        if len(data) != release.size or hashlib.sha256(data).hexdigest() != release.sha256:
            raise UpdateError("The download does not match the signed update, so it was refused.")
        self.work.mkdir(parents=True, exist_ok=True)
        package = self.work / release.file
        package.write_bytes(data)
        return package

    def install(self, package: Path, release: Release, run: Callable[..., Any] = subprocess.run) -> None:
        """Unpacks next to IRIS, keeps a copy of what it replaces, and puts it back on failure."""
        staging = self.work / "new"
        previous = self.work / "previous"
        for folder in (staging, previous):
            shutil.rmtree(folder, ignore_errors=True)
        with zipfile.ZipFile(package) as archive:
            for name in archive.namelist():
                parts = Path(name).parts
                if name.startswith("/") or ".." in parts or (parts and parts[0] in KEEP):
                    raise UpdateError("The update tried to write outside IRIS's own files.")
            archive.extractall(staging)
        if not (staging / "iris" / "__init__.py").exists():
            raise UpdateError("The update does not contain IRIS.")
        if current_version(staging) != release.version:
            raise UpdateError("The update's contents do not match its version.")
        replaced: list[Path] = []
        try:
            for source in sorted(path for path in staging.rglob("*") if path.is_file()):
                relative = source.relative_to(staging)
                target = self.root / relative
                if target.exists():
                    backup = previous / relative
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, backup)
                replaced.append(relative)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            self._packages(run)
        except Exception:
            self._roll_back(replaced, previous)
            raise
        finally:
            shutil.rmtree(staging, ignore_errors=True)
            package.unlink(missing_ok=True)

    def _packages(self, run: Callable[..., Any]) -> None:
        files = [name for name in REQUIREMENTS if (self.root / name).exists()]
        if not files:
            return
        pip = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-q"]
        commands = [pip + [part for name in files for part in ("-r", str(self.root / name))]]
        if (self.root / NO_DEPS).exists():
            commands.append(pip + ["--no-deps", "-r", str(self.root / NO_DEPS)])
        for step in commands:
            result = run(step, cwd=self.root, capture_output=True, text=True, timeout=1800)
            if getattr(result, "returncode", 1) != 0:
                raise UpdateError("Python packages for the update could not be installed.")

    def _roll_back(self, replaced: list[Path], previous: Path) -> None:
        for relative in replaced:
            backup = previous / relative
            target = self.root / relative
            if backup.exists():
                shutil.copy2(backup, target)
            else:
                target.unlink(missing_ok=True)
