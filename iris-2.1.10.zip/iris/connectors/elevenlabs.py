"""A natural speaking voice from ElevenLabs. The words IRIS says go to their service."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Iterator

from iris.connectors.base import ConnectorError, ServiceRefused, call_json
from iris.connectors.vault import Vault

API = "https://api.elevenlabs.io/v1"
MODEL = "eleven_flash_v2_5"
SAMPLE_RATE = 22050
FORMAT = f"pcm_{SAMPLE_RATE}"
DEFAULT_VOICE = "EXAVITQu4vr4xnSDxMaL"
SHORT_LINE = 20  # short confirmations use the free local voice, to save credits
REST_SECONDS = 15 * 60  # after a refusal, for example no credits left
CHUNK = 4096


class ElevenLabs:
    id = "elevenlabs"
    name = "ElevenLabs"
    in_settings = True

    def __init__(self, vault: Vault, api: str = API) -> None:
        self.vault = vault
        self.api = api
        self.resting_until = 0.0

    def _saved(self) -> dict[str, Any] | None:
        return self.vault.load(self.id)

    def status(self) -> dict[str, Any]:
        saved = self._saved()
        return {"connected": bool(saved), "on": bool(saved and saved.get("on", True)), "voice": (saved or {}).get("voice", DEFAULT_VOICE)}

    def tools(self) -> list[Any]:
        return []

    def disconnect(self) -> None:
        self.vault.delete(self.id)

    def _get(self, key: str, path: str) -> Any:
        return call_json("GET", f"{self.api}{path}", headers={"xi-api-key": key})

    def connect(self, key: str) -> None:
        key = key.strip()
        if not key:
            raise ConnectorError("Paste the API key first.")
        self.vault.save(self.id, {"key": key, "voice": DEFAULT_VOICE, "on": True})
        self.resting_until = 0.0
        try:
            next(self.speak("Hello."))
        except (ConnectorError, StopIteration):
            self.vault.delete(self.id)
            raise ConnectorError("ElevenLabs refused that key. Check that it may use Text to Speech.") from None

    def choose(self, voice: str | None, on: bool | None) -> None:
        saved = self._saved()
        if not saved:
            raise ConnectorError("Connect ElevenLabs first.")
        if voice is not None:
            saved["voice"] = voice
        if on is not None:
            saved["on"] = on
        self.vault.save(self.id, saved)
        self.resting_until = 0.0

    def screen(self) -> dict[str, Any]:
        """What the Voice screen shows. A key may lack these rights, and speech still works without them."""
        found = self.status()
        saved = self._saved()
        if not saved:
            return found
        try:
            voices = self._get(saved["key"], "/voices").get("voices", [])
            found["voices"] = [{"id": item.get("voice_id", ""), "name": item.get("name", "")} for item in voices]
        except ConnectorError:
            found["voices"] = []
        try:
            used = self._get(saved["key"], "/user/subscription")
            found["used"], found["limit"] = used.get("character_count"), used.get("character_limit")
        except ConnectorError:
            pass
        return found

    def wanted(self, text: str) -> bool:
        return self.status()["on"] and len(text) > SHORT_LINE and time.time() >= self.resting_until

    def speak(self, text: str) -> Iterator[bytes]:
        """Give sound as it arrives: 16-bit mono."""
        saved = self._saved()
        if not saved:
            raise ConnectorError("ElevenLabs is not connected.")
        voice = urllib.parse.quote(saved.get("voice") or DEFAULT_VOICE, safe="")
        request = urllib.request.Request(
            f"{self.api}/text-to-speech/{voice}/stream?output_format={FORMAT}",
            data=json.dumps({"text": text, "model_id": MODEL}).encode("utf-8"),
            method="POST",
            headers={"xi-api-key": saved["key"], "Content-Type": "application/json", "Accept": "audio/pcm", "User-Agent": "IRIS"},
        )
        try:
            response = urllib.request.urlopen(request, timeout=15)
        except urllib.error.HTTPError as error:
            self.resting_until = time.time() + REST_SECONDS
            raise ServiceRefused(error.code, error.read(300).decode("utf-8", errors="replace")) from None
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            raise ConnectorError(f"ElevenLabs could not be reached ({type(error).__name__}).") from None
        with response:
            while True:
                part = response.read(CHUNK)
                if not part:
                    return
                yield part
