"""Reads text from pictures and scanned PDF pages with the OCR built into Windows."""
from __future__ import annotations

import base64
import os
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path
from typing import Any

from iris.connectors.base import ConnectorError

IMAGES = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
MAX_PAGES = 30
MAX_PIXELS = 100_000_000
OCR_TIMEOUT_SECONDS = 300
PAGE_BREAK = "\f"
SCRIPT = r"""
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
  $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Finish($operation, $type) {
  $task = $asTask.MakeGenericMethod($type).Invoke($null, @($operation))
  $task.Wait()
  $task.Result
}
$engine = $null
foreach ($code in 'bs', 'hr', 'sr-Latn') {
  $language = [Windows.Globalization.Language]::new($code)
  if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($language)) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
    break
  }
}
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $engine) { throw 'no language' }
foreach ($path in ($env:IRIS_OCR_FILES -split "`n")) {
  $file = Finish ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
  $stream = Finish ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  $decoder = Finish ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bitmap = Finish ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $result = Finish ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
  $stream.Dispose()
  ($result.Lines | ForEach-Object { $_.Text }) -join "`n"
  "`f"
}
"""


def recognize(paths: list[Path]) -> list[str]:
    """Return the text of each picture, in order."""
    if sys.platform != "win32":
        raise ConnectorError("Reading scans needs Windows.")
    command = base64.b64encode(SCRIPT.encode("utf-16-le")).decode("ascii")
    try:
        done = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", command],
            capture_output=True,
            timeout=OCR_TIMEOUT_SECONDS,
            env={**os.environ, "IRIS_OCR_FILES": "\n".join(str(path) for path in paths)},
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except (OSError, subprocess.TimeoutExpired):
        raise ConnectorError("Windows OCR did not finish.") from None
    if done.returncode != 0:
        raise ConnectorError("Windows OCR could not run on this computer.")
    pages = done.stdout.decode("utf-8", errors="replace").split(PAGE_BREAK)
    return [page.strip() for page in pages[: len(paths)]]


def _chunk(kind: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))


def make_png(pixels: bytes, width: int, height: int, depth: int, channels: int) -> bytes:
    stride = (width * channels * depth + 7) // 8
    if len(pixels) < stride * height:
        raise ValueError("short image")
    rows = b"".join(b"\0" + pixels[row * stride : (row + 1) * stride] for row in range(height))
    header = struct.pack(">IIBBBBB", width, height, depth, 0 if channels == 1 else 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", header) + _chunk(b"IDAT", zlib.compress(rows)) + _chunk(b"IEND", b"")


def make_tiff(data: bytes, width: int, height: int, group4: bool, black_is_one: bool) -> bytes:
    """Wrap fax-style scan data, which is one strip of a TIFF file, so Windows can open it."""
    tags = [
        (256, 4, width), (257, 4, height), (258, 3, 1), (259, 3, 4 if group4 else 3),
        (262, 3, 1 if black_is_one else 0), (273, 4, 0), (278, 4, height), (279, 4, len(data)),
    ]
    start = 8 + 2 + len(tags) * 12 + 4
    head = b"II*\0" + struct.pack("<I", 8) + struct.pack("<H", len(tags))
    for tag, kind, value in tags:
        head += struct.pack("<HHII", tag, kind, 1, start if tag == 273 else value)
    return head + struct.pack("<I", 0) + data


def _channels(space: Any) -> int | None:
    space = space.get_object() if hasattr(space, "get_object") else space
    if space in ("/DeviceGray", "/CalGray"):
        return 1
    if space in ("/DeviceRGB", "/CalRGB"):
        return 3
    if isinstance(space, list) and space and space[0] == "/ICCBased":
        return {1: 1, 3: 3}.get(int(space[1].get_object().get("/N", 0)))
    return None


def _picture(image: Any) -> tuple[bytes, str] | None:
    """Turn one PDF image into a file Windows can open, using no extra libraries."""
    width, height = int(image.get("/Width", 0)), int(image.get("/Height", 0))
    if not 0 < width * height <= MAX_PIXELS:
        return None
    filters = image.get("/Filter", [])
    filters = [filters] if isinstance(filters, str) else [str(name) for name in filters]
    if filters == ["/DCTDecode"]:
        return image._data, ".jpg"
    if filters == ["/CCITTFaxDecode"]:
        settings = image.get("/DecodeParms") or {}
        settings = settings[0] if isinstance(settings, list) else settings
        settings = settings.get_object()
        return make_tiff(image._data, width, height, int(settings.get("/K", 0)) < 0, bool(settings.get("/BlackIs1", False))), ".tif"
    if any(name not in ("/FlateDecode", "/LZWDecode", "/ASCII85Decode") for name in filters):
        return None
    depth = 1 if image.get("/ImageMask") else int(image.get("/BitsPerComponent", 8))
    channels = 1 if image.get("/ImageMask") else _channels(image.get("/ColorSpace"))
    if depth not in (1, 8) or channels is None or (depth == 1 and channels != 1):
        return None
    return make_png(image.get_data(), width, height, depth, channels), ".png"


def page_picture(page: Any) -> tuple[bytes, str] | None:
    """Return the largest picture on a page, which on a scan is the page itself."""
    try:
        objects = page["/Resources"]["/XObject"].get_object()
    except (KeyError, TypeError, AttributeError):
        return None
    images = [item.get_object() for item in objects.values()]
    images = [item for item in images if item.get("/Subtype") == "/Image"]
    images.sort(key=lambda item: int(item.get("/Width", 0)) * int(item.get("/Height", 0)), reverse=True)
    return _picture(images[0]) if images else None


def read_scanned_pages(reader: Any) -> str:
    """Return the OCR text of a scanned PDF, or an empty string if it holds no usable pictures."""
    with tempfile.TemporaryDirectory(prefix="iris-ocr-") as folder:
        paths = []
        for number, page in enumerate(reader.pages[:MAX_PAGES], 1):
            found = page_picture(page)
            if found:
                paths.append(Path(folder) / f"{number:04}{found[1]}")
                paths[-1].write_bytes(found[0])
        if not paths:
            return ""
        text = "\n\n".join(recognize(paths)).strip()
    if text and len(reader.pages) > MAX_PAGES:
        text += f"\n...[only the first {MAX_PAGES} pages were read]"
    return text
