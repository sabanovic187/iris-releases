"""Currency conversion with European Central Bank reference rates. Needs no account."""
from __future__ import annotations

import re
import urllib.parse
from typing import Any

from iris.connectors.base import READ, ConnectorError, Tool, call_json, require_text

API = "https://api.frankfurter.dev/v1"
BAM_PER_EURO = 1.95583  # fixed by the Central Bank of Bosnia and Herzegovina


def _code(args: dict[str, Any], name: str) -> str:
    code = require_text(args, name, 3).upper()
    if not re.fullmatch(r"[A-Z]{3}", code):
        raise ConnectorError(f"{name} must be a currency code such as EUR.")
    return code


class Rates:
    id = "rates"
    name = "Currency rates"
    summary = "Convert money with daily European Central Bank rates. The KM rate is fixed to the euro."

    def __init__(self, api: str = API) -> None:
        self.api = api

    def status(self) -> dict[str, Any]:
        return {"connected": True}

    def _convert(self, args: dict[str, Any]) -> str:
        source, target = _code(args, "source"), _code(args, "target")
        try:
            amount = float(args.get("amount", 1))
        except (TypeError, ValueError):
            raise ConnectorError("amount must be a number.") from None
        day = str(args.get("date") or "latest")
        if day != "latest" and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            raise ConnectorError("Use a date such as 2026-01-31.")
        needed = {source, target} - {"EUR", "BAM"}
        per_euro = {"EUR": 1.0, "BAM": BAM_PER_EURO}
        when = day
        if needed:
            query = urllib.parse.urlencode({"base": "EUR", "symbols": ",".join(sorted(needed))})
            found = call_json("GET", f"{self.api}/{day}?{query}")
            per_euro.update(found.get("rates", {}))
            when = found.get("date", day)
        if source not in per_euro or target not in per_euro:
            raise ConnectorError("That currency has no rate.")
        result = amount / per_euro[source] * per_euro[target]
        return f"{amount:g} {source} = {result:,.4f} {target} (rate of {when})"

    def tools(self) -> list[Tool]:
        return [
            Tool(
                "currency_convert",
                "Convert an amount between currencies. date is optional, as YYYY-MM-DD.",
                {"amount": float, "source": str, "target": str, "date": str},
                READ,
                self._convert,
            )
        ]
