"""Looks at the owner's own network with Nmap. Other networks cannot be chosen."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, wait
import ipaddress
import os
import re
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import WRITE, ConnectorError, Tool, require_text

SCAN_TIMEOUT_SECONDS = 180
POLL_SECONDS = 0.5
ANY_PUBLIC_ADDRESS = ("192.0.2.1", 9)  # no packet is sent; this only picks the local address
LOOKUP_SECONDS = 5
MAKERS_FILE = "nmap-mac-prefixes"
PRIVATE_NOTE = "private Wi-Fi address, usually a phone, tablet or laptop"


def local_address() -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        probe.connect(ANY_PUBLIC_ADDRESS)
        return probe.getsockname()[0]


def find_nmap() -> str | None:
    found = shutil.which("nmap")
    if found:
        return found
    for variable in ("ProgramFiles(x86)", "ProgramFiles"):
        base = os.environ.get(variable)
        if base and (Path(base) / "Nmap" / "nmap.exe").exists():
            return str(Path(base) / "Nmap" / "nmap.exe")
    return None


def _run(command: list[str], blocked: Callable[[], bool] = lambda: False) -> str:
    flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    try:
        process = subprocess.Popen(
            command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, errors="replace", creationflags=flags
        )
    except OSError:
        raise ConnectorError("Nmap could not start.") from None
    ends = time.monotonic() + SCAN_TIMEOUT_SECONDS
    while True:
        try:
            output = process.communicate(timeout=POLL_SECONDS)[0]
            break
        except subprocess.TimeoutExpired:
            if blocked() or time.monotonic() >= ends:
                process.kill()
                process.communicate()
                raise ConnectorError("The scan was stopped.") from None
    if process.returncode != 0:
        raise ConnectorError("Nmap reported a problem.")
    return output


def _quick(command: list[str]) -> str:
    """Reads a small Windows command. Without it the list is only shorter, so failures stay quiet."""
    flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    try:
        return subprocess.run(
            command, capture_output=True, text=True, errors="replace", timeout=LOOKUP_SECONDS, creationflags=flags
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def known_hardware() -> dict[str, str]:
    """Maps each address on the network to its hardware address, from the table Windows keeps."""
    found = re.findall(r"^\s*(\d+\.\d+\.\d+\.\d+)\s+((?:[0-9a-f]{2}[-:]){5}[0-9a-f]{2})\s", _quick(["arp", "-a"]), re.M | re.I)
    return {ip: mac.replace("-", "").replace(":", "").upper() for ip, mac in found}


def router_address() -> str | None:
    found = re.search(r"^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)\s", _quick(["route", "print", "-4", "0.0.0.0"]), re.M)
    return found.group(1) if found else None


def device_name(address: str) -> str:
    try:
        return socket.gethostbyaddr(address)[0]
    except OSError:
        return ""


def read_makers(path: Path) -> dict[str, str]:
    """Nmap ships this list of hardware makers next to nmap.exe."""
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return {}
    makers = {}
    for line in lines:
        prefix, _, maker = line.partition(" ")
        if prefix and maker and not line.startswith("#"):
            makers[prefix.upper()] = maker.strip()
    return makers


def maker_of(hardware: str, makers: dict[str, str]) -> str:
    for size in (9, 7, 6):
        if hardware[:size] in makers:
            return makers[hardware[:size]]
    return ""


def is_private_hardware(hardware: str) -> bool:
    return len(hardware) == 12 and hardware[1] in "26AE"


def names_of(addresses: list[str], lookup: Callable[[str], str]) -> dict[str, str]:
    """Slow answers are dropped, so one silent device cannot hold up the list."""
    if not addresses:
        return {}
    pool = ThreadPoolExecutor(max_workers=min(32, len(addresses)))
    jobs = {pool.submit(lookup, address): address for address in addresses}
    finished, _late = wait(jobs, timeout=LOOKUP_SECONDS)
    pool.shutdown(wait=False, cancel_futures=True)
    return {jobs[job]: job.result() for job in finished if not job.exception() and job.result()}


class Network:
    id = "network"
    name = "Home network"
    summary = "List devices and open ports on your own network. Each scan needs approval."

    def __init__(
        self,
        address: Callable[[], str] = local_address,
        locate: Callable[[], str | None] = find_nmap,
        run: Callable[[list[str]], str] | None = None,
        hardware: Callable[[], dict[str, str]] = known_hardware,
        router: Callable[[], str | None] = router_address,
        lookup: Callable[[str], str] = device_name,
    ) -> None:
        self.address = address
        self.locate = locate
        self.blocked: Callable[[], bool] = lambda: False
        self.run = run or (lambda command: _run(command, self.blocked))
        self.hardware = hardware
        self.router = router
        self.lookup = lookup

    def status(self) -> dict[str, Any]:
        return {"connected": bool(self.locate())}

    def _nmap(self) -> str:
        path = self.locate()
        if not path:
            raise ConnectorError("Nmap is not installed.")
        return path

    def _home_network(self) -> ipaddress.IPv4Network:
        address = ipaddress.ip_address(self.address())
        if not address.is_private or address.is_loopback:
            raise ConnectorError("This computer is not on a private network, so scanning is refused.")
        return ipaddress.ip_network(f"{address}/24", strict=False)

    def _devices(self, _args: dict[str, Any]) -> str:
        nmap = self._nmap()
        output = self.run([nmap, "-sn", "-oG", "-", str(self._home_network())])
        found = re.findall(r"^Host: (\S+) \((.*?)\)\s+Status: Up", output, re.M)
        if not found:
            return "No devices found."
        hardware, router = self.hardware(), self.router()
        names = names_of([ip for ip, name in found if not name], self.lookup)
        makers = read_makers(Path(nmap).parent / MAKERS_FILE)
        here = self.address()
        lines = []
        for ip, name in found:
            parts = [ip]
            if ip == here:
                parts.append("this computer")
            if ip == router:
                parts.append("router")
            if name or names.get(ip):
                parts.append(f"name: {name or names[ip]}")
            mac = hardware.get(ip, "")
            maker = maker_of(mac, makers)
            if maker:
                parts.append(f"maker: {maker}")
            elif is_private_hardware(mac):
                parts.append(PRIVATE_NOTE)
            lines.append(" | ".join(parts))
        return "\n".join(lines)

    def _ports(self, args: dict[str, Any]) -> str:
        try:
            host = ipaddress.ip_address(require_text(args, "host", 50))
        except ValueError:
            raise ConnectorError("Use an address such as 192.168.1.20.") from None
        if host not in self._home_network():
            raise ConnectorError("Only devices on your own network can be scanned.")
        output = self.run([self._nmap(), "-F", "-oG", "-", str(host)])
        ports = re.findall(r"(\d+)/open/\w+//([^/]*)/", output)
        return "\n".join(f"{port} {name}".strip() for port, name in ports) or "No common ports are open."

    def tools(self) -> list[Tool]:
        return [
            Tool("network_devices", "List devices on the owner's own network, with names and hardware makers when known.", {}, WRITE, self._devices),
            Tool("network_ports", "List common open ports on one device on the owner's network.", {"host": str}, WRITE, self._ports),
        ]
