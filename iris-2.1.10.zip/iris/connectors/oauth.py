"""Pieces shared by sign-ins that return to this computer."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import secrets
import urllib.parse

DONE_PAGE = "IRIS is connected. You can close this tab."
FAILED_PAGE = "IRIS could not connect. Go back to IRIS and try again."


def pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode()).digest()
    return verifier, base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


async def local_callback(state: str, port: int = 0) -> tuple[asyncio.Server, int, "asyncio.Future[str]"]:
    """Listen on this computer for the sign-in page to send back its code."""
    answer: asyncio.Future[str] = asyncio.get_running_loop().create_future()

    async def receive(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            line = (await reader.readline()).decode("latin-1").split(" ")
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(line[1]).query) if len(line) > 1 else {}
            valid = query.get("state", [""])[0] == state and bool(query.get("code"))
            body = (DONE_PAGE if valid else FAILED_PAGE).encode()
            writer.write(
                b"HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\n"
                + f"Content-Length: {len(body)}\r\n\r\n".encode() + body
            )
            await writer.drain()
            if valid and not answer.done():
                answer.set_result(query["code"][0])
        finally:
            writer.close()

    server = await asyncio.start_server(receive, "127.0.0.1", port)
    return server, server.sockets[0].getsockname()[1], answer
