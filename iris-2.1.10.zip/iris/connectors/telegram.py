"""Talks with the owner through their own Telegram bot. It connects outward, so nothing opens to the internet."""
from __future__ import annotations

import re
import secrets
import urllib.request
import uuid
from typing import Any, Callable

from iris.connectors.base import ConnectorError, call_json
from iris.connectors.vault import Vault

API = "https://api.telegram.org"
POLL_SECONDS = 15  # shorter than the request timeout
MAX_MESSAGE = 3900
MAX_CAPTION = 1000
MAX_VOICE_BYTES = 20 * 1024 * 1024  # Telegram's own limit for bots
SAFE_COMMANDS = {"/today", "/briefing", "/digest", "/system", "/stop"}


class Telegram:
    id = "telegram"
    name = "Telegram"
    summary = "Talk to IRIS from your phone and approve its actions there. Commands and Windows control are approved on this computer."

    def __init__(self, vault: Vault, api: str = API, fetch: Callable[..., Any] = call_json) -> None:
        self.vault = vault
        self.api = api
        self.fetch = fetch
        self.offset = 0
        self.pair_code = ""
        self.decisions: list[tuple[str, bool]] = []

    def _saved(self) -> dict[str, Any] | None:
        return self.vault.load(self.id)

    def status(self) -> dict[str, Any]:
        saved = self._saved()
        return {
            "connected": bool(saved and saved.get("chat_id")),
            "account": (saved or {}).get("bot", ""),
            "has_bot": bool(saved),
            "pair_code": self.pair_code if saved and not saved.get("chat_id") else "",
        }

    def _call(self, token: str, method: str, data: dict[str, Any] | None = None) -> Any:
        answer = self.fetch("POST", f"{self.api}/bot{token}/{method}", data=data or {})
        return answer.get("result")

    def connect(self, token: str) -> None:
        token = token.strip()
        if not token:
            raise ConnectorError("Paste the bot token first.")
        bot = self._call(token, "getMe")
        self.vault.save(self.id, {"token": token, "bot": bot.get("username", "")})
        self.pair_code = secrets.token_hex(4)

    def disconnect(self) -> None:
        self.vault.delete(self.id)
        self.pair_code = ""

    def poll(self) -> list[Any]:
        """Wait for messages. Only the paired owner gets through; all others are ignored."""
        saved = self._saved()
        if not saved:
            return []
        if not saved.get("chat_id") and not self.pair_code:
            self.pair_code = secrets.token_hex(4)  # a new code after each restart
        updates = self._call(saved["token"], "getUpdates", {"offset": self.offset, "timeout": POLL_SECONDS}) or []
        accepted = []
        for update in updates:
            self.offset = update["update_id"] + 1
            if update.get("callback_query"):
                self._button(saved, update["callback_query"])
                continue
            message = update.get("message") or {}
            chat = message.get("chat", {})
            text = str(message.get("text", "")).strip()
            voice = message.get("voice") or {}
            if (not text and not voice.get("file_id")) or chat.get("type") != "private":
                continue
            if not saved.get("chat_id"):
                if self.pair_code and text == f"/start {self.pair_code}":
                    saved["chat_id"] = chat["id"]
                    self.vault.save(self.id, saved)
                    self.pair_code = ""
                    self.send("Connected. I am IRIS.")
                continue
            if chat.get("id") == saved["chat_id"]:
                accepted.append(text or {"voice": voice["file_id"], "duration": int(voice.get("duration", 0))})
        return accepted

    def _button(self, saved: dict[str, Any], press: dict[str, Any]) -> None:
        """A button counts only from the paired owner, on a message in the paired chat."""
        owner = saved.get("chat_id")
        chat = press.get("message", {}).get("chat", {})
        self._call(saved["token"], "answerCallbackQuery", {"callback_query_id": press.get("id")})
        found = re.fullmatch(r"(allow|deny):([0-9a-f]{32})", str(press.get("data", "")))
        if found and owner and press.get("from", {}).get("id") == owner and chat.get("id") == owner and chat.get("type") == "private":
            self.decisions.append((found.group(2), found.group(1) == "allow"))

    def ask_approval(self, request_id: str, text: str, may_allow: bool) -> int | None:
        """Send one approval with its buttons. Return its message number so the buttons can be removed later."""
        saved = self._saved()
        if not saved or not saved.get("chat_id"):
            return None
        buttons = [{"text": "Decline", "callback_data": f"deny:{request_id}"}]
        if may_allow:
            buttons.insert(0, {"text": "Allow", "callback_data": f"allow:{request_id}"})
        sent = self._call(saved["token"], "sendMessage", {
            "chat_id": saved["chat_id"], "text": text[:MAX_MESSAGE], "reply_markup": {"inline_keyboard": [buttons]},
        })
        return (sent or {}).get("message_id")

    def close_approval(self, message_id: int, text: str) -> None:
        saved = self._saved()
        if saved and saved.get("chat_id"):
            self._call(saved["token"], "editMessageText", {"chat_id": saved["chat_id"], "message_id": message_id, "text": text[:MAX_MESSAGE]})

    def send(self, text: str) -> None:
        saved = self._saved()
        if not saved or not saved.get("chat_id"):
            return
        for start in range(0, len(text), MAX_MESSAGE):
            self._call(saved["token"], "sendMessage", {"chat_id": saved["chat_id"], "text": text[start:start + MAX_MESSAGE]})

    def download(self, file_id: str) -> bytes:
        """A voice message the owner sent."""
        saved = self._saved()
        if not saved:
            raise ConnectorError("Telegram is not connected.")
        found = self._call(saved["token"], "getFile", {"file_id": file_id}) or {}
        path = str(found.get("file_path", ""))
        if not path or int(found.get("file_size", 0)) > MAX_VOICE_BYTES:
            raise ConnectorError("The voice message could not be fetched.")
        request = urllib.request.Request(f"{self.api}/file/bot{saved['token']}/{path}", headers={"User-Agent": "IRIS"})
        with urllib.request.urlopen(request, timeout=60) as response:
            return response.read(MAX_VOICE_BYTES + 1)[:MAX_VOICE_BYTES]

    def send_voice(self, audio: bytes, caption: str = "") -> None:
        """Answers with a voice message (OGG Opus), with the reply as its caption."""
        saved = self._saved()
        if not saved or not saved.get("chat_id"):
            return
        boundary = uuid.uuid4().hex
        fields = {"chat_id": str(saved["chat_id"]), "caption": caption[:MAX_CAPTION]}
        body = b"".join(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode("utf-8")
            for name, value in fields.items()
        )
        body += (
            f'--{boundary}\r\nContent-Disposition: form-data; name="voice"; filename="iris.ogg"\r\n'
            "Content-Type: audio/ogg\r\n\r\n"
        ).encode("ascii") + audio + f"\r\n--{boundary}--\r\n".encode("ascii")
        request = urllib.request.Request(
            f"{self.api}/bot{saved['token']}/sendVoice", data=body, method="POST",
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}", "User-Agent": "IRIS"},
        )
        with urllib.request.urlopen(request, timeout=60) as response:
            response.read()

    def tools(self) -> list[Any]:
        return []
