"""Makes images through ComfyUI on this computer."""
from __future__ import annotations

import random
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import WRITE, ConnectorError, Tool, call_json, require_text

COMFY_URL = "http://127.0.0.1:8188"
OLLAMA_URL = "http://127.0.0.1:11434"
WAIT_SECONDS = 600
POLL_SECONDS = 2
SIZE = 512


def build_workflow(checkpoint: str, prompt: str, avoid: str, seed: int) -> dict[str, Any]:
    return {
        "3": {"class_type": "KSampler", "inputs": {
            "cfg": 7, "denoise": 1, "latent_image": ["5", 0], "model": ["4", 0], "negative": ["7", 0],
            "positive": ["6", 0], "sampler_name": "euler", "scheduler": "normal", "seed": seed, "steps": 25,
        }},
        "4": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "5": {"class_type": "EmptyLatentImage", "inputs": {"batch_size": 1, "height": SIZE, "width": SIZE}},
        "6": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["4", 1], "text": prompt}},
        "7": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["4", 1], "text": avoid}},
        "8": {"class_type": "VAEDecode", "inputs": {"samples": ["3", 0], "vae": ["4", 2]}},
        "9": {"class_type": "SaveImage", "inputs": {"filename_prefix": "IRIS", "images": ["8", 0]}},
    }


class Images:
    id = "images"
    name = "Image making"
    summary = "Make images on this computer with ComfyUI. Each image needs approval."

    def __init__(
        self,
        workspace: Path,
        ollama_model: str = "iris-local",
        comfy: str = COMFY_URL,
        ollama: str = OLLAMA_URL,
        wait_seconds: float = WAIT_SECONDS,
        poll_seconds: float = POLL_SECONDS,
    ) -> None:
        self.folder = workspace / "images"
        self.ollama_model = ollama_model
        self.comfy = comfy
        self.ollama = ollama
        self.wait_seconds = wait_seconds
        self.poll_seconds = poll_seconds
        self.blocked: Callable[[], bool] = lambda: False
        self.running = False

    def refresh(self) -> None:
        """Called in the background so the screen never waits for ComfyUI."""
        try:
            call_json("GET", f"{self.comfy}/system_stats")
            self.running = True
        except ConnectorError:
            self.running = False

    def status(self) -> dict[str, Any]:
        return {"connected": self.running}

    def _free_graphics_card(self) -> None:
        try:
            call_json("POST", f"{self.ollama}/api/generate", data={"model": self.ollama_model, "keep_alive": 0})
        except ConnectorError:
            pass  # Ollama may simply be off

    def _checkpoint(self) -> str:
        info = call_json("GET", f"{self.comfy}/object_info/CheckpointLoaderSimple")
        try:
            names = info["CheckpointLoaderSimple"]["input"]["required"]["ckpt_name"][0]
        except (KeyError, IndexError, TypeError):
            raise ConnectorError("ComfyUI did not list its models.") from None
        if not names:
            raise ConnectorError("ComfyUI has no model yet. Add one to its checkpoints folder.")
        return names[0]

    def _wait(self, prompt_id: str) -> list[dict[str, Any]]:
        ends = time.monotonic() + self.wait_seconds
        while time.monotonic() < ends:
            if self.blocked():
                raise ConnectorError("Stopped by the owner.")
            history = call_json("GET", f"{self.comfy}/history/{urllib.parse.quote(prompt_id, safe='')}")
            if prompt_id in history:
                outputs = history[prompt_id].get("outputs", {})
                return [image for node in outputs.values() for image in node.get("images", [])]
            time.sleep(self.poll_seconds)
        raise ConnectorError("ComfyUI took too long.")

    def _save(self, image: dict[str, Any]) -> Path:
        query = urllib.parse.urlencode({
            "filename": image["filename"], "subfolder": image.get("subfolder", ""), "type": image.get("type", "output"),
        })
        try:
            with urllib.request.urlopen(f"{self.comfy}/view?{query}", timeout=60) as response:
                content = response.read()
        except (urllib.error.URLError, OSError):
            raise ConnectorError("The image could not be fetched.") from None
        self.folder.mkdir(parents=True, exist_ok=True)
        target = self.folder / Path(image["filename"]).name
        target.write_bytes(content)
        return target

    def _generate(self, args: dict[str, Any]) -> str:
        prompt = require_text(args, "prompt", 2000)
        avoid = str(args.get("avoid", ""))[:1000]
        self._free_graphics_card()
        workflow = build_workflow(self._checkpoint(), prompt, avoid, random.randrange(2**32))
        queued = call_json("POST", f"{self.comfy}/prompt", data={"prompt": workflow})
        if not queued.get("prompt_id"):
            raise ConnectorError("ComfyUI refused the request.")
        saved = [self._save(image) for image in self._wait(queued["prompt_id"])]
        try:
            call_json("POST", f"{self.comfy}/free", data={"unload_models": True, "free_memory": True})
        except ConnectorError:
            pass
        if not saved:
            raise ConnectorError("ComfyUI finished without an image.")
        return "Saved: " + ", ".join(str(path) for path in saved)

    def tools(self) -> list[Tool]:
        return [
            Tool("image_generate", "Make an image from a description.", {"prompt": str, "avoid": str}, WRITE, self._generate),
        ]
