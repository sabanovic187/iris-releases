"""A separate, signed-out browser for IRIS. It reaches public websites only, through a filter it cannot bypass."""
from __future__ import annotations

import base64
import ipaddress
import json
import os
import re
import select
import shutil
import socket
import socketserver
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit

from iris.connectors.base import READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, require_text, whole_number
from iris.connectors.media import check_public_url

START_SECONDS = 20
CALL_SECONDS = 20
LOAD_SECONDS = 15
IDLE_SECONDS = 10 * 60
MAX_TEXT = 20000
MAX_HEAD = 64 * 1024
MAX_FRAME = 64 * 1024 * 1024
TUNNEL_IDLE_SECONDS = 120
WEB_PORTS = (80, 443)
BLOCKED = b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
READY = b"HTTP/1.1 200 Connection established\r\n\r\n"
PRIVATE_FIELD = re.compile(r"pass|pwd|card|cvv|cvc|iban|\bpin\b|otp|one.?time|ssn|jmbg|lozink|kartic", re.I)
PRIVATE_AUTOFILL = re.compile(r"^(cc-|current-password|new-password|one-time-code)", re.I)
REFUSED_TYPES = {"password", "file", "hidden"}
SPENDING = re.compile(
    r"\b(pay|buy|purchase|checkout|check out|place order|subscribe|donate|plati|kupi|naru[cč]i|pretplat)", re.I
)
PAGE_SCRIPT = r"""(() => {
  const found = [], items = [];
  const clean = (text) => (text || "").replace(/\s+/g, " ").trim().slice(0, 80);
  for (const item of document.querySelectorAll("a[href],button,input,select,textarea,summary,[role=button],[role=link]")) {
    const box = item.getBoundingClientRect(), style = getComputedStyle(item);
    if (box.width < 2 || box.height < 2 || style.visibility !== "visible" || style.opacity === "0" || item.disabled) continue;
    const typed = ["INPUT", "TEXTAREA", "SELECT"].includes(item.tagName);
    const button = item.tagName === "INPUT" && ["submit", "button"].includes(item.type);
    const label = clean(item.getAttribute("aria-label")) || clean(item.labels && item.labels[0] && item.labels[0].innerText)
      || clean(typed ? "" : item.innerText) || clean(button ? item.value : "") || clean(item.placeholder)
      || clean(item.title) || clean(item.name) || clean(item.id);
    if (!label) continue;
    found.push(item);
    items.push({
      number: found.length, tag: item.tagName.toLowerCase(), type: item.type || "", label, typed: typed && !button,
      hint: [item.name, item.id, item.autocomplete, item.placeholder].join(" "), autofill: item.autocomplete || "",
    });
    if (found.length >= 150) break;
  }
  window.__iris = found;
  return JSON.stringify({ title: document.title, url: location.href, text: document.body ? document.body.innerText : "", items });
})()"""
AIM_SCRIPT = r"""(() => {
  const item = window.__iris && window.__iris[%d - 1];
  if (!item || !item.isConnected) return "";
  item.scrollIntoView({ block: "center" });
  const box = item.getBoundingClientRect(), x = box.left + box.width / 2, y = box.top + box.height / 2;
  const top = document.elementFromPoint(x, y);
  if (!top || !(top === item || item.contains(top) || (item.labels && [...item.labels].includes(top)))) return "";
  return JSON.stringify({ x, y });
})()"""
FOCUS_SCRIPT = r"""(() => {
  const item = window.__iris && window.__iris[%d - 1];
  if (!item || !item.isConnected) return false;
  item.focus();
  if (item.select) item.select();
  return document.activeElement === item;
})()"""


def find_browser() -> str | None:
    bases = [os.environ.get(name) for name in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
    for base in filter(None, bases):
        for part in ("Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe"):
            if (Path(base) / part).exists():
                return str(Path(base) / part)
    return next(filter(None, map(shutil.which, ("msedge", "google-chrome", "chromium", "chromium-browser"))), None)


def public_address(host: str) -> str | None:
    """Return the address to use, or nothing when any answer points somewhere private."""
    try:
        found = [item[4][0].split("%")[0] for item in socket.getaddrinfo(host, None)]
    except OSError:
        return None
    return found[0] if found and all(ipaddress.ip_address(item).is_global for item in found) else None


class _Filter(socketserver.ThreadingTCPServer):
    """All browser traffic passes here, including pop-ups and hidden frames, so nothing reaches the home network."""

    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, resolve: Callable[[str], str | None], ports: tuple[int, ...]) -> None:
        self.resolve = resolve
        self.ports = ports
        super().__init__(("127.0.0.1", 0), _FilterHandler)
        threading.Thread(target=self.serve_forever, daemon=True).start()

    @property
    def port(self) -> int:
        return self.server_address[1]

    def stop(self) -> None:
        self.shutdown()
        self.server_close()


class _FilterHandler(socketserver.BaseRequestHandler):
    def _head(self) -> bytes:
        head = b""
        while b"\r\n\r\n" not in head and len(head) < MAX_HEAD:
            part = self.request.recv(4096)
            if not part:
                return b""
            head += part
        return head

    def _open(self, host: str, port: int) -> socket.socket | None:
        address = self.server.resolve(host) if port in self.server.ports else None
        return socket.create_connection((address, port), timeout=CALL_SECONDS) if address else None

    def handle(self) -> None:
        self.request.settimeout(TUNNEL_IDLE_SECONDS)
        try:
            head = self._head()
            first = head.split(b"\r\n", 1)[0].decode("latin-1").split()
            if len(first) != 3:
                return
            if first[0] == "CONNECT":
                host, _, port = first[1].rpartition(":")
                remote = self._open(host.strip("[]"), int(port or 0))
                if remote:
                    self.request.sendall(READY)
            else:
                parts = urlsplit(first[1])
                remote = self._open(parts.hostname or "", parts.port or 80) if parts.scheme == "http" else None
                if remote:
                    path = (parts.path or "/") + (f"?{parts.query}" if parts.query else "")
                    rest = re.sub(rb"(?im)^(proxy-connection|connection):.*\r\n", b"", head.split(b"\r\n", 1)[1])
                    remote.sendall(f"{first[0]} {path} {first[2]}\r\nConnection: close\r\n".encode("latin-1") + rest)
            if not remote:
                self.request.sendall(BLOCKED)
                return
            with remote:
                self._relay(remote)
        except (OSError, ValueError):
            return

    def _relay(self, remote: socket.socket) -> None:
        pair = {self.request: remote, remote: self.request}
        while True:
            ready = select.select(list(pair), [], [], TUNNEL_IDLE_SECONDS)[0]
            if not ready:
                return
            for side in ready:
                data = side.recv(65536)
                if not data:
                    return
                pair[side].sendall(data)


class _Socket:
    """The small part of the WebSocket protocol the browser's control channel needs."""

    def __init__(self, url: str) -> None:
        parts = urlsplit(url)
        self.raw = socket.create_connection((parts.hostname, parts.port), timeout=CALL_SECONDS)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        self.raw.sendall(
            f"GET {parts.path} HTTP/1.1\r\nHost: {parts.netloc}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n".encode("ascii")
        )
        answer = b""
        while b"\r\n\r\n" not in answer:
            part = self.raw.recv(1)
            if not part:
                raise OSError("no answer")
            answer += part
        if b" 101 " not in answer.split(b"\r\n", 1)[0]:
            raise OSError("refused")

    def _bytes(self, count: int) -> bytes:
        data = b""
        while len(data) < count:
            part = self.raw.recv(count - len(data))
            if not part:
                raise OSError("closed")
            data += part
        return data

    def _send(self, kind: int, data: bytes) -> None:
        size = len(data)
        length = bytes([0x80 | size]) if size < 126 else b"\xfe" + struct.pack(">H", size) if size < 65536 else b"\xff" + struct.pack(">Q", size)
        mask = os.urandom(4)
        masked = bytes(byte ^ mask[index % 4] for index, byte in enumerate(data))
        self.raw.sendall(bytes([0x80 | kind]) + length + mask + masked)

    def send(self, text: str) -> None:
        self._send(1, text.encode("utf-8"))

    def receive(self, seconds: float) -> str | None:
        self.raw.settimeout(seconds)
        try:
            first = self._bytes(2)
        except TimeoutError:
            return None
        self.raw.settimeout(CALL_SECONDS)
        message = b""
        while True:
            size = first[1] & 0x7F
            if size == 126:
                size = struct.unpack(">H", self._bytes(2))[0]
            elif size == 127:
                size = struct.unpack(">Q", self._bytes(8))[0]
            if size > MAX_FRAME:
                raise OSError("too large")
            data = self._bytes(size)
            kind = first[0] & 0x0F
            if kind == 8:
                raise OSError("closed")
            if kind == 9:
                self._send(10, data)
            elif kind != 10:
                message += data
                if first[0] & 0x80:
                    return message.decode("utf-8", errors="replace")
            first = self._bytes(2)

    def close(self) -> None:
        self.raw.close()


class _Page:
    def __init__(self, url: str) -> None:
        self.socket = _Socket(url)
        self.last = 0
        self.events: list[str] = []
        self.call("Page.enable")
        self.call("Page.setDownloadBehavior", behavior="deny")

    def _handle(self, message: dict[str, Any]) -> None:
        method = message.get("method", "")
        self.events.append(method)
        if method == "Page.javascriptDialogOpening":
            self.socket.send(json.dumps({"id": 0, "method": "Page.handleJavaScriptDialog", "params": {"accept": False}}))

    def call(self, method: str, **params: Any) -> dict[str, Any]:
        self.last += 1
        wanted = self.last
        self.socket.send(json.dumps({"id": wanted, "method": method, "params": params}))
        ends = time.monotonic() + CALL_SECONDS
        while time.monotonic() < ends:
            text = self.socket.receive(max(0.05, ends - time.monotonic()))
            if text is None:
                continue
            message = json.loads(text)
            if "method" in message:
                self._handle(message)
            elif message.get("id") == wanted:
                if "error" in message:
                    raise ConnectorError("The page refused that action. Read the page again.")
                return message.get("result", {})
        raise OSError("no answer")

    def wait(self, event: str, seconds: float) -> bool:
        ends = time.monotonic() + seconds
        while event not in self.events and time.monotonic() < ends:
            text = self.socket.receive(max(0.05, ends - time.monotonic()))
            if text is not None:
                message = json.loads(text)
                if "method" in message:
                    self._handle(message)
        return event in self.events


class Browser:
    id = "browser"
    name = "Browser"
    summary = "Open public websites in a separate, signed-out browser. Pages open and clicks happen only with approval."

    def __init__(
        self,
        folder: Path,
        locate: Callable[[], str | None] = find_browser,
        resolve: Callable[[str], str | None] = public_address,
        check_url: Callable[[str], str] = check_public_url,
        ports: tuple[int, ...] = WEB_PORTS,
        extra_arguments: tuple[str, ...] = (),
    ) -> None:
        self.folder = folder
        self.locate = locate
        self.resolve = resolve
        self.check_url = check_url
        self.ports = ports
        self.extra_arguments = extra_arguments
        self.blocked: Callable[[], bool] = lambda: False
        self.lock = threading.RLock()
        self.process: subprocess.Popen | None = None
        self.filter: _Filter | None = None
        self.page: _Page | None = None
        self.profile: Path | None = None
        self.port = 0
        self.target = ""
        self.world = 0
        self.items: dict[int, dict[str, Any]] = {}
        self.timer: threading.Timer | None = None

    def status(self) -> dict[str, Any]:
        return {"connected": bool(self.locate()), "open": self.process is not None}

    def _list(self) -> list[dict[str, Any]]:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f"http://127.0.0.1:{self.port}/json/list", timeout=CALL_SECONDS) as response:
            return [item for item in json.loads(response.read()) if item.get("type") == "page"]

    def _start(self) -> None:
        path = self.locate()
        if not path:
            raise ConnectorError("Install Microsoft Edge or Google Chrome.")
        shutil.rmtree(self.folder, ignore_errors=True)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.profile = Path(tempfile.mkdtemp(dir=self.folder))
        self.filter = _Filter(self.resolve, self.ports)
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        self.process = subprocess.Popen(
            [
                path, "--headless=new", "--remote-debugging-port=0", f"--user-data-dir={self.profile}",
                f"--proxy-server=http://127.0.0.1:{self.filter.port}", "--proxy-bypass-list=<-loopback>",
                "--disable-quic", "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",
                "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--disable-sync",
                "--disable-background-networking", "--disable-component-update", "--disable-gpu",
                "--window-size=1280,900", *self.extra_arguments, "about:blank",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
        )
        port_file = self.profile / "DevToolsActivePort"
        ends = time.monotonic() + START_SECONDS
        while time.monotonic() < ends:
            if port_file.exists() and port_file.read_text(encoding="ascii").strip():
                self.port = int(port_file.read_text(encoding="ascii").split()[0])
                pages = self._list()
                if pages:
                    self._attach(pages[0])
                    return
            if self.process.poll() is not None:
                break
            time.sleep(0.1)
        self.close()
        raise ConnectorError("The browser did not start.")

    def _attach(self, target: dict[str, Any]) -> None:
        if self.page:
            self.page.socket.close()
        self.page = _Page(target["webSocketDebuggerUrl"])
        self.target = target["id"]

    def close(self) -> None:
        with self.lock:
            if self.timer:
                self.timer.cancel()
                self.timer = None
            process, self.process = self.process, None
            if self.page:
                try:
                    self.page.socket.close()
                except OSError:
                    pass
                self.page = None
            if process:
                if sys.platform == "win32":
                    subprocess.run(
                        ["taskkill", "/T", "/F", "/PID", str(process.pid)],
                        capture_output=True,
                        creationflags=subprocess.CREATE_NO_WINDOW,
                    )
                process.kill()
                process.wait()
            if self.filter:
                self.filter.stop()
                self.filter = None
            if self.profile:
                shutil.rmtree(self.profile, ignore_errors=True)
                self.profile = None
            self.items = {}
            self.world = 0

    def _guarded(self, action: Callable[[], str]) -> str:
        with self.lock:
            if self.blocked():
                self.close()
                raise ConnectorError("IRIS is stopped, so the browser is closed.")
            try:
                result = action()
            except (OSError, ValueError, KeyError):
                self.close()
                raise ConnectorError("The browser stopped responding, so it was closed.") from None
            if self.timer:
                self.timer.cancel()
            self.timer = threading.Timer(IDLE_SECONDS, self.close)
            self.timer.daemon = True
            self.timer.start()
            return result

    def _settle(self) -> None:
        """Wait for a page load if the last action started one."""
        if self.page.wait("Page.frameStartedLoading", 1.0):
            self.page.wait("Page.loadEventFired", LOAD_SECONDS)
        time.sleep(0.4)

    def _script(self, source: str) -> Any:
        result = self.page.call("Runtime.evaluate", expression=source, contextId=self.world, returnByValue=True)
        if "exceptionDetails" in result:
            raise ConnectorError("The page changed. Read it again.")
        return result["result"].get("value")

    def _read_page(self, page_number: int = 1) -> str:
        # The separate script world keeps the page from faking what IRIS reads.
        frame = self.page.call("Page.getFrameTree")["frameTree"]["frame"]["id"]
        self.world = self.page.call("Page.createIsolatedWorld", frameId=frame, worldName="iris")["executionContextId"]
        seen = json.loads(self._script(PAGE_SCRIPT))
        self.items = {item["number"]: {**item, "host": urlsplit(seen["url"]).hostname or ""} for item in seen["items"]}
        text = seen["text"].strip()
        start = (page_number - 1) * MAX_TEXT
        part = text[start : start + MAX_TEXT]
        lines = [UNTRUSTED_NOTE + f"Title: {seen['title']}", f"Address: {seen['url']}", "", part]
        if start + MAX_TEXT < len(text):
            lines.append(f"...[more text: use part {page_number + 1}]")
        if self.items:
            lines += ["", "Things on this page:"]
            lines += [f"[{item['number']}] {item['tag']} {item['type']}: {item['label']}".replace("  ", " ") for item in self.items.values()]
        return "\n".join(lines)

    def _open(self, args: dict[str, Any]) -> str:
        url = self.check_url(require_text(args, "url", 2000))

        def action() -> str:
            if not self.process:
                self._start()
            self.page.events.clear()
            found = self.page.call("Page.navigate", url=url)
            if found.get("errorText"):
                return "That page could not be opened."
            self.page.wait("Page.loadEventFired", LOAD_SECONDS)
            time.sleep(0.4)
            return self._read_page()

        return self._guarded(action)

    def _read(self, args: dict[str, Any]) -> str:
        if not self.process:
            return "No page is open."
        return self._guarded(lambda: self._read_page(whole_number(args, "part", 1, 100)))

    def _item(self, args: dict[str, Any], name: str) -> dict[str, Any]:
        """Check the approved words against the real page, so the approval shows what will really happen."""
        item = self.items.get(whole_number(args, "number", 0, 1000))
        if not item:
            raise ConnectorError("That is not on the page. Read the page again.")
        site = require_text(args, "site", 300).lower().removeprefix("www.")
        wanted = require_text(args, name, 200).casefold()
        if site != item["host"].lower().removeprefix("www.") or len(wanted) < 2 or wanted not in item["label"].casefold():
            raise ConnectorError(f"Number {item['number']} on this site is: {item['label']}. Nothing was done.")
        return item

    def _after_action(self) -> str:
        self._settle()
        known = self.target
        pages = self._list()
        fresh = next((page for page in pages if page["id"] != known), None)
        if fresh:
            self._attach(fresh)
            self.page.wait("Page.loadEventFired", 5)
            urllib.request.build_opener(urllib.request.ProxyHandler({})).open(
                f"http://127.0.0.1:{self.port}/json/close/{known}", timeout=CALL_SECONDS
            ).close()
        return self._read_page()

    def _click(self, args: dict[str, Any]) -> str:
        def action() -> str:
            item = self._item(args, "what")
            if SPENDING.search(item["label"]):
                raise ConnectorError("IRIS does not press buttons that spend money. Please do that yourself.")
            if item["type"] == "file":
                raise ConnectorError("IRIS does not upload files.")
            aim = self._script(AIM_SCRIPT % item["number"])
            if not aim:
                raise ConnectorError("Something covers that item, or it is gone. Read the page again.")
            point = json.loads(aim)
            self.page.events.clear()
            for kind in ("mousePressed", "mouseReleased"):
                self.page.call("Input.dispatchMouseEvent", type=kind, x=point["x"], y=point["y"], button="left", clickCount=1)
            return self._after_action()

        return self._guarded(action)

    def _type(self, args: dict[str, Any]) -> str:
        text = require_text(args, "text", 2000)

        def action() -> str:
            item = self._item(args, "field")
            private = PRIVATE_FIELD.search(f"{item['label']} {item['hint']}") or PRIVATE_AUTOFILL.match(item["autofill"])
            if item["type"] in REFUSED_TYPES or private:
                raise ConnectorError("IRIS does not fill in passwords, card numbers or similar. Please do that yourself.")
            if not item["typed"] or item["tag"] == "select":
                raise ConnectorError("IRIS cannot type there.")
            if not self._script(FOCUS_SCRIPT % item["number"]):
                raise ConnectorError("That field is gone. Read the page again.")
            self.page.events.clear()
            self.page.call("Input.insertText", text=text)
            if args.get("submit"):
                for kind in ("keyDown", "keyUp"):
                    self.page.call(
                        "Input.dispatchKeyEvent", type=kind, key="Enter", code="Enter",
                        windowsVirtualKeyCode=13, text="\r" if kind == "keyDown" else "",
                    )
            return self._after_action()

        return self._guarded(action)

    def _close(self, _args: dict[str, Any]) -> str:
        self.close()
        return "The browser is closed and everything from the visit is deleted."

    def tools(self) -> list[Tool]:
        return [
            Tool("browser_open", "Open a public web page in the separate browser and read it.", {"url": str}, WRITE, self._open),
            Tool("browser_read", "Read the open page again. Long pages have numbered parts.", {"part": int}, READ, self._read),
            Tool(
                "browser_click",
                "Click one numbered thing on the page. site is its address and what is its exact label, both as listed.",
                {"site": str, "number": int, "what": str},
                WRITE,
                self._click,
            ),
            Tool(
                "browser_type",
                "Type into one numbered field. site is its address, field its exact label. submit presses Enter.",
                {"site": str, "number": int, "field": str, "text": str, "submit": bool},
                WRITE,
                self._type,
            ),
            Tool("browser_close", "Close the browser and delete everything from the visit.", {}, READ, self._close),
        ]
