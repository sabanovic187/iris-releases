"""The Unbound brain: a model from abliteration.ai for conversation only.

It is never given a tool, never sees IRIS memory, files or connected services, and is never
chosen by Auto. It receives only the words of the current Unbound conversation.
"""
from __future__ import annotations

from typing import Any

from iris.connectors.base import ConnectorError, call_json
from iris.connectors.vault import Vault

API = "https://api.abliteration.ai/v1"
DEFAULT_MODEL = "abliterated-model"
ROLE = "You are IRIS in Unbound mode, talking with your owner. You have no tools; you only talk. Be direct and natural."
MAX_TURNS = 40
MAX_LINE = 8000
MAX_ANSWER_TOKENS = 2000
ANSWER_SECONDS = 120


def reply_text(reply: dict[str, Any]) -> str:
    choices = reply.get("choices") or []
    if not choices:
        return ""
    return str((choices[0].get("message") or {}).get("content") or "").strip()


class Abliteration:
    id = "abliteration"
    name = "Unbound"
    in_settings = True

    def __init__(self, vault: Vault, api: str = API) -> None:
        self.vault = vault
        self.api = api
        self.turns: list[dict[str, str]] = []
        self.on_usage: Any = lambda _model, _in, _out: None

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        return {"connected": bool(saved), "account": (saved or {}).get("model", "")}

    def connect(self, key: str, model: str = "") -> str:
        key, model = key.strip(), model.strip() or DEFAULT_MODEL
        if not key:
            raise ConnectorError("Paste an API key first.")
        found = call_json("GET", f"{self.api}/models", key)
        ids = [item.get("id", "") for item in found.get("data", [])] if isinstance(found, dict) else []
        if ids and model not in ids:
            raise ConnectorError(f"This account does not offer that model. Available: {', '.join(ids)}.")
        self.vault.save(self.id, {"key": key, "model": model})
        return model

    def disconnect(self) -> None:
        self.vault.delete(self.id)
        self.forget()

    def forget(self) -> None:
        self.turns = []

    def chat(self, line: str) -> str:
        """One turn of conversation. No tools are offered, so the model can only answer in words."""
        saved = self.vault.load(self.id)
        if not saved:
            raise ConnectorError("Unbound has no key. Add it in Settings.")
        self.turns.append({"role": "user", "content": line[:MAX_LINE]})
        self.turns = self.turns[-MAX_TURNS:]
        body = {
            "model": saved["model"],
            "messages": [{"role": "system", "content": ROLE}, *self.turns],
            "max_tokens": MAX_ANSWER_TOKENS,
        }
        try:
            reply = call_json("POST", f"{self.api}/chat/completions", saved["key"], data=body, timeout=ANSWER_SECONDS)
        except ConnectorError as error:
            self.turns.pop()
            if "(401)" in str(error) or "(403)" in str(error):
                raise ConnectorError("The Unbound key was refused. Check it in Settings.") from None
            if "(429)" in str(error):
                raise ConnectorError("Unbound refused: no credit left or too many requests.") from None
            raise
        text = reply_text(reply) if isinstance(reply, dict) else ""
        if not text:
            self.turns.pop()
            return "No answer came back."
        self.turns.append({"role": "assistant", "content": text})
        used = reply.get("usage") or {}
        self.on_usage(saved["model"], int(used.get("prompt_tokens") or 0), int(used.get("completion_tokens") or 0))
        return text
