"""Keeps the connectors together and gives their tools to IRIS."""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Callable

from claude_agent_sdk import create_sdk_mcp_server, tool

from iris.audit import redact
from iris.connectors.base import UNTRUSTED_NOTE, ConnectorError, Tool
from iris.connectors.abliteration import Abliteration
from iris.connectors.agents import LocalAgent, OpenAI
from iris.connectors.browser import Browser
from iris.connectors.documents import Documents
from iris.connectors.elevenlabs import ElevenLabs
from iris.connectors.files import Files
from iris.connectors.github import GitHub
from iris.connectors.google import Google
from iris.connectors.home import Home
from iris.connectors.images import Images
from iris.connectors.knowledge import Knowledge
from iris.connectors.media import Media
from iris.connectors.network import Network
from iris.connectors.outlook import Outlook
from iris.connectors.rates import Rates
from iris.connectors.spotify import Spotify
from iris.connectors.telegram import Telegram
from iris.connectors.vault import Vault
from iris.connectors.watch import Watches
from iris.safety import scan, warning

SERVER_NAME = "connectors"


# Services that only work after the owner connects them or installs something.
NEEDS_CONNECTION = frozenset({"google", "outlook", "github", "spotify", "home", "openai", "network", "media"})


class Connectors:
    def __init__(self, data_dir: Path, vault: Vault | None = None, workspace: Path | None = None) -> None:
        folder = data_dir / "connectors"
        self.vault = vault or Vault(folder)
        self.google = Google(self.vault)
        self.github = GitHub(self.vault)
        self.files = Files(folder / "folders.json")
        self.media = Media(workspace or data_dir, data_dir / "models")
        self.watches = Watches(folder / "watches.json", data_dir / "alerts.jsonl")
        self.images = Images(workspace or data_dir)
        self.network = Network()
        self.home = Home(self.vault)
        self.telegram = Telegram(self.vault)
        self.on_suspicious: Callable[[str, list[str]], None] = lambda _tool, _findings: None
        self.documents = Documents(workspace or data_dir, self.files.folders)
        self.knowledge = Knowledge(data_dir / "knowledge.db", self.files.folders)
        self.browser = Browser(data_dir / "browser")
        self.outlook = Outlook(self.vault)
        self.elevenlabs = ElevenLabs(self.vault)
        self.spotify = Spotify(self.vault)
        self.rates = Rates()
        self.openai = OpenAI(self.vault)
        # Conversation only. Kept out of self.items on purpose, so it can never offer a tool.
        self.abliteration = Abliteration(self.vault)
        self.local_agent = LocalAgent()
        self.items = (
            self.telegram, self.openai, self.local_agent, self.elevenlabs, self.google, self.outlook, self.spotify, self.rates, self.github, self.files, self.knowledge, self.documents, self.browser, self.home,
            self.media, self.watches, self.images, self.network,
        )
        self.extra_tools: list[Tool] = []

    def tools(self) -> list[Tool]:
        return [item for connector in self.items for item in connector.tools()] + self.extra_tools

    def _ready(self, connector: Any) -> bool:
        if connector.id not in NEEDS_CONNECTION:
            return True
        try:
            return bool(connector.status().get("connected"))
        except (OSError, ValueError):
            return False

    def active_tools(self) -> list[Tool]:
        """Every tool's description is sent with every message, so tools for services that are not
        connected stay out until they are."""
        return [item for connector in self.items if self._ready(connector) for item in connector.tools()] + self.extra_tools

    def active_signature(self) -> tuple[str, ...]:
        return tuple(sorted(connector.id for connector in self.items if connector.id in NEEDS_CONNECTION and self._ready(connector)))

    def risks(self) -> dict[str, str]:
        return {item.name: item.risk for item in self.tools()}

    def status(self) -> list[dict[str, Any]]:
        found = []
        for connector in self.items:
            if getattr(connector, "in_settings", False):
                continue
            try:
                state = connector.status()
            except (OSError, ValueError):
                state = {"connected": False, "problem": "The saved connection could not be read. Connect again."}
            found.append({"id": connector.id, "name": connector.name, "summary": connector.summary, **state})
        return found

    def inspect(self, name: str, text: str) -> str:
        """Remove secrets from tool output and warn about text that tries to give orders."""
        text = redact(text)
        if UNTRUSTED_NOTE in text:
            findings = scan(text)
            if findings:
                self.on_suspicious(name, findings)
                return warning(findings) + text
        return text

    def server(self, only: frozenset[str] | None = None) -> dict[str, Any]:
        def wrap(item: Tool) -> Any:
            @tool(item.name, item.description, item.schema)
            async def run(args: dict[str, Any]) -> dict[str, Any]:
                try:
                    text = item.run(args) if item.on_loop else await asyncio.to_thread(item.run, args)
                    if asyncio.iscoroutine(text):  # a tool that needs to wait on the main loop
                        text = await text
                except ConnectorError as error:
                    text = str(error)
                except OSError as error:
                    text = f"The action failed ({type(error).__name__})."
                return {"content": [{"type": "text", "text": self.inspect(item.name, text)}]}

            return run

        return {SERVER_NAME: create_sdk_mcp_server(SERVER_NAME, tools=[wrap(item) for item in self.active_tools() if only is None or item.name in only])}
