"""Home devices through the owner's Home Assistant on the home network."""
from __future__ import annotations

import ipaddress
import re
import socket
from typing import Any
from urllib.parse import quote, urlsplit

from iris.connectors.base import READ, WRITE, ConnectorError, Tool, call_json, require_text
from iris.connectors.vault import Vault

SHOWN = {"light", "switch", "media_player", "climate", "sensor", "binary_sensor", "vacuum", "fan"}
ACTIONS = {
    "light": {"turn_on", "turn_off", "toggle"},
    "switch": {"turn_on", "turn_off", "toggle"},
    "fan": {"turn_on", "turn_off"},
    "media_player": {"turn_on", "turn_off", "media_play", "media_pause", "volume_mute"},
    "vacuum": {"start", "stop", "return_to_base"},
}
MAX_DEVICES = 200
FORBIDDEN = re.compile(r"lock|alarm|siren|garage|gate|door|camera|brava|kapij|vrata|garaz|garaž|sirena|kamer", re.I)


def check_home_address(url: str) -> str:
    """Home Assistant must be on this home network, so the token never leaves it."""
    url = url.strip().rstrip("/")
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise ConnectorError("Use an address like http://homeassistant.local:8123.")
    try:
        found = socket.getaddrinfo(parts.hostname, None)
    except OSError:
        raise ConnectorError("That address could not be found.") from None
    for item in found:
        if not ipaddress.ip_address(item[4][0].split("%")[0]).is_private:
            raise ConnectorError("Home Assistant must be on your home network.")
    return url


class Home:
    id = "home"
    name = "Home Assistant"
    summary = "See home devices and control lights, plugs, media and vacuums with approval. Locks and alarms stay out."

    def __init__(self, vault: Vault, check_address: Any = check_home_address) -> None:
        self.vault = vault
        self.check_address = check_address

    def _saved(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        if not saved:
            raise ConnectorError("Home Assistant is not connected. Connect it on the Connections screen.")
        return saved

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        return {"connected": bool(saved), "account": (saved or {}).get("url", "")}

    def connect(self, url: str, token: str) -> None:
        url = self.check_address(url)
        token = token.strip()
        if not token:
            raise ConnectorError("Paste a long-lived access token first.")
        call_json("GET", f"{url}/api/", token)
        self.vault.save(self.id, {"url": url, "token": token})

    def disconnect(self) -> None:
        self.vault.delete(self.id)

    def _devices(self, _args: dict[str, Any]) -> str:
        saved = self._saved()
        states = call_json("GET", f"{saved['url']}/api/states", saved["token"])
        lines = []
        for item in states:
            entity = item.get("entity_id", "")
            if entity.split(".")[0] in SHOWN:
                name = item.get("attributes", {}).get("friendly_name", "")
                lines.append(f"{entity} | {name} | {item.get('state', '')}")
        return "\n".join(lines[:MAX_DEVICES]) or "No devices found."

    def _control(self, args: dict[str, Any]) -> str:
        entity = require_text(args, "entity_id", 200)
        action = require_text(args, "action", 50)
        if not re.fullmatch(r"[a-z_]+\.[a-z0-9_]+", entity):
            raise ConnectorError("That is not a device name.")
        domain = entity.split(".")[0]
        if action not in ACTIONS.get(domain, set()):
            raise ConnectorError("IRIS may not do that with this device.")
        saved = self._saved()
        state = call_json("GET", f"{saved['url']}/api/states/{quote(entity)}", saved["token"])
        attributes = state.get("attributes", {})
        label = f"{entity} {attributes.get('friendly_name', '')} {attributes.get('device_class', '')}"
        if FORBIDDEN.search(label):
            raise ConnectorError("Locks, alarms, doors and cameras are not available to IRIS.")
        url = f"{saved['url']}/api/services/{quote(domain)}/{quote(action)}"
        call_json("POST", url, saved["token"], data={"entity_id": entity})
        return f"Sent {action} to {entity}."

    def set_lights(self, entities: list[str], on: bool, brightness: int | None = None, kelvin: int | None = None) -> str:
        """Lights and switches for a scene the owner made. Locks and the like never pass."""
        saved = self._saved()
        by_domain: dict[str, list[str]] = {}
        for entity in entities:
            if not re.fullmatch(r"(light|switch)\.[a-z0-9_]+", entity) or FORBIDDEN.search(entity):
                raise ConnectorError(f"{entity} cannot be switched by a scene.")
            by_domain.setdefault(entity.split(".")[0], []).append(entity)
        for domain, items in by_domain.items():
            data: dict[str, Any] = {"entity_id": items}
            if on and domain == "light":
                if brightness is not None:
                    data["brightness_pct"] = brightness
                if kelvin is not None:
                    data["color_temp_kelvin"] = kelvin
            action = "turn_on" if on else "turn_off"
            call_json("POST", f"{saved['url']}/api/services/{domain}/{action}", saved["token"], data=data)
        return f"Lights {'on' if on else 'off'}."

    def tools(self) -> list[Tool]:
        return [
            Tool("home_devices", "List home devices and their state.", {}, READ, self._devices),
            Tool("home_control", "Control a light, switch, fan, media player or vacuum.", {"entity_id": str, "action": str}, WRITE, self._control),
        ]
