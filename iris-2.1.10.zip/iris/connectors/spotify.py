"""Spotify playback, signed in through the owner's own Spotify app."""
from __future__ import annotations

import asyncio
import re
import secrets
import time
import urllib.parse
from typing import Any, Callable

from iris.connectors.base import READ, UNTRUSTED_NOTE, ConnectorError, ServiceRefused, Tool, call_json, require_text
from iris.connectors.oauth import local_callback, pkce
from iris.connectors.vault import Vault

AUTH_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API = "https://api.spotify.com/v1"
SCOPES = "user-read-playback-state user-modify-playback-state"
CALLBACK_PORT = 8974
REDIRECT = f"http://127.0.0.1:{CALLBACK_PORT}/callback"
SIGN_IN_SECONDS = 300
MAX_RESULTS = 10  # Spotify's limit for apps in development mode
ACTIONS = {"pause": ("PUT", "pause"), "resume": ("PUT", "play"), "next": ("POST", "next"), "previous": ("POST", "previous")}


class Spotify:
    id = "spotify"
    name = "Spotify"
    summary = "See what is playing, search and control playback. Needs Spotify Premium."

    def __init__(self, vault: Vault, token_url: str = TOKEN_URL, api: str = API) -> None:
        self.vault = vault
        self.token_url = token_url
        self.api = api
        self.access: tuple[str, float] | None = None
        self.sign_in: asyncio.Server | None = None

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        return {"connected": bool(saved), "account": (saved or {}).get("account", "")}

    def disconnect(self) -> None:
        self.access = None
        self.vault.delete(self.id)

    async def begin_sign_in(self, client_id: str, open_page: Callable[[str], Any], finished: Callable[[str | None], None]) -> None:
        client_id = client_id.strip()
        if not client_id:
            raise ConnectorError("Enter the client ID.")
        if self.sign_in:
            self.sign_in.close()
        verifier, challenge = pkce()
        state = secrets.token_urlsafe(24)
        try:
            server, _port, answer = await local_callback(state, CALLBACK_PORT)
        except OSError:
            raise ConnectorError(f"Port {CALLBACK_PORT} is in use. Try again in a moment.") from None
        self.sign_in = server

        async def wait() -> None:
            try:
                code = await asyncio.wait_for(answer, SIGN_IN_SECONDS)
                await asyncio.to_thread(self._finish, client_id, code, verifier)
                finished(None)
            except asyncio.TimeoutError:
                finished("Sign-in timed out. Try again.")
            except ConnectorError as error:
                finished(str(error))
            finally:
                server.close()
                self.sign_in = None

        self.waiter = asyncio.create_task(wait())
        query = urllib.parse.urlencode({
            "client_id": client_id, "response_type": "code", "redirect_uri": REDIRECT, "scope": SCOPES,
            "state": state, "code_challenge": challenge, "code_challenge_method": "S256",
        })
        await asyncio.to_thread(open_page, f"{AUTH_URL}?{query}")

    def _finish(self, client_id: str, code: str, verifier: str) -> None:
        tokens = call_json("POST", self.token_url, form={
            "client_id": client_id, "grant_type": "authorization_code", "code": code,
            "redirect_uri": REDIRECT, "code_verifier": verifier,
        })
        if not tokens.get("refresh_token"):
            raise ConnectorError("Spotify did not give IRIS lasting access. Try again.")
        self.access = (tokens["access_token"], time.time() + int(tokens.get("expires_in", 0)))
        profile = call_json("GET", f"{self.api}/me", self.access[0])
        self.vault.save(self.id, {
            "client_id": client_id, "refresh_token": tokens["refresh_token"], "account": profile.get("display_name") or "",
        })

    def _token(self) -> str:
        if self.access and self.access[1] - 60 > time.time():
            return self.access[0]
        saved = self.vault.load(self.id)
        if not saved:
            raise ConnectorError("Spotify is not connected. Connect it on the Connections screen.")
        tokens = call_json("POST", self.token_url, form={
            "client_id": saved["client_id"], "grant_type": "refresh_token", "refresh_token": saved["refresh_token"],
        })
        if tokens.get("refresh_token"):
            self.vault.save(self.id, {**saved, "refresh_token": tokens["refresh_token"]})
        self.access = (tokens["access_token"], time.time() + int(tokens.get("expires_in", 0)))
        return self.access[0]

    def _player(self, method: str, path: str, data: dict[str, Any] | None = None) -> None:
        try:
            call_json(method, f"{self.api}/me/player/{path}", self._token(), data=data, plain=True)
        except ServiceRefused as error:
            if error.status == 404:
                raise ConnectorError("No active device. Open Spotify on a device first.") from None
            if error.status == 403:
                if "PREMIUM_REQUIRED" in error.detail:
                    raise ConnectorError("Spotify refused. Controlling playback needs Premium.") from None
                # Spotify says this when the player is already in that state, such as play while playing.
                raise ConnectorError("Spotify did not allow that right now. Nothing changed.") from None
            raise

    def state(self) -> dict[str, Any]:
        """What the music panel shows."""
        state = call_json("GET", f"{self.api}/me/player", self._token(), plain=True)
        devices = call_json("GET", f"{self.api}/me/player/devices", self._token(), plain=True).get("devices", [])
        item = state.get("item") or {}
        pictures = item.get("album", {}).get("images", [])
        picture = next((image["url"] for image in reversed(pictures) if image.get("width", 0) >= 200), "")
        return {
            "connected": True,
            "playing": bool(state.get("is_playing")),
            "title": item.get("name", ""),
            "artist": ", ".join(artist.get("name", "") for artist in item.get("artists", [])),
            "image": picture if picture.startswith("https://i.scdn.co/") else "",
            "position": state.get("progress_ms") or 0,
            "length": item.get("duration_ms") or 0,
            "volume": state.get("device", {}).get("volume_percent"),
            "device": state.get("device", {}).get("id", ""),
            "devices": [{"id": device.get("id", ""), "name": device.get("name", "")} for device in devices if device.get("id")],
        }

    def find(self, query: str) -> list[dict[str, str]]:
        words = urllib.parse.urlencode({"q": query.strip()[:200], "type": "track", "limit": MAX_RESULTS})
        tracks = call_json("GET", f"{self.api}/search?{words}", self._token()).get("tracks", {}).get("items", [])
        return [
            {"uri": track.get("uri", ""), "title": track.get("name", ""), "artist": ", ".join(artist.get("name", "") for artist in track.get("artists", []))}
            for track in tracks if track
        ]

    def use_device(self, device: str) -> None:
        if not re.fullmatch(r"[A-Za-z0-9]{10,64}", device):
            raise ConnectorError("Unknown device.")
        try:
            call_json("PUT", f"{self.api}/me/player", self._token(), data={"device_ids": [device], "play": True}, plain=True)
        except ConnectorError as error:
            raise ConnectorError("Spotify could not switch to that device.") from error

    def _now(self, _args: dict[str, Any]) -> str:
        state = call_json("GET", f"{self.api}/me/player", self._token())
        item = state.get("item")
        if not item:
            return "Nothing is playing."
        artists = ", ".join(artist.get("name", "") for artist in item.get("artists", []))
        word = "Playing" if state.get("is_playing") else "Paused"
        device = state.get("device", {}).get("name", "")
        return f"{UNTRUSTED_NOTE}{word}: {item.get('name', '')} by {artists} on {device}"

    def _search(self, args: dict[str, Any]) -> str:
        query = urllib.parse.urlencode({"q": require_text(args, "query", 200), "type": "track,playlist", "limit": MAX_RESULTS})
        found = call_json("GET", f"{self.api}/search?{query}", self._token())
        lines = []
        for track in found.get("tracks", {}).get("items", []):
            artists = ", ".join(artist.get("name", "") for artist in track.get("artists", []))
            lines.append(f"{track.get('uri')} | {track.get('name')} by {artists}")
        for playlist in found.get("playlists", {}).get("items", []):
            if playlist:
                lines.append(f"{playlist.get('uri')} | Playlist: {playlist.get('name')}")
        return UNTRUSTED_NOTE + ("\n".join(lines) or "Nothing found.")

    def _play(self, args: dict[str, Any]) -> str:
        uri = require_text(args, "uri", 100)
        if not re.fullmatch(r"spotify:(track|album|artist|playlist):[A-Za-z0-9]{10,40}", uri):
            raise ConnectorError("Use a link from spotify_search.")
        self._player("PUT", "play", {"uris": [uri]} if ":track:" in uri else {"context_uri": uri})
        return "Playing."

    def _control(self, args: dict[str, Any]) -> str:
        action = require_text(args, "action", 20).lower()
        if action == "volume":
            level = max(0, min(int(args.get("volume", 50)), 100))
            self._player("PUT", f"volume?volume_percent={level}")
            return f"Volume {level}."
        if action not in ACTIONS:
            raise ConnectorError("Use pause, resume, next, previous or volume.")
        self._player(*ACTIONS[action])
        return "Done."

    def tools(self) -> list[Tool]:
        # The owner chose no approvals for Spotify, so playback tools use the same level as reading.
        return [
            Tool("spotify_now", "See what is playing on Spotify.", {}, READ, self._now),
            Tool("spotify_search", "Search Spotify for tracks and playlists.", {"query": str}, READ, self._search),
            Tool("spotify_play", "Play a track, album, artist or playlist by its spotify: link.", {"uri": str}, READ, self._play),
            Tool("spotify_control", "Control playback: pause, resume, next, previous or volume (0-100).", {"action": str, "volume": int}, READ, self._control),
        ]
