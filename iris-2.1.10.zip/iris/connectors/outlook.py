"""Outlook mail and calendar through Microsoft Graph. There is no secret: the owner signs in with a short code."""
from __future__ import annotations

import threading
import time
import urllib.parse
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from iris.connectors.base import READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, call_json, require_text, whole_number
from iris.connectors.vault import Vault

LOGIN = "https://login.microsoftonline.com/common/oauth2/v2.0"
GRAPH = "https://graph.microsoft.com/v1.0"
SCOPES = "offline_access User.Read Mail.Read Mail.Send Calendars.Read"
DEVICE_GRANT = "urn:ietf:params:oauth:grant-type:device_code"
MAX_BODY = 8000
TEXT_BODY = {"Prefer": 'outlook.body-content-type="text"'}


class Outlook:
    id = "outlook"
    name = "Outlook"
    summary = "Read Outlook mail and calendar. Sending mail needs approval."

    def __init__(self, vault: Vault, login: str = LOGIN, graph: str = GRAPH) -> None:
        self.vault = vault
        self.login = login
        self.graph = graph
        self.access: tuple[str, float] | None = None
        self.pending: dict[str, str] | None = None
        self.wait_seconds: Callable[[float], None] = time.sleep

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        return {"connected": bool(saved), "account": (saved or {}).get("account", ""), "pending": self.pending}

    def disconnect(self) -> None:
        self.access = None
        self.pending = None
        self.vault.delete(self.id)

    def begin_sign_in(self, client_id: str, open_page: Callable[[str], Any], finished: Callable[[str | None], None]) -> None:
        client_id = client_id.strip()
        if not client_id:
            raise ConnectorError("Enter the application ID.")
        code = call_json("POST", f"{self.login}/devicecode", form={"client_id": client_id, "scope": SCOPES})
        if not code.get("device_code"):
            raise ConnectorError("Microsoft refused. Check the application ID.")
        self.pending = {"code": code["user_code"], "url": code["verification_uri"]}
        threading.Thread(target=self._wait, args=(client_id, code, finished), daemon=True).start()
        open_page(code["verification_uri"])

    def _wait(self, client_id: str, code: dict[str, Any], finished: Callable[[str | None], None]) -> None:
        ends = time.monotonic() + int(code.get("expires_in", 900))
        pause = int(code.get("interval", 5))
        problem: str | None = "Sign-in timed out. Try again."
        while time.monotonic() < ends and self.pending:
            self.wait_seconds(pause)
            try:
                tokens = call_json("POST", f"{self.login}/token", allow_error=True, form={
                    "client_id": client_id, "grant_type": DEVICE_GRANT, "device_code": code["device_code"],
                })
            except ConnectorError:
                continue
            if tokens.get("error") == "authorization_pending":
                continue
            if tokens.get("error") == "slow_down":
                pause += 5
                continue
            if tokens.get("refresh_token"):
                problem = self._save(client_id, tokens)
            else:
                problem = "Microsoft did not finish the sign-in. Try again."
            break
        self.pending = None
        finished(problem)

    def _save(self, client_id: str, tokens: dict[str, Any]) -> str | None:
        self.access = (tokens["access_token"], time.time() + int(tokens.get("expires_in", 0)))
        try:
            me = call_json("GET", f"{self.graph}/me", self.access[0])
        except ConnectorError as error:
            return str(error)
        self.vault.save(self.id, {
            "client_id": client_id, "refresh_token": tokens["refresh_token"],
            "account": me.get("mail") or me.get("userPrincipalName", ""),
        })
        return None

    def _token(self) -> str:
        if self.access and self.access[1] - 60 > time.time():
            return self.access[0]
        saved = self.vault.load(self.id)
        if not saved:
            raise ConnectorError("Outlook is not connected. Connect it on the Connections screen.")
        tokens = call_json("POST", f"{self.login}/token", form={
            "client_id": saved["client_id"], "grant_type": "refresh_token",
            "refresh_token": saved["refresh_token"], "scope": SCOPES,
        })
        if tokens.get("refresh_token"):
            self.vault.save(self.id, {**saved, "refresh_token": tokens["refresh_token"]})
        self.access = (tokens["access_token"], time.time() + int(tokens.get("expires_in", 0)))
        return self.access[0]

    def _search(self, args: dict[str, Any]) -> str:
        count = whole_number(args, "limit", 10, 25)
        query = {"$top": count, "$select": "id,subject,from,receivedDateTime"}
        words = str(args.get("query", "")).replace('"', " ").strip()
        if words:
            query["$search"] = f'"{words}"'
        items = call_json("GET", f"{self.graph}/me/messages?{urllib.parse.urlencode(query)}", self._token()).get("value", [])
        lines = [
            f"{item['id']} | {item.get('receivedDateTime', '')} | "
            f"{item.get('from', {}).get('emailAddress', {}).get('address', '')} | {item.get('subject', '')}"
            for item in items
        ]
        return UNTRUSTED_NOTE + ("\n".join(lines) or "No matching mail.")

    def _read(self, args: dict[str, Any]) -> str:
        message_id = urllib.parse.quote(require_text(args, "id", 500), safe="")
        item = call_json("GET", f"{self.graph}/me/messages/{message_id}", self._token(), headers=TEXT_BODY)
        sender = item.get("from", {}).get("emailAddress", {}).get("address", "")
        body = item.get("body", {}).get("content", "")[:MAX_BODY]
        return f"{UNTRUSTED_NOTE}From: {sender}\nSubject: {item.get('subject', '')}\nDate: {item.get('receivedDateTime', '')}\n\n{body}"

    def _send(self, args: dict[str, Any]) -> str:
        message = {
            "subject": require_text(args, "subject", 500).replace("\n", " "),
            "body": {"contentType": "Text", "content": require_text(args, "body")},
            "toRecipients": [{"emailAddress": {"address": require_text(args, "to", 300)}}],
        }
        call_json("POST", f"{self.graph}/me/sendMail", self._token(), data={"message": message, "saveToSentItems": True})
        return "Mail sent."

    def _calendar(self, args: dict[str, Any]) -> str:
        start = datetime.now(timezone.utc)
        query = urllib.parse.urlencode({
            "startDateTime": start.isoformat(),
            "endDateTime": (start + timedelta(days=whole_number(args, "days", 7, 60))).isoformat(),
            "$orderby": "start/dateTime", "$top": 50, "$select": "subject,start,end",
        })
        items = call_json("GET", f"{self.graph}/me/calendarView?{query}", self._token()).get("value", [])
        lines = [f"{item.get('start', {}).get('dateTime', '')[:16]} UTC {item.get('subject', '')}" for item in items]
        return UNTRUSTED_NOTE + ("\n".join(lines) or "Nothing scheduled.")

    def tools(self) -> list[Tool]:
        return [
            Tool("outlook_search", "Search Outlook mail.", {"query": str, "limit": int}, READ, self._search),
            Tool("outlook_read", "Read one Outlook message by id.", {"id": str}, READ, self._read),
            Tool("outlook_send", "Send an email from Outlook.", {"to": str, "subject": str, "body": str}, WRITE, self._send),
            Tool("outlook_calendar", "List upcoming Outlook events.", {"days": int}, READ, self._calendar),
        ]
