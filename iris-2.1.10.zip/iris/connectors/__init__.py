"""Links to the owner's apps. Reading runs freely; changes need approval."""
