"""Other AI models that IRIS can hand a job to. They get text only and have no tools of their own."""
from __future__ import annotations

from typing import Any

from iris.connectors.base import READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, call_json, require_text
from iris.connectors.vault import Vault

OPENAI = "https://api.openai.com/v1"
ROLE = "You are helping IRIS, a personal assistant. Answer the task directly and briefly."
MAX_TASK = 40000
MAX_ANSWER_TOKENS = 4000
ANSWER_SECONDS = 120
LOCAL_SECONDS = 300
# Checked against the account's real list, because model names change often.
PREFERRED_MODELS = ("gpt-5.6-terra", "gpt-6.1-terra", "gpt-6-sol", "gpt-5.6-luna", "gpt-5.5", "gpt-5.4")
NOT_TEXT = ("audio", "image", "tts", "realtime", "transcribe", "search", "embedding", "moderation", "cyber")


def pick_model(ids: list[str]) -> str:
    for name in PREFERRED_MODELS:
        if name in ids:
            return name
    usable = sorted(item for item in ids if item.startswith("gpt-") and not any(word in item for word in NOT_TEXT))
    if not usable:
        raise ConnectorError("This OpenAI account offers no text model.")
    return usable[-1]


def answer_text(reply: dict[str, Any]) -> tuple[str, list[str]]:
    """Return the words and the web links from an OpenAI answer."""
    parts, links = [], []
    for item in reply.get("output", []):
        for piece in item.get("content", []) or []:
            if piece.get("type") == "output_text":
                parts.append(piece.get("text", ""))
                for note in piece.get("annotations", []) or []:
                    if note.get("type") == "url_citation" and note.get("url") not in links:
                        links.append(note.get("url"))
    return "\n".join(parts).strip(), links


class OpenAI:
    id = "openai"
    name = "OpenAI"
    in_settings = True  # a brain, so its key lives in Settings and not in Connections
    summary = "A second AI for drafts, second opinions and web search. Each job needs approval, because the text leaves this computer."

    def __init__(self, vault: Vault, api: str = OPENAI) -> None:
        self.vault = vault
        self.api = api
        self.blocked = lambda: False
        self.on_usage: Any = lambda _model, _in, _out: None

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        return {"connected": bool(saved), "account": (saved or {}).get("model", "")}

    def connect(self, key: str, model: str = "") -> str:
        key, model = key.strip(), model.strip()
        if not key:
            raise ConnectorError("Paste an API key first.")
        ids = [item.get("id", "") for item in call_json("GET", f"{self.api}/models", key).get("data", [])]
        if model and model not in ids:
            raise ConnectorError("This account does not offer that model.")
        chosen = model or pick_model(ids)
        self.vault.save(self.id, {"key": key, "model": chosen})
        return chosen

    def disconnect(self) -> None:
        self.vault.delete(self.id)

    def _ask(self, args: dict[str, Any]) -> str:
        task = require_text(args, "task", MAX_TASK)
        if self.blocked():
            raise ConnectorError("IRIS is stopped.")
        saved = self.vault.load(self.id)
        if not saved:
            raise ConnectorError("OpenAI is not connected. Connect it on the Connections screen.")
        body: dict[str, Any] = {
            "model": saved["model"], "instructions": ROLE, "input": task, "max_output_tokens": MAX_ANSWER_TOKENS,
        }
        if args.get("web"):
            body["tools"] = [{"type": "web_search"}]
        try:
            reply = call_json("POST", f"{self.api}/responses", saved["key"], data=body, timeout=ANSWER_SECONDS)
        except ConnectorError as error:
            if "(429)" in str(error):
                raise ConnectorError("OpenAI refused: no credit left or too many requests.") from None
            raise
        text, links = answer_text(reply)
        if not text:
            return "OpenAI sent no answer."
        used = reply.get("usage", {})
        self.on_usage(saved["model"], int(used.get("input_tokens") or 0), int(used.get("output_tokens") or 0))
        lines = [UNTRUSTED_NOTE + text]
        if links:
            lines += ["", "Sources:", *links[:20]]
        lines += ["", f"[{saved['model']}, {used.get('input_tokens', 0)} in, {used.get('output_tokens', 0)} out]"]
        return "\n".join(lines)

    def tools(self) -> list[Tool]:
        return [
            Tool(
                "ask_openai",
                "Give a job to OpenAI. It sees only this text. Set web to search the web. Never include secrets.",
                {"task": str, "web": bool},
                WRITE,
                self._ask,
            )
        ]


class LocalAgent:
    id = "local_agent"
    name = "Local AI"
    in_settings = True
    summary = "A free, private AI through Ollama for jobs that should stay on this computer."

    def __init__(self, url: str = "http://127.0.0.1:11434", model: str = "iris-local") -> None:
        self.url = url
        self.model = model
        self.blocked = lambda: False

    def status(self) -> dict[str, Any]:
        return {"connected": True, "account": self.model}

    def _ask(self, args: dict[str, Any]) -> str:
        task = require_text(args, "task", MAX_TASK)
        if self.blocked():
            raise ConnectorError("IRIS is stopped.")
        body = {
            "model": self.model, "stream": False,
            "messages": [{"role": "system", "content": ROLE}, {"role": "user", "content": task}],
        }
        try:
            reply = call_json("POST", f"{self.url}/api/chat", data=body, timeout=LOCAL_SECONDS)
        except ConnectorError:
            raise ConnectorError("The local AI is not running. Start Ollama.") from None
        text = reply.get("message", {}).get("content", "").strip()
        return UNTRUSTED_NOTE + text if text else "The local AI sent no answer."

    def tools(self) -> list[Tool]:
        return [Tool("ask_local", "Give a job to the free, private AI on this computer. It sees only this text.", {"task": str}, READ, self._ask)]
