"""Reads PDF, Word, Excel and PowerPoint files, and writes Word and Excel files."""
from __future__ import annotations

import importlib.util
import re
import zipfile
from pathlib import Path
from typing import Any, Callable
from xml.etree import ElementTree
from xml.sax.saxutils import escape

from iris.connectors.base import READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, require_text
from iris.connectors import ocr

MAX_FILE = 50 * 1024 * 1024
MAX_UNPACKED = 100 * 1024 * 1024
MAX_RETURNED = 30000
MAX_ROWS = 2000
WORD = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
SLIDE_TEXT = "{http://schemas.openxmlformats.org/drawingml/2006/main}t"
READABLE = {".txt", ".md", ".csv", ".log", ".json", ".pdf", ".docx", ".xlsx", ".pptx"}


def _unpack(path: Path) -> zipfile.ZipFile:
    try:
        archive = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError):
        raise ConnectorError("That file is damaged or is not what its name says.") from None
    if sum(item.file_size for item in archive.infolist()) > MAX_UNPACKED:
        raise ConnectorError("That file is too large to open.")
    return archive


def _xml(archive: zipfile.ZipFile, name: str) -> ElementTree.Element:
    try:
        return ElementTree.fromstring(archive.read(name))
    except (ElementTree.ParseError, KeyError):
        raise ConnectorError("That file is damaged.") from None


def read_word(path: Path) -> str:
    with _unpack(path) as archive:
        root = _xml(archive, "word/document.xml")
    paragraphs = []
    for paragraph in root.iter(f"{WORD}p"):
        text = "".join(item.text or "" for item in paragraph.iter(f"{WORD}t"))
        if text.strip():
            paragraphs.append(text)
    return "\n".join(paragraphs)


def read_slides(path: Path) -> str:
    with _unpack(path) as archive:
        names = [name for name in archive.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)]
        names.sort(key=lambda name: int(re.search(r"\d+", name.rsplit("/", 1)[1]).group()))
        slides = []
        for number, name in enumerate(names, 1):
            words = [item.text for item in _xml(archive, name).iter(SLIDE_TEXT) if item.text]
            slides.append(f"Slide {number}: " + " ".join(words))
    return "\n".join(slides)


def read_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader
        from pypdf.errors import PyPdfError
    except ImportError:
        raise ConnectorError("PDF tools are not installed. Run scripts\\setup-tools.ps1.") from None
    try:
        reader = PdfReader(path)
        if reader.is_encrypted:
            raise ConnectorError("That PDF is protected by a password.")
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        return text.strip() or ocr.read_scanned_pages(reader) or "This PDF has no readable text."
    except (PyPdfError, ValueError, KeyError, OSError):
        raise ConnectorError("That PDF could not be read.") from None


def read_sheet(path: Path) -> str:
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise ConnectorError("Excel tools are not installed. Run scripts\\setup-tools.ps1.") from None
    try:
        book = load_workbook(path, read_only=True, data_only=True)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile):
        raise ConnectorError("That workbook could not be read.") from None
    lines = []
    for sheet in book.worksheets:
        lines.append(f"Sheet: {sheet.title}")
        for number, row in enumerate(sheet.iter_rows(values_only=True)):
            if number >= MAX_ROWS:
                lines.append("...[shortened]")
                break
            if any(cell is not None for cell in row):
                lines.append("\t".join("" if cell is None else str(cell) for cell in row))
    book.close()
    return "\n".join(lines)


def read_text(path: Path) -> str:
    """Return the text of a supported file."""
    kind = path.suffix.lower()
    if kind not in READABLE:
        raise ConnectorError("IRIS cannot read that kind of file yet.")
    if path.stat().st_size > MAX_FILE:
        raise ConnectorError("That file is too large.")
    readers = {".pdf": read_pdf, ".docx": read_word, ".xlsx": read_sheet, ".pptx": read_slides}
    if kind in readers:
        return readers[kind](path)
    with path.open("rb") as handle:
        return handle.read(MAX_FILE).decode("utf-8", errors="replace")


DOCX_TYPES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    '<Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/word/document.xml" ContentType='
    '"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'
)
DOCX_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
    'officeDocument" Target="word/document.xml"/></Relationships>'
)


def write_word(path: Path, text: str) -> None:
    body = []
    for line in text.split("\n"):
        heading = line.startswith("# ")
        content = escape(line[2:] if heading else line)
        run = "<w:rPr><w:b/><w:sz w:val=\"32\"/></w:rPr>" if heading else ""
        body.append(f'<w:p><w:r>{run}<w:t xml:space="preserve">{content}</w:t></w:r></w:p>')
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'
        + "".join(body) + "</w:body></w:document>"
    )
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", DOCX_TYPES)
        archive.writestr("_rels/.rels", DOCX_RELS)
        archive.writestr("word/document.xml", document)


def write_sheet(path: Path, rows: str) -> None:
    try:
        from openpyxl import Workbook
    except ImportError:
        raise ConnectorError("Excel tools are not installed. Run scripts\\setup-tools.ps1.") from None
    book = Workbook()
    sheet = book.active
    for line in rows.splitlines():
        cells = []
        for cell in line.split("\t"):
            # A leading = would become a live formula in a file built from outside text.
            cells.append("'" + cell if cell[:1] in ("=", "+", "-", "@") else cell)
        sheet.append(cells)
    book.save(path)


class Documents:
    id = "documents"
    name = "Documents"
    summary = "Read PDF, Word, Excel and PowerPoint files, scans and pictures of text. New files go to the workspace with approval."

    def __init__(self, workspace: Path, allowed_folders: Callable[[], list[str]] = lambda: []) -> None:
        self.workspace = workspace
        self.folder = workspace / "documents"
        self.allowed_folders = allowed_folders

    def status(self) -> dict[str, Any]:
        return {"connected": all(importlib.util.find_spec(name) for name in ("pypdf", "openpyxl"))}

    def _source(self, raw: str) -> Path:
        path = Path(raw)
        path = (path if path.is_absolute() else self.workspace / path).resolve()
        roots = [self.workspace.resolve(), *(Path(folder) for folder in self.allowed_folders())]
        if not any(path.is_relative_to(root) for root in roots):
            raise ConnectorError("That file is outside the workspace and your added folders.")
        from iris.policy import _contains_sensitive_part

        if _contains_sensitive_part(path):
            raise ConnectorError("That looks like a secret file.")
        if not path.is_file():
            raise ConnectorError("That file does not exist.")
        return path

    def _target(self, name: str, suffix: str) -> Path:
        if not re.fullmatch(r"[\w .()-]{1,100}", name) or ".." in name:
            raise ConnectorError("Use a simple file name.")
        self.folder.mkdir(parents=True, exist_ok=True)
        target = self.folder / (Path(name).stem + suffix)
        if target.exists():
            raise ConnectorError("A file with that name already exists.")
        return target

    def _read(self, args: dict[str, Any]) -> str:
        path = self._source(require_text(args, "path", 1000))
        if path.suffix.lower() in ocr.IMAGES:
            if path.stat().st_size > MAX_FILE:
                raise ConnectorError("That file is too large.")
            text = ocr.recognize([path])[0] or "No text was found in that picture."
        else:
            text = read_text(path)
        ending = "\n...[shortened]" if len(text) > MAX_RETURNED else ""
        return UNTRUSTED_NOTE + text[:MAX_RETURNED] + ending

    def _word(self, args: dict[str, Any]) -> str:
        target = self._target(require_text(args, "name", 100), ".docx")
        write_word(target, require_text(args, "text", 200000))
        return f"Saved to {target}"

    def _sheet(self, args: dict[str, Any]) -> str:
        target = self._target(require_text(args, "name", 100), ".xlsx")
        write_sheet(target, require_text(args, "rows", 500000))
        return f"Saved to {target}"

    def tools(self) -> list[Tool]:
        return [
            Tool("document_read", "Read a PDF, scanned PDF, picture of text, Word, Excel, PowerPoint or text file.", {"path": str}, READ, self._read),
            Tool("document_write_word", "Create a Word file. Lines starting with # become headings.", {"name": str, "text": str}, WRITE, self._word),
            Tool("document_write_excel", "Create an Excel file. Rows are lines, cells are separated by tabs.", {"name": str, "rows": str}, WRITE, self._sheet),
        ]
