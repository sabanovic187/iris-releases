"""GitHub, using a personal access token."""
from __future__ import annotations

import re
from typing import Any

from iris.connectors.base import READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, call_json, require_text, whole_number
from iris.connectors.vault import Vault

API = "https://api.github.com"
MAX_BODY = 6000
HEADERS = {"X-GitHub-Api-Version": "2022-11-28", "Accept": "application/vnd.github+json"}


def _repo(args: dict[str, Any]) -> str:
    repo = require_text(args, "repo", 150)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo) or ".." in repo:
        raise ConnectorError("repo must look like owner/name.")
    return repo


class GitHub:
    id = "github"
    name = "GitHub"
    summary = "Read repositories, issues and pull requests. New issues and comments need approval."

    def __init__(self, vault: Vault, api: str = API) -> None:
        self.vault = vault
        self.api = api

    def _token(self) -> str:
        saved = self.vault.load(self.id)
        if not saved:
            raise ConnectorError("GitHub is not connected. Connect it on the Connections screen.")
        return saved["token"]

    def _call(self, method: str, path: str, data: dict[str, Any] | None = None) -> Any:
        return call_json(method, self.api + path, self._token(), data=data, headers=HEADERS)

    def connect(self, token: str) -> str:
        token = token.strip()
        if not token:
            raise ConnectorError("Paste a token first.")
        user = call_json("GET", f"{self.api}/user", token, headers=HEADERS)
        self.vault.save(self.id, {"token": token, "account": user.get("login", "")})
        return user.get("login", "")

    def disconnect(self) -> None:
        self.vault.delete(self.id)

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        return {"connected": bool(saved), "account": (saved or {}).get("account", "")}

    def _repos(self, args: dict[str, Any]) -> str:
        count = whole_number(args, "limit", 30, 100)
        items = self._call("GET", f"/user/repos?sort=pushed&per_page={count}")
        return "\n".join(item["full_name"] for item in items) or "No repositories."

    def _list(self, args: dict[str, Any], kind: str) -> str:
        count = whole_number(args, "limit", 20, 100)
        items = self._call("GET", f"/repos/{_repo(args)}/{kind}?state=open&per_page={count}")
        lines = [f"#{item['number']} {item['title']}" for item in items]
        return UNTRUSTED_NOTE + ("\n".join(lines) or "Nothing open.")

    def _read(self, args: dict[str, Any]) -> str:
        number = whole_number(args, "number", 1, 10**9)
        item = self._call("GET", f"/repos/{_repo(args)}/issues/{number}")
        body = (item.get("body") or "")[:MAX_BODY]
        return f"{UNTRUSTED_NOTE}#{item['number']} {item['title']} [{item['state']}]\n{body}"

    def _create_issue(self, args: dict[str, Any]) -> str:
        data = {"title": require_text(args, "title", 300), "body": str(args.get("body", ""))}
        item = self._call("POST", f"/repos/{_repo(args)}/issues", data)
        return f"Created issue #{item['number']}: {item.get('html_url', '')}"

    def _comment(self, args: dict[str, Any]) -> str:
        number = whole_number(args, "number", 1, 10**9)
        data = {"body": require_text(args, "body")}
        item = self._call("POST", f"/repos/{_repo(args)}/issues/{number}/comments", data)
        return f"Comment added: {item.get('html_url', '')}"

    def tools(self) -> list[Tool]:
        return [
            Tool("github_repositories", "List the owner's GitHub repositories.", {"limit": int}, READ, self._repos),
            Tool("github_issues", "List open issues in a repository.", {"repo": str, "limit": int}, READ,
                 lambda args: self._list(args, "issues")),
            Tool("github_pull_requests", "List open pull requests in a repository.", {"repo": str, "limit": int}, READ,
                 lambda args: self._list(args, "pulls")),
            Tool("github_read_issue", "Read one issue or pull request.", {"repo": str, "number": int}, READ, self._read),
            Tool("github_create_issue", "Create an issue.", {"repo": str, "title": str, "body": str}, WRITE, self._create_issue),
            Tool("github_comment", "Comment on an issue or pull request.", {"repo": str, "number": int, "body": str}, WRITE, self._comment),
        ]


