"""Read-only access to folders the owner chose."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from iris.connectors.base import READ, UNTRUSTED_NOTE, ConnectorError, Tool, require_text, whole_number
from iris.policy import _contains_sensitive_part

MAX_READ = 200 * 1024
MAX_MATCHES = 100
MAX_SCANNED = 20000


class Files:
    id = "files"
    name = "Folders on this computer"
    summary = "Read files in the folders you add here. IRIS cannot change them."

    def __init__(self, state_path: Path) -> None:
        self.state_path = state_path

    def folders(self) -> list[str]:
        if not self.state_path.exists():
            return []
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _save(self, folders: list[str]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(json.dumps(folders, ensure_ascii=False), encoding="utf-8")

    def add(self, raw: str) -> None:
        raw = raw.strip().strip('"')
        if not raw:
            raise ConnectorError("Enter a folder path.")
        folder = Path(raw).expanduser().resolve()
        if not folder.is_dir():
            raise ConnectorError("That folder does not exist.")
        if folder == Path(folder.anchor) or folder == Path.home():
            raise ConnectorError("Choose a smaller folder than a whole drive or your home folder.")
        if _contains_sensitive_part(folder):
            raise ConnectorError("That folder holds secrets, so IRIS cannot use it.")
        folders = self.folders()
        if str(folder) not in folders:
            self._save(folders + [str(folder)])

    def remove(self, folder: str) -> None:
        self._save([item for item in self.folders() if item != folder])

    def disconnect(self) -> None:
        self._save([])

    def status(self) -> dict[str, Any]:
        folders = self.folders()
        return {"connected": bool(folders), "folders": folders}

    def _inside(self, raw: str) -> Path:
        path = Path(raw).expanduser().resolve()
        if not any(path.is_relative_to(folder) for folder in self.folders()):
            raise ConnectorError("That path is outside the folders you added.")
        if _contains_sensitive_part(path):
            raise ConnectorError("That looks like a secret file.")
        return path

    def _list(self, args: dict[str, Any]) -> str:
        raw = str(args.get("path", "")).strip()
        if not raw:
            return "\n".join(self.folders()) or "No folders added."
        path = self._inside(raw)
        if not path.is_dir():
            raise ConnectorError("That is not a folder.")
        names = sorted(item.name + ("\\" if item.is_dir() else "") for item in path.iterdir()
                       if not _contains_sensitive_part(item))
        return "\n".join(names[:500]) or "The folder is empty."

    def _search(self, args: dict[str, Any]) -> str:
        wanted = require_text(args, "name", 200).lower()
        limit = whole_number(args, "limit", 30, MAX_MATCHES)
        found: list[str] = []
        scanned = 0
        for folder in self.folders():
            for item in Path(folder).rglob("*"):
                scanned += 1
                if scanned > MAX_SCANNED:
                    return "\n".join(found + ["...search stopped early, try a smaller folder"])
                if wanted in item.name.lower() and not _contains_sensitive_part(item):
                    found.append(str(item))
                    if len(found) >= limit:
                        return "\n".join(found)
        return "\n".join(found) or "No matching files."

    def _read(self, args: dict[str, Any]) -> str:
        path = self._inside(require_text(args, "path", 1000))
        if not path.is_file():
            raise ConnectorError("That is not a file.")
        with path.open("rb") as handle:
            content = handle.read(MAX_READ + 1)
        if b"\0" in content[:4096]:
            raise ConnectorError("IRIS can only read text files for now.")
        text = content[:MAX_READ].decode("utf-8", errors="replace")
        ending = "\n...[shortened]" if len(content) > MAX_READ else ""
        return UNTRUSTED_NOTE + text + ending

    def tools(self) -> list[Tool]:
        return [
            Tool("files_list", "List added folders, or the contents of one.", {"path": str}, READ, self._list),
            Tool("files_search", "Find files by name in added folders.", {"name": str, "limit": int}, READ, self._search),
            Tool("files_read", "Read a text file in an added folder.", {"path": str}, READ, self._read),
        ]
