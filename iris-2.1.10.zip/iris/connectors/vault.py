"""Stores connection secrets encrypted for this Windows account."""
from __future__ import annotations

import ctypes
import json
import re
import sys
from ctypes import wintypes
from pathlib import Path
from typing import Any, Callable

Cipher = Callable[[bytes], bytes]


class _Blob(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_char))]


def _dpapi(function_name: str, content: bytes) -> bytes:
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    buffer = ctypes.create_string_buffer(content, len(content))
    source = _Blob(len(content), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_char)))
    target = _Blob()
    function = getattr(crypt32, function_name)
    no_prompt = 1
    if not function(ctypes.byref(source), None, None, None, None, no_prompt, ctypes.byref(target)):
        raise OSError("Windows could not process the secret.")
    try:
        return ctypes.string_at(target.data, target.size)
    finally:
        kernel32.LocalFree(target.data)


def protect(content: bytes) -> bytes:
    return _dpapi("CryptProtectData", content)


def unprotect(content: bytes) -> bytes:
    return _dpapi("CryptUnprotectData", content)


class Vault:
    """Secrets never reach the logs, the screen or the conversation."""

    def __init__(self, folder: Path, lock: Cipher | None = None, unlock: Cipher | None = None) -> None:
        if (lock is None or unlock is None) and sys.platform != "win32":
            raise OSError("Secure storage is only available on Windows.")
        self.folder = folder
        self.folder.mkdir(parents=True, exist_ok=True)
        self.lock = lock or protect
        self.unlock = unlock or unprotect

    def _path(self, name: str) -> Path:
        if not re.fullmatch(r"[a-z_]+", name):
            raise ValueError("bad secret name")
        return self.folder / f"{name}.secret"

    def save(self, name: str, value: dict[str, Any]) -> None:
        self._path(name).write_bytes(self.lock(json.dumps(value).encode("utf-8")))

    def load(self, name: str) -> dict[str, Any] | None:
        """None when nothing is saved, or when the secret was saved on another computer or
        Windows account. Windows cannot open those, so the file is moved to old-secrets and the
        service shows as not connected until the owner enters the key again."""
        path = self._path(name)
        if not path.exists():
            return None
        try:
            return json.loads(self.unlock(path.read_bytes()))
        except (OSError, ValueError):
            self._set_aside(path)
            return None

    def _set_aside(self, path: Path) -> None:
        aside = self.folder / "old-secrets"
        try:
            aside.mkdir(exist_ok=True)
            path.replace(aside / path.name)
        except OSError:
            pass

    def delete(self, name: str) -> None:
        self._path(name).unlink(missing_ok=True)
