"""Gmail, Calendar, Contacts and Drive, signed in through the owner's own Google project."""
from __future__ import annotations

import asyncio
import base64
import secrets
import tempfile
import time
import urllib.parse
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import (
    READ, UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, call_bytes, call_json, require_text, whole_number,
)
from iris.connectors.documents import MAX_FILE, MAX_RETURNED, READABLE, read_text
from iris.connectors.oauth import local_callback, pkce
from iris.connectors.vault import Vault

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
GMAIL = "https://gmail.googleapis.com/gmail/v1/users/me"
CALENDAR = "https://www.googleapis.com/calendar/v3"
SCOPES = (
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/calendar.events",
    "https://www.googleapis.com/auth/contacts.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
)
PEOPLE = "https://people.googleapis.com/v1"
DRIVE = "https://www.googleapis.com/drive/v3"
EXPORTS = {
    "application/vnd.google-apps.document": "text/plain",
    "application/vnd.google-apps.spreadsheet": "text/csv",
    "application/vnd.google-apps.presentation": "text/plain",
}
NEW_ACCESS = "Google refused. Enable the People API and Drive API in your project, then disconnect and sign in again."
SIGN_IN_SECONDS = 300
MAX_BODY = 8000
EXPIRY_MARGIN_SECONDS = 60

def message_text(part: dict[str, Any]) -> str:
    """Find the plain text in a Gmail message."""
    if part.get("mimeType") == "text/plain" and part.get("body", {}).get("data"):
        raw = part["body"]["data"]
        return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode("utf-8", errors="replace")
    for child in part.get("parts", []) or []:
        text = message_text(child)
        if text:
            return text
    return ""


def _header(message: dict[str, Any], name: str) -> str:
    for item in message.get("payload", {}).get("headers", []):
        if item.get("name", "").lower() == name.lower():
            return item.get("value", "")
    return ""


def _one_line(args: dict[str, Any], name: str) -> str:
    value = require_text(args, name, 500)
    if "\n" in value or "\r" in value:
        raise ConnectorError(f"{name} must be one line.")
    return value


class Google:
    id = "google"
    name = "Google"
    summary = "Read mail, calendar, contacts and Drive. Sending mail and adding events need approval."

    def __init__(
        self,
        vault: Vault,
        token_url: str = TOKEN_URL,
        gmail: str = GMAIL,
        calendar: str = CALENDAR,
        people: str = PEOPLE,
        drive: str = DRIVE,
    ) -> None:
        self.vault = vault
        self.people = people
        self.drive = drive
        self.contacts_ready = False
        self.token_url = token_url
        self.gmail = gmail
        self.calendar = calendar
        self.access: tuple[str, float] | None = None
        self.sign_in: asyncio.Server | None = None

    def status(self) -> dict[str, Any]:
        saved = self.vault.load(self.id)
        found = {
            "connected": bool(saved and saved.get("refresh_token")),
            "account": (saved or {}).get("account", ""),
            "has_client": bool(saved and saved.get("client_id")),
        }
        if found["connected"] and saved.get("scopes") != list(SCOPES):
            found["problem"] = "Contacts and Drive need a new sign-in. Disconnect, then sign in again."
        return found

    def disconnect(self) -> None:
        self.access = None
        self.vault.delete(self.id)

    async def begin_sign_in(
        self, client_id: str, client_secret: str, open_page: Callable[[str], Any], finished: Callable[[str | None], None]
    ) -> None:
        """Open Google's sign-in page and wait for it to call back to this computer."""
        client_id, client_secret = client_id.strip(), client_secret.strip()
        if not client_id or not client_secret:
            raise ConnectorError("Enter the client ID and client secret.")
        if self.sign_in:
            self.sign_in.close()
        verifier, challenge = pkce()
        state = secrets.token_urlsafe(24)
        server, port, answer = await local_callback(state)
        self.sign_in = server
        redirect = f"http://127.0.0.1:{port}"
        query = urllib.parse.urlencode({
            "client_id": client_id,
            "redirect_uri": redirect,
            "response_type": "code",
            "scope": " ".join(SCOPES),
            "access_type": "offline",
            "prompt": "consent",
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        })

        async def wait() -> None:
            try:
                code = await asyncio.wait_for(answer, SIGN_IN_SECONDS)
                await asyncio.to_thread(self._finish, client_id, client_secret, code, verifier, redirect)
                finished(None)
            except asyncio.TimeoutError:
                finished("Sign-in timed out. Try again.")
            except ConnectorError as error:
                finished(str(error))
            finally:
                server.close()
                self.sign_in = None

        self.waiter = asyncio.create_task(wait())
        await asyncio.to_thread(open_page, f"{AUTH_URL}?{query}")

    def _finish(self, client_id: str, client_secret: str, code: str, verifier: str, redirect: str) -> None:
        tokens = call_json("POST", self.token_url, form={
            "client_id": client_id,
            "client_secret": client_secret,
            "code": code,
            "code_verifier": verifier,
            "grant_type": "authorization_code",
            "redirect_uri": redirect,
        })
        if not tokens.get("refresh_token"):
            raise ConnectorError("Google did not give IRIS lasting access. Try again.")
        self.access = (tokens["access_token"], time.time() + int(tokens.get("expires_in", 0)))
        profile = call_json("GET", f"{self.gmail}/profile", self.access[0])
        self.vault.save(self.id, {
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": tokens["refresh_token"],
            "account": profile.get("emailAddress", ""),
            "scopes": list(SCOPES),
        })

    def _token(self) -> str:
        if self.access and self.access[1] - EXPIRY_MARGIN_SECONDS > time.time():
            return self.access[0]
        saved = self.vault.load(self.id)
        if not saved or not saved.get("refresh_token"):
            raise ConnectorError("Gmail and Calendar are not connected. Connect them on the Connections screen.")
        tokens = call_json("POST", self.token_url, form={
            "client_id": saved["client_id"],
            "client_secret": saved["client_secret"],
            "refresh_token": saved["refresh_token"],
            "grant_type": "refresh_token",
        })
        self.access = (tokens["access_token"], time.time() + int(tokens.get("expires_in", 0)))
        return self.access[0]

    def _mail_search(self, args: dict[str, Any]) -> str:
        count = whole_number(args, "limit", 10, 25)
        query = urllib.parse.urlencode({"q": str(args.get("query", "")), "maxResults": count})
        found = call_json("GET", f"{self.gmail}/messages?{query}", self._token()).get("messages", [])
        lines = []
        for item in found:
            message = call_json(
                "GET",
                f"{self.gmail}/messages/{urllib.parse.quote(item['id'], safe='')}?format=metadata"
                "&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date",
                self._token(),
            )
            lines.append(
                f"{item['id']} | {_header(message, 'Date')} | {_header(message, 'From')} | {_header(message, 'Subject')}"
            )
        return UNTRUSTED_NOTE + ("\n".join(lines) or "No matching mail.")

    def important_mail(self, limit: int = 10) -> list[dict[str, str]]:
        query = urllib.parse.urlencode({"q": "is:important is:unread newer_than:1d", "maxResults": limit})
        found = call_json("GET", f"{self.gmail}/messages?{query}", self._token()).get("messages", [])
        results = []
        for item in found:
            message = call_json(
                "GET",
                f"{self.gmail}/messages/{urllib.parse.quote(item['id'], safe='')}?format=metadata"
                "&metadataHeaders=From&metadataHeaders=Subject",
                self._token(),
            )
            results.append({"id": item["id"], "from": _header(message, "From"), "subject": _header(message, "Subject")})
        return results

    def _mail_read(self, args: dict[str, Any]) -> str:
        message_id = urllib.parse.quote(require_text(args, "id", 200), safe="")
        message = call_json("GET", f"{self.gmail}/messages/{message_id}?format=full", self._token())
        text = message_text(message.get("payload", {})) or message.get("snippet", "")
        return (
            f"{UNTRUSTED_NOTE}From: {_header(message, 'From')}\nSubject: {_header(message, 'Subject')}\n"
            f"Date: {_header(message, 'Date')}\n\n{text[:MAX_BODY]}"
        )

    def _mail_send(self, args: dict[str, Any]) -> str:
        message = EmailMessage()
        message["To"] = _one_line(args, "to")
        message["Subject"] = _one_line(args, "subject")
        message.set_content(require_text(args, "body"))
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        sent = call_json("POST", f"{self.gmail}/messages/send", self._token(), data={"raw": raw})
        return f"Mail sent, id {sent.get('id', 'unknown')}."

    def upcoming(self, days: int = 1, limit: int = 8) -> list[dict[str, str]]:
        now = datetime.now(timezone.utc)
        query = urllib.parse.urlencode({
            "timeMin": now.isoformat(),
            "timeMax": (now + timedelta(days=days)).isoformat(),
            "singleEvents": "true",
            "orderBy": "startTime",
            "maxResults": limit,
        })
        items = call_json("GET", f"{self.calendar}/calendars/primary/events?{query}", self._token()).get("items", [])
        return [
            {
                "start": item["start"].get("dateTime") or item["start"].get("date", ""),
                "title": item.get("summary", "(no title)"),
            }
            for item in items
        ]

    def _calendar_list(self, args: dict[str, Any]) -> str:
        items = self.upcoming(whole_number(args, "days", 7, 60), 50)
        lines = [f"{item['start']} {item['title']}" for item in items]
        return UNTRUSTED_NOTE + ("\n".join(lines) or "Nothing scheduled.")

    def _calendar_add(self, args: dict[str, Any]) -> str:
        event = {
            "summary": _one_line(args, "title"),
            "start": {"dateTime": _one_line(args, "start")},
            "end": {"dateTime": _one_line(args, "end")},
            "description": str(args.get("description", "")),
        }
        made = call_json("POST", f"{self.calendar}/calendars/primary/events", self._token(), data=event)
        return f"Event added: {made.get('htmlLink', '')}"

    def _extra(self, method: str, url: str) -> Any:
        try:
            return call_json(method, url, self._token())
        except ConnectorError as error:
            if "(403)" in str(error):
                raise ConnectorError(NEW_ACCESS) from None
            raise

    def _contacts(self, args: dict[str, Any]) -> str:
        mask = "names,emailAddresses,phoneNumbers"
        if not self.contacts_ready:  # Google asks for one empty search first, to prepare its index
            self._extra("GET", f"{self.people}/people:searchContacts?" + urllib.parse.urlencode({"query": "", "readMask": mask}))
            self.contacts_ready = True
        query = urllib.parse.urlencode({
            "query": require_text(args, "query", 200), "readMask": mask, "pageSize": whole_number(args, "limit", 10, 30),
        })
        lines = []
        for result in self._extra("GET", f"{self.people}/people:searchContacts?{query}").get("results", []):
            person = result.get("person", {})
            name = next((item.get("displayName") for item in person.get("names", [])), "(no name)")
            mail = ", ".join(item.get("value", "") for item in person.get("emailAddresses", []))
            phone = ", ".join(item.get("value", "") for item in person.get("phoneNumbers", []))
            lines.append(" | ".join(part for part in (name, mail, phone) if part))
        return UNTRUSTED_NOTE + ("\n".join(lines) or "No matching contact.")

    def _drive_search(self, args: dict[str, Any]) -> str:
        words = require_text(args, "query", 200).replace("\\", "\\\\").replace("'", "\\'")
        query = urllib.parse.urlencode({
            "q": f"fullText contains '{words}' and trashed = false",
            "pageSize": whole_number(args, "limit", 10, 30),
            "fields": "files(id,name,mimeType,modifiedTime)",
        })
        files = self._extra("GET", f"{self.drive}/files?{query}").get("files", [])
        lines = [f"{item['id']} | {item.get('modifiedTime', '')[:10]} | {item.get('name', '')}" for item in files]
        return UNTRUSTED_NOTE + ("\n".join(lines) or "No matching files.")

    def _drive_read(self, args: dict[str, Any]) -> str:
        file_id = urllib.parse.quote(require_text(args, "id", 200), safe="")
        about = self._extra("GET", f"{self.drive}/files/{file_id}?fields=name,mimeType")
        kind = about.get("mimeType", "")
        suffix = Path(about.get("name", "")).suffix.lower()
        if kind in EXPORTS:
            url = f"{self.drive}/files/{file_id}/export?" + urllib.parse.urlencode({"mimeType": EXPORTS[kind]})
            text = call_bytes(url, self._token(), MAX_FILE).decode("utf-8", errors="replace")
        elif suffix in READABLE:
            content = call_bytes(f"{self.drive}/files/{file_id}?alt=media", self._token(), MAX_FILE)
            with tempfile.TemporaryDirectory(prefix="iris-drive-") as folder:
                path = Path(folder) / f"file{suffix}"
                path.write_bytes(content)
                text = read_text(path)
        else:
            raise ConnectorError("IRIS cannot read that kind of file yet.")
        return UNTRUSTED_NOTE + text[:MAX_RETURNED]

    def tools(self) -> list[Tool]:
        return [
            Tool("contacts_search", "Find a Google contact's mail and phone.", {"query": str, "limit": int}, READ, self._contacts),
            Tool("drive_search", "Search Google Drive by words in the files.", {"query": str, "limit": int}, READ, self._drive_search),
            Tool("drive_read", "Read one Google Drive file by id.", {"id": str}, READ, self._drive_read),
            Tool("gmail_search", "Search mail with Gmail search words.", {"query": str, "limit": int}, READ, self._mail_search),
            Tool("gmail_read", "Read one message by id.", {"id": str}, READ, self._mail_read),
            Tool("gmail_send", "Send an email.", {"to": str, "subject": str, "body": str}, WRITE, self._mail_send),
            Tool("calendar_upcoming", "List upcoming events.", {"days": int}, READ, self._calendar_list),
            Tool(
                "calendar_add_event",
                "Add an event. Times are RFC 3339 with an offset.",
                {"title": str, "start": str, "end": str, "description": str},
                WRITE,
                self._calendar_add,
            ),
        ]
