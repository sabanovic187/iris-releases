"""Video and audio links: details, download and local transcripts."""
from __future__ import annotations

import importlib.util
import ipaddress
import socket
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit

from iris.connectors.base import UNTRUSTED_NOTE, WRITE, ConnectorError, Tool, require_text

MAX_SECONDS = 2 * 60 * 60
MAX_BYTES = 500 * 1024 * 1024
MAX_RETURNED = 30000
TIMEOUT_SECONDS = 30
WHISPER_MODEL = "base"  # understands many languages, unlike base.en


def check_public_url(url: str) -> str:
    """Accept web links only, so a link in a message cannot reach this computer or home network."""
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise ConnectorError("Use a normal web link.")
    try:
        found = socket.getaddrinfo(parts.hostname, None)
    except OSError:
        raise ConnectorError("That address could not be found.") from None
    for item in found:
        if not ipaddress.ip_address(item[4][0].split("%")[0]).is_global:
            raise ConnectorError("Links to this computer or a private network are refused.")
    return url


class Media:
    id = "media"
    name = "Video and audio"
    summary = "Transcribe links and files on this computer. Each download needs approval."

    def __init__(
        self,
        workspace: Path,
        models: Path,
        check_url: Callable[[str], str] = check_public_url,
        transcribe: Callable[[Path], list[str]] | None = None,
        extractors: tuple[str, ...] = ("default", "-generic"),  # generic reads links out of any page
    ) -> None:
        self.workspace = workspace
        self.folder = workspace / "media"
        self.models = models
        self.check_url = check_url
        self.extractors = list(extractors)
        self.transcribe_file = transcribe or self._whisper
        self.blocked: Callable[[], bool] = lambda: False
        self.model: Any = None

    def status(self) -> dict[str, Any]:
        installed = all(importlib.util.find_spec(name) for name in ("yt_dlp", "faster_whisper"))
        return {"connected": installed}

    def _stop_if_blocked(self) -> None:
        if self.blocked():
            raise ConnectorError("Stopped by the owner.")

    def _tool(self) -> Any:
        try:
            import yt_dlp
        except ImportError:
            raise ConnectorError("Video tools are not installed. Run scripts\\setup-tools.ps1.") from None
        return yt_dlp

    def _downloader(self, extra: dict[str, Any]) -> Any:
        def progress(_update: dict[str, Any]) -> None:
            self._stop_if_blocked()

        return self._tool().YoutubeDL({
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "allowed_extractors": self.extractors,
            "socket_timeout": TIMEOUT_SECONDS,
            "progress_hooks": [progress],
            **extra,
        })

    def _details(self, url: str) -> dict[str, Any]:
        tool = self._tool()
        try:
            with self._downloader({"skip_download": True, "format": "bestaudio/best"}) as downloader:
                return downloader.extract_info(url, download=False)
        except tool.utils.DownloadError:
            raise ConnectorError("That link could not be read. It may be private or unsupported.") from None

    def _info(self, args: dict[str, Any]) -> str:
        info = self._details(self.check_url(require_text(args, "url", 2000)))
        return (
            f"{UNTRUSTED_NOTE}Title: {info.get('title', 'unknown')}\n"
            f"Channel: {info.get('uploader', 'unknown')}\n"
            f"Length: {info.get('duration', 'unknown')} seconds\n"
            f"Description: {(info.get('description') or '')[:1500]}"
        )

    def _download(self, url: str) -> Path:
        tool = self._tool()
        info = self._details(url)
        if (info.get("duration") or 0) > MAX_SECONDS:
            raise ConnectorError("That is longer than the two hour limit.")
        for item in info.get("requested_formats") or info.get("requested_downloads") or [info]:
            if item.get("url"):
                self.check_url(item["url"])
        self.folder.mkdir(parents=True, exist_ok=True)
        options = {
            "format": "bestaudio/best",
            "outtmpl": str(self.folder / "%(id)s.%(ext)s"),
            "restrictfilenames": True,
            "max_filesize": MAX_BYTES,
        }
        try:
            with self._downloader(options) as downloader:
                done = downloader.extract_info(url, download=True)
                path = Path(downloader.prepare_filename(done))
        except tool.utils.DownloadError:
            raise ConnectorError("The download failed. The link may be private or too large.") from None
        if not path.is_file():
            raise ConnectorError("The download was skipped, probably because it is over 500 MB.")
        return path

    def _whisper(self, path: Path) -> list[str]:
        try:
            from iris.voice.speech import Transcriber

            if self.model is None:
                self.model = Transcriber(WHISPER_MODEL, self.models).model
        except ImportError:
            raise ConnectorError("Speech tools are not installed. Run scripts\\setup-voice.ps1.") from None
        lines = []
        try:
            segments, _ = self.model.transcribe(str(path), beam_size=1, vad_filter=True)
            for segment in segments:
                self._stop_if_blocked()
                lines.append(segment.text.strip())
        except ImportError as error:  # PyAV blocked by Smart App Control
            raise ConnectorError(str(error) or "Audio files cannot be read on this computer.") from None
        return lines

    def _finish(self, path: Path) -> str:
        self._stop_if_blocked()
        text = "\n".join(self.transcribe_file(path))
        target = path.with_suffix(".txt")
        target.write_text(text, encoding="utf-8")
        ending = "\n...[shortened, the full text is in the file]" if len(text) > MAX_RETURNED else ""
        return f"Saved to {target}\n\n{UNTRUSTED_NOTE}{text[:MAX_RETURNED]}{ending}"

    def _transcribe_link(self, args: dict[str, Any]) -> str:
        return self._finish(self._download(self.check_url(require_text(args, "url", 2000))))

    def _transcribe_file(self, args: dict[str, Any]) -> str:
        path = Path(require_text(args, "path", 1000))
        path = (path if path.is_absolute() else self.workspace / path).resolve()
        if not path.is_relative_to(self.workspace.resolve()):
            raise ConnectorError("That file is outside the workspace.")
        if not path.is_file():
            raise ConnectorError("That file does not exist.")
        return self._finish(path)

    def tools(self) -> list[Tool]:
        return [
            Tool("media_info", "Read a video's title, channel and length without downloading it.", {"url": str}, WRITE, self._info),
            Tool("media_transcribe_link", "Download audio from a link and transcribe it locally.", {"url": str}, WRITE, self._transcribe_link),
            Tool("media_transcribe_file", "Transcribe an audio or video file in the workspace.", {"path": str}, WRITE, self._transcribe_file),
        ]
