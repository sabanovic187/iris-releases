"""Finds things in the owner's folders by meaning. Everything stays on this computer."""
from __future__ import annotations

import json
import math
import re
import sqlite3
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import READ, UNTRUSTED_NOTE, ConnectorError, Tool, call_json, require_text, whole_number
from iris.connectors.documents import READABLE, read_text
from iris.policy import _contains_sensitive_part

OLLAMA_URL = "http://127.0.0.1:11434"
MODEL = "nomic-embed-text"
PIECE = 900
OVERLAP = 120
BATCH = 32
RANK_OFFSET = 60
MAX_FILES = 5000
MAX_SIZE = 10 * 1024 * 1024
SCHEMA = """
CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, changed REAL NOT NULL);
CREATE TABLE IF NOT EXISTS pieces(id INTEGER PRIMARY KEY, path TEXT NOT NULL, text TEXT NOT NULL, vector TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS pieces_path ON pieces(path);
"""


def split_text(text: str) -> list[str]:
    text = " ".join(text.split())
    pieces = []
    start = 0
    while start < len(text):
        pieces.append(text[start:start + PIECE])
        start += PIECE - OVERLAP
    return pieces


def word_score(query: str, text: str) -> int:
    """Count exact words, which catches names and codes that meaning search misses."""
    words = set(re.findall(r"\w{3,}", query.lower()))
    body = text.lower()
    return sum(body.count(word) for word in words)


def combine(meaning: list[int], words: list[int]) -> dict[int, float]:
    """Merge two rankings. Items placed well in either one rise to the top."""
    scores: dict[int, float] = {}
    for ranking in (meaning, words):
        for place, item in enumerate(ranking):
            scores[item] = scores.get(item, 0.0) + 1 / (RANK_OFFSET + place)
    return scores


def similarity(left: list[float], right: list[float]) -> float:
    top = sum(a * b for a, b in zip(left, right))
    bottom = math.sqrt(sum(a * a for a in left)) * math.sqrt(sum(b * b for b in right))
    return top / bottom if bottom else 0.0


class Knowledge:
    id = "knowledge"
    name = "Knowledge base"
    summary = "Search your added folders by meaning. The index stays on this computer."

    def __init__(
        self,
        db_path: Path,
        folders: Callable[[], list[str]],
        ollama: str = OLLAMA_URL,
    ) -> None:
        self.db_path = db_path
        self.folders = folders
        self.ollama = ollama
        self.blocked: Callable[[], bool] = lambda: False
        self.count = 0
        self.running = False

    def _open(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.db_path)
        connection.executescript(SCHEMA)
        return connection

    def status(self) -> dict[str, Any]:
        return {"connected": self.count > 0, "pieces": self.count, "running": self.running}

    def refresh_count(self) -> None:
        connection = self._open()
        self.count = connection.execute("SELECT COUNT(*) FROM pieces").fetchone()[0]
        connection.close()

    def _embed(self, texts: list[str]) -> list[list[float]]:
        try:
            answer = call_json("POST", f"{self.ollama}/api/embed", data={"model": MODEL, "input": texts})
        except ConnectorError:
            raise ConnectorError("Ollama could not make the index. Check that it is running with nomic-embed-text.") from None
        return answer["embeddings"]

    def _candidates(self) -> dict[str, float]:
        found: dict[str, float] = {}
        for folder in self.folders():
            for path in Path(folder).rglob("*"):
                if len(found) >= MAX_FILES:
                    return found
                if (
                    path.suffix.lower() in READABLE
                    and path.is_file()
                    and not path.is_symlink()
                    and not _contains_sensitive_part(path)
                    and path.stat().st_size <= MAX_SIZE
                ):
                    found[str(path)] = path.stat().st_mtime
        return found

    def update(self) -> str:
        """Add new and changed files, and drop removed ones."""
        if self.running:
            return "The index is already updating."
        self.running = True
        connection = self._open()
        added = skipped = 0
        try:
            wanted = self._candidates()
            known = dict(connection.execute("SELECT path, changed FROM files"))
            for path in set(known) - set(wanted):
                connection.execute("DELETE FROM pieces WHERE path = ?", (path,))
                connection.execute("DELETE FROM files WHERE path = ?", (path,))
            for path, changed in wanted.items():
                if known.get(path) == changed:
                    continue
                if self.blocked():
                    raise ConnectorError("Stopped by the owner.")
                try:
                    pieces = split_text(read_text(Path(path)))
                except (ConnectorError, OSError):
                    skipped += 1
                    continue
                vectors = []
                for start in range(0, len(pieces), BATCH):
                    vectors += self._embed(pieces[start:start + BATCH])
                connection.execute("DELETE FROM pieces WHERE path = ?", (path,))
                connection.executemany(
                    "INSERT INTO pieces(path, text, vector) VALUES(?, ?, ?)",
                    [(path, piece, json.dumps(vector)) for piece, vector in zip(pieces, vectors)],
                )
                connection.execute("INSERT OR REPLACE INTO files(path, changed) VALUES(?, ?)", (path, changed))
                connection.commit()
                added += 1
            connection.commit()
            return f"Index updated: {added} files added, {skipped} skipped."
        finally:
            connection.close()
            self.running = False
            self.refresh_count()

    def disconnect(self) -> None:
        connection = self._open()
        connection.execute("DELETE FROM pieces")
        connection.execute("DELETE FROM files")
        connection.commit()
        connection.close()
        self.count = 0

    def _search(self, args: dict[str, Any]) -> str:
        query = require_text(args, "query", 1000)
        limit = whole_number(args, "limit", 5, 20)
        vector = self._embed([f"search_query: {query}"])[0]
        connection = self._open()
        rows = connection.execute("SELECT path, text, vector FROM pieces").fetchall()
        connection.close()
        if not rows:
            return "The index is empty. Add a folder and update the index."
        folders = [Path(folder) for folder in self.folders()]
        usable = [row for row in rows if any(Path(row[0]).is_relative_to(folder) for folder in folders)]
        indexes = range(len(usable))
        meaning = sorted(indexes, key=lambda i: similarity(vector, json.loads(usable[i][2])), reverse=True)
        counts = [word_score(query, row[1]) for row in usable]
        words = sorted((i for i in indexes if counts[i]), key=lambda i: counts[i], reverse=True)
        merged = combine(meaning, words)
        best = sorted(merged, key=merged.get, reverse=True)[:limit]
        lines = [f"{usable[i][0]}\n{usable[i][1]}" for i in best]
        return UNTRUSTED_NOTE + ("\n\n".join(lines) or "Nothing found.")

    def tools(self) -> list[Tool]:
        return [
            Tool("knowledge_search", "Search the owner's added folders by meaning.", {"query": str, "limit": int}, READ, self._search),
        ]
