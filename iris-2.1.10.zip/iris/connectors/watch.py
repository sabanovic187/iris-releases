"""Watches public pages for changes. Uses no AI model."""
from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.error
import urllib.request
import urllib.robotparser
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit

from iris.connectors.base import READ, WRITE, ConnectorError, Tool, require_text
from iris.connectors.media import check_public_url

AGENT = "IRIS-personal"
TIMEOUT_SECONDS = 20
MAX_PAGE = 2 * 1024 * 1024
MAX_PAGES = 30
CHECK_EVERY_SECONDS = 60 * 60
SKIPPED_TAGS = {"script", "style", "noscript", "svg"}


class _Text(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skipping = 0

    def handle_starttag(self, tag: str, _attrs: Any) -> None:
        if tag in SKIPPED_TAGS:
            self.skipping += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in SKIPPED_TAGS and self.skipping:
            self.skipping -= 1

    def handle_data(self, data: str) -> None:
        if not self.skipping and data.strip():
            self.parts.append(data.strip())


def page_text(html: str) -> str:
    parser = _Text()
    parser.feed(html)
    return re.sub(r"\s+", " ", " ".join(parser.parts)).strip()


class _CheckedRedirects(urllib.request.HTTPRedirectHandler):
    """A public page must not be able to redirect IRIS into the home network."""

    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> Any:
        check_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _get(url: str) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": AGENT})
    opener = urllib.request.build_opener(_CheckedRedirects)
    with opener.open(request, timeout=TIMEOUT_SECONDS) as response:
        return response.read(MAX_PAGE).decode("utf-8", errors="replace")


class Watches:
    id = "watches"
    name = "Watched pages"
    summary = "Get an alert when a public page changes. IRIS follows each site's rules."

    def __init__(
        self,
        state_path: Path,
        alerts_path: Path,
        check_url: Callable[[str], str] = check_public_url,
        fetch: Callable[[str], str] = _get,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.state_path = state_path
        self.alerts_path = alerts_path
        self.check_url = check_url
        self.fetch = fetch
        self.clock = clock

    def pages(self) -> list[dict[str, Any]]:
        if not self.state_path.exists():
            return []
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _save(self, pages: list[dict[str, Any]]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(json.dumps(pages, ensure_ascii=False), encoding="utf-8")

    def status(self) -> dict[str, Any]:
        pages = [{"url": page["url"], "note": page.get("note", "")} for page in self.pages()]
        return {"connected": bool(pages), "pages": pages}

    def _allowed(self, url: str) -> bool:
        parts = urlsplit(url)
        robots = urllib.robotparser.RobotFileParser()
        try:
            robots.parse(self.fetch(f"{parts.scheme}://{parts.netloc}/robots.txt").splitlines())
        except (urllib.error.HTTPError, urllib.error.URLError, OSError, ValueError):
            return True  # a site without readable rules sets no limit
        return robots.can_fetch(AGENT, url)

    def _read(self, url: str, words: str) -> dict[str, str]:
        try:
            text = page_text(self.fetch(url))
        except (urllib.error.URLError, OSError, ValueError):
            raise ConnectorError("That page could not be read.") from None
        if words:
            found = [word for word in re.split(r"[,\s]+", words.lower()) if word and word in text.lower()]
            text = " ".join(sorted(found))
        return {"hash": hashlib.sha256(text.encode()).hexdigest(), "preview": text[:200]}

    def add(self, url: str, words: str = "") -> None:
        url = self.check_url(url.strip())
        pages = self.pages()
        if len(pages) >= MAX_PAGES:
            raise ConnectorError("Too many watched pages. Remove one first.")
        if any(page["url"] == url for page in pages):
            return
        if not self._allowed(url):
            raise ConnectorError("This site does not allow automatic reading.")
        first = self._read(url, words.strip())
        self._save(pages + [{"url": url, "words": words.strip(), "checked": self.clock(), "note": "", **first}])

    def remove(self, url: str) -> None:
        self._save([page for page in self.pages() if page["url"] != url])

    def disconnect(self) -> None:
        self._save([])

    def _alert(self, url: str) -> None:
        entry = {
            "time": datetime.now(timezone.utc).isoformat(),
            "kind": "changed",
            "check": f"watch {url}",
            "message": f"{url} has changed",
        }
        with self.alerts_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def check_due(self) -> bool:
        """Check pages that are due. Returns True when anything changed."""
        pages = self.pages()
        changed = False
        for page in pages:
            if self.clock() - page["checked"] < CHECK_EVERY_SECONDS:
                continue
            page["checked"] = self.clock()
            try:
                self.check_url(page["url"])
                if not self._allowed(page["url"]):
                    page["note"] = "The site no longer allows automatic reading."
                    continue
                fresh = self._read(page["url"], page.get("words", ""))
            except ConnectorError as error:
                page["note"] = str(error)
                continue
            page["note"] = ""
            if fresh["hash"] != page["hash"]:
                page.update(fresh)
                self._alert(page["url"])
                changed = True
        self._save(pages)
        return changed

    def _tool_add(self, args: dict[str, Any]) -> str:
        self.add(require_text(args, "url", 2000), str(args.get("words", "")))
        return "Watching that page."

    def _tool_remove(self, args: dict[str, Any]) -> str:
        self.remove(require_text(args, "url", 2000))
        return "No longer watching that page."

    def _tool_list(self, _args: dict[str, Any]) -> str:
        return "\n".join(page["url"] for page in self.pages()) or "No watched pages."

    def tools(self) -> list[Tool]:
        return [
            Tool("watch_list", "List watched pages.", {}, READ, self._tool_list),
            Tool("watch_add", "Watch a public page. Words limit alerts to those words.", {"url": str, "words": str}, WRITE, self._tool_add),
            Tool("watch_remove", "Stop watching a page.", {"url": str}, WRITE, self._tool_remove),
        ]
