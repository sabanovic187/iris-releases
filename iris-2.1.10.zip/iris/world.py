"""Live public layers for the globe. Only public data, kept per source, so one failure never hides the rest."""
from __future__ import annotations

import csv
import io
import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import ConnectorError, call_json

FLIGHTS = "https://opensky-network.org/api/states/all"
MILITARY = "https://api.adsb.lol/v2/mil"
SATELLITES = "https://celestrak.org/NORAD/elements/gp.php?GROUP={group}&FORMAT=tle"
SATELLITE_GROUPS = ("stations", "visual", "gps-ops", "weather", "starlink")
MAX_PER_GROUP = {"starlink": 400}
CABLES = "https://www.submarinecablemap.com/api/v3/cable/cable-geo.json"
CRYPTO = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true"
PRICES = "https://stooq.com/q/l/?s=^spx+^ndx+xauusd+cl.f&f=sd2t2ohlc&h&e=csv"
FOREIGN = "https://api.frankfurter.dev/v1/latest?base=EUR&symbols=USD,GBP,CHF"
PRICE_NAMES = {"^SPX": "S&P 500", "^NDX": "Nasdaq 100", "XAUUSD": "Gold", "CL.F": "Crude oil"}
MAX_FLIGHTS = 15000
MAX_DOWNLOAD = 40 * 1024 * 1024
FLIGHT_SECONDS = 15 * 60  # OpenSky's free limit is about one world view each 15 minutes
FAST_SECONDS = 5 * 60
SATELLITE_SECONDS = 6 * 60 * 60  # CelesTrak asks people not to download more often
CABLE_SECONDS = 7 * 24 * 60 * 60
VIEW_SECONDS = 30 * 60

# Approximate centres, used only to place headlines on the globe.
COUNTRIES = {
    "Afghanistan": (34, 66), "Albania": (41, 20), "Algeria": (28, 2), "Argentina": (-34, -64), "Armenia": (40, 45),
    "Australia": (-25, 134), "Austria": (47.5, 14), "Azerbaijan": (40.3, 47.7), "Bangladesh": (24, 90), "Belarus": (53, 28),
    "Belgium": (50.6, 4.6), "Bosnia": (44, 18), "Brazil": (-10, -52), "Bulgaria": (42.7, 25.5), "Canada": (56, -106),
    "Chile": (-33, -71), "China": (35, 103), "Colombia": (4, -73), "Congo": (-3, 23), "Croatia": (45.3, 16),
    "Cuba": (22, -79), "Cyprus": (35, 33), "Czech": (49.8, 15.5), "Denmark": (56, 10), "Egypt": (27, 30),
    "Ethiopia": (9, 40), "Finland": (64, 26), "France": (46.5, 2.5), "Gaza": (31.4, 34.4), "Georgia": (42, 43.5),
    "Germany": (51, 10), "Greece": (39, 22), "Haiti": (19, -72.5), "Hungary": (47, 19.5), "India": (21, 78),
    "Indonesia": (-2, 118), "Iran": (32, 53), "Iraq": (33, 44), "Ireland": (53, -8), "Israel": (31.5, 35),
    "Italy": (42.8, 12.5), "Japan": (36, 138), "Jordan": (31, 36.5), "Kazakhstan": (48, 67), "Kenya": (0.5, 38),
    "Kosovo": (42.6, 21), "Kuwait": (29.3, 47.7), "Lebanon": (33.9, 35.9), "Libya": (27, 17), "Malaysia": (3.5, 102),
    "Mali": (17, -4), "Mexico": (23, -102), "Moldova": (47, 28.5), "Montenegro": (42.8, 19.2), "Morocco": (32, -6),
    "Myanmar": (21, 96), "Nepal": (28, 84), "Netherlands": (52.2, 5.3), "New Zealand": (-41, 174), "Niger": (17, 9),
    "Nigeria": (9, 8), "North Korea": (40, 127), "North Macedonia": (41.6, 21.7), "Norway": (62, 9), "Pakistan": (30, 70),
    "Philippines": (13, 122), "Poland": (52, 19), "Portugal": (39.5, -8), "Qatar": (25.3, 51.2), "Romania": (46, 25),
    "Russia": (60, 95), "Saudi Arabia": (24, 45), "Serbia": (44, 21), "Slovakia": (48.7, 19.5), "Slovenia": (46.1, 14.8),
    "Somalia": (5, 46), "South Africa": (-29, 25), "South Korea": (36.5, 128), "South Sudan": (7, 30), "Spain": (40, -3.5),
    "Sudan": (15, 30), "Sweden": (62, 15), "Switzerland": (47, 8), "Syria": (35, 38), "Taiwan": (23.7, 121),
    "Thailand": (15, 101), "Tunisia": (34, 9), "Turkey": (39, 35), "Ukraine": (49, 32), "United Arab Emirates": (24, 54),
    "United Kingdom": (54, -2), "United States": (39, -98), "Venezuela": (8, -66), "Vietnam": (16, 107), "Yemen": (15.5, 47),
    "Zimbabwe": (-19, 29.5),
}
ALSO_CALLED = {
    "Bosnia": "Bosnian|Sarajevo", "China": "Chinese|Beijing", "Gaza": "Palestinian|Hamas", "Germany": "German|Berlin",
    "France": "French|Paris", "Iran": "Iranian|Tehran", "Israel": "Israeli|Netanyahu", "Japan": "Japanese|Tokyo",
    "Russia": "Russian|Moscow|Kremlin|Putin", "Serbia": "Serbian|Belgrade", "Turkey": "Turkish|Ankara|Türkiye",
    "Ukraine": "Ukrainian|Kyiv|Zelensky", "United Kingdom": "UK|Britain|British|London", "India": "Indian|Delhi",
    "United States": "US|U\\.S\\.|USA|America|American|Washington|White House|Pentagon", "North Korea": "Pyongyang",
    "Lebanon": "Lebanese|Beirut|Hezbollah", "Syria": "Syrian|Damascus", "Yemen": "Houthi|Sanaa", "Taiwan": "Taiwanese|Taipei",
    "Italy": "Italian|Rome", "Spain": "Spanish|Madrid", "Pakistan": "Pakistani|Islamabad", "Sudan": "Sudanese|Khartoum",
}
CRISIS = re.compile(r"\b(war|attack|strike|missile|killed|dead|bomb|invasion|troops|protest|coup|crisis|earthquake|flood)", re.I)
_PATTERNS = {
    name: re.compile(rf"\b({re.escape(name)}|{ALSO_CALLED[name]})\b" if name in ALSO_CALLED else rf"\b{re.escape(name)}\b")
    for name in COUNTRIES
}


def _text(url: str) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": "IRIS-personal"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read(MAX_DOWNLOAD).decode("utf-8", errors="replace")


def read_flights(fetch: Callable[..., Any] = call_json) -> list[list[Any]]:
    """Each flight is [lon, lat, height m, heading, speed m/s, callsign, country]."""
    found = []
    for row in fetch("GET", FLIGHTS, timeout=40).get("states") or []:
        if row[5] is None or row[6] is None or row[8]:
            continue
        found.append([row[5], row[6], row[7] or 0, row[10] or 0, row[9] or 0, (row[1] or "").strip(), row[2] or ""])
    return found[:MAX_FLIGHTS]


def read_military(fetch: Callable[..., Any] = call_json) -> list[list[Any]]:
    found = []
    for item in fetch("GET", MILITARY, timeout=30).get("ac") or []:
        if item.get("lat") is None or item.get("lon") is None:
            continue
        height = item.get("alt_baro")
        height = 0 if not isinstance(height, (int, float)) else height * 0.3048
        found.append([item["lon"], item["lat"], height, item.get("track") or 0, (item.get("gs") or 0) * 0.5144,
                      (item.get("flight") or "").strip(), item.get("t") or ""])
    return found[:MAX_FLIGHTS]


def parse_satellites(text: str, group: str) -> list[list[str]]:
    lines = [line.rstrip() for line in text.splitlines() if line.strip()]
    found = []
    for index in range(0, len(lines) - 2, 3):
        name, one, two = lines[index:index + 3]
        if one.startswith("1 ") and two.startswith("2 "):
            found.append([name.strip(), one, two, group])
    return found[:MAX_PER_GROUP.get(group, 300)]


def read_satellites(fetch_text: Callable[[str], str] = _text) -> list[list[str]]:
    found: list[list[str]] = []
    problems = 0
    for group in SATELLITE_GROUPS:
        try:
            found += parse_satellites(fetch_text(SATELLITES.format(group=group)), group)
        except (OSError, ValueError):
            problems += 1
    if problems == len(SATELLITE_GROUPS):
        raise ConnectorError("no satellite data")
    unique: dict[str, list[str]] = {}
    for item in found:
        unique.setdefault(item[1][2:7], item)
    return list(unique.values())


def read_cables(fetch_text: Callable[[str], str] = _text) -> list[dict[str, Any]]:
    found = []
    for item in json.loads(fetch_text(CABLES)).get("features", []):
        shape = item.get("geometry", {})
        lines = shape.get("coordinates") or []
        lines = [lines] if shape.get("type") == "LineString" else lines
        found.append({"name": item.get("properties", {}).get("name", "Cable"), "lines": lines})
    return found


def read_markets(fetch: Callable[..., Any] = call_json, fetch_text: Callable[[str], str] = _text) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    problems = 0
    try:
        for name, code in (("Bitcoin", "bitcoin"), ("Ether", "ethereum")):
            coin = fetch("GET", CRYPTO)[code]
            found.append({"name": name, "price": coin["usd"], "change": coin.get("usd_24h_change")})
    except (ConnectorError, KeyError, TypeError):
        problems += 1
    try:
        for row in csv.DictReader(io.StringIO(fetch_text(PRICES))):
            if row.get("Symbol") in PRICE_NAMES and row.get("Close") not in (None, "", "N/D"):
                opened, closed = float(row["Open"]), float(row["Close"])
                found.append({"name": PRICE_NAMES[row["Symbol"]], "price": closed, "change": (closed / opened - 1) * 100 if opened else None})
    except (OSError, ValueError):
        problems += 1
    try:
        for code, rate in fetch("GET", FOREIGN).get("rates", {}).items():
            found.append({"name": f"EUR/{code}", "price": rate, "change": None})
    except ConnectorError:
        problems += 1
    if problems == 3:
        raise ConnectorError("no market data")
    return found


def news_focus(news: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Count headlines per country. This measures attention in the news, not real danger."""
    focus: dict[str, dict[str, Any]] = {}
    for item in news:
        title = str(item.get("title", ""))
        for name, pattern in _PATTERNS.items():
            if pattern.search(title):
                lat, lon = COUNTRIES[name]
                spot = focus.setdefault(name, {"country": name, "lat": lat, "lon": lon, "count": 0, "crisis": 0, "titles": []})
                spot["count"] += 1
                spot["crisis"] += 1 if CRISIS.search(title) else 0
                spot["titles"].append(title)
    return sorted(focus.values(), key=lambda item: (item["crisis"], item["count"]), reverse=True)


class World:
    """Keeps each layer and its age. Paid-for limits of the free services decide how often each one refreshes."""

    def __init__(self, folder: Path, fetch: Callable[..., Any] = call_json, fetch_text: Callable[[str], str] = _text) -> None:
        self.folder = folder
        self.viewed = 0.0
        self.sources: dict[str, tuple[int, bool, Callable[[], Any]]] = {
            "flights": (FLIGHT_SECONDS, False, lambda: read_flights(fetch)),
            "military": (FAST_SECONDS, False, lambda: read_military(fetch)),
            "satellites": (SATELLITE_SECONDS, True, lambda: read_satellites(fetch_text)),
            "cables": (CABLE_SECONDS, True, lambda: read_cables(fetch_text)),
            "markets": (FAST_SECONDS, False, lambda: read_markets(fetch, fetch_text)),
        }
        self.layers: dict[str, Any] = {}
        self.updated: dict[str, float] = {}
        self.failed: dict[str, float] = {}
        for name, (_seconds, keep, _read) in self.sources.items():
            path = folder / f"{name}.json"
            if keep and path.exists():
                try:
                    self.layers[name] = json.loads(path.read_text(encoding="utf-8"))
                    self.updated[name] = path.stat().st_mtime
                except (OSError, ValueError):
                    pass

    def looked_at(self) -> None:
        self.viewed = time.time()

    def due(self, now: float) -> list[str]:
        """Nothing is fetched while nobody looks, so the free limits are not spent for nothing."""
        if now - self.viewed > VIEW_SECONDS:
            return []
        return [
            name for name, (seconds, _keep, _read) in self.sources.items()
            if now - max(self.updated.get(name, 0), self.failed.get(name, 0)) >= seconds
        ]

    def refresh(self, now: float | None = None) -> list[str]:
        now = time.time() if now is None else now
        changed = []
        for name in self.due(now):
            seconds, keep, read = self.sources[name]
            try:
                self.layers[name] = read()
            except (ConnectorError, KeyError, IndexError, TypeError, ValueError, OSError):
                self.failed[name] = now
                continue
            self.failed.pop(name, None)
            self.updated[name] = now
            changed.append(name)
            if keep:
                self.folder.mkdir(parents=True, exist_ok=True)
                (self.folder / f"{name}.json").write_text(json.dumps(self.layers[name]), encoding="utf-8")
        return changed

    def snapshot(self, layer: str) -> dict[str, Any]:
        return {"items": self.layers.get(layer, []), "updated": self.updated.get(layer), "failed": layer in self.failed}

    def summary(self) -> dict[str, Any]:
        return {
            "counts": {name: len(self.layers.get(name, [])) for name in self.sources},
            "updated": {name: self.updated.get(name) for name in self.sources},
            "failed": sorted(self.failed),
            "markets": self.layers.get("markets", []),
        }
