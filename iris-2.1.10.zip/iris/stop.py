"""Emergency stop. While the STOP file exists, IRIS refuses every tool call."""
from __future__ import annotations

from pathlib import Path


class EmergencyStop:
    interrupt_event = "emergency_stop"
    blocked_reason = "emergency stop is active"

    def __init__(self, data_dir: Path) -> None:
        self.path = data_dir / "STOP"

    @property
    def active(self) -> bool:
        return self.path.exists()

    def trigger(self, reason: str = "manual") -> None:
        self.path.write_text(reason + "\n", encoding="utf-8")

    def clear(self) -> None:
        self.path.unlink(missing_ok=True)


class ControlLock:
    """Blocks work during an emergency stop or while the owner has taken control."""

    def __init__(self, stop: EmergencyStop) -> None:
        self.stop = stop
        self.owner_has_control = False

    @property
    def active(self) -> bool:
        return self.owner_has_control or self.stop.active

    @property
    def interrupt_event(self) -> str:
        return self.stop.interrupt_event if self.stop.active else "control_interrupted"

    @property
    def blocked_reason(self) -> str:
        return self.stop.blocked_reason if self.stop.active else "the owner has taken control"
