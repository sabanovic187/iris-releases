"""Add-ons: extra abilities the owner chooses in Settings, Add-ons, instead of getting everything.

Everything IRIS had before add-ons stays in IRIS itself. Add-ons are for big or special things
(World Monitor, cameras, video editing) that not every owner wants on their computer.

The publisher keeps each add-on in addons/<id>/ in IRIS's repository:
  addon.toml     name, version, what it does, what it needs, what it may do
  install.ps1    optional, run once on install (Windows), with -Root <IRIS folder>
  uninstall.ps1  optional, run on removal
  tools.py       optional, def tools(hub) -> list[Tool]: abilities IRIS gets while it is installed

Releases publish addons/addons.json (the catalog, signed like IRIS updates) and one zip per
add-on. IRIS installs only add-ons in a catalog signed by IRIS's publisher, and only a zip that
matches the size and SHA-256 written in that signed catalog. Installed add-ons live in
data/addons/<id>/ on this computer, so updates never touch them and they never travel with IRIS.
Their tools go through the same approvals and rules as every other IRIS tool.
"""
from __future__ import annotations

import base64
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tomllib
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from iris.ed25519 import verify
from iris.update import CHANNEL, PUBLIC_KEY, UpdateError, _fetch, signed_bytes, version_key

MAX_ADDON = 100 * 1024 * 1024
INSTALL_SECONDS = 2 * 3600
ID_CHARS = set("abcdefghijklmnopqrstuvwxyz0123456789-")


class AddonError(Exception):
    pass


@dataclass(frozen=True)
class Need:
    command: str
    name: str
    url: str = ""


@dataclass(frozen=True)
class Addon:
    id: str
    name: str
    version: str
    summary: str
    details: str = ""
    size: str = ""  # how much it takes on disk once installed, in words ("about 4 GB")
    needs: tuple[Need, ...] = ()
    permissions: tuple[str, ...] = ()
    windows_only: bool = False
    file: str = ""
    sha256: str = ""
    bytes: int = 0


def valid_id(value: str) -> bool:
    return bool(value) and set(value) <= ID_CHARS and not value.startswith("-")


def read_manifest(data: dict[str, Any], **extra: Any) -> Addon:
    try:
        addon = Addon(
            id=str(data["id"]),
            name=str(data["name"]),
            version=str(data["version"]),
            summary=str(data["summary"]),
            details=str(data.get("details", "")),
            size=str(data.get("size", "")),
            needs=tuple(Need(str(n["command"]), str(n["name"]), str(n.get("url", ""))) for n in data.get("needs", [])),
            permissions=tuple(str(p) for p in data.get("permissions", [])),
            windows_only=bool(data.get("windows_only", False)),
            **extra,
        )
    except (KeyError, TypeError, ValueError) as error:
        raise AddonError("An add-on description is incomplete.") from error
    if not valid_id(addon.id):
        raise AddonError("An add-on has an unexpected name.")
    return addon


def check_catalog(catalog: dict[str, Any], public_key: str = "") -> list[Addon]:
    key = public_key or PUBLIC_KEY
    try:
        signature = base64.b64decode(catalog["signature"], validate=True)
        good = verify(base64.b64decode(key), signed_bytes(catalog), signature)
    except (KeyError, ValueError, TypeError):
        good = False
    if not good:
        raise AddonError("The add-on list is not signed by IRIS's publisher, so it was refused.")
    addons = []
    for entry in catalog.get("addons", []):
        if not isinstance(entry, dict):
            raise AddonError("The add-on list is damaged.")
        try:
            addon = read_manifest(entry, file=str(entry["file"]), sha256=str(entry["sha256"]).lower(), bytes=int(entry["bytes"]))
        except (KeyError, TypeError, ValueError) as error:
            raise AddonError("The add-on list is damaged.") from error
        if addon.file != f"{addon.id}-{addon.version}.zip" or not 0 < addon.bytes <= MAX_ADDON:
            raise AddonError("The add-on list names an unexpected file.")
        addons.append(addon)
    return addons


def missing(addon: Addon, which: Callable[[str], str | None] = shutil.which) -> list[Need]:
    return [need for need in addon.needs if not which(need.command)]


@dataclass
class Job:
    busy: str = ""  # "installing" or "removing"
    problem: str = ""
    log: list[str] = field(default_factory=list)


class Addons:
    def __init__(self, root: Path, channel: str = CHANNEL, public_key: str = "",
                 fetch: Callable[[str, int], bytes] = _fetch, run: Callable[..., Any] = subprocess.run,
                 which: Callable[[str], str | None] = shutil.which, windows: bool | None = None) -> None:
        self.root = root
        self.folder = root / "data" / "addons"
        self.channel = channel.rstrip("/")
        self.public_key = public_key
        self.fetch = fetch
        self.run = run
        self.which = which
        self.windows = sys.platform == "win32" if windows is None else windows
        self.catalog: list[Addon] = []
        self.checked = False
        self.problem = ""
        self.jobs: dict[str, Job] = {}

    # What is offered and what is here

    def refresh(self) -> list[Addon]:
        try:
            data = json.loads(self.fetch(f"{self.channel}/addons/addons.json", 256 * 1024))
        except (OSError, ValueError, UpdateError) as error:
            self.problem = "The add-on list could not be reached."
            raise AddonError(self.problem) from error
        self.catalog = check_catalog(data, self.public_key)
        self.checked, self.problem = True, ""
        return self.catalog

    def installed(self) -> dict[str, Addon]:
        found: dict[str, Addon] = {}
        if self.folder.is_dir():
            for manifest in sorted(self.folder.glob("*/addon.toml")):
                try:
                    addon = read_manifest(tomllib.loads(manifest.read_text(encoding="utf-8")))
                except (OSError, ValueError, AddonError):
                    continue
                if addon.id == manifest.parent.name:
                    found[addon.id] = addon
        # World Monitor installed before it became an add-on stays installed.
        if "worldmonitor" not in found and (self.root / "worldmonitor").is_dir():
            found["worldmonitor"] = Addon("worldmonitor", "World Monitor", "0", "Installed before add-ons.")
        return found

    def is_installed(self, addon_id: str) -> bool:
        return addon_id in self.installed()

    def state(self) -> dict[str, Any]:
        here = self.installed()
        offered = {addon.id: addon for addon in self.catalog}
        cards = []
        for addon_id in list(offered) + [i for i in here if i not in offered]:
            addon = offered.get(addon_id) or here[addon_id]
            mine = here.get(addon_id)
            job = self.jobs.get(addon_id, Job())
            cards.append({
                "id": addon_id,
                "name": addon.name,
                "summary": addon.summary,
                "details": addon.details,
                "size": addon.size,
                "version": addon.version,
                "installed": mine.version if mine else "",
                "update": bool(mine and addon_id in offered and version_key(offered[addon_id].version) > version_key(mine.version)),
                "needs": [{"name": n.name, "url": n.url} for n in missing(addon, self.which)],
                "permissions": list(addon.permissions),
                "unavailable": "This add-on works on Windows only." if addon.windows_only and not self.windows else "",
                "busy": job.busy,
                "problem": job.problem,
            })
        return {"addons": cards, "checked": self.checked, "problem": self.problem}

    # Installing and removing

    def install(self, addon_id: str) -> Addon:
        addon = next((a for a in self.catalog if a.id == addon_id), None)
        if addon is None:
            raise AddonError("That add-on is not in the signed add-on list.")
        if addon.windows_only and not self.windows:
            raise AddonError("This add-on works on Windows only.")
        lacking = missing(addon, self.which)
        if lacking:
            raise AddonError("First install: " + ", ".join(need.name for need in lacking) + ".")
        try:
            data = self.fetch(f"{self.channel}/addons/{addon.file}", addon.bytes)
        except (OSError, UpdateError) as error:
            raise AddonError("The add-on could not be downloaded.") from error
        if len(data) != addon.bytes or hashlib.sha256(data).hexdigest() != addon.sha256:
            raise AddonError("The download does not match the signed add-on list, so it was refused.")
        target = self.folder / addon.id
        staging = self.folder / f".{addon.id}.new"
        shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir(parents=True)
        package = staging.parent / f".{addon.id}.zip"
        package.write_bytes(data)
        try:
            with zipfile.ZipFile(package) as archive:
                for name in archive.namelist():
                    parts = Path(name).parts
                    if name.startswith("/") or ".." in parts or ":" in name:
                        raise AddonError("The add-on tried to write outside its own folder.")
                archive.extractall(staging)
            if read_manifest(tomllib.loads((staging / "addon.toml").read_text(encoding="utf-8"))).version != addon.version:
                raise AddonError("The add-on's contents do not match the signed add-on list.")
        except (OSError, ValueError, zipfile.BadZipFile) as error:
            shutil.rmtree(staging, ignore_errors=True)
            raise AddonError("The add-on package is damaged.") from error
        except AddonError:
            shutil.rmtree(staging, ignore_errors=True)
            raise
        finally:
            package.unlink(missing_ok=True)
        self._script(staging, "install.ps1")
        shutil.rmtree(target, ignore_errors=True)
        staging.rename(target)
        return addon

    def remove(self, addon_id: str) -> None:
        if not self.is_installed(addon_id):
            raise AddonError("That add-on is not installed.")
        target = self.folder / addon_id
        if (target / "uninstall.ps1").exists():
            self._script(target, "uninstall.ps1")
        shutil.rmtree(target, ignore_errors=True)

    def _script(self, folder: Path, name: str) -> None:
        script = folder / name
        if not script.exists():
            return
        if not self.windows:
            raise AddonError("This add-on installs on Windows only.")
        quoted = lambda path: "'" + str(path).replace("'", "''") + "'"
        wrapper = (f"try {{ & {quoted(script)} -Root {quoted(self.root)}; exit $LASTEXITCODE }} "
                   "catch { Write-Output ('PROBLEM: ' + $_.Exception.Message); exit 1 }")
        command = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", wrapper]
        try:
            result = self.run(command, cwd=self.root, capture_output=True, text=True, timeout=INSTALL_SECONDS)
        except (OSError, subprocess.SubprocessError) as error:
            raise AddonError(f"{name} could not run ({type(error).__name__}).") from error
        output = ((getattr(result, "stdout", "") or "") + (getattr(result, "stderr", "") or "")).strip()
        try:
            (folder / f"{name}.log").write_text(output, encoding="utf-8")
        except OSError:
            pass
        if getattr(result, "returncode", 1) != 0:
            lines = output.splitlines()
            said = [line[9:] for line in lines if line.startswith("PROBLEM: ")]
            last = said[-1] if said else (lines[-1] if lines else "no details")
            raise AddonError(f"Setup stopped: {last[:300]} (details in {script.name}.log)")

    # Abilities from installed add-ons

    def tools(self, hub: Any, taken: set[str]) -> list[Any]:
        found = []
        for addon_id in self.installed():
            path = self.folder / addon_id / "tools.py"
            if not path.exists():
                continue
            try:
                spec = importlib.util.spec_from_file_location(f"iris_addon_{addon_id.replace('-', '_')}", path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                for tool in module.tools(hub):
                    if tool.name in taken:
                        continue  # an add-on never replaces one of IRIS's own tools
                    taken.add(tool.name)
                    found.append(tool)
            except Exception as error:  # a broken add-on must not stop IRIS
                hub.audit.write("addon_failed", addon=addon_id, error=f"{type(error).__name__}: {error}"[:200])
        return found
