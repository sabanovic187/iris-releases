"""Microphone test: python -m iris.voice.wake_test"""
from __future__ import annotations

import time
from pathlib import Path

from iris.config import ROOT, load_settings, read_raw
from iris.voice.wake import listen, load_detector, resolve_wake_model


def main() -> int:
    import sounddevice

    voice = read_raw(ROOT)["voice"]
    print(f"Microphone: {sounddevice.query_devices(kind='input')['name']}")
    print("Loading the wake word model...")
    model = resolve_wake_model(voice["wake_model"], load_settings(ROOT).data_dir / "wake")
    detector = load_detector(
        model,
        float(voice["wake_threshold"]),
        float(voice["wake_vad_threshold"]),
        float(voice["wake_cooldown_seconds"]),
    )
    print(f"Say {Path(model).stem.replace('_', ' ')}. Audio is processed here and is not saved. Press Ctrl+C to finish.")

    stats = {"hits": 0, "peak": 0.0}

    def on_wake() -> None:
        stats["hits"] += 1
        print(f"\nWAKE WORD DETECTED #{stats['hits']} at {time.strftime('%H:%M:%S')}")

    def on_frame(score: float) -> None:
        stats["peak"] = max(stats["peak"], score)
        print(f"\rscore {score:0.3f}  highest {stats['peak']:0.3f}   ", end="", flush=True)

    try:
        listen(detector, on_wake, on_frame)
    except KeyboardInterrupt:
        print(f"\nDetections: {stats['hits']}. Highest score: {stats['peak']:0.3f}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
