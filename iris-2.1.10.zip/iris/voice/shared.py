"""Hearing and speaking for places other than the computer's microphone: the IRIS Pod and Telegram.

Uses the voice IRIS already loaded when it is on, and loads its own copy otherwise.
"""
from __future__ import annotations

import io
import threading
from typing import Any, Iterable, Iterator

import numpy as np

SPEECH_RATE = 16000  # what Whisper listens to


class SpeechTools:
    def __init__(self, hub: Any) -> None:
        self.hub = hub
        self.lock = threading.Lock()
        self.transcriber: Any = None
        self.piper: Any = None

    def _config(self) -> dict[str, Any]:
        voice = getattr(self.hub, "voice", None)
        try:
            return voice._config() if voice else {}
        except Exception:
            return {}

    def transcribe(self, samples: np.ndarray) -> str:
        """16 kHz 16-bit samples to text."""
        with self.lock:
            transcriber = getattr(getattr(self.hub, "voice", None), "transcriber", None)
            if transcriber is None:
                if self.transcriber is None:
                    from iris.voice.speech import Transcriber

                    model = self._config().get("speech_model", "base.en")
                    self.transcriber = Transcriber(model, self.hub.settings.data_dir / "models")
                transcriber = self.transcriber
            return transcriber.transcribe(samples)

    def _local(self) -> Any:
        speaker = getattr(getattr(self.hub, "voice", None), "speaker", None)
        local = getattr(speaker, "local", speaker)
        if getattr(local, "voice", None) is not None:
            return local.voice
        if self.piper is None:
            from piper import PiperVoice

            name = self._config().get("voice_name", "en_GB-alan-medium")
            self.piper = PiperVoice.load(self.hub.settings.data_dir / "voices" / f"{name}.onnx")
        return self.piper

    def synthesize(self, text: str) -> Iterator[tuple[np.ndarray, int]]:
        """Sound for the text: the cloud voice when it is on, otherwise the local one."""
        connectors = getattr(self.hub, "connectors", None)
        cloud = connectors.elevenlabs if connectors else None
        if cloud and cloud.wanted(text):
            try:
                from iris.connectors.elevenlabs import SAMPLE_RATE

                left = b""
                for part in cloud.speak(text):
                    part = left + part
                    even = len(part) - len(part) % 2
                    left = part[even:]
                    yield np.frombuffer(part[:even], dtype=np.int16), SAMPLE_RATE
                return
            except Exception:
                pass
        piper = self._local()
        for chunk in piper.synthesize(text):
            yield chunk.audio_int16_array, piper.config.sample_rate


def decode_audio(data: bytes, rate: int = SPEECH_RATE) -> np.ndarray:
    """Any audio file (a Telegram voice note is OGG Opus) to mono 16-bit samples."""
    import av

    container = av.open(io.BytesIO(data))
    resampler = av.AudioResampler(format="s16", layout="mono", rate=rate)
    parts = []
    try:
        for frame in container.decode(audio=0):
            parts.extend(out.to_ndarray().reshape(-1) for out in resampler.resample(frame))
        parts.extend(out.to_ndarray().reshape(-1) for out in resampler.resample(None))
    finally:
        container.close()
    return np.concatenate(parts).astype(np.int16) if parts else np.zeros(0, dtype=np.int16)


def encode_voice_note(chunks: Iterable[tuple[np.ndarray, int]]) -> bytes:
    """Sound to OGG Opus, the format Telegram plays as a voice message."""
    import av

    buffer = io.BytesIO()
    container = av.open(buffer, "w", format="ogg")
    stream = container.add_stream("libopus", rate=48000, layout="mono")
    stream.bit_rate = 32000
    resampler, rate_now = None, None
    for samples, rate in chunks:
        if resampler is None or rate != rate_now:
            resampler, rate_now = av.AudioResampler(format="s16", layout="mono", rate=48000), rate
        frame = av.AudioFrame.from_ndarray(samples.astype(np.int16).reshape(1, -1), format="s16", layout="mono")
        frame.sample_rate = rate
        for out in resampler.resample(frame):
            out.pts = None
            for packet in stream.encode(out):
                container.mux(packet)
    for packet in stream.encode(None):
        container.mux(packet)
    container.close()
    return buffer.getvalue()
