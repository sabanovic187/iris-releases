"""Voice mode: python -m iris.voice.chat"""
from __future__ import annotations

import asyncio
import threading
from typing import Any, Callable

from iris.agent import Agent, budget_problem
from iris.audit import AuditLog
from iris.cli import approve_in_terminal
from iris.config import ROOT, Settings, load_settings, read_raw
from iris.gate import ToolGate
from iris.hotkey import HOTKEY_NAME, start_stop_hotkey
from iris.memory import Memory
from iris.policy import Policy
from iris.projects import TaskManager
from iris.task_tools import BackgroundTasks, build_task_server
from iris.stop import EmergencyStop
from iris.voice.loop import ListenLimits, VoiceLoop
from iris.voice.speech import Speaker, Transcriber
from iris.voice.wake import ensure_models, load_detector, microphone_frames, resolve_wake_model

SPEECH_THRESHOLD = 0.5
MAX_SPOKEN_CHARACTERS = 1200


class ClaudeResponder:
    """Runs the agent on its own event loop so the microphone never waits."""

    def __init__(self, settings: Settings, audit: AuditLog, stop: EmergencyStop, say: Callable[[str], None]) -> None:
        self.settings = settings
        self.stop = stop
        self.say = say
        self.loop = asyncio.new_event_loop()
        threading.Thread(target=self.loop.run_forever, daemon=True).start()
        self.memory = asyncio.run_coroutine_threadsafe(self._open(audit), self.loop).result()

    async def _open(self, audit: AuditLog) -> Memory:
        memory = Memory(self.settings.data_dir / "iris.db")
        policy = Policy(self.settings.workspace, self.settings.level, self.settings.allowed_apps)
        gate = ToolGate(policy, audit, self.stop, self._approve)
        tasks = TaskManager(self.settings, memory, audit, self.stop, self._approve)
        runner = BackgroundTasks(tasks, self.say)
        servers = build_task_server(tasks, runner)
        self.agent = Agent(self.settings, memory, audit, self.stop, gate, extra_mcp=servers)
        await self.agent.start()
        return memory

    async def _approve(self, tool: str, args: dict[str, Any], reason: str) -> bool:
        self.say("I need your approval on the screen.")
        return await approve_in_terminal(tool, args, reason)

    async def _ask(self, text: str) -> str:
        problem = budget_problem(self.settings, self.memory)
        if problem:
            return problem
        parts: list[str] = []
        result = await self.agent.ask(text, parts.append)
        if result and result.is_error:
            return "I could not finish that request."
        return " ".join(parts)[:MAX_SPOKEN_CHARACTERS]

    def respond(self, text: str) -> str:
        return asyncio.run_coroutine_threadsafe(self._ask(text), self.loop).result()


def main() -> int:
    settings = load_settings()
    voice = read_raw(ROOT)["voice"]
    audit = AuditLog(settings.data_dir / "audit" / "audit.jsonl")
    stop = EmergencyStop(settings.data_dir)
    if stop.active:
        print("Emergency stop is active. Run scripts\\clear-stop.ps1 first.")
        return 1

    print("Loading voice models...")
    ensure_models()
    from openwakeword.vad import VAD

    vad = VAD()
    detector = load_detector(
        resolve_wake_model(voice["wake_model"], settings.data_dir / "wake"),
        float(voice["wake_threshold"]),
        float(voice["wake_vad_threshold"]),
        float(voice["wake_cooldown_seconds"]),
    )
    transcriber = Transcriber(voice["speech_model"], settings.data_dir / "models")
    speaker = Speaker(settings.data_dir / "voices" / f"{voice['voice_name']}.onnx")

    if settings.brain_ready:
        respond = ClaudeResponder(settings, audit, stop, speaker.say).respond
        print("Mode: Claude.")
    else:
        respond = lambda text: f"I heard you say: {text}"
        print("Mode: local test. No API key, so IRIS repeats what it heard.")

    loop = VoiceLoop(
        detector=detector,
        is_speech=lambda frame: float(vad.predict(frame[:1200])) >= SPEECH_THRESHOLD,
        transcribe=transcriber.transcribe,
        respond=respond,
        say=speaker.say,
        stop_speaking=speaker.stop,
        limits=ListenLimits(
            float(voice["silence_seconds"]),
            float(voice["no_speech_seconds"]),
            float(voice["max_listen_seconds"]),
        ),
        on_status=lambda status: print(f"[{status}]"),
    )
    print('Say "Hey Jarvis", then speak. Audio is not saved. Press Ctrl+C to finish.')
    def frames() -> Any:
        for frame in microphone_frames():
            if stop.active:
                print("Emergency stop is active. Voice mode closed.")
                return
            yield frame

    def emergency() -> None:
        stop.trigger("hotkey")
        speaker.stop()

    ready = start_stop_hotkey(emergency)
    if getattr(ready, "registered", False):
        print(f"Emergency stop: {HOTKEY_NAME}")
    try:
        loop.run(frames())
    except KeyboardInterrupt:
        print("Voice mode closed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
