"""Voice conversation: wake word, listening, thinking, speaking.

After IRIS answers she keeps listening for a few seconds, so a follow-up question needs no wake
word. Saying the wake word while she talks stops her at once and starts a new question.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, Iterable, Protocol

import re

import numpy as np

from iris.voice.wake import FRAME_SECONDS


class Detector(Protocol):
    def process(self, frame: np.ndarray) -> bool: ...


@dataclass(frozen=True)
class ListenLimits:
    silence_seconds: float = 0.8
    no_speech_seconds: float = 5.0
    max_seconds: float = 20.0
    follow_up_seconds: float = 0.0  # 0 means the wake word is needed every time


# Said in the follow-up window, these end the conversation instead of starting a new question.
DISMISSALS = re.compile(
    r"^(thanks?( you)?|that'?s (all|it)|never ?mind|no(pe)?|nothing|ok(ay)?|stop|goodbye|bye|hvala|to je sve|ništa|nista)"
    r"(,? (iris|sir|very much))?[.!? ]*$",
    re.IGNORECASE,
)


def is_dismissal(text: str) -> bool:
    return bool(DISMISSALS.match(" ".join(text.split())))


class VoiceLoop:
    def __init__(
        self,
        detector: Detector,
        is_speech: Callable[[np.ndarray], bool],
        transcribe: Callable[[np.ndarray], str],
        respond: Callable[[str], str],
        say: Callable[[str], None],
        stop_speaking: Callable[[], None],
        limits: ListenLimits = ListenLimits(),
        on_status: Callable[[str], None] = lambda _status: None,
        wait_until_quiet: Callable[[], None] = lambda: None,
    ) -> None:
        self.detector = detector
        self.is_speech = is_speech
        self.transcribe = transcribe
        self.respond = respond
        self.say = say
        self.stop_speaking = stop_speaking
        self.limits = limits
        self.on_status = on_status
        self.wait_until_quiet = wait_until_quiet
        self.turn = 0
        self.following = False
        self.follow_up_turn: int | None = None
        self.worker = ThreadPoolExecutor(max_workers=1)
        self._reset_capture()
        self.capturing = False

    def _reset_capture(self) -> None:
        self.buffer: list[np.ndarray] = []
        self.heard_speech = False
        self.silent_frames = 0

    def _frames(self, seconds: float) -> int:
        return round(seconds / FRAME_SECONDS)

    def _start_listening(self) -> None:
        self.stop_speaking()
        self.turn += 1
        self.follow_up_turn = None
        self.following = False
        self._reset_capture()
        self.capturing = True
        self.on_status("listening")

    def _start_follow_up(self) -> None:
        self.turn += 1
        self.follow_up_turn = None
        self.following = True
        self._reset_capture()
        self.capturing = True
        self.on_status("following up")

    def listen_now(self) -> None:
        """Start listening without the wake word. Call from the microphone thread."""
        self._start_listening()

    def _capture(self, frame: np.ndarray) -> None:
        self.buffer.append(frame)
        if self.is_speech(frame):
            self.heard_speech = True
            self.silent_frames = 0
        else:
            self.silent_frames += 1

        finished = self.heard_speech and self.silent_frames >= self._frames(self.limits.silence_seconds)
        too_long = len(self.buffer) >= self._frames(self.limits.max_seconds)
        wait = self.limits.follow_up_seconds if self.following else self.limits.no_speech_seconds
        nothing_said = not self.heard_speech and len(self.buffer) >= self._frames(wait)
        if nothing_said:
            self.capturing = False
            self.on_status("follow-up over" if self.following else "nothing heard")
        elif finished or too_long:
            self.capturing = False
            audio = np.concatenate(self.buffer)
            self.worker.submit(self._answer, audio, self.turn, self.following)

    def _answer(self, audio: np.ndarray, turn: int, follow_up: bool = False) -> None:
        try:
            self.on_status("thinking")
            text = self.transcribe(audio)
            if not text:
                # In the follow-up window a cough or the room is not worth a remark.
                self.on_status("follow-up over" if follow_up else "nothing understood")
                return
            if follow_up and is_dismissal(text):
                self.on_status("follow-up over")
                return
            self.on_status(f"you said: {text}")
            reply = self.respond(text)
            if turn == self.turn and reply:
                self.on_status(f"iris: {reply}")
                self.say(reply)
            self.on_status("waiting for wake word")
            if self.limits.follow_up_seconds > 0 and turn == self.turn:
                self.wait_until_quiet()
                if turn == self.turn:
                    self.follow_up_turn = turn  # the microphone thread opens the window
        except Exception as error:
            self.on_status(f"error: {type(error).__name__}: {error}")

    def process(self, frame: np.ndarray) -> None:
        if self.capturing:
            self._capture(frame)
        elif self.detector.process(frame):
            self._start_listening()
        elif self.follow_up_turn is not None and self.follow_up_turn == self.turn:
            self._start_follow_up()

    def run(self, frames: Iterable[np.ndarray]) -> None:
        try:
            for frame in frames:
                self.process(frame)
        finally:
            self.stop_speaking()
            self.worker.shutdown(wait=False, cancel_futures=True)
