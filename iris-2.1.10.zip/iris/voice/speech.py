"""Local speech recognition and speech generation."""
from __future__ import annotations

import itertools
import os
import re
import sys
import threading
import types
from pathlib import Path
from typing import Any, Callable

import numpy as np

from iris.connectors.base import ConnectorError
from iris.connectors.elevenlabs import SAMPLE_RATE


FULL_SPEECH = 6000.0
AV_BLOCKED_MARK = "pyav-blocked"
AV_BLOCKED = (
    "Windows Smart App Control blocks PyAV, the library that reads audio and video files, "
    "so files cannot be transcribed. Live voice still works."
)


class AudioFilesBlocked(ImportError):
    pass


def _without_av() -> types.ModuleType:
    """Stands in for PyAV. Whisper only needs it to read files; IRIS hands it microphone samples."""
    stand_in = types.ModuleType("av")

    def missing(name: str) -> Any:
        raise AudioFilesBlocked(AV_BLOCKED)

    stand_in.__getattr__ = missing  # type: ignore[method-assign]
    return stand_in


def whisper_model_class(cache_dir: Path) -> Any:
    """Load faster-whisper even when Smart App Control blocks PyAV's bundled video codecs.

    Once PyAV is found blocked, a mark in the models folder stops IRIS from trying again,
    because every try makes Windows show a warning. Delete the mark to try again.
    """
    mark = cache_dir / AV_BLOCKED_MARK
    if "av" not in sys.modules:
        if mark.exists():
            sys.modules["av"] = _without_av()
        else:
            try:
                import av  # noqa: F401
            except ImportError as error:
                if "No module named" in str(error):
                    raise
                sys.modules["av"] = _without_av()
                try:
                    cache_dir.mkdir(parents=True, exist_ok=True)
                    mark.write_text(f"{error}\n", encoding="utf-8")
                except OSError:
                    pass
    from faster_whisper import WhisperModel

    return WhisperModel


class Transcriber:
    def __init__(self, model_name: str, cache_dir: Path) -> None:
        # hf_xet is a blocked DLL under Smart App Control. Plain downloads work.
        os.environ["HF_HUB_DISABLE_XET"] = "1"
        os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
        WhisperModel = whisper_model_class(cache_dir)
        options = {"device": "cpu", "compute_type": "int8", "download_root": str(cache_dir)}
        try:
            # The model on disk is enough. Asking the internet for a newer copy can take long.
            self.model = WhisperModel(model_name, local_files_only=True, **options)
        except Exception:
            self.model = WhisperModel(model_name, **options)

    def transcribe(self, audio: np.ndarray) -> str:
        samples = audio.astype(np.float32) / 32768.0
        segments, _ = self.model.transcribe(samples, language="en", beam_size=1, vad_filter=False)
        return " ".join(segment.text.strip() for segment in segments).strip()


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [part.strip() for part in parts if part.strip()]


def loudness(samples: np.ndarray) -> float:
    """How loud a block of 16-bit sound is, from 0 to 1."""
    if not len(samples):
        return 0.0
    return min(1.0, float(np.sqrt(np.mean(np.square(samples.astype(np.float32))))) / FULL_SPEECH)


class Speaker:
    """Speaks one sentence at a time and can stop at once."""

    def __init__(self, voice_path: Path) -> None:
        from piper import PiperVoice

        self.voice = PiperVoice.load(voice_path)
        self._stop = threading.Event()
        self.on_level: Callable[[float], None] = lambda _level: None

    def stop(self) -> None:
        self._stop.set()

    def say(self, text: str) -> None:
        import sounddevice

        self._stop.clear()
        rate = self.voice.config.sample_rate
        with sounddevice.OutputStream(samplerate=rate, channels=1, dtype="int16") as stream:
            for sentence in split_sentences(text):
                for chunk in self.voice.synthesize(sentence):
                    audio = chunk.audio_int16_array
                    block = rate // 10
                    for start in range(0, len(audio), block):
                        if self._stop.is_set():
                            stream.abort()
                            return
                        part = audio[start:start + block]
                        self.on_level(loudness(part))
                        stream.write(part)


class MixedSpeaker:
    """Uses the cloud voice when it can, and the local voice whenever the cloud voice cannot speak."""

    def __init__(self, local: Speaker, cloud: Any, note: Callable[[str], None] = lambda _text: None) -> None:
        self.local = local
        self.cloud = cloud
        self.note = note
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()
        self.local.stop()

    def say(self, text: str) -> None:
        self._stop.clear()
        if self.cloud.wanted(text):
            try:
                self._play(text)
                return
            except (ConnectorError, OSError) as error:
                self.note(f"Using the local voice: {error}")
        self.local.say(text)

    def _play(self, text: str) -> None:
        sound = self.cloud.speak(text)
        first = next(sound, b"")  # any refusal arrives here, before the speaker opens
        import sounddevice

        left = b""
        with sounddevice.RawOutputStream(samplerate=SAMPLE_RATE, channels=1, dtype="int16") as stream:
            for part in itertools.chain([first], sound):
                if self._stop.is_set():
                    stream.abort()
                    return
                part = left + part
                even = len(part) - len(part) % 2
                self.local.on_level(loudness(np.frombuffer(part[:even], dtype=np.int16)))
                stream.write(part[:even])
                left = part[even:]
