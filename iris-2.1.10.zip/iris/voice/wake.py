"""Local wake word detection. Audio stays on this computer."""
from __future__ import annotations

import queue
from pathlib import Path
from typing import Any, Callable, Iterator

import numpy as np

SAMPLE_RATE = 16_000
FRAME_SAMPLES = 1_280  # 80 ms, the frame size openWakeWord expects
FRAME_SECONDS = FRAME_SAMPLES / SAMPLE_RATE
FALLBACK_WAKE_MODEL = "hey_jarvis"


class WakeDetector:
    """Turns a stream of frames into single wake events."""

    def __init__(self, model: Any, name: str, threshold: float, cooldown_seconds: float) -> None:
        self.model = model
        self.name = name
        self.threshold = threshold
        self.cooldown_frames = round(cooldown_seconds / FRAME_SECONDS)
        self._cooldown = 0
        self.last_score = 0.0
        # While IRIS talks the microphone also hears her, so interrupting her needs a surer match.
        # None means she cannot be interrupted by voice; the Stop and Talk buttons still work.
        self.speaking_threshold: float | None = threshold
        self.speaking = False

    def process(self, frame: np.ndarray) -> bool:
        scores = self.model.predict(frame)
        self.last_score = float(scores.get(self.name, 0.0))
        if self._cooldown > 0:
            self._cooldown -= 1
            return False
        threshold = self.speaking_threshold if self.speaking else self.threshold
        if threshold is not None and self.last_score >= threshold:
            self._cooldown = self.cooldown_frames
            self.model.reset()
            return True
        return False


def ensure_models() -> None:
    """Download the shared and wake word models once."""
    import os

    import openwakeword
    from openwakeword.utils import download_models

    needed = ["melspectrogram", "embedding_model", "silero_vad", "hey_jarvis_v0.1"]
    folder = os.path.join(os.path.dirname(openwakeword.__file__), "resources", "models")
    present = os.listdir(folder) if os.path.isdir(folder) else []
    if not all(any(name.startswith(item) and not name.endswith(".part") for name in present) for item in needed):
        os.makedirs(folder, exist_ok=True)
        download_models(["hey_jarvis_v0.1"], folder)


BUILT_IN = Path(__file__).resolve().parent / "models"  # wake words that ship with IRIS, such as hey_iris


def resolve_wake_model(name: str, folder: Path) -> str:
    """The owner's own model first, then one that ships with IRIS. Otherwise "Hey Jarvis" keeps voice working."""
    for place in (folder, BUILT_IN):
        candidate = place / f"{name}.onnx"
        if candidate.is_file():
            return str(candidate)
    return FALLBACK_WAKE_MODEL


def load_detector(name: str, threshold: float, vad_threshold: float, cooldown: float) -> WakeDetector:
    from openwakeword.model import Model

    ensure_models()
    model = Model(
        wakeword_models=[name],
        inference_framework="onnx",
        vad_threshold=vad_threshold,
    )
    return WakeDetector(model, next(iter(model.models)), threshold, cooldown)


def microphone_frames(device: int | None = None) -> Iterator[np.ndarray]:
    """Yield 80 ms microphone frames. Frames are never saved."""
    import sounddevice

    frames: queue.Queue[np.ndarray] = queue.Queue(maxsize=50)

    def receive(data: np.ndarray, _count: int, _time: Any, _status: Any) -> None:
        try:
            frames.put_nowait(data[:, 0].copy())
        except queue.Full:
            pass

    with sounddevice.InputStream(
        samplerate=SAMPLE_RATE,
        blocksize=FRAME_SAMPLES,
        channels=1,
        dtype="int16",
        device=device,
        callback=receive,
    ):
        while True:
            yield frames.get()


def listen(
    detector: WakeDetector,
    on_wake: Callable[[], None],
    on_frame: Callable[[float], None] | None = None,
    device: int | None = None,
) -> None:
    """Listen on the microphone until interrupted."""
    for frame in microphone_frames(device):
        if detector.process(frame):
            on_wake()
        if on_frame:
            on_frame(detector.last_score)
