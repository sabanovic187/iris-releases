"""Lets the agent use OpenAI as its brain, so tools, approvals and stops work the same for every brain.

The agent speaks Anthropic's message format. This small server on this computer translates it.
"""
from __future__ import annotations

import hmac
import json
import secrets
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Iterator

from iris.audit import redact
MODEL_LABEL = "iris-openai"
ANSWER_SECONDS = 120
MAX_REQUEST = 64 * 1024 * 1024
MAX_DESCRIPTION = 1000  # OpenAI refuses longer tool descriptions
MAX_ANSWER_TOKENS = 16000


def _plain(content: Any) -> str:
    if isinstance(content, str):
        return content
    return "\n".join(item.get("text", "") for item in content or [] if item.get("type") == "text")


def _image(block: dict[str, Any]) -> dict[str, Any] | None:
    source = block.get("source", {})
    if source.get("type") != "base64":
        return None
    return {"type": "image_url", "image_url": {"url": f"data:{source.get('media_type')};base64,{source.get('data')}"}}


def _assistant(content: list[dict[str, Any]]) -> dict[str, Any]:
    message: dict[str, Any] = {"role": "assistant", "content": _plain(content) or None}
    calls = [
        {"id": item["id"], "type": "function", "function": {"name": item["name"], "arguments": json.dumps(item.get("input", {}))}}
        for item in content
        if item.get("type") == "tool_use"
    ]
    if calls:
        message["tool_calls"] = calls
    return message


def _user(content: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Tool answers must come first, straight after the assistant message that asked for them."""
    found: list[dict[str, Any]] = []
    parts: list[dict[str, Any]] = []
    for item in content:
        kind = item.get("type")
        if kind == "tool_result":
            text = _plain(item.get("content"))
            found.append({"role": "tool", "tool_call_id": item["tool_use_id"], "content": ("Error: " + text) if item.get("is_error") else text})
        elif kind == "text":
            parts.append({"type": "text", "text": item.get("text", "")})
        elif kind == "image":
            picture = _image(item)
            if picture:
                parts.append(picture)
    if parts:
        found.append({"role": "user", "content": parts})
    return found


def tidy(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Give OpenAI the strict order it needs. Each asked-for tool gets exactly one answer right after it."""
    joined: list[dict[str, Any]] = []
    for item in messages:
        if item["role"] == "assistant" and joined and joined[-1]["role"] == "assistant":
            last = joined[-1]
            texts = [text for text in (last.get("content"), item.get("content")) if text]
            last["content"] = "\n".join(texts) or None
            if item.get("tool_calls"):
                last["tool_calls"] = last.get("tool_calls", []) + item["tool_calls"]
        else:
            joined.append(dict(item))
    answers = {item["tool_call_id"]: item for item in joined if item["role"] == "tool"}
    final: list[dict[str, Any]] = []
    for item in joined:
        if item["role"] == "tool":
            continue
        if item["role"] == "assistant" and not item.get("content") and not item.get("tool_calls"):
            continue
        final.append(item)
        for call in item.get("tool_calls", []):
            final.append(answers.get(call["id"]) or {"role": "tool", "tool_call_id": call["id"], "content": "No answer."})
    return final


def ask_openai(url: str, key: str, body: dict[str, Any]) -> tuple[int, Any]:
    """Return OpenAI's status and answer. A refusal keeps its real reason. A stream stays open for the caller."""
    request = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"), method="POST",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json", "User-Agent": "IRIS"},
    )
    try:
        response = urllib.request.urlopen(request, timeout=ANSWER_SECONDS)
        if body.get("stream"):
            return 200, response
        with response:
            return 200, json.loads(response.read())
    except urllib.error.HTTPError as error:
        try:
            return error.code, json.loads(error.read())
        except ValueError:
            return error.code, {}
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return 503, {"error": {"message": "OpenAI could not be reached."}}


def read_stream(response: Any) -> Iterator[dict[str, Any]]:
    """Give each part of an OpenAI answer as soon as it arrives."""
    for raw in response:
        line = raw.decode("utf-8", errors="replace").strip()
        if not line.startswith("data:") or line == "data: [DONE]":
            continue
        try:
            yield json.loads(line[5:])
        except ValueError:
            continue


def to_openai(request: dict[str, Any], model: str) -> dict[str, Any]:
    messages: list[dict[str, Any]] = []
    system = _plain(request.get("system"))
    if system:
        messages.append({"role": "system", "content": system})
    for item in request.get("messages", []):
        content = item.get("content")
        if isinstance(content, str):
            messages.append({"role": item["role"], "content": content})
        elif item["role"] == "assistant":
            messages.append(_assistant(content))
        else:
            messages.extend(_user(content))
    body: dict[str, Any] = {
        "model": model,
        "messages": tidy(messages),
        "max_completion_tokens": min(int(request.get("max_tokens") or 4096), MAX_ANSWER_TOKENS),
        "reasoning_effort": "none",  # the quickest answers, and the only choice GPT-5.6 allows with tools here
    }
    tools = [
        {"type": "function", "function": {
            "name": item["name"], "description": item.get("description", "")[:MAX_DESCRIPTION], "parameters": item["input_schema"],
        }}
        for item in request.get("tools", [])
        if "input_schema" in item
    ]
    if tools:
        body["tools"] = tools
        choice = request.get("tool_choice", {})
        if choice.get("type") == "any":
            body["tool_choice"] = "required"
        elif choice.get("type") == "tool":
            body["tool_choice"] = {"type": "function", "function": {"name": choice["name"]}}
    return body


def to_anthropic(reply: dict[str, Any]) -> dict[str, Any]:
    choice = (reply.get("choices") or [{}])[0]
    message = choice.get("message", {})
    content: list[dict[str, Any]] = []
    if message.get("content"):
        content.append({"type": "text", "text": message["content"]})
    for call in message.get("tool_calls") or []:
        try:
            arguments = json.loads(call["function"].get("arguments") or "{}")
        except ValueError:
            arguments = {}
        content.append({"type": "tool_use", "id": call["id"], "name": call["function"]["name"], "input": arguments})
    if any(item["type"] == "tool_use" for item in content):
        reason = "tool_use"
    else:
        reason = "max_tokens" if choice.get("finish_reason") == "length" else "end_turn"
    usage = reply.get("usage", {})
    return {
        "id": f"msg_{uuid.uuid4().hex}", "type": "message", "role": "assistant", "model": MODEL_LABEL, "content": content,
        "stop_reason": reason, "stop_sequence": None,
        "usage": {"input_tokens": usage.get("prompt_tokens", 0), "output_tokens": usage.get("completion_tokens", 0)},
    }


class Bridge:
    def __init__(self, account: Callable[[], dict[str, Any] | None], api: str) -> None:
        self.account = account
        self.api = api
        self.token = secrets.token_urlsafe(32)
        # Called from the bridge's thread with (model, input tokens, output tokens) after each reply.
        self.on_usage: Callable[[str, int, int], None] = lambda _model, _in, _out: None
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *_args: Any) -> None:
                pass

            def _send(self, status: int, data: bytes, kind: str = "application/json") -> None:
                self.send_response(status)
                self.send_header("Content-Type", kind)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _problem(self, status: int, text: str) -> None:
                self._send(status, json.dumps({"type": "error", "error": {"type": "api_error", "message": text}}).encode())

            def do_HEAD(self) -> None:
                self._send(200, b"")

            def do_GET(self) -> None:
                self._send(200, b"{}")

            def do_POST(self) -> None:
                size = int(self.headers.get("content-length", 0))
                if size > MAX_REQUEST:
                    self._problem(413, "That request is too large.")
                    return
                body = self.rfile.read(size)
                given = self.headers.get("x-api-key") or self.headers.get("authorization", "").removeprefix("Bearer ")
                if not hmac.compare_digest(given.encode(), bridge.token.encode()):
                    self._problem(401, "Not allowed.")
                    return
                path = self.path.split("?")[0]
                try:
                    request = json.loads(body)
                except ValueError:
                    self._problem(400, "Unreadable request.")
                    return
                if path.endswith("/count_tokens"):
                    self._send(200, json.dumps({"input_tokens": len(body) // 4}).encode())
                elif path.endswith("/messages"):
                    self._messages(request)
                else:
                    self._problem(404, "Unknown address.")

            def _messages(self, request: dict[str, Any]) -> None:
                saved = bridge.account()
                if not saved:
                    self._problem(401, "OpenAI is not connected. Add the key in Settings.")
                    return
                started = time.monotonic()
                body = to_openai(request, saved["model"])
                if request.get("stream"):
                    body["stream"] = True
                    body["stream_options"] = {"include_usage": True}
                url = f"{bridge.api}/chat/completions"
                status, reply = ask_openai(url, saved["key"], body)
                if status == 400 and "reasoning" in json.dumps(reply):  # this model has no such setting
                    body.pop("reasoning_effort")
                    status, reply = ask_openai(url, saved["key"], body)
                if status != 200:
                    reason = str(reply.get("error", {}).get("message", "")) or "no reason given"
                    # Only temporary problems may be retried. Anything else must reach the owner at once.
                    code = status if status in (408, 429, 503) and "quota" not in reason else 400
                    print(f"OpenAI refused ({status}): {redact(reason)[:300]}", file=sys.stderr, flush=True)
                    self._problem(code, redact(f"OpenAI refused ({status}): {reason}"[:500]))
                    return
                if request.get("stream"):
                    with reply:
                        used = self._stream(reply, started)
                else:
                    used = reply.get("usage", {})
                    self._send(200, json.dumps(to_anthropic(reply)).encode())
                try:
                    bridge.on_usage(saved["model"], int(used.get("prompt_tokens") or 0), int(used.get("completion_tokens") or 0))
                except Exception:
                    pass
                print(
                    f"OpenAI: {time.monotonic() - started:.1f} s, {used.get('prompt_tokens', 0)} in, "
                    f"{used.get('completion_tokens', 0)} out", file=sys.stderr, flush=True,
                )

            def _event(self, name: str, data: dict[str, Any]) -> None:
                self.wfile.write(f"event: {name}\ndata: {json.dumps(data)}\n\n".encode())
                self.wfile.flush()

            def _stream(self, response: Any, started: float) -> dict[str, Any]:
                """Pass words on as they arrive. A tool request is sent whole, once it is complete."""
                self.close_connection = True
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Connection", "close")
                self.end_headers()
                begin = {
                    "id": f"msg_{uuid.uuid4().hex}", "type": "message", "role": "assistant", "model": MODEL_LABEL, "content": [],
                    "stop_reason": None, "stop_sequence": None, "usage": {"input_tokens": 0, "output_tokens": 0},
                }
                self._event("message_start", {"type": "message_start", "message": begin})
                calls: dict[int, dict[str, str]] = {}
                usage: dict[str, Any] = {}
                writing = False
                index = 0
                ended = "end_turn"
                for part in read_stream(response):
                    usage = part.get("usage") or usage
                    for choice in part.get("choices") or []:
                        delta = choice.get("delta") or {}
                        if choice.get("finish_reason") == "length":
                            ended = "max_tokens"
                        if delta.get("content"):
                            if not writing:
                                writing = True
                                print(f"OpenAI first words: {time.monotonic() - started:.1f} s", file=sys.stderr, flush=True)
                                self._event("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}})
                            self._event("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": delta["content"]}})
                        for call in delta.get("tool_calls") or []:
                            item = calls.setdefault(call.get("index", 0), {"id": "", "name": "", "arguments": ""})
                            item["id"] = call.get("id") or item["id"]
                            function = call.get("function") or {}
                            item["name"] += function.get("name") or ""
                            item["arguments"] += function.get("arguments") or ""
                if writing:
                    self._event("content_block_stop", {"type": "content_block_stop", "index": 0})
                    index = 1
                for call in calls.values():
                    self._event("content_block_start", {"type": "content_block_start", "index": index, "content_block": {"type": "tool_use", "id": call["id"], "name": call["name"], "input": {}}})
                    self._event("content_block_delta", {"type": "content_block_delta", "index": index, "delta": {"type": "input_json_delta", "partial_json": call["arguments"] or "{}"}})
                    self._event("content_block_stop", {"type": "content_block_stop", "index": index})
                    index += 1
                self._event("message_delta", {
                    "type": "message_delta", "delta": {"stop_reason": "tool_use" if calls else ended, "stop_sequence": None},
                    "usage": {"output_tokens": usage.get("completion_tokens", 0)},
                })
                self._event("message_stop", {"type": "message_stop"})
                return usage

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.url = f"http://127.0.0.1:{self.server.server_port}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self) -> None:
        self.server.shutdown()
        self.server.server_close()
