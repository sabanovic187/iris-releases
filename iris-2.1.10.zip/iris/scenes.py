"""Scenes: one sentence ("Goodnight", "Film") sets music, lights, quiet mode and IRIS herself.

Scenes are the owner's own, kept in data\\scenes.json. IRIS ships four to start with. Lights go
through Home Assistant, which also reaches Tuya/Smart Life, Hue, WiZ and Govee lights. Locks,
alarms, doors and cameras can never be part of a scene.
"""
from __future__ import annotations

import json
import re
import threading
from pathlib import Path
from typing import Any

from iris.connectors.home import FORBIDDEN

DEFAULT_SCENES: dict[str, dict[str, Any]] = {
    "focus": {
        "label": "Focus",
        "steps": [
            {"do": "quiet", "on": True},
            {"do": "lights", "state": "on", "brightness": 85, "kelvin": 5000},
            {"do": "music", "action": "play", "query": "deep focus instrumental"},
            {"do": "volume", "level": 30},
        ],
    },
    "film": {
        "label": "Film",
        "steps": [
            {"do": "quiet", "on": True},
            {"do": "music", "action": "pause"},
            {"do": "lights", "state": "on", "brightness": 12, "kelvin": 2700},
        ],
    },
    "goodnight": {
        "label": "Goodnight",
        "steps": [
            {"do": "music", "action": "pause"},
            {"do": "say", "text": "Good night."},
            {"do": "lights", "state": "off"},
            {"do": "quiet", "on": True},
        ],
    },
    "morning": {
        "label": "Morning",
        "steps": [
            {"do": "quiet", "on": False},
            {"do": "lights", "state": "on", "brightness": 100, "kelvin": 4000},
            {"do": "overview"},
        ],
    },
}
KINDS = {"quiet", "music", "volume", "lights", "say", "overview"}
MUSIC_ACTIONS = {"play", "pause", "resume"}
LIGHT_ENTITY = re.compile(r"(light|switch)\.[a-z0-9_]+")
NAME = re.compile(r"[a-z][a-z0-9_]{1,30}")
MAX_SCENES = 20
MAX_STEPS = 12


class SceneError(ValueError):
    pass


def check_step(step: Any) -> dict[str, Any]:
    if not isinstance(step, dict) or step.get("do") not in KINDS:
        raise SceneError(f"A step must be one of: {', '.join(sorted(KINDS))}.")
    kind = step["do"]
    if kind == "quiet":
        return {"do": kind, "on": bool(step.get("on", True))}
    if kind == "music":
        action = str(step.get("action", "play"))
        if action not in MUSIC_ACTIONS:
            raise SceneError("Music can play, pause or resume.")
        query = " ".join(str(step.get("query", "")).split())[:120]
        if action == "play" and not query:
            raise SceneError("Say what music to play.")
        return {"do": kind, "action": action, **({"query": query} if action == "play" else {})}
    if kind == "volume":
        return {"do": kind, "level": max(0, min(100, int(step.get("level", 40))))}
    if kind == "lights":
        state = "off" if str(step.get("state", "on")) == "off" else "on"
        clean: dict[str, Any] = {"do": kind, "state": state}
        if state == "on":
            if "brightness" in step:
                clean["brightness"] = max(1, min(100, int(step["brightness"])))
            if "kelvin" in step:
                clean["kelvin"] = max(2000, min(6500, int(step["kelvin"])))
        entities = [str(item) for item in step.get("lights", [])][:30]
        for entity in entities:
            if not LIGHT_ENTITY.fullmatch(entity) or FORBIDDEN.search(entity):
                raise SceneError(f"{entity} cannot be part of a scene.")
        if entities:
            clean["lights"] = entities
        return clean
    if kind == "say":
        text = " ".join(str(step.get("text", "")).split())[:200]
        if not text:
            raise SceneError("Say what IRIS should say.")
        return {"do": kind, "text": text}
    return {"do": kind}


class Scenes:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.Lock()

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("scenes"), dict):
                return data
        except (OSError, ValueError):
            pass
        return {"scenes": json.loads(json.dumps(DEFAULT_SCENES)), "lights": []}

    def _save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def all(self) -> dict[str, dict[str, Any]]:
        return self._load()["scenes"]

    def lights(self) -> list[str]:
        return list(self._load().get("lights", []))

    def listing(self) -> list[dict[str, Any]]:
        return [{"name": name, "label": scene["label"], "steps": scene["steps"]} for name, scene in self.all().items()]

    def get(self, name: str) -> dict[str, Any] | None:
        return self.all().get(name)

    def save(self, name: str, label: str, steps: list[Any]) -> dict[str, Any]:
        name = name.strip().lower().replace(" ", "_")
        if not NAME.fullmatch(name):
            raise SceneError("Use a short name of letters, like focus or reading.")
        if not steps or len(steps) > MAX_STEPS:
            raise SceneError(f"A scene has 1 to {MAX_STEPS} steps.")
        scene = {"label": " ".join(label.split())[:30] or name.title(), "steps": [check_step(step) for step in steps]}
        with self.lock:
            data = self._load()
            if name not in data["scenes"] and len(data["scenes"]) >= MAX_SCENES:
                raise SceneError("There are too many scenes. Remove one first.")
            data["scenes"][name] = scene
            self._save(data)
        return scene

    def remove(self, name: str) -> bool:
        with self.lock:
            data = self._load()
            if data["scenes"].pop(name, None) is None:
                return False
            self._save(data)
            return True

    def set_lights(self, entities: list[str]) -> list[str]:
        clean = []
        for entity in entities:
            entity = entity.strip()
            if not entity:
                continue
            if not LIGHT_ENTITY.fullmatch(entity) or FORBIDDEN.search(entity):
                raise SceneError(f"{entity} cannot be a scene light.")
            clean.append(entity)
        with self.lock:
            data = self._load()
            data["lights"] = clean[:30]
            self._save(data)
        return clean

    def match(self, line: str) -> str | None:
        """The scene a short sentence asks for: "goodnight", "film mode", "start the focus scene"."""
        text = re.sub(r"[^a-z ]", "", line.lower().replace("good night", "goodnight")).strip()
        text = re.sub(r"^(hey )?(iris )?(please )?(start |set |turn on |activate |go to )?(the )?", "", text)
        while True:
            shorter = re.sub(r" ?\b(scene|mode|time|please|now)$", "", text).strip()
            if shorter == text:
                break
            text = shorter
        for name, scene in self.all().items():
            if text in (name.replace("_", " "), scene["label"].lower()):
                return name
        return None
