"""Tells the owner about things without being asked. Uses no AI model."""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, time as clock_time, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from iris.connectors.base import ConnectorError

SOON = timedelta(minutes=30)
MAX_SEEN = 500
DEFAULTS = {"remind_minutes": 10, "quiet_from": "23:00", "quiet_to": "07:00", "overview_from": "05:00"}


@dataclass(frozen=True)
class Notice:
    text: str
    urgent: bool  # urgent notices still come through in quiet mode


def add_alert(path: Path, kind: str, source: str, message: str) -> None:
    entry = {"time": datetime.now(timezone.utc).isoformat(), "kind": kind, "check": source, "message": message}
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


def parse_clock(text: str, fallback: str) -> clock_time:
    try:
        hour, minute = (int(part) for part in str(text).split(":", 1))
        return clock_time(hour, minute)
    except (ValueError, TypeError):
        hour, minute = (int(part) for part in fallback.split(":", 1))
        return clock_time(hour, minute)


def in_quiet_hours(now: clock_time, start: clock_time, end: clock_time) -> bool:
    """Quiet hours may run past midnight, such as 23:00 to 07:00."""
    if start == end:
        return False
    if start < end:
        return start <= now < end
    return now >= start or now < end


def greeting(hour: int) -> str:
    if hour < 12:
        return "Good morning"
    if hour < 18:
        return "Good afternoon"
    return "Good evening"


def overview_text(address: str, hour: int, weather: str, events: list[tuple[str, str]], mail: int | None) -> str:
    """A short spoken overview of the day. Events are (local time, title) still ahead today."""
    parts = [f"{greeting(hour)}, {address}."]
    if weather:
        parts.append(weather)
    if events:
        first_time, first_title = events[0]
        if len(events) == 1:
            parts.append(f"You have one more event today: {first_title} at {first_time}.")
        else:
            parts.append(f"You have {len(events)} more events today. The first is {first_title} at {first_time}.")
    elif events is not None and mail is not None:
        parts.append("Nothing else is in your calendar today.")
    if mail:
        parts.append(f"{mail} important unread {'email' if mail == 1 else 'emails'}.")
    return " ".join(parts)


class Proactive:
    def __init__(
        self,
        google: Any,
        seen_path: Path,
        alerts_path: Path,
        clock: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
        remind: timedelta = SOON,
    ) -> None:
        self.google = google
        self.seen_path = seen_path
        self.alerts_path = alerts_path
        self.clock = clock
        self.remind = remind
        self.first_mail_check = True

    def _seen(self) -> list[str]:
        return json.loads(self.seen_path.read_text(encoding="utf-8")) if self.seen_path.exists() else []

    def _events(self, seen: list[str]) -> list[str]:
        messages = []
        for item in self.google.upcoming(1, 10):
            if "T" not in item["start"]:
                continue
            start = datetime.fromisoformat(item["start"].replace("Z", "+00:00"))
            key = f"event {item['title']} {item['start']}"
            if timedelta(0) <= start - self.clock() <= self.remind and key not in seen:
                seen.append(key)
                minutes = max(1, round((start - self.clock()).total_seconds() / 60))
                messages.append(f"In {minutes} minutes: {item['title']}")
        return messages

    def _mail(self, seen: list[str]) -> list[str]:
        messages = []
        for item in self.google.important_mail():
            key = f"mail {item['id']}"
            if key not in seen:
                seen.append(key)
                if not self.first_check_of_inbox():
                    messages.append(f"Important mail from {item['from']}: {item['subject']}")
        return messages

    def first_check_of_inbox(self) -> bool:
        return self.first_mail_check and not self.seen_path.exists()

    def check_all(self) -> list[Notice]:
        """Return new notices and record them as alerts. Old mail never causes a burst."""
        if not self.google.status()["connected"]:
            return []
        seen = self._seen()
        try:
            notices = [Notice(text, True) for text in self._events(seen)]
            notices += [Notice(text, False) for text in self._mail(seen)]
        except ConnectorError:
            return []
        self.first_mail_check = False
        self.seen_path.parent.mkdir(parents=True, exist_ok=True)
        self.seen_path.write_text(json.dumps(seen[-MAX_SEEN:], ensure_ascii=False), encoding="utf-8")
        for notice in notices:
            add_alert(self.alerts_path, "notice", "proactive", notice.text)
        return notices

    def check(self) -> list[str]:
        return [notice.text for notice in self.check_all()]

    def today(self) -> tuple[list[tuple[str, str]] | None, int | None]:
        """Events still ahead today (local time, title) and the count of important unread mail.
        None means Google is not connected or did not answer."""
        if not self.google.status()["connected"]:
            return None, None
        try:
            now = self.clock().astimezone()
            events = []
            for item in self.google.upcoming(1, 20):
                if "T" not in item["start"]:
                    continue
                start = datetime.fromisoformat(item["start"].replace("Z", "+00:00")).astimezone(now.tzinfo)
                if start.date() == now.date() and start >= now:
                    events.append((start.strftime("%H:%M"), item["title"]))
            mail = len(self.google.important_mail())
        except ConnectorError:
            return None, None
        return events, mail
