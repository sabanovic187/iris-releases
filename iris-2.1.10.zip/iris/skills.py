"""Written procedures in the skills folder. IRIS can read them but not change them."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from iris.connectors.base import READ, ConnectorError, Tool, require_text


class Skills:
    def __init__(self, folder: Path) -> None:
        self.folder = folder

    def names(self) -> list[str]:
        return sorted(path.stem for path in self.folder.glob("*.md")) if self.folder.is_dir() else []

    def _list(self, _args: dict[str, Any]) -> str:
        lines = []
        for name in self.names():
            text = (self.folder / f"{name}.md").read_text(encoding="utf-8").splitlines()
            use = next((line for line in text if line and not line.startswith("#")), "")
            lines.append(f"{name}: {use}")
        return "\n".join(lines) or "No skills yet."

    def _read(self, args: dict[str, Any]) -> str:
        name = require_text(args, "name", 100)
        if name not in self.names():
            raise ConnectorError("There is no skill with that name.")
        return (self.folder / f"{name}.md").read_text(encoding="utf-8")

    def tools(self) -> list[Tool]:
        return [
            Tool("skill_list", "List written procedures the owner has saved.", {}, READ, self._list),
            Tool("skill_read", "Read one saved procedure.", {"name": str}, READ, self._read),
        ]
