"""Estimated spending for brains that do not report a price: OpenAI and Unbound.

Both report tokens with every reply. IRIS multiplies them by list prices in US dollars per million
tokens (input, output). Prices change, so the owner can override or add them in config\\settings.toml:

    [prices]
    "gpt-6.1-sol" = [2.0, 10.0]
"""
from __future__ import annotations

from typing import Any

# Checked 2026-11-18: abliteration.ai/pricing and the Standard table on OpenAI's pricing page.
PRICES: dict[str, tuple[float, float]] = {
    "abliterated-model": (1.0, 3.0),
    "abliterated-model-large-flash": (1.0, 2.0),
    "abliterated-model-large-v2": (3.0, 5.0),
    "abliterated-model-large": (3.0, 5.0),
    "gpt-6.2-sol": (2.0, 10.0),
    "gpt-6.1-sol": (2.0, 10.0),
    "gpt-6.2-astra": (8.0, 40.0),
    "gpt-6-astra": (10.0, 50.0),
}


def price_table(overrides: dict[str, Any] | None = None) -> dict[str, tuple[float, float]]:
    table = dict(PRICES)
    for model, pair in (overrides or {}).items():
        try:
            table[str(model)] = (float(pair[0]), float(pair[1]))
        except (TypeError, ValueError, IndexError):
            continue
    return table


def estimate(model: str, input_tokens: int, output_tokens: int, table: dict[str, tuple[float, float]]) -> float | None:
    """US dollars, or None when the model's price is not known."""
    price = table.get(model)
    if not price:
        return None
    return (input_tokens * price[0] + output_tokens * price[1]) / 1_000_000
