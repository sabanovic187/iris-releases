"""Global emergency stop hotkey: Ctrl+Alt+Shift+X. Test with python -m iris.hotkey"""
from __future__ import annotations

import ctypes
import sys
import threading
import time
from typing import Callable

MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_NOREPEAT = 0x4000
VK_X = 0x58
WM_HOTKEY = 0x0312
HOTKEY_NAME = "Ctrl+Alt+Shift+X"


def start_stop_hotkey(on_press: Callable[[], None]) -> threading.Event:
    """Listen in the background. The returned event is set when registration has finished."""
    ready = threading.Event()
    state = {"registered": False}

    def watch() -> None:
        user32 = ctypes.windll.user32
        modifiers = MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT
        state["registered"] = bool(user32.RegisterHotKey(None, 1, modifiers, VK_X))
        ready.registered = state["registered"]  # type: ignore[attr-defined]
        ready.set()
        if not state["registered"]:
            return
        message = ctypes.wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
            if message.message == WM_HOTKEY:
                on_press()

    if sys.platform != "win32":
        ready.registered = False  # type: ignore[attr-defined]
        ready.set()
        return ready
    import ctypes.wintypes  # noqa: F401

    threading.Thread(target=watch, daemon=True).start()
    ready.wait(3)
    return ready


def main() -> int:
    pressed = threading.Event()
    ready = start_stop_hotkey(pressed.set)
    if not getattr(ready, "registered", False):
        print("HOTKEY TEST FAILED: Windows did not accept the shortcut.")
        return 1
    print(f"Press {HOTKEY_NAME} within 20 seconds. This test stops nothing.")
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        if pressed.wait(0.2):
            print("HOTKEY TEST PASSED")
            return 0
    print("HOTKEY TEST FAILED: the shortcut was not received.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
