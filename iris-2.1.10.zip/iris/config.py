"""Settings and secrets."""
from __future__ import annotations

import os
import re
import sqlite3
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
LOCAL_HOSTS = {"127.0.0.1", "localhost"}
RESERVED_SERVERS = {"iris", "windows", "connectors"}


@dataclass(frozen=True)
class Settings:
    root: Path
    data_dir: Path
    workspace: Path
    address: str
    model: str
    max_turns: int
    max_usd_per_message: float
    max_usd_per_month: float
    max_usd_per_task: float
    max_turns_per_task: int
    level: int
    api_key: str | None
    windows_enabled: bool
    allowed_apps: tuple[str, ...]
    brain: str = "claude"
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "iris-local"
    mcp_servers: tuple[dict[str, Any], ...] = ()
    bridge_url: str = ""
    bridge_token: str = ""
    fresh_after_hours: float = 3.0
    smart_model: str = "claude-sonnet-5-5"
    worldmonitor_port: int = 3000
    tablet_enabled: bool = False
    tablet_port: int = 8770
    pod_enabled: bool = True
    pod_port: int = 8772

    @property
    def local_brain(self) -> bool:
        return self.brain == "local"

    @property
    def openai_brain(self) -> bool:
        return self.brain == "openai"

    @property
    def brain_ready(self) -> bool:
        if self.openai_brain:
            return bool(self.bridge_url)
        return self.local_brain or bool(self.api_key)


def read_env_key(path: Path) -> str | None:
    """Return ANTHROPIC_API_KEY from a .env file, or from the environment."""
    if path.exists():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            name, sep, value = line.strip().partition("=")
            if sep and name.strip() == "ANTHROPIC_API_KEY":
                value = value.strip().strip("'\"")
                if value:
                    return value
    return os.environ.get("ANTHROPIC_API_KEY") or None


def check_local_model(url: str, model: str) -> None:
    """The local brain must stay on this computer, so remote and cloud models are refused."""
    if urlsplit(url).hostname not in LOCAL_HOSTS:
        raise ValueError("ollama.url must point to this computer")
    if "cloud" in model.lower():
        raise ValueError("ollama.model must be a local model")


def check_mcp_servers(servers: list[dict[str, Any]]) -> tuple[dict[str, Any], ...]:
    """Extra tool servers come only from this file, never from the screen or from IRIS."""
    for server in servers:
        name = str(server.get("name", ""))
        if not re.fullmatch(r"[a-z0-9_]+", name) or name in RESERVED_SERVERS:
            raise ValueError(f"bad MCP server name: {name!r}")
        if not server.get("command"):
            raise ValueError(f"MCP server {name} needs a command")
    return tuple(servers)


def saved_brain(data_dir: Path) -> str:
    """Every way of starting IRIS uses the brain chosen on the screen."""
    path = data_dir / "iris.db"
    if not path.exists():
        return "claude"
    try:
        connection = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
        try:
            row = connection.execute("SELECT value FROM state WHERE key = 'brain'").fetchone()
        finally:
            connection.close()
    except sqlite3.Error:
        return "local"  # if the choice cannot be read, keep data on this computer
    return row[0] if row and row[0] in ("claude", "local") else "claude"


# What IRIS used before owner settings moved to data\settings.toml. Computers that already
# ran IRIS keep these; a new install asks its owner instead.
LEGACY_OWNER: dict[str, dict[str, Any]] = {
    "identity": {"address_owner_as": "sir"},
    "situation": {"place": "Sarajevo", "lat": 43.856, "lon": 18.413},
}


def owner_file(root: Path = ROOT) -> Path:
    """The owner's own settings. They stay in data, so they never travel with IRIS."""
    return root / "data" / "settings.toml"


def _merge(base: dict[str, Any], extra: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in extra.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, str):
        return '"' + value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ") + '"'
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_toml_value(item) for item in value) + "]"
    raise TypeError(f"cannot save {type(value).__name__} in settings")


def read_owner(root: Path = ROOT) -> dict[str, Any]:
    path = owner_file(root)
    if not path.exists():
        return {}
    try:
        with path.open("rb") as handle:
            return tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError):
        return {}


def write_owner(root: Path, owner: dict[str, Any]) -> None:
    lines = ["# Your own IRIS settings. They stay on this computer and are never part of IRIS itself.", ""]
    for section, values in owner.items():
        lines.append(f"[{section}]")
        lines.extend(f"{key} = {_toml_value(value)}" for key, value in values.items())
        lines.append("")
    path = owner_file(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def save_owner(root: Path, section: str, values: dict[str, Any]) -> None:
    owner = read_owner(root)
    owner[section] = {**owner.get(section, {}), **values}
    write_owner(root, owner)


def read_raw(root: Path = ROOT) -> dict[str, Any]:
    """IRIS's own settings with the owner's on top."""
    with (root / "config" / "settings.toml").open("rb") as handle:
        product = tomllib.load(handle)
    return _merge(product, read_owner(root))


def setup_needed(root: Path = ROOT) -> bool:
    owner = read_owner(root)
    return not owner.get("identity", {}).get("address_owner_as") or not owner.get("situation", {}).get("place")


def save_api_key(root: Path, key: str) -> None:
    """Writes the Claude key into .env on this computer, keeping the file's other lines."""
    path = root / ".env"
    lines = path.read_text(encoding="utf-8-sig").splitlines() if path.exists() else []
    lines = [line for line in lines if line.strip().partition("=")[0].strip() != "ANTHROPIC_API_KEY"]
    lines.append(f"ANTHROPIC_API_KEY={key}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def prepare_owner(root: Path = ROOT) -> None:
    """Runs before IRIS opens her memory. A computer that already used IRIS keeps what it had;
    a new one gets an empty owner file, so IRIS asks its owner on first start."""
    if not owner_file(root).exists():
        used_before = (root / "data" / "iris.db").exists()
        write_owner(root, LEGACY_OWNER if used_before else {})


def load_settings(root: Path = ROOT) -> Settings:
    prepare_owner(root)
    raw = read_raw(root)
    level = int(raw["permissions"]["level"])
    if level not in (1, 3):
        raise ValueError("permissions.level must be 1 or 3")
    ollama = raw.get("ollama", {})
    ollama_url = str(ollama.get("url", "http://127.0.0.1:11434"))
    ollama_model = str(ollama.get("model", "iris-local"))
    check_local_model(ollama_url, ollama_model)
    data_dir = root / "data"
    workspace = (root / raw["permissions"]["workspace"]).resolve()
    data_dir.mkdir(exist_ok=True)
    workspace.mkdir(exist_ok=True)
    return Settings(
        root=root,
        data_dir=data_dir,
        workspace=workspace,
        address=str(raw.get("identity", {}).get("address_owner_as", "")),
        model=raw["model"]["name"],
        smart_model=str(raw["model"].get("smart", raw["model"]["name"])),
        max_turns=int(raw["limits"]["max_turns"]),
        max_usd_per_message=float(raw["limits"]["max_usd_per_message"]),
        max_usd_per_month=float(raw["limits"]["max_usd_per_month"]),
        max_usd_per_task=float(raw["limits"]["max_usd_per_task"]),
        max_turns_per_task=int(raw["limits"]["max_turns_per_task"]),
        level=level,
        api_key=read_env_key(root / ".env"),
        windows_enabled=bool(raw["windows"]["enabled"]),
        allowed_apps=tuple(raw["windows"]["allowed_apps"]),
        brain=saved_brain(data_dir),
        ollama_url=ollama_url,
        ollama_model=ollama_model,
        mcp_servers=check_mcp_servers(list(raw.get("mcp", []))),
        fresh_after_hours=float(raw["limits"].get("fresh_after_hours", 3.0)),
        worldmonitor_port=int(raw.get("worldmonitor", {}).get("port", 3000)),
        tablet_enabled=bool(raw.get("tablet", {}).get("enabled", True)),
        tablet_port=int(raw.get("tablet", {}).get("port", 8770)),
        pod_enabled=bool(raw.get("pod", {}).get("enabled", True)),
        pod_port=int(raw.get("pod", {}).get("port", 8772)),
    )
