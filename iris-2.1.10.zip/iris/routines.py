"""Work that runs at a set time. Actions inside a routine still need approval."""
from __future__ import annotations

import json
import re
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

SAFE_COMMANDS = {"/today", "/briefing", "/system", "/digest"}
MAX_ROUTINES = 30
LATE_MINUTES = 30


class RoutineError(ValueError):
    """A problem to show the owner."""


class Routines:
    def __init__(self, path: Path) -> None:
        self.path = path

    def items(self) -> list[dict[str, Any]]:
        return json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else []

    def _save(self, items: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")

    def add(self, name: str, time: str, days: list[int], request: str) -> dict[str, Any]:
        name, request = name.strip(), request.strip()
        if not name or len(name) > 80:
            raise RoutineError("Give the routine a short name.")
        if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", time):
            raise RoutineError("Use a time like 08:30.")
        if not days or any(day not in range(7) for day in days):
            raise RoutineError("Choose at least one day.")
        if not request or len(request) > 4000:
            raise RoutineError("Write what IRIS should do.")
        if request.startswith("/") and request not in SAFE_COMMANDS:
            raise RoutineError("A routine can only use /today, /briefing, /digest or /system.")
        items = self.items()
        if len(items) >= MAX_ROUTINES:
            raise RoutineError("Too many routines. Remove one first.")
        item = {"id": uuid.uuid4().hex, "name": name, "time": time, "days": sorted(set(days)), "request": request, "last": ""}
        self._save(items + [item])
        return item

    def remove(self, routine_id: str) -> None:
        self._save([item for item in self.items() if item["id"] != routine_id])

    def due(self, now: datetime) -> list[dict[str, Any]]:
        """Return routines to run now and mark them done for today."""
        items = self.items()
        today = now.date().isoformat()
        ready = []
        for item in items:
            hour, minute = map(int, item["time"].split(":"))
            planned = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            waited = (now - planned).total_seconds() / 60
            if now.weekday() in item["days"] and item["last"] != today and 0 <= waited <= LATE_MINUTES:
                item["last"] = today
                ready.append(item)
        if ready:
            self._save(items)
        return ready
