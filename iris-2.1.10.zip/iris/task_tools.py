"""Lets IRIS start and check development tasks. There is deliberately no merge tool."""
from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

from claude_agent_sdk import create_sdk_mcp_server, tool

from iris.projects import ProjectError, TaskManager

MAX_SPOKEN_SUMMARY = 300


def first_line(text: str) -> str:
    return text.splitlines()[0][:MAX_SPOKEN_SUMMARY] if text else "The task ended without a report."


class BackgroundTasks:
    """Runs one task at a time and announces how it ended."""

    def __init__(self, tasks: TaskManager, announce: Callable[[str], None]) -> None:
        self.tasks = tasks
        self.announce = announce
        self.current: asyncio.Task[None] | None = None

    @property
    def busy(self) -> bool:
        return self.current is not None and not self.current.done()

    def launch(self, work: Callable[[], Awaitable[str]]) -> str:
        if self.busy:
            return "Another task is running. Wait for it to finish."

        async def run() -> None:
            try:
                self.announce(first_line(await work()))
            except ProjectError as error:
                self.announce(f"The task could not run: {error}")
            except Exception as error:
                self.announce(f"The task stopped with an error: {type(error).__name__}.")

        self.current = asyncio.create_task(run())
        return "Task started in the background. I will report when it ends."


def _text(value: str) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": value}]}


def build_task_server(tasks: TaskManager, runner: BackgroundTasks, extra: list[Any] | None = None) -> dict[str, Any]:
    @tool("list_projects", "List registered projects.", {})
    async def list_projects(_args: dict[str, Any]) -> dict[str, Any]:
        return _text(tasks.list_projects())

    @tool("list_tasks", "List recent development tasks.", {})
    async def list_tasks(_args: dict[str, Any]) -> dict[str, Any]:
        return _text(tasks.list_tasks())

    @tool("review_task", "Show a task's changes and test result.", {"task_id": int})
    async def review_task(args: dict[str, Any]) -> dict[str, Any]:
        try:
            return _text(tasks.review(int(args["task_id"])))
        except ProjectError as error:
            return _text(str(error))

    @tool("start_task", "Start a development task on its own branch.", {"project": str, "goal": str})
    async def start_task(args: dict[str, Any]) -> dict[str, Any]:
        return _text(runner.launch(lambda: tasks.start_task(args["project"], args["goal"])))

    @tool("continue_task", "Continue a project's latest open task.", {"project": str, "note": str})
    async def continue_task(args: dict[str, Any]) -> dict[str, Any]:
        return _text(runner.launch(lambda: tasks.continue_task(args["project"], args.get("note", ""))))

    server = create_sdk_mcp_server(
        "iris", tools=[list_projects, list_tasks, review_task, start_task, continue_task, *(extra or [])]
    )
    return {"iris": server}
