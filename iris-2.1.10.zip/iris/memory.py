"""Local SQLite store for facts, the conversation journal, decisions and spending.

The journal keeps every conversation word for word on this computer, with a full-text index,
so IRIS can find what was said or decided weeks ago. Unbound is never written here.
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from iris.audit import redact

SCHEMA = """
CREATE TABLE IF NOT EXISTS facts(
    id INTEGER PRIMARY KEY, text TEXT NOT NULL, created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS messages(
    id INTEGER PRIMARY KEY, role TEXT NOT NULL, text TEXT NOT NULL, created TEXT NOT NULL,
    brain TEXT NOT NULL DEFAULT 'claude');
CREATE TABLE IF NOT EXISTS spending(
    id INTEGER PRIMARY KEY, month TEXT NOT NULL, usd REAL NOT NULL);
CREATE TABLE IF NOT EXISTS usage(
    id INTEGER PRIMARY KEY, month TEXT NOT NULL, provider TEXT NOT NULL, model TEXT NOT NULL,
    input INTEGER NOT NULL, output INTEGER NOT NULL, usd REAL);
CREATE TABLE IF NOT EXISTS decisions(
    id INTEGER PRIMARY KEY, text TEXT NOT NULL, created TEXT NOT NULL, brain TEXT NOT NULL DEFAULT 'claude');
"""
JOURNAL = (
    "CREATE VIRTUAL TABLE IF NOT EXISTS journal USING fts5("
    "text, kind UNINDEXED, created UNINDEXED, brain UNINDEXED, tokenize='unicode61 remove_diacritics 2')"
)
JOURNAL_HITS = 12
WORD = re.compile(r"\w+", re.UNICODE)


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Memory:
    def __init__(self, path: Path) -> None:
        self.db = sqlite3.connect(path)
        self.db.executescript(SCHEMA)
        try:
            self.db.execute(JOURNAL)
            self.journal = True
        except sqlite3.OperationalError:
            self.journal = False  # no full-text search in this SQLite; plain search still works
        self.db.commit()
        if self.journal and not self.get_state("journal_indexed"):
            self._index_past()

    def close(self) -> None:
        self.db.close()

    def remember(self, text: str) -> int:
        cursor = self.db.execute(
            "INSERT INTO facts(text, created) VALUES(?, ?)", (text, _now().isoformat())
        )
        self.db.commit()
        return int(cursor.lastrowid)

    def facts(self) -> list[tuple[int, str]]:
        return list(self.db.execute("SELECT id, text FROM facts ORDER BY id"))

    def add_message(self, role: str, text: str, brain: str = "claude") -> None:
        clean, created = redact(text), _now().isoformat()
        self.db.execute(
            "INSERT INTO messages(role, text, created, brain) VALUES(?, ?, ?, ?)", (role, clean, created, brain),
        )
        self._journal(clean, role, created, brain)
        self.db.commit()

    # The journal

    def _journal(self, text: str, kind: str, created: str, brain: str) -> None:
        if self.journal:
            self.db.execute("INSERT INTO journal(text, kind, created, brain) VALUES(?, ?, ?, ?)", (text, kind, created, brain))

    def _index_past(self) -> None:
        """Conversations from before the journal existed are indexed once."""
        rows = self.db.execute("SELECT role, text, created, brain FROM messages ORDER BY id").fetchall()
        self.db.executemany("INSERT INTO journal(text, kind, created, brain) VALUES(?, ?, ?, ?)",
                            [(row[1], row[0], row[2], row[3]) for row in rows])
        self.set_state("journal_indexed", "1")

    def add_decision(self, text: str, brain: str = "claude") -> None:
        clean, created = redact(text), _now().isoformat()
        self.db.execute("INSERT INTO decisions(text, created, brain) VALUES(?, ?, ?)", (clean, created, brain))
        self._journal(clean, "decision", created, brain)
        self.db.commit()

    def decisions(self, limit: int = 50) -> list[tuple[str, str]]:
        rows = self.db.execute("SELECT created, text FROM decisions ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [(row[0], row[1]) for row in rows]

    def journal_search(self, words: str, brain: str = "claude", since: str = "", until: str = "") -> list[str]:
        """The best matches for the words, newest first among equals. Claude never sees local talks."""
        terms = WORD.findall(words.lower())[:12]
        if not terms or not self.journal:
            return self.search(words, brain)
        where = "journal MATCH ? AND (? = 'local' OR brain = 'claude')"
        extra: list[str] = []
        if since:
            where += " AND created >= ?"
            extra.append(since)
        if until:
            where += " AND created < ?"
            extra.append(until + "T99")
        found: list[tuple[str, str, str]] = []
        for joiner in (" ", " OR "):  # every word first, then any of them
            query = joiner.join(f'"{term}"*' for term in terms)
            found = self.db.execute(
                f"SELECT created, kind, snippet(journal, 0, '', '', ' ... ', 24) FROM journal WHERE {where} "
                "ORDER BY bm25(journal), created DESC LIMIT ?",
                (query, brain, *extra, JOURNAL_HITS),
            ).fetchall()
            if found or len(terms) == 1:
                break
        return [f"{row[0][:16].replace('T', ' ')} {row[1]}: {row[2]}" for row in found]

    def journal_day(self, day: str, brain: str = "claude", limit: int = 400) -> list[str]:
        rows = self.db.execute(
            "SELECT created, role, text FROM messages WHERE created LIKE ? AND (? = 'local' OR brain = 'claude') "
            "ORDER BY id LIMIT ?",
            (f"{day}%", brain, limit),
        ).fetchall()
        decided = self.db.execute(
            "SELECT created, text FROM decisions WHERE created LIKE ? AND (? = 'local' OR brain = 'claude') ORDER BY id",
            (f"{day}%", brain),
        ).fetchall()
        lines = [f"{row[0][11:16]} {row[1]}: {row[2]}" for row in rows]
        return lines + [f"{row[0][11:16]} decision: {row[1]}" for row in decided]

    def recent_messages(self, limit: int = 50) -> list[tuple[str, str, str]]:
        rows = self.db.execute(
            "SELECT role, text, created FROM messages ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [(row[0], row[1], row[2]) for row in reversed(rows)]

    @staticmethod
    def _pattern(text: str) -> str:
        escaped = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        return f"%{escaped}%"

    def search(self, text: str, brain: str = "local", limit: int = 20) -> list[str]:
        """Find saved facts and past conversation. Claude cannot see local conversations."""
        pattern = self._pattern(text)
        facts = self.db.execute(
            "SELECT text FROM facts WHERE text LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT ?", (pattern, limit)
        ).fetchall()
        talks = self.db.execute(
            "SELECT created, role, text FROM messages WHERE text LIKE ? ESCAPE '\\' "
            "AND (? = 'local' OR brain = 'claude') ORDER BY id DESC LIMIT ?",
            (pattern, brain, limit),
        ).fetchall()
        return [f"Fact: {row[0]}" for row in facts] + [f"{row[0][:10]} {row[1]}: {row[2][:400]}" for row in talks]

    def forget(self, fact_id: int) -> bool:
        cursor = self.db.execute("DELETE FROM facts WHERE id = ?", (fact_id,))
        self.db.commit()
        return cursor.rowcount > 0

    def get_state(self, key: str) -> str | None:
        row = self.db.execute("SELECT value FROM state WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_state(self, key: str, value: str | None) -> None:
        if value is None:
            self.db.execute("DELETE FROM state WHERE key = ?", (key,))
        else:
            self.db.execute(
                "INSERT INTO state(key, value) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value),
            )
        self.db.commit()

    def add_spending(self, usd: float) -> None:
        self.db.execute(
            "INSERT INTO spending(month, usd) VALUES(?, ?)", (_now().strftime("%Y-%m"), usd)
        )
        self.db.commit()

    def replace_month_spending(self, month: str, usd: float) -> None:
        self.db.execute("DELETE FROM spending WHERE month = ?", (month,))
        self.db.execute("INSERT INTO spending(month, usd) VALUES(?, ?)", (month, usd))
        self.db.commit()

    def add_usage(self, provider: str, model: str, input_tokens: int, output_tokens: int, usd: float | None) -> None:
        """Tokens used by OpenAI or Unbound. usd is an estimate, or None when the price is unknown."""
        self.db.execute(
            "INSERT INTO usage(month, provider, model, input, output, usd) VALUES(?, ?, ?, ?, ?, ?)",
            (_now().strftime("%Y-%m"), provider, model, int(input_tokens), int(output_tokens), usd),
        )
        self.db.commit()

    def month_usage(self, provider: str) -> dict[str, float | int]:
        row = self.db.execute(
            "SELECT COALESCE(SUM(input), 0), COALESCE(SUM(output), 0), COALESCE(SUM(usd), 0), "
            "COALESCE(SUM(CASE WHEN usd IS NULL THEN input + output ELSE 0 END), 0) "
            "FROM usage WHERE month = ? AND provider = ?",
            (_now().strftime("%Y-%m"), provider),
        ).fetchone()
        return {"input": int(row[0]), "output": int(row[1]), "usd": float(row[2]), "unpriced": int(row[3])}

    def month_spending(self) -> float:
        row = self.db.execute(
            "SELECT COALESCE(SUM(usd), 0) FROM spending WHERE month = ?",
            (_now().strftime("%Y-%m"),),
        ).fetchone()
        return float(row[0])
