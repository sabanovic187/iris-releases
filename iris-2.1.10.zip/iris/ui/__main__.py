"""Command Center: python -m iris.ui"""
from __future__ import annotations

import argparse
import asyncio
import os
import secrets
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Any

from iris.config import load_settings
from iris.connectors.registry import Connectors
from iris.hotkey import HOTKEY_NAME, start_stop_hotkey
from iris.memory import Memory
from iris.stop import EmergencyStop
from iris.ui.hub import Hub, LiveAudit
from iris.health import Health, Supervisor, Watchdog, record_exception, take_crash_note
from iris.pod.server import PodServer
from iris.ui.wmproxy import WorldMonitorProxy
from iris.ui.server import Server
from iris.ui.voice import VoiceBridge
from iris.ui.voice_options import load_saved

DEFAULT_PORT = 8765
RESTART = 3  # exit code that tells the start script to start IRIS again (after an update)


def find_edge() -> str | None:
    found = shutil.which("msedge")
    if found:
        return found
    for variable in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(variable)
        if base:
            path = Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe"
            if path.exists():
                return str(path)
    return None


def open_window(url: str, profile: Path) -> None:
    """Use an Edge app window. Its separate profile keeps it apart from normal browsing."""
    edge = find_edge() if sys.platform == "win32" else None
    if edge:
        subprocess.Popen([edge, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run"])
    else:
        webbrowser.open(url)


def start_voice(hub: Hub) -> None:
    """IRIS starts ready: replies are spoken and she listens for the wake word, unless turned off."""
    try:
        voice = hub.voice._config()
    except (OSError, KeyError, ValueError):
        return
    chosen = hub.memory.get_state("speak_replies")
    hub.speak_replies = chosen == "1" if chosen in ("0", "1") else bool(voice.get("speak_replies", True))
    if voice.get("start_with_iris", True):
        hub.switch_voice(True)


def session_token(data_dir: Path) -> tuple[str, bool]:
    """After a restart the open window keeps working: the previous token is used once more."""
    kept = data_dir / "restart-token"
    try:
        token = kept.read_text(encoding="utf-8").strip()
        kept.unlink()
        if len(token) >= 32:
            return token, True
    except OSError:
        pass
    return secrets.token_urlsafe(32), False


async def run(port: int, show_window: bool) -> int:
    settings = load_settings()
    stop = EmergencyStop(settings.data_dir)
    audit = LiveAudit(settings.data_dir / "audit" / "audit.jsonl")
    memory = Memory(settings.data_dir / "iris.db")
    hub = Hub(settings, memory, audit, stop, Connectors(settings.data_dir, workspace=settings.workspace))
    hub.voice = VoiceBridge(hub)
    hub.voice.saved = load_saved(memory)
    start_voice(hub)

    ready = start_stop_hotkey(lambda: stop.trigger("hotkey"))
    if getattr(ready, "registered", False):
        print(f"Emergency stop: {HOTKEY_NAME}")
    else:
        print("Warning: the emergency stop shortcut is unavailable. Use the button or scripts\\stop.ps1.")

    token, restarted = session_token(settings.data_dir)
    server = Server(hub, token)
    listener = await server.start(port)
    # Listeners that self-care opens again if they close: name -> (server, opener)
    openers: dict[str, Any] = {}
    if settings.tablet_enabled:
        openers["Tablet"] = lambda: Server(hub, "", panel=True).start(settings.tablet_port)
        if settings.worldmonitor_port > 0 and hub.addons.is_installed("worldmonitor"):
            openers["Tablet World Monitor"] = lambda: WorldMonitorProxy(
                hub.devices.check, settings.worldmonitor_port).start(settings.tablet_port + 1)
    if settings.pod_enabled:
        openers["IRIS Pod"] = lambda: PodServer(hub, hub.pods).start(settings.pod_port)
    listeners: dict[str, Any] = {}
    for name, opener in openers.items():
        try:
            listeners[name] = (await opener(), opener)
        except OSError:
            listeners[name] = (None, opener)
            print(f"Warning: {name} cannot listen; its port is in use. IRIS will try again.", flush=True)
    if settings.tablet_enabled:
        print(f"Tablets: pair them in Settings. Address {hub.tablet_address()}", flush=True)
    if settings.pod_enabled:
        print(f"IRIS Pod: OTA address {hub.pod_address()}", flush=True)
    health = Health(hub, listeners)
    hub.health = health
    supervisor = Supervisor(health.problem)
    watchdog = Watchdog(settings.data_dir)
    supervisor.keep("Ticker", hub.run_ticker)
    supervisor.keep("Background checks", hub.run_background)
    supervisor.keep("Telegram", hub.run_telegram)
    supervisor.keep("Updates", hub.run_update_checks)
    supervisor.keep("Self-care", health.run_forever)
    supervisor.keep("Heartbeat", watchdog.beat)
    hub.supervised = supervisor.tasks
    watchdog.start()
    crash = take_crash_note(settings.data_dir)
    if crash:
        hub.loop.call_later(20, hub.tell_owner, crash)  # once Telegram has had time to start
    opener = settings.data_dir / "open-url.txt"  # lets the desktop icon reopen this window
    opener.write_text(server.open_url, encoding="utf-8")
    print(f"IRIS Command Center: {server.open_url}", flush=True)
    print("Keep this window open. Press Ctrl+C to close IRIS.", flush=True)
    if show_window and not restarted:
        open_window(server.open_url, settings.data_dir / "ui-profile")
    try:
        async with listener:
            serving = asyncio.create_task(listener.serve_forever())
            restart = asyncio.create_task(hub.restart_wanted.wait())
            await asyncio.wait({serving, restart}, return_when=asyncio.FIRST_COMPLETED)
            if hub.restart_wanted.is_set():
                (settings.data_dir / "restart-token").write_text(token, encoding="utf-8")
                print("Restarting IRIS...", flush=True)
                serving.cancel()
                return RESTART
            restart.cancel()
            return 0
    finally:
        opener.unlink(missing_ok=True)
        watchdog.stop()
        for server, _opener in health.listeners.values():
            if server is not None:
                server.close()
        supervisor.cancel()
        await hub.close()
        memory.close()


def main() -> int:
    parser = argparse.ArgumentParser(prog="iris.ui")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--no-window", action="store_true")
    options = parser.parse_args()
    try:
        return asyncio.run(run(options.port, not options.no_window))
    except KeyboardInterrupt:
        pass
    except Exception as error:  # the start script starts IRIS again; she says what happened
        record_exception(load_settings().data_dir, error)
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
