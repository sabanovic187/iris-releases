"""Choices for the voice screen. Saved values override config\\settings.toml."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

STATE_KEY = "voice_options"
LIMITS = {"wake_threshold": (0.2, 0.9), "silence_seconds": (0.4, 2.0), "follow_up_seconds": (0.0, 10.0)}


def load_saved(memory: Any) -> dict[str, Any]:
    raw = memory.get_state(STATE_KEY)
    return json.loads(raw) if raw else {}


def microphones(devices: Any, default_hostapi: int) -> list[str]:
    """Windows lists each microphone once per audio system, so keep the default system."""
    return [
        device["name"]
        for device in devices
        if device.get("max_input_channels", 0) > 0 and device.get("hostapi") == default_hostapi
    ]


def device_index(name: str, devices: Any, default_hostapi: int) -> int | None:
    """Return the device number, or None for the Windows default microphone."""
    for index, device in enumerate(devices):
        if (
            device.get("name") == name
            and device.get("hostapi") == default_hostapi
            and device.get("max_input_channels", 0) > 0
        ):
            return index
    return None


def voices(folder: Path) -> list[str]:
    return sorted(path.stem for path in folder.glob("*.onnx")) if folder.is_dir() else []


def clean_change(data: dict[str, Any], known_mics: list[str], known_voices: list[str]) -> dict[str, Any]:
    """Keep only valid values. Raises ValueError with text for the owner."""
    change: dict[str, Any] = {}
    for name, (low, high) in LIMITS.items():
        if name in data:
            try:
                value = float(data[name])
            except (TypeError, ValueError):
                raise ValueError("That value is not a number.") from None
            if not low <= value <= high:
                raise ValueError("That value is out of range.")
            change[name] = value
    if "microphone" in data:
        name = str(data["microphone"])
        if name and name not in known_mics:
            raise ValueError("That microphone is not available.")
        change["microphone"] = name
    if "voice_name" in data:
        name = str(data["voice_name"])
        if name not in known_voices:
            raise ValueError("That voice is not installed.")
        change["voice_name"] = name
    return change
