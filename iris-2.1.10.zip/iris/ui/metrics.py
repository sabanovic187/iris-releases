"""Real readings from this computer. Anything that cannot be measured is left out."""
from __future__ import annotations

import ctypes
import shutil
import sys
from pathlib import Path
from typing import Any


class _FileTime(ctypes.Structure):
    _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]

    @property
    def value(self) -> int:
        return (self.high << 32) | self.low


class _MemoryStatus(ctypes.Structure):
    _fields_ = [
        ("length", ctypes.c_uint32),
        ("load", ctypes.c_uint32),
        ("total", ctypes.c_uint64),
        ("available", ctypes.c_uint64),
        ("page_total", ctypes.c_uint64),
        ("page_available", ctypes.c_uint64),
        ("virtual_total", ctypes.c_uint64),
        ("virtual_available", ctypes.c_uint64),
        ("extended", ctypes.c_uint64),
    ]


class _PowerStatus(ctypes.Structure):
    _fields_ = [
        ("ac", ctypes.c_uint8),
        ("flags", ctypes.c_uint8),
        ("percent", ctypes.c_uint8),
        ("saver", ctypes.c_uint8),
        ("seconds", ctypes.c_uint32),
        ("full_seconds", ctypes.c_uint32),
    ]


def _cpu_times() -> tuple[int, int] | None:
    """Return (idle, total) counters."""
    if sys.platform == "win32":
        idle, kernel, user = _FileTime(), _FileTime(), _FileTime()
        if not ctypes.windll.kernel32.GetSystemTimes(
            ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)
        ):
            return None
        return idle.value, kernel.value + user.value  # kernel time includes idle time
    fields = Path("/proc/stat").read_text(encoding="ascii").splitlines()[0].split()[1:]
    numbers = [int(item) for item in fields]
    return numbers[3] + numbers[4], sum(numbers[:8])


def _memory_percent() -> float | None:
    if sys.platform == "win32":
        status = _MemoryStatus()
        status.length = ctypes.sizeof(status)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return None
        return float(status.load)
    values = {}
    for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
        name, _, rest = line.partition(":")
        values[name] = int(rest.split()[0])
    return 100 * (1 - values["MemAvailable"] / values["MemTotal"])


def _uptime_seconds() -> int | None:
    if sys.platform == "win32":
        ctypes.windll.kernel32.GetTickCount64.restype = ctypes.c_uint64
        return int(ctypes.windll.kernel32.GetTickCount64() / 1000)
    return int(float(Path("/proc/uptime").read_text(encoding="ascii").split()[0]))


def _battery() -> int | None:
    """Return the charge level, or None on a computer without a battery."""
    if sys.platform != "win32":
        return None
    status = _PowerStatus()
    if not ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
        return None
    no_battery = bool(status.flags & 128) or status.percent == 255
    return None if no_battery else int(status.percent)


class SystemReader:
    def __init__(self, disks: list[str]) -> None:
        self.disks = disks
        self._last_cpu: tuple[int, int] | None = None

    def _cpu_percent(self) -> float | None:
        now = _cpu_times()
        previous, self._last_cpu = self._last_cpu, now
        if now is None or previous is None or now[1] <= previous[1]:
            return None
        busy = 1 - (now[0] - previous[0]) / (now[1] - previous[1])
        return max(0.0, min(100.0, busy * 100))

    def _disks(self) -> list[dict[str, Any]]:
        found = []
        for path in self.disks:
            try:
                usage = shutil.disk_usage(path)
            except OSError:
                continue
            found.append({"path": path, "used_percent": usage.used / usage.total * 100})
        return found

    def read(self) -> dict[str, Any]:
        """Each reading is optional: a failed one is missing, never guessed."""
        readings: dict[str, Any] = {"disks": self._disks()}
        sources = {
            "cpu_percent": self._cpu_percent,
            "memory_percent": _memory_percent,
            "uptime_seconds": _uptime_seconds,
            "battery_percent": _battery,
        }
        for name, source in sources.items():
            try:
                value = source()
            except (OSError, ValueError, KeyError, IndexError, AttributeError, ZeroDivisionError):
                value = None
            if value is not None:
                readings[name] = value
        return readings
