"""Runs the voice loop for the Command Center. The microphone is off until you turn it on."""
from __future__ import annotations

import asyncio
import concurrent.futures
import queue
import threading
import time
from pathlib import Path
from typing import Any

import numpy as np

from iris.ui import voice_options
from iris.voice.wake import resolve_wake_model
from iris.ui.hub import Busy, Hub
from iris.config import read_raw

SPEECH_THRESHOLD = 0.5
MAX_SPOKEN_CHARACTERS = 1200
LEVEL_FRAMES = 2
MIC_TEST_SECONDS = 3
HEARD_LEVEL = 0.03
SAMPLE_LINE = "This is how I sound, sir."
READY_NOTE = "Say the wake word, or press Talk."
FULL_SCALE_RMS = 6000.0
LINE_WAIT_SECONDS = 1.5
FOLLOW_UP_NOTE = "I'm listening."
FOLLOW_UP_PAUSE = 0.35  # lets the room go quiet after her last word
QUIET_WAIT_SECONDS = 120
BUSY_WAIT_SECONDS = 20
SPEECH_LOAD_SECONDS = 180


def mic_level(frame: np.ndarray) -> float:
    rms = float(np.sqrt(np.mean(np.square(frame.astype(np.float32)))))
    return min(1.0, rms / FULL_SCALE_RMS)


class VoiceBridge:
    def __init__(self, hub: Hub) -> None:
        self.hub = hub
        self.loop = hub.loop
        self.running = threading.Event()
        self.listen_requested = threading.Event()
        self.speaker: Any = None
        self.thread: threading.Thread | None = None
        self.testing = threading.Event()
        self.saved: dict[str, Any] = {}
        self.stats: dict[str, int] = {}
        self.lines: queue.SimpleQueue[str] = queue.SimpleQueue()
        self.talker: threading.Thread | None = None
        self.talking = threading.Event()
        self.detector: Any = None
        self.speech_loading = threading.Event()
        self.speech_ready = threading.Event()
        self.transcriber: Any = None

    def _on_loop(self, function: Any, *args: Any) -> None:
        self.loop.call_soon_threadsafe(function, *args)

    def turn_on(self, listen: bool = False) -> None:
        if listen:
            self.listen_requested.set()
        if self.thread and self.thread.is_alive():
            return
        self.running.set()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def shut_down(self) -> None:
        self.running.clear()
        self.listen_requested.clear()
        self._silence()

    def quiet(self) -> None:
        self.listen_requested.clear()
        self._silence()

    def _silence(self) -> None:
        self.hub.live_speech = False
        while not self.lines.empty():
            self.lines.get_nowait()
        if self.speaker:
            self.speaker.stop()

    def speak(self, text: str) -> None:
        """Lines wait their turn, so a reply is heard in order while the rest is still being written."""
        if not text or not self.running.is_set() or not (self.speaker or self.speech_loading.is_set()):
            return
        self.lines.put(text)
        if not self.talker or not self.talker.is_alive():
            self.talker = threading.Thread(target=self._say, daemon=True)
            self.talker.start()

    def _say(self) -> None:
        if self.speech_loading.is_set() and not self.speech_ready.wait(SPEECH_LOAD_SECONDS):
            return
        if not self.speaker:
            return
        self._on_loop(self.hub.set_voice, "speaking")
        while True:
            try:
                text = self.lines.get(timeout=LINE_WAIT_SECONDS)
            except queue.Empty:
                break
            self._talking(True)
            try:
                self.speaker.say(text)
            except Exception as error:
                self._on_loop(self.hub.set_voice_status, "on", f"Speech failed: {type(error).__name__}.")
            finally:
                self._talking(self.lines.qsize() > 0)
        self._on_loop(self.hub.set_voice, None)

    def _talking(self, on: bool) -> None:
        if on:
            self.talking.set()
        else:
            self.talking.clear()
        if self.detector is not None:
            self.detector.speaking = on

    def wait_until_quiet(self) -> None:
        """Wait until every queued line is spoken, so the follow-up window starts after her last word."""
        ends = time.monotonic() + QUIET_WAIT_SECONDS
        while (self.talking.is_set() or not self.lines.empty()) and time.monotonic() < ends:
            if not self.running.is_set():
                return
            time.sleep(0.05)
        time.sleep(FOLLOW_UP_PAUSE)

    def _respond(self, text: str) -> str:
        self._on_loop(self.hub.set_voice, None)
        ends = time.monotonic() + BUSY_WAIT_SECONDS
        while self.hub.busy and time.monotonic() < ends:
            time.sleep(0.1)  # she was interrupted; the earlier reply is finishing in writing
        future = asyncio.run_coroutine_threadsafe(self.hub.send(text, live_speech=True), self.loop)
        try:
            reply = future.result() or getattr(self.hub, "last_spoken", "")
        except Busy:
            return "I am still working on your last request."
        self.hub.last_spoken = ""
        return reply[:MAX_SPOKEN_CHARACTERS]

    def _status(self, status: str) -> None:
        if status == "listening":
            self._on_loop(self.hub.set_voice_status, "on", READY_NOTE)
            self._on_loop(self.hub.set_voice, "listening")
        elif status == "following up":
            self._on_loop(self.hub.set_voice_status, "on", FOLLOW_UP_NOTE)
            self._on_loop(self.hub.set_voice, "listening")
        elif status == "follow-up over":
            self._on_loop(self.hub.set_voice, None)
            self._on_loop(self.hub.set_voice_status, "on", READY_NOTE)
        elif status == "thinking":
            self._on_loop(self.hub.set_voice, "thinking")
        elif status in ("nothing heard", "nothing understood"):
            self._on_loop(self.hub.set_voice, None)
            self._on_loop(self.hub.set_voice_status, "on", "I did not catch that.")
        elif status.startswith("error:"):
            self._on_loop(self.hub.set_voice, None)
            self._on_loop(self.hub.set_voice_status, "on", "Voice error. Try again.")

    def _config(self) -> dict[str, Any]:
        settings = self.hub.settings
        return {**read_raw(settings.root)["voice"], **self.saved}

    def _devices(self) -> tuple[Any, int]:
        import sounddevice

        return sounddevice.query_devices(), sounddevice.default.hostapi

    def options(self) -> dict[str, Any]:
        """Return what the voice screen shows. Missing voice parts give empty lists."""
        config = self._config()
        try:
            devices, hostapi = self._devices()
            mics = voice_options.microphones(devices, hostapi)
        except (ImportError, OSError):
            mics = []
        return {
            "microphones": mics,
            "microphone": config.get("microphone", ""),
            "voices": voice_options.voices(self.hub.settings.data_dir / "voices"),
            "voice_name": config["voice_name"],
            "wake_threshold": float(config["wake_threshold"]),
            "silence_seconds": float(config["silence_seconds"]),
            "follow_up_seconds": float(config.get("follow_up_seconds", 5.0)),
            "wake_word": Path(resolve_wake_model(config["wake_model"], self.hub.settings.data_dir / "wake")).stem,
            "speech_model": config["speech_model"],
            "stats": self.stats,
        }

    def _microphone(self) -> int | None:
        name = self._config().get("microphone", "")
        if not name:
            return None
        devices, hostapi = self._devices()
        return voice_options.device_index(name, devices, hostapi)

    def test_microphone(self) -> None:
        if self.testing.is_set():
            return
        self.testing.set()
        threading.Thread(target=self._test_microphone, daemon=True).start()

    def _test_microphone(self) -> None:
        from iris.voice.wake import microphone_frames

        highest = 0.0
        try:
            frames = microphone_frames(self._microphone()) if not self.running.is_set() else None
            if frames is None:
                note = "Voice is on, so the meter is already live. Speak now."
            else:
                ends = time.monotonic() + MIC_TEST_SECONDS
                for frame in frames:
                    level = mic_level(frame)
                    highest = max(highest, level)
                    self._on_loop(self.hub.publish, "level", {"level": round(level, 3)})
                    if time.monotonic() >= ends:
                        break
                frames.close()
                note = "Microphone works." if highest >= HEARD_LEVEL else "I heard nothing. Check the microphone."
        except ImportError:
            note = "Voice is not installed. Run scripts\\setup-voice.ps1."
        except Exception as error:
            note = f"The microphone could not start: {type(error).__name__}."
        finally:
            self.testing.clear()
        self._on_loop(self.hub.publish, "notice", {"text": note})

    def test_speech(self) -> None:
        threading.Thread(target=self._test_speech, daemon=True).start()

    def _test_speech(self) -> None:
        try:
            if self.speaker and self.running.is_set():
                self.speaker.say(SAMPLE_LINE)
                return
            self._speaker().say(SAMPLE_LINE)
        except ImportError:
            self._on_loop(self.hub.publish, "notice", {"text": "Voice is not installed. Run scripts\\setup-voice.ps1."})
        except Exception as error:
            self._on_loop(self.hub.publish, "notice", {"text": f"Speech failed: {type(error).__name__}."})

    def _speaker(self) -> Any:
        from iris.voice.speech import MixedSpeaker, Speaker

        path = self.hub.settings.data_dir / "voices" / f"{self._config()['voice_name']}.onnx"
        local = Speaker(path)
        local.on_level = lambda level: self._on_loop(self.hub.publish, "sound", {"level": round(level, 2)})
        connectors = self.hub.connectors
        if not connectors:
            return local
        return MixedSpeaker(local, connectors.elevenlabs, lambda text: self._on_loop(self.hub.publish, "notice", {"text": text}))

    def _timed(self, name: str, work: Any, *args: Any) -> Any:
        started = time.monotonic()
        result = work(*args)
        self.stats[name] = round((time.monotonic() - started) * 1000)
        return result

    def _load_wake(self) -> tuple[Any, ...]:
        """What listening for the wake word needs. This is quick, so IRIS listens within seconds."""
        from iris.voice.loop import ListenLimits
        from iris.voice.wake import ensure_models, load_detector

        settings = self.hub.settings
        voice = self._config()
        ensure_models()
        from openwakeword.vad import VAD

        detector = load_detector(
            resolve_wake_model(voice["wake_model"], settings.data_dir / "wake"),
            float(voice["wake_threshold"]),
            float(voice["wake_vad_threshold"]),
            float(voice["wake_cooldown_seconds"]),
        )
        detector.speaking_threshold = float(voice.get("barge_in_threshold", 0.7)) if voice.get("barge_in", True) else None
        limits = ListenLimits(
            float(voice["silence_seconds"]),
            float(voice["no_speech_seconds"]),
            float(voice["max_listen_seconds"]),
            float(voice.get("follow_up_seconds", 5.0)),
        )
        return VAD(), detector, limits

    def _load_speech(self) -> Any:
        """Whisper and the speaking voice load while IRIS already waits for the wake word."""
        from iris.voice.speech import Transcriber

        try:
            voice = self._config()
            transcriber = self._timed("whisper_load_ms", Transcriber, voice["speech_model"], self.hub.settings.data_dir / "models")
            self.speaker = self._timed("voice_load_ms", self._speaker)
            print(
                f"Voice: speech ready (Whisper {self.stats['whisper_load_ms'] / 1000:.1f} s, voice {self.stats['voice_load_ms'] / 1000:.1f} s).",
                flush=True,
            )
            self.transcriber = transcriber
            return transcriber
        except Exception as error:
            print(f"Voice: speech could not load: {type(error).__name__}: {error}", flush=True)
            note = "Voice is not installed. Run scripts\\setup-voice.ps1." if isinstance(error, ImportError) else f"Voice could not start: {type(error).__name__}."
            self._on_loop(self.hub.set_voice_status, "unavailable", note)
            self.running.clear()
            raise
        finally:
            self.speech_loading.clear()
            self.speech_ready.set()

    def _frames(self, loop: Any) -> Any:
        from iris.voice.wake import microphone_frames

        count = 0
        for frame in microphone_frames(self._microphone()):
            if not self.running.is_set():
                return
            if self.listen_requested.is_set():
                self.listen_requested.clear()
                loop.listen_now()
            count += 1
            if count % LEVEL_FRAMES == 0:
                level = round(mic_level(frame), 3)
                self._on_loop(self.hub.publish, "level", {"level": level})
                if loop.capturing:
                    self._on_loop(self.hub.publish, "sound", {"level": level})
            yield frame

    def _run(self) -> None:
        from iris.voice.loop import VoiceLoop

        self._on_loop(self.hub.set_voice_status, "loading", "Loading voice models.")
        loader = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        try:
            vad, detector, limits = self._timed("wake_load_ms", self._load_wake)
            self.detector = detector
            speech: concurrent.futures.Future[Any] = concurrent.futures.Future()
            if self.transcriber and self.speaker:
                speech.set_result(self.transcriber)  # loaded at an earlier start in this session
            else:
                self.speech_ready.clear()
                self.speech_loading.set()
                speech = loader.submit(self._load_speech)
            print(f"Voice: listening for the wake word ({self.stats['wake_load_ms'] / 1000:.1f} s).", flush=True)

            def transcribe(audio: Any) -> str:
                return speech.result(SPEECH_LOAD_SECONDS).transcribe(audio)

            loop = VoiceLoop(
                detector=detector,
                is_speech=lambda frame: float(vad.predict(frame[:1200])) >= SPEECH_THRESHOLD,
                transcribe=lambda audio: self._timed("heard_ms", transcribe, audio),
                respond=lambda text: self._timed("reply_ms", self._respond, text),
                say=self.speak,
                stop_speaking=self._silence,
                limits=limits,
                on_status=self._status,
                wait_until_quiet=self.wait_until_quiet,
            )
            self._on_loop(self.hub.set_voice_status, "on", READY_NOTE)
            loop.run(self._frames(loop))
            if not (speech.done() and speech.exception()):
                self._on_loop(self.hub.set_voice_status, "off")
        except ImportError:
            self._on_loop(self.hub.set_voice_status, "unavailable", "Voice is not installed. Run scripts\\setup-voice.ps1.")
        except Exception as error:
            self._on_loop(self.hub.set_voice_status, "unavailable", f"Voice could not start: {type(error).__name__}.")
        finally:
            self.running.clear()
            loader.shutdown(wait=False)
