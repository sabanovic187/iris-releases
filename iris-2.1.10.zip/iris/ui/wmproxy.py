"""Lets a paired tablet show World Monitor.

World Monitor listens only on this computer. This passes a tablet's connection through to it,
on the home network, after checking the tablet's pairing cookie on the first request. Cookies do
not depend on the port, so the cookie the tablet got when pairing is sent here as well.
Anyone without that cookie gets 403 and never reaches World Monitor.
"""
from __future__ import annotations

import asyncio
from typing import Any, Callable

COOKIE = "iris_panel"
MAX_HEAD = 64 * 1024


def cookie_value(head: bytes, name: str = COOKIE) -> str:
    for line in head.split(b"\r\n")[1:]:
        key, _, value = line.partition(b":")
        if key.strip().lower() != b"cookie":
            continue
        for part in value.decode("latin-1").split(";"):
            label, _, found = part.strip().partition("=")
            if label == name:
                return found
    return ""


async def _pipe(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        while True:
            chunk = await reader.read(65536)
            if not chunk:
                break
            writer.write(chunk)
            await writer.drain()
    except (ConnectionError, asyncio.CancelledError):
        pass
    finally:
        try:
            writer.close()
        except Exception:
            pass


class WorldMonitorProxy:
    def __init__(self, check: Callable[[str], Any], target_port: int) -> None:
        self.check = check  # the tablet list: returns the device for a valid cookie, else None
        self.target_port = target_port

    async def start(self, port: int) -> asyncio.Server:
        return await asyncio.start_server(self._serve, "0.0.0.0", port)

    async def _serve(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            head = await reader.readuntil(b"\r\n\r\n")
        except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, ConnectionError):
            writer.close()
            return
        if len(head) > MAX_HEAD or not self.check(cookie_value(head)):
            writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 19\r\nConnection: close\r\n\r\nPair this screen.\r\n")
            await writer.drain()
            writer.close()
            return
        try:
            upstream_reader, upstream_writer = await asyncio.open_connection("127.0.0.1", self.target_port)
        except OSError:
            writer.write(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 27\r\nConnection: close\r\n\r\nWorld Monitor is not running")
            await writer.drain()
            writer.close()
            return
        upstream_writer.write(head)
        await asyncio.gather(_pipe(reader, upstream_writer), _pipe(upstream_reader, writer))
