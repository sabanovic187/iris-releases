// The live globe. Page text is always placed as plain text, and all data comes through IRIS.
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const IMAGERY = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
  const LAYERS = ["flights", "military", "satellites", "cables", "quakes", "events", "news"];
  const LAYER_NAMES = { flights: "Air traffic", military: "Military air", satellites: "Satellites", cables: "Undersea cables", quakes: "Earthquakes", events: "Fires and storms", news: "News focus" };
  const COLORS = { flights: "#ffd76a", military: "#ff6b5e", satellites: "#7fe3ff", quakes: "#ffb14a", events: "#ff5a52", news: "#c8a6ff", home: "#66dcae" };
  const FLIGHTS_PER_FRAME = 400;
  const SATELLITES_PER_FRAME = 30;
  const SHADERS = {
    night: `uniform sampler2D colorTexture; in vec2 v_textureCoordinates;
      float noise(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233)) + czm_frameNumber * 0.1) * 43758.5453); }
      void main() { vec2 uv = v_textureCoordinates; float l = dot(texture(colorTexture, uv).rgb, vec3(.3, .59, .11));
        l = pow(l, .55) * 1.5 + noise(uv) * .08; float d = distance(uv, vec2(.5)); l *= smoothstep(.75, .3, d);
        out_FragColor = vec4(l * .25, l, l * .3, 1.); }`,
    thermal: `uniform sampler2D colorTexture; in vec2 v_textureCoordinates;
      vec3 ramp(float t) { return mix(mix(vec3(.02, .01, .2), vec3(.75, .05, .5), smoothstep(0., .4, t)), mix(vec3(1., .45, .05), vec3(1., 1., .8), smoothstep(.65, 1., t)), smoothstep(.35, .7, t)); }
      void main() { float l = dot(texture(colorTexture, v_textureCoordinates).rgb, vec3(.3, .59, .11)); out_FragColor = vec4(ramp(l), 1.); }`,
    crt: `uniform sampler2D colorTexture; in vec2 v_textureCoordinates;
      void main() { vec2 uv = v_textureCoordinates; vec3 c = vec3(texture(colorTexture, uv + vec2(.0012, 0.)).r, texture(colorTexture, uv).g, texture(colorTexture, uv - vec2(.0012, 0.)).b);
        c *= .78 + .22 * sin(uv.y * czm_viewport.w * 1.6); c *= smoothstep(.85, .35, distance(uv, vec2(.5))); out_FragColor = vec4(c * 1.15, 1.); }`,
  };
  const state = { viewer: null, starting: null, on: new Set(["flights", "satellites", "quakes", "events", "news"]), data: null, summary: null, flights: [], aircraft: { flights: [], military: [] }, sats: [], pulses: [], sets: {}, stage: null, mode: "normal", spinning: true, selected: null, orbit: null, loaded: {}, nextFlight: 0, nextSat: 0 };

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function load(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.append(script);
    });
  }

  function planeImage() {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 32;
    const draw = canvas.getContext("2d");
    draw.fillStyle = "#fff";
    draw.beginPath();
    for (const [x, y] of [[16, 1], [18, 11], [30, 19], [30, 22], [18, 18], [18, 26], [22, 29], [22, 31], [16, 29], [10, 31], [10, 29], [14, 26], [14, 18], [2, 22], [2, 19], [14, 11]]) draw.lineTo(x, y);
    draw.fill();
    return canvas.toDataURL();
  }

  async function start() {
    window.CESIUM_BASE_URL = "/cesium/";
    const sheet = document.createElement("link");
    sheet.rel = "stylesheet";
    sheet.href = "/cesium/Widgets/widgets.css";
    document.head.append(sheet);
    await load("/cesium/Cesium.js");
    await load("/satellite.js");
    const C = window.Cesium;
    C.Ion.defaultAccessToken = "";
    // CesiumWidget is used instead of Viewer because Viewer needs unsafe-eval, which this page's security rules refuse.
    const viewer = new C.CesiumWidget($("globe"), {
      baseLayer: C.ImageryLayer.fromProviderAsync(C.TileMapServiceImageryProvider.fromUrl(C.buildModuleUrl("Assets/Textures/NaturalEarthII"))),
      creditContainer: $("globe-credits"),
    });
    viewer.targetFrameRate = 30;
    state.viewer = viewer;
    const imagery = new C.UrlTemplateImageryProvider({ url: IMAGERY, maximumLevel: 17, credit: "Imagery: Esri, Maxar, Earthstar Geographics" });
    viewer.imageryLayers.addImageryProvider(imagery);
    const scene = viewer.scene;
    scene.globe.enableLighting = false;
    scene.globe.baseColor = C.Color.fromCssColorString("#06121c");
    scene.backgroundColor = C.Color.BLACK;
    viewer.clock.shouldAnimate = true;
    state.plane = planeImage();
    state.sets = {
      flights: scene.primitives.add(new C.BillboardCollection()),
      military: scene.primitives.add(new C.BillboardCollection()),
      satellites: scene.primitives.add(new C.PointPrimitiveCollection()),
      cables: scene.primitives.add(new C.PolylineCollection()),
      quakes: scene.primitives.add(new C.PointPrimitiveCollection()),
      events: scene.primitives.add(new C.PointPrimitiveCollection()),
      news: scene.primitives.add(new C.PointPrimitiveCollection()),
      labels: scene.primitives.add(new C.LabelCollection()),
      home: scene.primitives.add(new C.PointPrimitiveCollection()),
    };
    state.orbit = scene.primitives.add(new C.PolylineCollection());
    const handler = new C.ScreenSpaceEventHandler(scene.canvas);
    handler.setInputAction((click) => pick(click.position), C.ScreenSpaceEventType.LEFT_CLICK);
    handler.setInputAction(() => { state.spinning = false; }, C.ScreenSpaceEventType.LEFT_DOWN);
    handler.setInputAction(() => { state.spinning = false; }, C.ScreenSpaceEventType.WHEEL);
    scene.preRender.addEventListener(frame);
    viewer.camera.setView({ destination: C.Cartesian3.fromDegrees(18, 25, 21000000) });
    paintLayerButtons();
    showData();
    await Promise.all(["flights", "military", "satellites", "cables"].map(fetchLayer));
    showStatus();
  }

  function frame() {
    const C = window.Cesium;
    move();
    moveSatellites(SATELLITES_PER_FRAME);
    const now = performance.now() / 700;
    for (const [point, size] of state.pulses) point.pixelSize = size * (1 + 0.28 * Math.sin(now));
    if (state.spinning && !$("tab-situation").hidden) state.viewer.scene.camera.rotate(C.Cartesian3.UNIT_Z, -0.0004);
  }

  async function fetchLayer(layer) {
    const response = await fetch("/api/world", { method: "POST", headers: { "Content-Type": "application/json", "X-IRIS": "1" }, body: JSON.stringify({ layer }) }).catch(() => null);
    if (!response || !response.ok) return;
    const data = await response.json();
    state.loaded[layer] = data;
    if (layer === "flights" || layer === "military") drawAircraft(layer, data.items);
    if (layer === "satellites") drawSatellites(data.items);
    if (layer === "cables") drawCables(data.items);
    visibility();
  }

  function aircraftData(row, kind) {
    return { kind, lon: row[0], lat: row[1], height: row[2], heading: row[3], speed: row[4], name: row[5], from: row[6] };
  }

  function drawAircraft(layer, rows) {
    const C = window.Cesium;
    const set = state.sets[layer];
    set.removeAll();
    const fresh = [];
    const color = C.Color.fromCssColorString(COLORS[layer]);
    const fade = new C.NearFarScalar(2e5, 0.7, 2.5e7, 0.17);
    for (const row of rows) {
      const data = aircraftData(row, layer);
      const position = C.Cartesian3.fromDegrees(data.lon, data.lat, data.height);
      data.mark = set.add({ position, image: state.plane, color, scaleByDistance: fade, rotation: -C.Math.toRadians(data.heading), alignedAxis: C.Ellipsoid.WGS84.geodeticSurfaceNormal(position), id: data });
      data.at = Date.now();
      fresh.push(data);
    }
    state.aircraft[layer] = fresh;
    state.flights = [...state.aircraft.flights, ...state.aircraft.military];
  }

  // Between updates, each aircraft moves on along its last reported heading. A few are moved each frame, so clicks stay quick.
  function move() {
    if ($("tab-situation").hidden || !state.viewer) return;
    const C = window.Cesium;
    const now = Date.now();
    const count = Math.min(state.flights.length, FLIGHTS_PER_FRAME);
    for (let step = 0; step < count; step += 1) {
      state.nextFlight = (state.nextFlight + 1) % state.flights.length;
      const item = state.flights[state.nextFlight];
      const seconds = Math.min((now - item.at) / 1000, 1200);
      const metres = item.speed * seconds;
      const angle = C.Math.toRadians(item.heading);
      const lat = item.lat + (metres * Math.cos(angle)) / 111320;
      const lon = item.lon + (metres * Math.sin(angle)) / (111320 * Math.max(Math.cos(C.Math.toRadians(item.lat)), 0.1));
      item.mark.position = C.Cartesian3.fromDegrees(lon, lat, item.height);
    }
  }

  function drawSatellites(rows) {
    const C = window.Cesium;
    const set = state.sets.satellites;
    set.removeAll();
    state.sats = [];
    const color = C.Color.fromCssColorString(COLORS.satellites);
    for (const [name, one, two, group] of rows) {
      try {
        const record = window.satellite.twoline2satrec(one, two);
        const data = { kind: "satellites", name, group, record };
        data.mark = set.add({ pixelSize: 2.6, color, position: C.Cartesian3.ZERO, id: data, show: false });
        state.sats.push(data);
      } catch (error) { /* a damaged record is skipped */ }
    }
    moveSatellites();
  }

  function satellitePlace(record, date) {
    const found = window.satellite.propagate(record, date);
    if (!found || !found.position) return null;
    const place = window.satellite.eciToGeodetic(found.position, window.satellite.gstime(date));
    return window.Cesium.Cartesian3.fromRadians(place.longitude, place.latitude, place.height * 1000);
  }

  function moveSatellites(count = state.sats.length) {
    if ($("tab-situation").hidden || !state.viewer || !state.on.has("satellites") || !state.sats.length) return;
    const date = new Date();
    for (let step = 0; step < count; step += 1) {
      state.nextSat = (state.nextSat + 1) % state.sats.length;
      const item = state.sats[state.nextSat];
      const place = satellitePlace(item.record, date);
      item.mark.show = Boolean(place);
      if (place) item.mark.position = place;
    }
  }

  function drawCables(rows) {
    const C = window.Cesium;
    const set = state.sets.cables;
    set.removeAll();
    const material = C.Material.fromType("Color", { color: C.Color.fromCssColorString("#35d0c0").withAlpha(0.42) });
    for (const cable of rows) {
      for (const line of cable.lines) {
        if (line.length > 1) set.add({ positions: C.Cartesian3.fromDegreesArrayHeights(line.flatMap(([lon, lat]) => [lon, lat, 4000])), width: 1.1, material, id: { kind: "cables", name: cable.name } });
      }
    }
  }

  function showData() {
    if (!state.viewer || !state.data) return;
    const C = window.Cesium;
    const data = state.data;
    state.pulses = [];
    for (const name of ["quakes", "events", "news", "home"]) state.sets[name].removeAll();
    state.sets.labels.removeAll();
    const hide = new C.NearFarScalar(1e6, 1, 3e7, 0.55);
    for (const item of data.quakes || []) {
      const size = 3 + item.mag * 2.4;
      state.pulses.push([state.sets.quakes.add({ position: C.Cartesian3.fromDegrees(item.lon, item.lat), pixelSize: size, color: C.Color.fromCssColorString(COLORS.quakes).withAlpha(0.8), outlineColor: C.Color.BLACK, outlineWidth: 1, id: { kind: "quakes", ...item } }), size]);
    }
    for (const item of data.events || []) {
      state.sets.events.add({ position: C.Cartesian3.fromDegrees(item.lon, item.lat), pixelSize: 8, color: C.Color.fromCssColorString(COLORS.events), outlineColor: C.Color.WHITE.withAlpha(0.5), outlineWidth: 1, id: { kind: "events", ...item } });
    }
    for (const item of (data.focus || []).slice(0, 25)) {
      const size = 7 + Math.min(item.count, 12) * 1.3;
      const position = C.Cartesian3.fromDegrees(item.lon, item.lat, 8000);
      state.pulses.push([state.sets.news.add({ position, pixelSize: size, color: C.Color.fromCssColorString(COLORS.news).withAlpha(0.55), outlineColor: C.Color.fromCssColorString(COLORS.news), outlineWidth: 1.5, id: { kind: "news", ...item } }), size]);
      state.sets.labels.add({ position, text: item.country.toUpperCase(), font: "12px Saira, sans-serif", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 3, style: C.LabelStyle.FILL_AND_OUTLINE, pixelOffset: new C.Cartesian2(0, -18), scaleByDistance: hide, id: { kind: "news", ...item } });
    }
    state.sets.home.add({ position: C.Cartesian3.fromDegrees(data.lon, data.lat, 2000), pixelSize: 9, color: C.Color.fromCssColorString(COLORS.home), outlineColor: C.Color.WHITE, outlineWidth: 2, id: { kind: "home", place: data.place, lat: data.lat, lon: data.lon } });
    visibility();
  }

  function visibility() {
    if (!state.viewer) return;
    for (const name of LAYERS) if (state.sets[name]) state.sets[name].show = state.on.has(name);
    state.sets.labels.show = state.on.has("news");
    moveSatellites();
    showStatus();
  }

  function paintLayerButtons() {
    const box = $("globe-layers");
    box.replaceChildren(...LAYERS.map((name) => {
      const button = element("button", "layer", LAYER_NAMES[name]);
      button.type = "button";
      button.dataset.layer = name;
      button.setAttribute("aria-pressed", String(state.on.has(name)));
      button.style.setProperty("--layer", COLORS[name] || "#35d0c0");
      const count = element("small", "", "");
      count.id = `count-${name}`;
      button.append(count);
      button.addEventListener("click", () => {
        if (state.on.has(name)) state.on.delete(name); else state.on.add(name);
        button.setAttribute("aria-pressed", String(state.on.has(name)));
        visibility();
      });
      return button;
    }));
  }

  function age(stamp) {
    if (!stamp) return "";
    const minutes = Math.round((Date.now() / 1000 - stamp) / 60);
    return minutes < 1 ? "just now" : minutes < 60 ? `${minutes} min ago` : `${Math.round(minutes / 60)} h ago`;
  }

  function showStatus() {
    const data = state.data || {};
    const counts = {
      flights: state.loaded.flights?.items.length, military: state.loaded.military?.items.length, satellites: state.sats.length,
      cables: state.loaded.cables?.items.length, quakes: (data.quakes || []).length, events: (data.events || []).length, news: (data.focus || []).length,
    };
    for (const name of LAYERS) {
      const node = $(`count-${name}`);
      if (!node) continue;
      const failed = state.loaded[name]?.failed || (state.summary?.failed || []).includes(name) || (data.failed || []).includes(name);
      node.textContent = counts[name] ? counts[name].toLocaleString("en-US") : failed ? "not available" : "waiting";
    }
    $("g-air").textContent = (counts.flights || 0).toLocaleString("en-US");
    $("g-air-age").textContent = age(state.loaded.flights?.updated) || "waiting for data";
    $("g-sat").textContent = (counts.satellites || 0).toLocaleString("en-US");
    $("g-hot").textContent = String((data.focus || []).filter((item) => item.crisis).length);
  }

  function row(main, side, action) {
    const item = element("li", "item-line");
    const left = element(action ? "button" : "span", action ? "row-button" : "", main);
    if (action) { left.type = "button"; left.addEventListener("click", action); }
    item.append(left, element("span", "status", side));
    return item;
  }

  function fill(list, rows, empty) {
    list.replaceChildren(...(rows.length ? rows : [element("li", "empty", empty)]));
  }

  function headline(item) {
    const li = element("li");
    if (item.link) {
      const link = element("a", "news-link", item.title);
      link.href = item.link;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      li.append(link);
    } else li.append(element("span", "", item.title));
    li.append(element("div", "item-sub", item.source));
    return li;
  }

  function refreshed() {
    $("situation-refresh").textContent = "Refresh";
    $("situation-refresh").disabled = false;
  }

  function show(data) {
    if (!data || !data.updated) return;
    state.data = data;
    refreshed();
    const weather = data.weather;
    $("s-weather").textContent = weather ? `${data.place}: ${Math.round(weather.temperature)}°C, ${weather.sky}, wind ${Math.round(weather.wind)} km/h` : `${data.place}: weather not available`;
    const time = new Date(data.updated).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
    $("s-updated").textContent = `Updated ${time}.${data.failed.length ? ` Not available: ${data.failed.join(", ")}.` : ""}`;
    fill($("s-focus"), (data.focus || []).slice(0, 7).map((item) => row(item.country, `${item.count}`, () => focus(item))), "No headlines yet.");
    fill($("s-news"), (data.news || []).slice(0, 25).map(headline), "No headlines yet.");
    fill($("s-quakes"), [...(data.events || []).slice(0, 4).map((item) => row(item.title, item.kind, () => fly(item.lat, item.lon, 1500))), ...(data.quakes || []).slice(0, 4).map((item) => row(item.place, `M${item.mag.toFixed(1)}`, () => fly(item.lat, item.lon, 1500)))], "None reported.");
    showData();
    showStatus();
  }

  function fly(lat, lon, km) {
    if (!state.viewer) return;
    const C = window.Cesium;
    state.spinning = false;
    state.viewer.camera.flyTo({ destination: C.Cartesian3.fromDegrees(lon, lat, km * 1000), duration: 2.4 });
  }

  function focus(item) {
    fly(item.lat, item.lon, 2200);
    card(item.country, [`${item.count} headlines now, ${item.crisis} about crises.`, ...item.titles.slice(0, 4)], `What is happening in ${item.country}? Show it on the globe.`);
  }

  function card(title, lines, question) {
    $("g-card-title").textContent = title;
    $("g-card-body").replaceChildren(...lines.map((line) => element("p", "", line)));
    const ask = $("g-card-ask");
    ask.hidden = !question;
    ask.onclick = () => window.irisSend(question);
    $("g-card").hidden = false;
  }

  function showOrbit(item) {
    const C = window.Cesium;
    state.orbit.removeAll();
    if (!item) return;
    const now = Date.now();
    const minutes = (2 * Math.PI) / item.record.no;
    const points = [];
    for (let step = 0; step <= 120; step += 1) {
      const place = satellitePlace(item.record, new Date(now + (step / 120) * minutes * 60000));
      if (place) points.push(place);
    }
    if (points.length > 1) state.orbit.add({ positions: points, width: 1.5, material: C.Material.fromType("Color", { color: C.Color.fromCssColorString(COLORS.satellites).withAlpha(0.7) }) });
  }

  function pick(position) {
    const C = window.Cesium;
    const found = state.viewer.scene.pick(position);
    const item = found && found.id;
    showOrbit(null);
    if (item && item.kind) {
      if (item.kind === "flights" || item.kind === "military") {
        card(item.name || "Unnamed aircraft", [item.kind === "military" ? `Type: ${item.from || "unknown"}` : `From: ${item.from || "unknown"}`, `Height ${Math.round(item.height).toLocaleString("en-US")} m`, `Speed ${Math.round(item.speed * 3.6)} km/h, heading ${Math.round(item.heading)}°`, `Reported ${age(item.at / 1000)}. Position between reports is estimated.`]);
      } else if (item.kind === "satellites") {
        showOrbit(item);
        card(item.name, [`Group: ${item.group}`, "Line shows one orbit, calculated from public CelesTrak data."], `What does the satellite ${item.name} do?`);
      } else if (item.kind === "quakes") card(`Magnitude ${item.mag}`, [item.place, new Date(item.time).toLocaleString()], `Tell me about the earthquake near ${item.place}.`);
      else if (item.kind === "events") card(item.title, [item.kind]);
      else if (item.kind === "news") focus(item);
      else if (item.kind === "cables") card(item.name, ["Undersea cable"]);
      else if (item.kind === "home") card(item.place, ["Home"]);
      return;
    }
    const ray = state.viewer.camera.getPickRay(position);
    const spot = ray && state.viewer.scene.globe.pick(ray, state.viewer.scene);
    if (!spot) { $("g-card").hidden = true; return; }
    const place = C.Cartographic.fromCartesian(spot);
    const lat = C.Math.toDegrees(place.latitude);
    const lon = C.Math.toDegrees(place.longitude);
    card(`${lat.toFixed(2)}°, ${lon.toFixed(2)}°`, ["Chosen place"], `What is happening around latitude ${lat.toFixed(2)}, longitude ${lon.toFixed(2)}? Show it on the globe.`);
  }

  function setMode(name) {
    const C = window.Cesium;
    state.mode = name;
    for (const button of document.querySelectorAll("[data-mode]")) button.setAttribute("aria-pressed", String(button.dataset.mode === name));
    if (!state.viewer) return;
    const stages = state.viewer.scene.postProcessStages;
    if (state.stage) stages.remove(state.stage);
    state.stage = SHADERS[name] ? stages.add(new C.PostProcessStage({ fragmentShader: SHADERS[name] })) : null;
  }

  async function open() {
    if (state.viewer) { state.viewer.resize(); moveSatellites(); return; }
    if (!state.starting) {
      state.starting = start().catch(() => {
        $("globe-problem").hidden = false;
        state.starting = null;
      });
    }
    await state.starting;
  }

  async function view(data) {
    $("g-caption").textContent = data.label || "";
    $("g-caption").hidden = !data.label;
    await open();
    if (data.layers) {
      state.on = new Set(data.layers);
      paintLayerButtons();
      visibility();
    }
    if (data.mode) setMode(data.mode);
    if (data.lat !== undefined) fly(data.lat, data.lon, data.km);
  }

  function world(data) {
    state.summary = data;
    const items = data.markets || [];
    fill($("s-markets"), items.slice(0, 9).map((item) => {
      const change = item.change === null || item.change === undefined ? "" : `${item.change >= 0 ? "+" : ""}${item.change.toFixed(2)}%`;
      const line = row(item.name, `${item.price.toLocaleString("en-US", { maximumFractionDigits: item.price < 10 ? 4 : 2 })} ${change}`);
      if (change) line.lastChild.classList.add(item.change >= 0 ? "rise" : "fall");
      return line;
    }), "Waiting for prices.");
    if (state.viewer) for (const name of data.changed || []) if (name !== "markets") fetchLayer(name);
    showStatus();
  }

  for (const button of document.querySelectorAll("[data-mode]")) button.addEventListener("click", () => setMode(button.dataset.mode));
  $("g-card-close").addEventListener("click", () => { $("g-card").hidden = true; showOrbit(null); });
  $("g-brief").addEventListener("click", () => window.irisSend("Give me a world brief. Follow the world-brief skill."));
  function reply(text) {
    if (!$("tab-situation").hidden) card("IRIS", text.split(/\n+/).slice(0, 12));
  }

  function status(text) {
    $("g-status").textContent = text;
  }

  window.irisSituation = { show, open, view, world, refreshed, reply, status };
})();
