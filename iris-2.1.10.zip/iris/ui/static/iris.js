// The moving eye. Its look follows what IRIS is really doing.
(function () {
  "use strict";
  const canvas = document.getElementById("iris");
  const draw = canvas.getContext("2d");
  const SIZE = canvas.width;
  const MID = SIZE / 2;
  const OUTER = SIZE * 0.40;
  const FIBRES = 170;
  const FRAME_MS = 33;
  const still = matchMedia("(prefers-reduced-motion: reduce)").matches;

  const LOOKS = {
    waiting:   { pupil: 0.36, glow: 0.65, spin: 0.03, ring: [85, 196, 245], fleck: [242, 180, 92] },
    listening: { pupil: 0.54, glow: 1.0,  spin: 0.05, ring: [143, 227, 255], fleck: [242, 180, 92] },
    thinking:  { pupil: 0.24, glow: 0.9,  spin: 0.5,  ring: [85, 196, 245], fleck: [242, 180, 92] },
    working:   { pupil: 0.28, glow: 1.0,  spin: 0.9,  ring: [102, 220, 174], fleck: [85, 196, 245] },
    speaking:  { pupil: 0.40, glow: 0.95, spin: 0.08, ring: [85, 196, 245], fleck: [242, 180, 92] },
    needs_you: { pupil: 0.46, glow: 1.0,  spin: 0.0,  ring: [242, 180, 92], fleck: [255, 226, 170] },
    owner:     { pupil: 0.16, glow: 0.45, spin: 0.0,  ring: [134, 163, 182], fleck: [134, 163, 182] },
    stopped:   { pupil: 0.10, glow: 0.5,  spin: 0.0,  ring: [255, 90, 82], fleck: [120, 40, 36] },
  };

  // Fixed pattern, so every start draws the same eye.
  let seed = 7;
  const random = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const fibres = Array.from({ length: FIBRES }, (_, index) => ({
    angle: (index / FIBRES) * Math.PI * 2 + random() * 0.03,
    length: 0.72 + random() * 0.28,
    bend: (random() - 0.5) * 0.09,
    strength: 0.3 + random() * 0.7,
    fleck: random() < 0.13,
  }));

  const current = { pupil: 0.36, glow: 0.65, spin: 0.03, ring: [85, 196, 245], fleck: [242, 180, 92] };
  let phase = "waiting";
  let level = 0;
  let turn = 0;
  let last = 0;

  const mix = (from, to, amount) => from + (to - from) * amount;
  const colour = (rgb, alpha) => `rgba(${rgb.map(Math.round).join(",")},${alpha})`;

  function paint(time) {
    const look = LOOKS[phase] || LOOKS.waiting;
    for (const key of ["pupil", "glow", "spin"]) current[key] = mix(current[key], look[key], 0.07);
    for (let i = 0; i < 3; i += 1) {
      current.ring[i] = mix(current.ring[i], look.ring[i], 0.07);
      current.fleck[i] = mix(current.fleck[i], look.fleck[i], 0.07);
    }
    turn += current.spin * 0.016;

    let open = current.pupil;
    if (!still) {
      open += Math.sin(time / 2600) * 0.012;
      if (phase === "speaking") open += Math.abs(Math.sin(time / 170)) * 0.05;
    }
    open += level * 0.16;
    const pupil = OUTER * Math.min(open, 0.74);

    draw.clearRect(0, 0, SIZE, SIZE);

    const halo = draw.createRadialGradient(MID, MID, OUTER * 0.7, MID, MID, OUTER * 1.24);
    halo.addColorStop(0, colour(current.ring, 0.34 * current.glow));
    halo.addColorStop(1, colour(current.ring, 0));
    draw.fillStyle = halo;
    draw.fillRect(0, 0, SIZE, SIZE);

    const body = draw.createRadialGradient(MID, MID, pupil, MID, MID, OUTER);
    body.addColorStop(0, "#14384f");
    body.addColorStop(0.65, "#0b2333");
    body.addColorStop(1, "#061420");
    draw.fillStyle = body;
    draw.beginPath();
    draw.arc(MID, MID, OUTER, 0, Math.PI * 2);
    draw.fill();

    draw.lineCap = "round";
    for (const fibre of fibres) {
      const angle = fibre.angle + turn;
      const reach = pupil + (OUTER - pupil) * fibre.length;
      const shimmer = still ? 1 : 0.8 + 0.2 * Math.sin(time / 900 + fibre.angle * 7);
      const alpha = fibre.strength * current.glow * shimmer * (0.78 + level * 0.3);
      draw.strokeStyle = colour(fibre.fleck ? current.fleck : current.ring, Math.min(alpha, 0.95));
      draw.lineWidth = fibre.fleck ? 3 : 1.9;
      draw.beginPath();
      draw.moveTo(MID + Math.cos(angle) * pupil, MID + Math.sin(angle) * pupil);
      draw.quadraticCurveTo(
        MID + Math.cos(angle + fibre.bend) * (pupil + reach) / 2,
        MID + Math.sin(angle + fibre.bend) * (pupil + reach) / 2,
        MID + Math.cos(angle) * reach,
        MID + Math.sin(angle) * reach,
      );
      draw.stroke();
    }

    draw.fillStyle = "#020608";
    draw.beginPath();
    draw.arc(MID, MID, pupil, 0, Math.PI * 2);
    draw.fill();
    draw.strokeStyle = colour(current.ring, 0.85 * current.glow);
    draw.lineWidth = 2;
    draw.stroke();

    draw.strokeStyle = colour(current.ring, 0.75);
    draw.lineWidth = 3;
    draw.beginPath();
    draw.arc(MID, MID, OUTER, 0, Math.PI * 2);
    draw.stroke();

    // The outer scale shows the real microphone level.
    const marks = 96;
    for (let index = 0; index < marks; index += 1) {
      const angle = (index / marks) * Math.PI * 2 - turn * 0.5;
      const lit = index % 12 === 0;
      const rise = level * OUTER * 0.16 * (0.4 + 0.6 * Math.abs(Math.sin(index * 1.7 + time / 120)));
      const from = OUTER * 1.08;
      const to = from + (lit ? 16 : 7) + rise;
      draw.strokeStyle = colour(current.ring, lit ? 0.85 : 0.35);
      draw.lineWidth = lit ? 2.4 : 1.4;
      draw.beginPath();
      draw.moveTo(MID + Math.cos(angle) * from, MID + Math.sin(angle) * from);
      draw.lineTo(MID + Math.cos(angle) * to, MID + Math.sin(angle) * to);
      draw.stroke();
    }

    level *= 0.9;
  }

  function loop(time) {
    requestAnimationFrame(loop);
    if (document.hidden || time - last < FRAME_MS) return;
    last = time;
    paint(time);
  }

  window.irisEye = {
    setPhase(next) {
      phase = next;
      if (still) requestAnimationFrame(() => paint(0));
    },
    setLevel(next) {
      level = Math.max(level, next);
    },
  };

  if (still) {
    Object.assign(current, { ...LOOKS.waiting, ring: [...LOOKS.waiting.ring], fleck: [...LOOKS.waiting.fleck] });
    paint(0);
    setInterval(() => paint(0), 500);
  } else {
    requestAnimationFrame(loop);
  }
})();
