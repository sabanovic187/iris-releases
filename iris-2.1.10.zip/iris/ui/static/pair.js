// Sends the code once. The key IRIS returns is kept by the browser as a cookie that scripts cannot read.
(function () {
  "use strict";
  const form = document.getElementById("pair-form");
  const problem = document.getElementById("pair-problem");
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    problem.hidden = true;
    const button = form.querySelector("button");
    button.disabled = true;
    try {
      const response = await fetch("/api/pair", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-IRIS": "1" },
        body: JSON.stringify({ code: document.getElementById("pair-code").value, name: document.getElementById("pair-name").value }),
      });
      const data = await response.json();
      if (data.ok) {
        location.replace("/");
        return;
      }
      problem.textContent = data.error || "Pairing failed.";
    } catch {
      problem.textContent = "IRIS is not answering. Check that the computer is on and IRIS is running.";
    }
    problem.hidden = false;
    button.disabled = false;
  });
})();
