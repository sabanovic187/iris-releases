// The chosen material is a convenience kept in this browser. Without storage, IRIS stays green.
(function () {
  "use strict";
  const KEY = "iris.material";
  const apply = (name) => {
    if (name === "grey") document.documentElement.dataset.material = "grey";
    else delete document.documentElement.dataset.material;
    document.querySelectorAll("button[data-material]").forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.material === (name === "grey" ? "grey" : "green")));
    });
  };
  const saved = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
  apply(saved());
  document.addEventListener("DOMContentLoaded", () => {
    apply(saved());
    document.querySelectorAll("button[data-material]").forEach((button) => {
      button.addEventListener("click", () => {
        apply(button.dataset.material);
        try { localStorage.setItem(KEY, button.dataset.material); } catch { /* stays for this visit */ }
      });
    });
  });
})();
