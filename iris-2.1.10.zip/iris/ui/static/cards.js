// Topic cards around the core. Every text is placed as plain text; links and pictures were checked by IRIS first.
(function () {
  "use strict";
  const FADE_AFTER_MS = 4 * 60 * 1000;
  const box = document.getElementById("cards");
  const viewer = document.getElementById("card-viewer");
  const viewerBody = document.getElementById("card-viewer-body");
  let post = async () => ({});
  let fadeTimer;
  let shown = [];

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  }

  function picture(src, className) {
    const image = element("img", className);
    image.alt = "";
    image.loading = "lazy";
    image.decoding = "async";
    image.referrerPolicy = "no-referrer";
    image.addEventListener("error", () => image.remove());
    image.src = src;
    return image;
  }

  function sparkline(points, wide) {
    const ns = "http://www.w3.org/2000/svg";
    const width = wide ? 520 : 240;
    const height = wide ? 180 : 64;
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.setAttribute("class", "spark");
    svg.setAttribute("aria-hidden", "true");
    const low = Math.min(...points);
    const high = Math.max(...points);
    const span = high - low || 1;
    const xy = points.map((value, index) => [
      (index / (points.length - 1)) * (width - 8) + 4,
      height - 6 - ((value - low) / span) * (height - 12),
    ]);
    const line = document.createElementNS(ns, "polyline");
    line.setAttribute("points", xy.map((pair) => pair.map((n) => n.toFixed(1)).join(",")).join(" "));
    const area = document.createElementNS(ns, "polygon");
    area.setAttribute("points", `4,${height} ` + line.getAttribute("points") + ` ${width - 4},${height}`);
    area.setAttribute("class", "spark-area");
    const end = document.createElementNS(ns, "circle");
    end.setAttribute("cx", xy[xy.length - 1][0].toFixed(1));
    end.setAttribute("cy", xy[xy.length - 1][1].toFixed(1));
    end.setAttribute("r", wide ? "4" : "3");
    svg.append(area, line, end);
    return svg;
  }

  function trend(text) {
    const node = element("span", "card-change", text);
    if (/^\+/.test(text)) node.classList.add("rise");
    if (/^[-−]/.test(text)) node.classList.add("fall");
    return node;
  }

  function cardNode(card, index) {
    const node = element("button", `topic-card kind-${card.kind}`);
    node.type = "button";
    node.style.setProperty("--i", String(index));
    node.setAttribute("aria-label", `${card.title}. Open`);
    if (card.image) {
      const frame = element("div", "card-picture");
      frame.append(picture(card.image));
      if (card.kind === "video") frame.append(element("span", "card-play", "▶︎"));
      node.append(frame);
    }
    const body = element("div", "card-body");
    if (card.source) body.append(element("span", "card-source", card.source));
    body.append(element("strong", "card-title", card.title));
    if (card.kind === "number") {
      const row = element("div", "card-figure");
      row.append(element("span", "card-value", card.value));
      if (card.change) row.append(trend(card.change));
      body.append(row);
    }
    if (card.kind === "chart") {
      if (card.value) body.append(element("span", "card-value small", card.value));
      body.append(sparkline(card.points, false));
    }
    if (card.text && card.kind !== "number") body.append(element("p", "card-text", card.text));
    node.append(body);
    node.addEventListener("click", () => open(card));
    return node;
  }

  function open(card) {
    const parts = [];
    if (card.kind === "video") {
      const frame = element("iframe", "card-video");
      frame.src = `https://www.youtube-nocookie.com/embed/${card.video}?autoplay=1&rel=0`;
      frame.title = card.title;
      frame.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
      frame.referrerPolicy = "strict-origin-when-cross-origin";
      frame.setAttribute("sandbox", "allow-scripts allow-same-origin allow-presentation allow-popups");
      parts.push(frame);
    } else if (card.image) {
      parts.push(picture(card.image, "viewer-picture"));
    }
    if (card.source) parts.push(element("span", "card-source", card.source));
    parts.push(element("h2", "viewer-title", card.title));
    if (card.kind === "number") {
      const row = element("div", "card-figure");
      row.append(element("span", "card-value", card.value));
      if (card.change) row.append(trend(card.change));
      parts.push(row);
    }
    if (card.kind === "chart") parts.push(sparkline(card.points, true));
    if (card.text) parts.push(element("p", card.report ? "viewer-text viewer-report" : "viewer-text", card.text));
    if (card.url) {
      const link = element("a", "viewer-link", card.kind === "video" ? "Open on YouTube" : "Open in the browser");
      link.href = card.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      parts.push(link);
    }
    viewerBody.replaceChildren(...parts);
    viewer.hidden = false;
    document.getElementById("card-close").focus();
  }

  function closeViewer() {
    viewer.hidden = true;
    viewerBody.replaceChildren();
  }

  function show(data) {
    clearTimeout(fadeTimer);
    shown = (data && data.cards) || [];
    box.classList.remove("leaving");
    box.replaceChildren(...shown.map(cardNode));
    box.hidden = shown.length === 0;
    box.dataset.count = String(shown.length);
    document.body.classList.toggle("has-cards", shown.length > 0);
  }

  function fade() {
    if (!shown.length) return;
    box.classList.add("leaving");
    setTimeout(() => post("cards", { clear: true }), 900);
  }

  function phase(name) {
    clearTimeout(fadeTimer);
    if (name === "waiting" && shown.length) fadeTimer = setTimeout(fade, FADE_AFTER_MS);
  }

  document.getElementById("card-close").addEventListener("click", closeViewer);
  viewer.addEventListener("click", (event) => { if (event.target === viewer) closeViewer(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !viewer.hidden) closeViewer(); });

  window.irisCards = {
    init: (sender) => { post = sender; },
    show,
    phase,
    open,
    any: () => shown.length > 0,
  };
})();
