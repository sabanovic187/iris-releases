// Unbound, clinical look: near-black room, slow haze, film grain, and a red particle core.
// One colour, slow movement. Runs only while Unbound is chosen and the Command Center is on screen.
(function () {
  "use strict";
  const back = document.getElementById("cipher");
  const coreCanvas = document.getElementById("cipher-core");
  const bigCanvas = document.getElementById("cipher-big");  // the large core on the presence screen
  const RED = [227, 38, 47];
  const WHITE = [255, 244, 242];
  const POINTS = 32000;
  const calm = matchMedia("(prefers-reduced-motion: reduce)");
  const state = { on: false, running: false, phase: "waiting", time: 0, last: 0, pulse: 0, spin: 0.12, glow: 0.5, haze: [], grain: null, grainAt: 0 };
  // How the core moves in each phase. Warnings keep their own colour.
  const LOOK = {
    waiting:   { spin: 0.10, glow: 0.45, size: 1.0,  colour: RED },
    listening: { spin: 0.16, glow: 0.65, size: 1.04, colour: RED },
    thinking:  { spin: 0.55, glow: 0.8,  size: 0.94, colour: RED },
    working:   { spin: 0.45, glow: 0.7,  size: 0.96, colour: RED },
    speaking:  { spin: 0.2,  glow: 0.75, size: 1.02, colour: RED },
    needs_you: { spin: 0.12, glow: 0.6,  size: 1.0,  colour: [255, 170, 60] },
    owner:     { spin: 0.04, glow: 0.25, size: 0.92, colour: [150, 150, 150] },
    stopped:   { spin: 0.0,  glow: 0.2,  size: 0.86, colour: [255, 40, 40] },
  };
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

  // The core: points on a slightly uneven shell, with a few hot ones.
  const points = [];
  let seed = 11;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  for (let i = 0; i < POINTS; i++) {
    const y = 1 - 2 * rnd(), r = Math.sqrt(1 - y * y), a = rnd() * Math.PI * 2;
    // Folds in the shell give it the banded, living surface of the large core.
    const fold = 0.05 * Math.sin(a * 6 + y * 9) + 0.03 * Math.sin(a * 13 - y * 5);
    points.push({ x: Math.cos(a) * r, y, z: Math.sin(a) * r, shell: 0.9 + fold + 0.08 * Math.pow(rnd(), 4), wave: a * 3 + y * 4, hot: Math.pow(rnd(), 9) > 0.45 });
  }

  function fit(canvas) {
    const ratio = Math.min(devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(canvas.clientWidth * ratio));
    const h = Math.max(1, Math.round(canvas.clientHeight * ratio));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; return true; }
    return false;
  }

  function seedHaze() {
    state.haze = Array.from({ length: 9 }, () => ({
      x: Math.random(), y: 0.2 + Math.random() * 0.7, r: 0.25 + Math.random() * 0.3,
      dx: (Math.random() - 0.5) * 0.004, alpha: 0.008 + Math.random() * 0.012,
    }));
    const grain = document.createElement("canvas");
    grain.width = 256; grain.height = 256;
    state.grain = grain;
  }

  function drawBack(step) {
    const g = back.getContext("2d");
    const { width: w, height: h } = back;
    const room = g.createRadialGradient(w * 0.33, h * 0.42, 0, w * 0.33, h * 0.42, Math.max(w, h) * 0.75);
    room.addColorStop(0, "#070707");
    room.addColorStop(1, "#000");
    g.fillStyle = room;
    g.fillRect(0, 0, w, h);
    for (const cloud of state.haze) {
      cloud.x += cloud.dx * step;
      if (cloud.x < -0.3 || cloud.x > 1.3) cloud.dx = -cloud.dx;
      const x = cloud.x * w, y = cloud.y * h, r = cloud.r * Math.max(w, h);
      const fog = g.createRadialGradient(x, y, 0, x, y, r);
      fog.addColorStop(0, `rgba(255,255,255,${cloud.alpha})`);
      fog.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = fog;
      g.fillRect(0, 0, w, h);
    }
    // Film grain, renewed a few times a second, laid over softly
    if (state.time - state.grainAt > 0.08) {
      state.grainAt = state.time;
      const gg = state.grain.getContext("2d"), image = gg.createImageData(256, 256);
      for (let i = 0; i < image.data.length; i += 4) {
        const n = Math.random() * 255;
        image.data[i] = image.data[i + 1] = image.data[i + 2] = n;
        image.data[i + 3] = 255;
      }
      gg.putImageData(image, 0, 0);
    }
    g.globalAlpha = 0.035;
    g.fillStyle = g.createPattern(state.grain, "repeat");
    g.fillRect(0, 0, w, h);
    g.globalAlpha = 1;
    const edge = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75);
    edge.addColorStop(0, "rgba(0,0,0,0)");
    edge.addColorStop(1, "rgba(0,0,0,0.85)");
    g.fillStyle = edge;
    g.fillRect(0, 0, w, h);
  }

  // scale: the shell's radius as a share of the canvas. The orbit reaches 1.36 times further,
  // so the scale stays below 0.36 to keep the ring whole.
  function drawCore(canvas, scale) {
    if (!canvas || !canvas.clientWidth) return;
    fit(canvas);
    const g = canvas.getContext("2d");
    const { width: w, height: h } = canvas;
    const look = LOOK[state.phase] || LOOK.waiting;
    g.clearRect(0, 0, w, h);
    const breath = 1 + Math.sin(state.time * 1.1) * 0.012 + state.pulse * 0.035;
    const R = Math.min(w, h) * scale * look.size * breath;
    const cx = w / 2, cy = h / 2;
    const turn = state.time * state.spin, tilt = 0.32;
    const ct = Math.cos(turn), st = Math.sin(turn), cl = Math.cos(tilt), sl = Math.sin(tilt);
    const dot = Math.max(1.1, Math.min(w, h) / 560);
    g.globalCompositeOperation = "lighter";
    for (const p of points) {
      const ripple = 1 + 0.035 * Math.sin(p.wave + state.time * 0.9 + p.y * 5);
      const x = p.x * ct - p.z * st, z = p.x * st + p.z * ct;
      const y = p.y * cl - z * sl, depth = (p.y * sl + z * cl + 1) / 2;
      const s = p.shell * ripple;
      g.fillStyle = rgba(p.hot ? WHITE : look.colour, (0.05 + 0.5 * depth * depth) * (0.55 + state.glow * 0.7));
      g.fillRect(cx + x * R * s, cy + y * R * s, dot, dot);
    }
    const heart = g.createRadialGradient(cx, cy, 0, cx, cy, R * 0.55);
    heart.addColorStop(0, rgba(WHITE, 0.5 * state.glow + 0.15 * state.pulse));
    heart.addColorStop(0.22, rgba(look.colour, 0.2 * state.glow));
    heart.addColorStop(1, rgba(look.colour, 0));
    g.fillStyle = heart;
    g.beginPath(); g.arc(cx, cy, R * 0.55, 0, Math.PI * 2); g.fill();
    g.globalCompositeOperation = "source-over";
    g.strokeStyle = rgba(look.colour, 0.28);
    g.lineWidth = Math.max(1, w / 900);
    g.beginPath(); g.ellipse(cx, cy, R * 1.36, R * 0.27, -0.18 + Math.sin(state.time * 0.05) * 0.03, 0, Math.PI * 2); g.stroke();
  }

  function frame(now) {
    if (!state.running) return;
    requestAnimationFrame(frame);
    const step = Math.min((now - state.last) / 1000, 0.1) * (calm.matches ? 0.3 : 1);
    state.last = now;
    state.time += step;
    const look = LOOK[state.phase] || LOOK.waiting;
    const ease = (from, to, speed) => from + (to - from) * Math.min(step * speed, 1);
    state.spin = ease(state.spin, look.spin, 1.5);
    state.glow = ease(state.glow, look.glow, 2);
    state.pulse = state.phase === "speaking" ? ease(state.pulse, Math.abs(Math.sin(now / 190)), 10) : ease(state.pulse, 0, 3);
    if (document.body.dataset.view === "presence") {
      drawCore(bigCanvas, 0.3);
      return;
    }
    if (fit(back) || !state.grain) seedHaze();
    drawBack(step);
    drawCore(coreCanvas, 0.33);
  }

  function update() {
    const go = state.on && !document.hidden;
    if (go && !state.running) {
      state.running = true;
      state.last = performance.now();
      fit(back);
      seedHaze();
      requestAnimationFrame(frame);
    } else if (!go) state.running = false;
  }

  document.addEventListener("visibilitychange", update);
  new MutationObserver(update).observe(document.body, { attributes: true, attributeFilter: ["data-view"] });
  window.irisCipher = {
    show(on) { state.on = Boolean(on); update(); },
    phase(name) { state.phase = name; },
  };
})();
