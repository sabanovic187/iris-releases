// The IRIS core: a living cloud of light. Every point is worked out on the graphics card, so nothing is stored.
(function () {
  "use strict";
  const canvas = document.getElementById("presence");
  const MOST = 420000;
  const FEWEST = 60000;
  const SLOW_FRAME_MS = 28;
  const LOOKS = {
    //            colour              heat             size  rough  spin  rings  hush
    waiting:   { a: [0.1, 0.42, 1],   b: [0.6, 0.92, 1], size: 0.62, rough: 0.1, spin: 0.08, rings: 0.45, calm: 1 },
    listening: { a: [0.25, 0.75, 1],  b: [0.9, 1, 1],    size: 0.7,  rough: 0.14, spin: 0.12, rings: 0.8, calm: 1 },
    thinking:  { a: [0.32, 0.2, 1],   b: [0.55, 0.85, 1], size: 0.52, rough: 0.2, spin: 0.75, rings: 1, calm: 1 },
    working:   { a: [0.05, 0.75, 0.6], b: [0.6, 1, 0.85], size: 0.56, rough: 0.2, spin: 1.1, rings: 1, calm: 1 },
    speaking:  { a: [0.12, 0.55, 1],  b: [0.8, 0.97, 1], size: 0.66, rough: 0.12, spin: 0.2, rings: 0.7, calm: 1 },
    needs_you: { a: [1, 0.5, 0.08],   b: [1, 0.86, 0.5], size: 0.6,  rough: 0.16, spin: 0.15, rings: 0.9, calm: 1 },
    owner:     { a: [0.3, 0.38, 0.45], b: [0.6, 0.68, 0.74], size: 0.44, rough: 0.05, spin: 0.03, rings: 0.2, calm: 0.5 },
    stopped:   { a: [1, 0.08, 0.05],  b: [1, 0.45, 0.35], size: 0.3,  rough: 0.04, spin: 0.02, rings: 0, calm: 0.35 },
  };
  // Unbound mode turns the core clinical red with white heat; warnings keep their own colours.
  const UNBOUND = { a: [0.89, 0.1, 0.13], b: [1, 0.93, 0.92], rough: 0.02, spin: -0.02 };
  const KEEP_COLOUR = new Set(["needs_you", "stopped", "owner"]);
  const VERTEX = `#version 300 es
  precision highp float;
  uniform float uTime, uCount, uAspect, uSize, uRough, uTurn, uRings, uSound, uFold, uPoint;
  uniform vec2 uLook;
  out float vHeat; out float vFade;
  vec3 m289(vec3 x) { return x - floor(x / 289.) * 289.; }
  vec4 m289(vec4 x) { return x - floor(x / 289.) * 289.; }
  vec4 perm(vec4 x) { return m289((x * 34. + 10.) * x); }
  float noise(vec3 v) {
    const vec2 C = vec2(1. / 6., 1. / 3.);
    vec3 i = floor(v + dot(v, C.yyy)), x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz), l = 1. - g;
    vec3 i1 = min(g, l.zxy), i2 = max(g, l.zxy);
    vec3 x1 = x0 - i1 + C.x, x2 = x0 - i2 + C.y, x3 = x0 - .5;
    i = m289(i);
    vec4 p = perm(perm(perm(i.z + vec4(0., i1.z, i2.z, 1.)) + i.y + vec4(0., i1.y, i2.y, 1.)) + i.x + vec4(0., i1.x, i2.x, 1.));
    vec3 ns = .142857142857 * vec3(2., .5, 1.) - vec3(0., 1., 0.);
    vec4 j = p - 49. * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z), y_ = floor(j - 7. * x_);
    vec4 x = x_ * ns.x + ns.yyyy, y = y_ * ns.x + ns.yyyy, h = 1. - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy), b1 = vec4(x.zw, y.zw), s0 = floor(b0) * 2. + 1., s1 = floor(b1) * 2. + 1., sh = -step(h, vec4(0.));
    vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy, a1 = b1.xzyw + s1.xzyw * sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x), p1 = vec3(a0.zw, h.y), p2 = vec3(a1.xy, h.z), p3 = vec3(a1.zw, h.w);
    vec4 n = 1.79284291400159 - .85373472095314 * vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3));
    p0 *= n.x; p1 *= n.y; p2 *= n.z; p3 *= n.w;
    vec4 m = max(.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.);
    return 42. * dot(m * m * m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
  }
  mat2 spin(float a) { float c = cos(a), s = sin(a); return mat2(c, s, -s, c); }
  float hash(float n) { return fract(sin(n * 12.9898) * 43758.5453); }
  void main() {
    float i = float(gl_VertexID), seed = hash(i), kind = hash(i + 7.);
    float y = 1. - 2. * (i + .5) / uCount, r = sqrt(max(0., 1. - y * y)), a = i * 2.39996323;
    vec3 dir = vec3(cos(a) * r, y, sin(a) * r), p;
    vHeat = seed;
    vFade = 1.;
    if (kind < .72) {
      // The body: a shell whose surface flows like liquid light.
      float t = uTime * .22;
      vec3 q = dir * 1.45 + vec3(0., t, t * .6);
      float big = noise(q), fine = noise(dir * 4.2 + big + t * 1.7);
      float folded = big * .8 + fine * .28;
      float reach = 1. + folded * (uRough + uSound * .4) * 1.5 + uFold * sin(dir.y * 16. + uTime * 7.) * .05 * (1. + uSound * 2.);
      reach += pow(max(fine, 0.), 3.) * (.1 + uSound * .9) * seed;
      p = dir * uSize * reach;
      vHeat = clamp(.2 + big * .9 + fine * .5 + uSound * .5, 0., 1.);
    } else if (kind < .84) {
      // The heart: a dense bright centre.
      float depth = pow(seed, 2.6);
      p = dir * uSize * (.1 + depth * .42) * (1. + uSound * .55 + sin(uTime * 1.2) * .03);
      vHeat = 1.;
      vFade = .55;
    } else if (kind < .955) {
      // Three thin orbits.
      float which = floor(seed * 3.), tilt = 1.15 + which * 1.05, along = a * .37 + uTime * uTurn * (1.6 + which * .7) * (mod(which, 2.) * 2. - 1.);
      float band = uSize * (1.34 + which * .17 + (hash(i + 3.) - .5) * .014) * (1. + uSound * .1);
      p = vec3(cos(along) * band, sin(along) * band, (hash(i + 5.) - .5) * .012);
      p.yz = spin(tilt) * p.yz;
      p.xy = spin(which * 1.9 + uTime * .05) * p.xy;
      vHeat = .85;
      vFade = uRings * (.25 + .75 * smoothstep(.2, 1., .5 + .5 * sin(along * 3. + uTime)));
    } else {
      // Sparks that leave the surface and fade.
      float life = fract(seed * 13.1 + uTime * (.06 + seed * .12));
      p = dir * uSize * (1.02 + life * life * (1.1 + uSound * 1.4));
      p.xz = spin(life * .9) * p.xz;
      vHeat = 1. - life * .6;
      vFade = (1. - life) * (1. - life) * smoothstep(0., .08, life);
    }
    p.xz = spin(uTime * uTurn * .4 + uLook.x * .55) * p.xz;
    p.yz = spin(uLook.y * .35 + .08) * p.yz;
    float depth = 3.1 - p.z;
    vFade *= smoothstep(-1.7, .25, p.z) * .85 + .15;
    gl_Position = vec4(p.x * 3.1 / depth / uAspect, p.y * 3.1 / depth, 0., 1.);
    gl_PointSize = uPoint * (.6 + seed * .9) * 3.1 / depth;
  }`;
  const FRAGMENT = `#version 300 es
  precision mediump float;
  in float vHeat; in float vFade; uniform vec3 uColorA, uColorB; uniform float uGain; out vec4 color;
  void main() {
    float d = length(gl_PointCoord - .5) * 2.;
    float a = smoothstep(1., 0., d);
    vec3 c = mix(uColorA, uColorB, vHeat * vHeat);
    color = vec4(c * a * a * vFade * uGain, 1.);
  }`;
  const state = { gl: null, phase: "waiting", set: {}, running: false, count: MOST, last: 0, look: [0, 0], aim: [0, 0], sound: 0, soundAim: 0, clock: 0, slow: 0, value: { ...LOOKS.waiting } };

  function shader(gl, kind, text) {
    const item = gl.createShader(kind);
    gl.shaderSource(item, text);
    gl.compileShader(item);
    if (!gl.getShaderParameter(item, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(item));
    return item;
  }

  function start() {
    const gl = canvas.getContext("webgl2", { antialias: false, alpha: false, powerPreference: "high-performance" });
    if (!gl) throw new Error("no webgl");
    const program = gl.createProgram();
    gl.attachShader(program, shader(gl, gl.VERTEX_SHADER, VERTEX));
    gl.attachShader(program, shader(gl, gl.FRAGMENT_SHADER, FRAGMENT));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
    gl.useProgram(program);
    gl.bindVertexArray(gl.createVertexArray());
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE);
    gl.clearColor(0, 0, 0, 1);
    for (const name of ["uTime", "uCount", "uAspect", "uSize", "uRough", "uTurn", "uRings", "uSound", "uFold", "uPoint", "uLook", "uColorA", "uColorB", "uGain"]) {
      state.set[name] = gl.getUniformLocation(program, name);
    }
    state.gl = gl;
    addEventListener("resize", resize);
    addEventListener("pointermove", (event) => {
      state.aim = [(event.clientX / innerWidth - 0.5) * 2, (event.clientY / innerHeight - 0.5) * 2];
    });
    resize();
    show(document.body.dataset.view === "presence");
  }

  function resize() {
    if (!canvas.clientWidth || !state.gl) return;
    const ratio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = canvas.clientWidth * ratio;
    canvas.height = canvas.clientHeight * ratio;
    state.gl.viewport(0, 0, canvas.width, canvas.height);
    state.gl.uniform1f(state.set.uAspect, canvas.width / canvas.height);
    state.gl.uniform1f(state.set.uPoint, Math.max(1.5, canvas.height / 560));
  }

  function frame(now) {
    if (!state.running) return;
    requestAnimationFrame(frame);
    const gl = state.gl;
    const passed = now / 1000 - state.last;
    state.last = now / 1000;
    const step = Math.min(passed, 0.1);
    // A slower computer simply draws fewer points.
    state.slow = passed * 1000 > SLOW_FRAME_MS ? state.slow + 1 : Math.max(0, state.slow - 1);
    if (state.slow > 40 && state.count > FEWEST) {
      state.count = Math.max(FEWEST, Math.round(state.count * 0.75));
      state.slow = 0;
    }
    const ease = (from, to, speed) => from + (to - from) * Math.min(step * speed, 1);
    let look = LOOKS[state.phase] || LOOKS.waiting;
    if (state.theme === "unbound" && !KEEP_COLOUR.has(state.phase)) {
      look = { ...look, a: UNBOUND.a, b: UNBOUND.b, rough: look.rough + UNBOUND.rough, spin: look.spin + UNBOUND.spin };
    }
    const value = state.value;
    for (const name of ["size", "rough", "spin", "rings", "calm"]) value[name] = ease(value[name], look[name], 2.6);
    value.a = value.a.map((item, index) => ease(item, look.a[index], 3));
    value.b = value.b.map((item, index) => ease(item, look.b[index], 3));
    state.look = [ease(state.look[0], state.aim[0], 2), ease(state.look[1], state.aim[1], 2)];
    state.soundAim = Math.max(0, state.soundAim - step * 2.2);
    state.sound = ease(state.sound, state.soundAim, 16);
    state.clock += step * (0.6 + value.spin * 1.2);
    const breath = 1 + Math.sin(now / 1000 * 1.05) * 0.018 * value.calm;
    const set = state.set;
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(set.uTime, state.clock);
    gl.uniform1f(set.uCount, state.count);
    gl.uniform1f(set.uSize, value.size * breath);
    gl.uniform1f(set.uRough, value.rough);
    gl.uniform1f(set.uTurn, value.spin);
    gl.uniform1f(set.uRings, value.rings);
    gl.uniform1f(set.uSound, state.sound);
    gl.uniform1f(set.uFold, state.phase === "speaking" ? 1 : 0);
    gl.uniform2f(set.uLook, state.look[0], state.look[1]);
    gl.uniform3fv(set.uColorA, value.a);
    gl.uniform3fv(set.uColorB, value.b);
    gl.uniform1f(set.uGain, 0.3 * (MOST / state.count) ** 0.5 * (0.9 + value.calm * 0.1));
    gl.drawArrays(gl.POINTS, 0, state.count);
  }

  function show(on) {
    const going = on && Boolean(state.gl) && !document.hidden && state.theme !== "unbound";
    if (going && !state.running) {
      state.running = true;
      state.last = performance.now() / 1000;
      resize();
      requestAnimationFrame(frame);
    } else if (!going) state.running = false;
  }

  document.addEventListener("visibilitychange", () => show(document.body.dataset.view === "presence"));
  try {
    start();
  } catch {
    document.getElementById("presence-problem").hidden = false;
  }
  window.irisPresence = {
    show,
    phase: (name) => { state.phase = name; },
    theme: (name) => { state.theme = name; show(document.body.dataset.view === "presence"); },  // Unbound draws its own core
    sound: (level) => { state.soundAim = Math.max(state.soundAim, Math.min(level, 1)); },
    failed: () => !state.gl,
  };
})();
