"""World Monitor (github.com/koala73/worldmonitor) runs beside IRIS in its own folder, in Docker.

Its code is not part of IRIS: it keeps its own licence (AGPL-3.0, free for personal use with
credit to its author) and is updated from its own repository. IRIS only shows it in the
Situation screen. Two local files adjust it for that:

- iris-nginx.conf lets the IRIS window show World Monitor in a frame. Its own setting only
  allows worldmonitor.app pages.
- docker-compose.override.yml mounts that file and keeps World Monitor on this computer only,
  instead of every network the computer is on.
"""
from __future__ import annotations

import argparse
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FOLDER = ROOT / "worldmonitor"
IRIS_PORT = 8765
FRAME_RULE = 'add_header X-Frame-Options "SAMEORIGIN" always;'
ANCESTORS = "frame-ancestors 'self'"

OVERRIDE = """# Written by IRIS (python -m iris.worldmonitor). Safe to delete; IRIS writes it again.
services:
  worldmonitor:
    ports: !override
      - "127.0.0.1:${{WM_PORT:-{port}}}:8080"
    volumes:
      - ./iris-nginx.conf:/etc/nginx/nginx.conf.template:ro
"""


TABLET_PORT = 8770


def iris_origins(port: int = IRIS_PORT, tablet_port: int = TABLET_PORT) -> str:
    """The IRIS window, and a paired tablet's page on the home network."""
    return f"http://127.0.0.1:{port} http://localhost:{port} http://*:{tablet_port}"


def patch_nginx(text: str, iris_port: int = IRIS_PORT) -> str:
    """Allow the IRIS window as a frame parent; everything else in the file stays as it is."""
    if FRAME_RULE not in text and ANCESTORS not in text:
        raise ValueError("World Monitor's web server settings changed; IRIS cannot adjust them.")
    lines = [line for line in text.splitlines(keepends=True) if line.strip() != FRAME_RULE]
    text = "".join(lines)
    return re.sub(re.escape(ANCESTORS) + r"(?! http://127\.0\.0\.1)", f"{ANCESTORS} {iris_origins(iris_port)}", text)


def write_local_files(folder: Path = FOLDER, port: int = 3000, iris_port: int = IRIS_PORT) -> None:
    source = folder / "docker" / "nginx.conf"
    if not source.exists():
        raise FileNotFoundError(f"World Monitor is not in {folder}. Run scripts\\setup-worldmonitor.ps1.")
    (folder / "iris-nginx.conf").write_text(patch_nginx(source.read_text(encoding="utf-8"), iris_port), encoding="utf-8")
    (folder / "docker-compose.override.yml").write_text(OVERRIDE.format(port=port), encoding="utf-8")


def reachable(port: int, timeout: float = 1.5) -> bool:
    if port <= 0:
        return False
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(f"http://127.0.0.1:{port}/", timeout=timeout) as response:
            return 200 <= response.status < 500
    except (urllib.error.URLError, OSError, ValueError):
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare World Monitor to run beside IRIS.")
    parser.add_argument("--port", type=int, default=3000)
    parser.add_argument("--iris-port", type=int, default=IRIS_PORT)
    parser.add_argument("--folder", type=Path, default=FOLDER)
    args = parser.parse_args()
    try:
        write_local_files(args.folder, args.port, args.iris_port)
    except (OSError, ValueError) as error:
        print(error, file=sys.stderr)
        return 1
    print("World Monitor is prepared for IRIS.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
