"""Decides what each tool call may do. Unknown tools are denied."""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path, PurePath
from typing import Any

ALLOWED_TOOLS = ["Read", "Grep", "Glob", "Write", "Edit", "Bash", "WebSearch", "WebFetch"]
PATH_KEYS = {
    "Read": "file_path",
    "Write": "file_path",
    "Edit": "file_path",
    "Grep": "path",
    "Glob": "path",
}
READ_TOOLS = {"Read", "Grep", "Glob", "WebSearch"}

CONNECTOR_PREFIX = "mcp__connectors__"
TASK_PREFIX = "mcp__iris__"
TASK_ALLOWED = {"list_projects", "list_tasks", "review_task", "start_job", "list_jobs", "read_job", "stop_job"}
TASK_ASK = {"start_task", "continue_task"}

WINDOWS_PREFIX = "mcp__windows__windows_"
WINDOWS_ALLOWED = {"list_windows", "active_window"}
WINDOWS_ASK = {
    "snapshot", "get_text", "screenshot", "focus", "click",
    "type", "fill", "send_keys", "close", "launch",
}
CHANGE_TOOLS = {"Write", "Edit", "Bash"}

SENSITIVE_NAMES = re.compile(
    r"(?i)^(\.env(\..+)?|id_(rsa|dsa|ecdsa|ed25519)|credentials(\.json)?|.*\.(pem|key|pfx|p12|kdbx))$"
)
SENSITIVE_DIRS = {".ssh", ".aws", ".gnupg", ".azure"}

# These catch obvious mistakes. The real safeguard for Bash is owner approval.
BLOCKED_COMMANDS = [
    (r"\brm\s+(-\w*\s+)*-\w*[rf]\w*\b", "recursive or forced delete"),
    (r"(?i)\bremove-item\b.*-(recurse|force)\b", "recursive or forced delete"),
    (r"(?i)\b(rd|rmdir)\s+/s\b", "recursive delete"),
    (r"(?i)\bdel\s+.*/[sfq]\b", "forced delete"),
    (r"(?i)\b(format|diskpart|mkfs|bcdedit|cipher\s+/w)\b", "disk operation"),
    (r"(?i)\b(shutdown|stop-computer|restart-computer)\b", "machine shutdown"),
    (r"(?i)\breg(\.exe)?\s+(delete|add)\b", "registry change"),
    (r"(?i)\b(set-executionpolicy|invoke-expression|iex)\b", "unsafe PowerShell"),
    (r"(?i)-e(nc|ncodedcommand)?\s+[A-Za-z0-9+/=]{16,}", "encoded command"),
    (r"(?i)\b(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)\b.*\|\s*(ba|z)?sh\b", "piping a download into a shell"),
    (r"(?i)\bgit\s+push\b.*(--force|-f\b)", "force push"),
    (r"(?i)\bgit\s+(reset\s+--hard|clean\s+-\w*f)", "destructive git command"),
]


# Branches and merges stay with IRIS and the owner during development tasks.
TASK_BLOCKED_COMMANDS = [
    (
        r"(?i)\bgit\b.*\b(push|pull|fetch|merge|rebase|checkout|switch|branch|worktree|remote|reset|tag|config)\b",
        "git branch operations are handled by IRIS",
    ),
]


class Decision(str, Enum):
    ALLOW = "allow"
    ASK = "ask"
    DENY = "deny"


@dataclass(frozen=True)
class Verdict:
    decision: Decision
    reason: str


def _contains_sensitive_part(path: PurePath) -> bool:
    return any(part.lower() in SENSITIVE_DIRS for part in path.parts) or bool(
        SENSITIVE_NAMES.match(path.name)
    )


class Policy:
    def __init__(
        self,
        workspace: Path,
        level: int,
        allowed_apps: tuple[str, ...] = (),
        task_mode: bool = False,
        connector_risks: dict[str, str] | None = None,
        mcp_servers: tuple[dict[str, Any], ...] = (),
    ) -> None:
        self.workspace = workspace.resolve()
        self.level = level
        self.allowed_apps = {app.lower() for app in allowed_apps}
        self.task_mode = task_mode
        self.connector_risks = connector_risks or {}
        self.mcp_read_tools = {
            f"mcp__{server['name']}__{tool}" for server in mcp_servers for tool in server.get("read_tools", [])
        }
        self.mcp_prefixes = tuple(f"mcp__{server['name']}__" for server in mcp_servers)

    def _evaluate_connector(self, tool: str) -> Verdict:
        action = tool.removeprefix(CONNECTOR_PREFIX)
        risk = self.connector_risks.get(action)
        if self.task_mode or risk is None:
            return Verdict(Decision.DENY, f"{action} is not allowed")
        if risk == "read":
            return Verdict(Decision.ALLOW, "reads a connected app")
        if self.level < 3:
            return Verdict(Decision.DENY, "level 1 is read-only")
        return Verdict(Decision.ASK, "changes something in a connected app")

    def _evaluate_extra_server(self, tool: str) -> Verdict:
        if self.task_mode:
            return Verdict(Decision.DENY, "extra tools are off during development tasks")
        if tool in self.mcp_read_tools:
            return Verdict(Decision.ALLOW, "listed as read-only in settings")
        if self.level < 3:
            return Verdict(Decision.DENY, "level 1 is read-only")
        return Verdict(Decision.ASK, "extra tool needs owner approval")

    def _evaluate_windows(self, tool: str, args: dict[str, Any]) -> Verdict:
        action = tool.removeprefix(WINDOWS_PREFIX)
        if action in WINDOWS_ALLOWED:
            return Verdict(Decision.ALLOW, "lists open windows")
        if action not in WINDOWS_ASK:
            return Verdict(Decision.DENY, f"{action} is not allowed")
        if action == "screenshot" and args.get("savePath"):
            return Verdict(Decision.DENY, "screenshots cannot be saved to disk")
        if action == "launch":
            if str(args.get("app", "")).lower() not in self.allowed_apps:
                return Verdict(Decision.DENY, "this app is not on the allowed list")
            if args.get("args"):
                return Verdict(Decision.DENY, "starting apps with arguments is not allowed")
        if self.level < 3 and action not in ("snapshot", "get_text", "screenshot"):
            return Verdict(Decision.DENY, "level 1 is read-only")
        return Verdict(Decision.ASK, "needs owner approval")

    def _check_path(self, raw: str) -> str | None:
        if raw.strip().startswith("~"):
            return "home folder paths are outside the workspace"
        candidate = Path(raw)
        if not candidate.is_absolute():
            candidate = self.workspace / candidate
        try:
            resolved = candidate.resolve()
        except (OSError, RuntimeError):
            return "the path could not be resolved"
        if not resolved.is_relative_to(self.workspace):
            return f"{raw} is outside the workspace"
        if _contains_sensitive_part(resolved):
            return f"{raw} looks like a secret file"
        if self.task_mode and ".git" in resolved.parts:
            return "the Git folder is off limits"
        return None

    def evaluate(self, tool: str, args: dict[str, Any]) -> Verdict:
        if tool.startswith(WINDOWS_PREFIX):
            return self._evaluate_windows(tool, args)
        if tool.startswith(CONNECTOR_PREFIX):
            return self._evaluate_connector(tool)
        if self.mcp_prefixes and tool.startswith(self.mcp_prefixes):
            return self._evaluate_extra_server(tool)
        if tool.startswith(TASK_PREFIX):
            action = tool.removeprefix(TASK_PREFIX)
            if action in TASK_ALLOWED:
                return Verdict(Decision.ALLOW, "reads task status")
            if action in TASK_ASK and self.level >= 3:
                return Verdict(Decision.ASK, "starts paid development work")
            return Verdict(Decision.DENY, f"{action} is not allowed")
        if tool not in ALLOWED_TOOLS:
            return Verdict(Decision.DENY, f"{tool} is not on the allowed tool list")

        key = PATH_KEYS.get(tool)
        if key:
            problem = self._check_path(str(args.get(key) or "."))
            if problem:
                return Verdict(Decision.DENY, problem)
        if tool == "Glob":
            pattern = str(args.get("pattern", ""))
            if "{" in pattern or ".." in PurePath(pattern).parts:
                return Verdict(Decision.DENY, "the pattern leaves the workspace")
            start = re.split(r"[*?\[]", pattern)[0]
            problem = self._check_path(start) if start else None
            if problem:
                return Verdict(Decision.DENY, problem)

        if tool == "Bash":
            command = str(args.get("command", ""))
            rules = BLOCKED_COMMANDS + (TASK_BLOCKED_COMMANDS if self.task_mode else [])
            for pattern, label in rules:
                if re.search(pattern, command):
                    return Verdict(Decision.DENY, f"blocked command: {label}")

        if tool in READ_TOOLS:
            return Verdict(Decision.ALLOW, "read-only")
        if self.level < 3 and tool in CHANGE_TOOLS:
            return Verdict(Decision.DENY, "level 1 is read-only")
        if self.task_mode and tool in ("Write", "Edit"):
            return Verdict(Decision.ALLOW, "isolated task branch")
        return Verdict(Decision.ASK, "needs owner approval")
