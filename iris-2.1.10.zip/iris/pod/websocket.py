"""A small WebSocket server side (RFC 6455): enough for the IRIS Pod, with no extra library."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import struct

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
TEXT, BINARY, CLOSE, PING, PONG, CONTINUATION = 0x1, 0x2, 0x8, 0x9, 0xA, 0x0
MAX_MESSAGE = 1024 * 1024


class Closed(Exception):
    pass


def accept_key(key: str) -> str:
    return base64.b64encode(hashlib.sha1((key + GUID).encode("ascii")).digest()).decode("ascii")


def handshake(headers: dict[str, str]) -> bytes | None:
    """The answer that turns an HTTP request into a WebSocket, or None if it is not one."""
    if headers.get("upgrade", "").lower() != "websocket" or "sec-websocket-key" not in headers:
        return None
    return (
        "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept_key(headers['sec-websocket-key'])}\r\n\r\n"
    ).encode("ascii")


def frame(opcode: int, payload: bytes) -> bytes:
    """A server frame: final, unmasked."""
    size = len(payload)
    if size < 126:
        head = struct.pack("!BB", 0x80 | opcode, size)
    elif size < 65536:
        head = struct.pack("!BBH", 0x80 | opcode, 126, size)
    else:
        head = struct.pack("!BBQ", 0x80 | opcode, 127, size)
    return head + payload


class WebSocket:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        self.reader = reader
        self.writer = writer
        self.closed = False
        self.lock = asyncio.Lock()

    async def _read_frame(self) -> tuple[bool, int, bytes]:
        first, second = await self.reader.readexactly(2)
        final, opcode, masked, size = bool(first & 0x80), first & 0x0F, bool(second & 0x80), second & 0x7F
        if size == 126:
            (size,) = struct.unpack("!H", await self.reader.readexactly(2))
        elif size == 127:
            (size,) = struct.unpack("!Q", await self.reader.readexactly(8))
        if size > MAX_MESSAGE:
            raise Closed("message too large")
        mask = await self.reader.readexactly(4) if masked else b""
        data = await self.reader.readexactly(size)
        if masked:
            data = bytes(byte ^ mask[i % 4] for i, byte in enumerate(data))
        return final, opcode, data

    async def receive(self) -> tuple[int, bytes]:
        """The next whole message as (TEXT or BINARY, data). Pings are answered here."""
        parts: list[bytes] = []
        kind = 0
        try:
            while True:
                final, opcode, data = await self._read_frame()
                if opcode == PING:
                    await self._send(PONG, data)
                    continue
                if opcode == PONG:
                    continue
                if opcode == CLOSE:
                    await self.close()
                    raise Closed("closed by the other side")
                if opcode != CONTINUATION:
                    kind = opcode
                parts.append(data)
                if sum(len(part) for part in parts) > MAX_MESSAGE:
                    raise Closed("message too large")
                if final:
                    return kind, b"".join(parts)
        except (asyncio.IncompleteReadError, ConnectionError) as error:
            self.closed = True
            raise Closed("connection lost") from error

    async def _send(self, opcode: int, payload: bytes) -> None:
        if self.closed:
            raise Closed("already closed")
        async with self.lock:
            try:
                self.writer.write(frame(opcode, payload))
                await self.writer.drain()
            except ConnectionError as error:
                self.closed = True
                raise Closed("connection lost") from error

    async def send_text(self, text: str) -> None:
        await self._send(TEXT, text.encode("utf-8"))

    async def send_binary(self, data: bytes) -> None:
        await self._send(BINARY, data)

    async def close(self) -> None:
        if self.closed:
            return
        try:
            await self._send(CLOSE, struct.pack("!H", 1000))
        except Closed:
            pass
        self.closed = True
        try:
            self.writer.close()
        except Exception:
            pass
