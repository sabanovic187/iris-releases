"""Sound for the IRIS Pod: Opus in and out through PyAV, and a simple ear for when speech ends.

The Pod sends 16 kHz mono Opus in 60 ms frames and plays whatever Opus IRIS sends back.
PyAV carries libopus, so no other library is needed.
"""
from __future__ import annotations

from typing import Iterator

import numpy as np

POD_RATE = 16000  # what the Pod records
REPLY_RATE = 24000  # what IRIS sends back
FRAME_MS = 60
QUIETEST_SPEECH = 60.0  # loudness (RMS of 16-bit samples) below which nothing counts as speech; the Pod's microphone is quiet
LOUDEST_THRESHOLD = 150.0
ROOM_FACTOR = 3.0
TARGET_PEAK = 16000.0
MAX_GAIN = 20.0


def _av() -> object:
    import av  # loaded only when a Pod connects

    return av


class OpusDecoder:
    """Opus packets from the Pod become 16 kHz 16-bit samples."""

    def __init__(self, rate: int = POD_RATE) -> None:
        av = _av()
        self.codec = av.CodecContext.create("libopus", "r")
        self.codec.sample_rate = rate
        self.codec.layout = "mono"
        self.resampler = av.AudioResampler(format="s16", layout="mono", rate=rate)
        self.av = av

    def decode(self, packet: bytes) -> np.ndarray:
        parts = []
        for frame in self.codec.decode(self.av.Packet(packet)):
            for out in self.resampler.resample(frame):
                parts.append(out.to_ndarray().reshape(-1))
        return np.concatenate(parts).astype(np.int16) if parts else np.zeros(0, dtype=np.int16)


class OpusEncoder:
    """16-bit samples at any rate become 60 ms Opus packets at 24 kHz for the Pod's speaker."""

    def __init__(self, rate: int = REPLY_RATE) -> None:
        av = _av()
        self.av = av
        self.rate = rate
        self.codec = av.CodecContext.create("libopus", "w")
        self.codec.sample_rate = rate
        self.codec.layout = "mono"
        self.codec.format = "s16"
        self.codec.options = {"frame_duration": str(FRAME_MS), "application": "voip"}
        self.codec.open()
        self.size = self.codec.frame_size  # samples in one 60 ms packet
        self.left = np.zeros(0, dtype=np.int16)
        self.pts = 0
        self.resamplers: dict[int, object] = {}

    def _to_rate(self, samples: np.ndarray, rate: int) -> np.ndarray:
        if rate == self.rate or not len(samples):
            return samples.astype(np.int16)
        if rate not in self.resamplers:
            self.resamplers[rate] = self.av.AudioResampler(format="s16", layout="mono", rate=self.rate)
        frame = self.av.AudioFrame.from_ndarray(samples.astype(np.int16).reshape(1, -1), format="s16", layout="mono")
        frame.sample_rate = rate
        out = [part.to_ndarray().reshape(-1) for part in self.resamplers[rate].resample(frame)]
        return np.concatenate(out).astype(np.int16) if out else np.zeros(0, dtype=np.int16)

    def _packets(self, samples: np.ndarray) -> Iterator[bytes]:
        for start in range(0, len(samples) - self.size + 1, self.size):
            frame = self.av.AudioFrame.from_ndarray(samples[start:start + self.size].reshape(1, -1), format="s16", layout="mono")
            frame.sample_rate = self.rate
            frame.pts = self.pts
            self.pts += self.size
            for packet in self.codec.encode(frame):
                yield bytes(packet)

    def encode(self, samples: np.ndarray, rate: int) -> Iterator[bytes]:
        joined = np.concatenate([self.left, self._to_rate(samples, rate)])
        whole = len(joined) - len(joined) % self.size
        self.left = joined[whole:]
        yield from self._packets(joined[:whole])

    def finish(self) -> Iterator[bytes]:
        """Pad the last piece with silence so the end of a sentence is not cut."""
        if len(self.left):
            padded = np.concatenate([self.left, np.zeros(self.size - len(self.left), dtype=np.int16)])
            self.left = np.zeros(0, dtype=np.int16)
            yield from self._packets(padded)
        for packet in self.codec.encode(None):  # what the encoder still holds
            yield bytes(packet)


class SpeechEnd:
    """Decides when the owner has finished speaking, from loudness alone.

    The room's own noise is measured at the start, so a fan or a quiet street does not count as speech.
    """

    def __init__(self, silence_s: float = 0.8, no_speech_s: float = 7.0, longest_s: float = 20.0) -> None:
        self.silence_s = silence_s
        self.no_speech_s = no_speech_s
        self.longest_s = longest_s
        self.reset()

    def reset(self) -> None:
        self.samples: list[np.ndarray] = []
        self.heard = 0.0
        self.spoke = False
        self.loud_run = 0
        self.quiet = 0.0
        self.room: list[float] = []
        self.loudest = 0.0

    @property
    def noise(self) -> float:
        return float(np.median(self.room)) if self.room else 0.0

    @property
    def threshold(self) -> float:
        """Speech is this loud. Talking straight away cannot raise it beyond normal speech."""
        return max(QUIETEST_SPEECH, min(self.noise * ROOM_FACTOR, LOUDEST_THRESHOLD))

    def add(self, block: np.ndarray, rate: int = POD_RATE) -> str:
        """Returns "listening", "done" (speech ended) or "nothing" (no speech came)."""
        if not len(block):
            return "listening"
        seconds = len(block) / rate
        self.heard += seconds
        level = float(np.sqrt(np.mean(np.square(block.astype(np.float32)))))
        self.loudest = max(self.loudest, level)
        if len(self.room) < 4:  # the first quarter second sets the room's noise
            self.room.append(level)
        loud = level > self.threshold
        if self.spoke or loud:
            self.samples.append(block)
        if loud:
            self.loud_run += 1
            self.quiet = 0.0
            if self.loud_run >= 2:
                self.spoke = True
        else:
            self.loud_run = 0
            if self.spoke:
                self.quiet += seconds
        if self.spoke and (self.quiet >= self.silence_s or self.heard >= self.longest_s):
            return "done"
        if not self.spoke and self.heard >= self.no_speech_s:
            return "nothing"
        return "listening"

    def speech(self) -> np.ndarray:
        """What was said, raised to a normal level so quiet speech is understood too."""
        if not self.samples:
            return np.zeros(0, dtype=np.int16)
        joined = np.concatenate(self.samples).astype(np.float32)
        peak = float(np.max(np.abs(joined))) or 1.0
        gain = min(MAX_GAIN, TARGET_PEAK / peak) if peak < TARGET_PEAK else 1.0
        return np.clip(joined * gain, -32768, 32767).astype(np.int16)
