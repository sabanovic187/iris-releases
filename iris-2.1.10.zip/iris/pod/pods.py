"""Which IRIS Pods may talk to IRIS.

A new Pod shows a six-digit code on its screen. Typing that code in IRIS Settings on the computer
pairs it. A Pod is then known by its network card address (Device-Id) and the random id its
firmware made (Client-Id); both arrive with every request.
"""
from __future__ import annotations

import json
import secrets
import threading
import time
from pathlib import Path
from typing import Any, Callable

PENDING_SECONDS = 15 * 60
MAX_PENDING = 5


class Pods:
    def __init__(self, path: Path, clock: Callable[[], float] = time.time) -> None:
        self.path = path
        self.clock = clock
        self.lock = threading.Lock()
        self.pending: dict[str, dict[str, Any]] = {}  # device id -> code, client, since

    def _load(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            return []

    def _save(self, pods: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(pods, indent=2), encoding="utf-8")

    def known(self, device: str, client: str) -> dict[str, Any] | None:
        device, client = device.lower(), client.lower()
        with self.lock:
            for pod in self._load():
                if pod["device"] == device and pod["client"] == client:
                    return pod
        return None

    def seen(self, device: str) -> None:
        with self.lock:
            pods = self._load()
            for pod in pods:
                if pod["device"] == device.lower():
                    pod["seen"] = self.clock()
            self._save(pods)

    def offer(self, device: str, client: str) -> str:
        """The code an unknown Pod shows. The same code is kept while it waits."""
        device, client = device.lower(), client.lower()
        now = self.clock()
        with self.lock:
            self.pending = {key: item for key, item in self.pending.items() if now - item["since"] < PENDING_SECONDS}
            item = self.pending.get(device)
            if item and item["client"] == client:
                return item["code"]
            if len(self.pending) >= MAX_PENDING:
                oldest = min(self.pending, key=lambda key: self.pending[key]["since"])
                del self.pending[oldest]
            code = f"{secrets.randbelow(1_000_000):06d}"
            self.pending[device] = {"code": code, "client": client, "since": now}
            return code

    def pair(self, code: str, name: str = "IRIS Pod") -> dict[str, Any] | None:
        code = code.strip()
        now = self.clock()
        with self.lock:
            for device, item in list(self.pending.items()):
                if now - item["since"] < PENDING_SECONDS and secrets.compare_digest(item["code"], code):
                    del self.pending[device]
                    pods = [pod for pod in self._load() if pod["device"] != device]
                    pod = {"device": device, "client": item["client"], "name": name[:40] or "IRIS Pod", "paired": now, "seen": now}
                    pods.append(pod)
                    self._save(pods)
                    return pod
        return None

    def remove(self, device: str) -> None:
        with self.lock:
            self._save([pod for pod in self._load() if pod["device"] != device.lower()])

    def listing(self) -> list[dict[str, Any]]:
        with self.lock:
            return [{"device": pod["device"], "name": pod["name"], "seen": pod.get("seen", 0)} for pod in self._load()]

    def waiting(self) -> int:
        now = self.clock()
        with self.lock:
            return sum(1 for item in self.pending.values() if now - item["since"] < PENDING_SECONDS)
