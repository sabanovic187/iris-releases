"""IRIS as the server for the IRIS Pod (an ESP32-S3 board with XiaoZhi firmware).

The Pod asks its "OTA address" where to talk, then opens a WebSocket, streams Opus from its
microphone and plays the Opus that comes back. IRIS answers both on one port on the home network:

  /xiaozhi/ota/            where to talk; an unknown Pod gets a six-digit code to pair it
  /xiaozhi/ota/activate    the Pod waits here until the code is typed in IRIS Settings
  /xiaozhi/v1/             the conversation, for paired Pods only

Speech goes through the same IRIS as typing does, so approvals, the brain and every rule apply.
Nothing is sent to XiaoZhi's own servers.
"""
from __future__ import annotations

import asyncio
import json
import re
import secrets
import threading
import time
import uuid
from datetime import datetime
from typing import Any, Iterator

import numpy as np

from iris.pod.audio import FRAME_MS, REPLY_RATE, OpusDecoder, OpusEncoder, SpeechEnd
from iris.pod.pods import Pods
from iris.pod.websocket import BINARY, TEXT, Closed, WebSocket, handshake

START_GAP = 0.15  # seconds between "speaking starts" and the first sound
END_GAP = 0.3  # extra time for the Pod's own sound buffer before "speaking ends"
PREBUFFER = 4  # packets sent at once so the Pod never runs dry; the rest follow in real time
GOODBYES = re.compile(r"^\s*(thanks|thank you|that's all|that is all|goodbye|bye|hvala|to je sve)[.!\s]*$", re.I)
LINK = re.compile(r"https?://\S+")
MARKS = re.compile(r"[*_`#>|]+")


def speakable(text: str) -> str:
    """What reads well aloud: no links or formatting marks."""
    text = LINK.sub("", text)
    text = MARKS.sub("", text)
    return re.sub(r"\s+", " ", text).strip()


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [part.strip() for part in parts if part.strip()]


def server_time() -> dict[str, Any]:
    now = datetime.now().astimezone()
    offset = now.utcoffset()
    return {"timestamp": int(time.time() * 1000), "timezone_offset": int(offset.total_seconds() // 60) if offset else 0}


def respond(writer: asyncio.StreamWriter, status: int, body: dict[str, Any] | None = None) -> None:
    reason = {200: "OK", 202: "Accepted", 400: "Bad Request", 401: "Unauthorized", 404: "Not Found"}.get(status, "OK")
    data = json.dumps(body or {}).encode("utf-8")
    writer.write(
        f"HTTP/1.1 {status} {reason}\r\nContent-Type: application/json\r\nContent-Length: {len(data)}\r\n"
        "Connection: close\r\n\r\n".encode("ascii") + data
    )


class PodServer:
    def __init__(self, hub: Any, pods: Pods) -> None:
        self.hub = hub
        self.pods = pods

    async def start(self, port: int) -> asyncio.Server:
        return await asyncio.start_server(self._serve, "0.0.0.0", port)

    async def _serve(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        from iris.ui.server import read_request

        try:
            request = await read_request(reader)
            if request is None:
                respond(writer, 400)
            elif request.path.rstrip("/").endswith("/xiaozhi/ota/activate"):
                self._activate(writer, request)
            elif request.path.rstrip("/").endswith("/xiaozhi/ota"):
                self._ota(writer, request)
            elif request.path.rstrip("/").endswith("/xiaozhi/v1"):
                await self._conversation(reader, writer, request)
                return
            else:
                respond(writer, 404)
            await writer.drain()
        except (ConnectionError, asyncio.CancelledError):
            pass
        finally:
            if not writer.is_closing():
                writer.close()

    # Where to talk, and pairing

    def _ota(self, writer: asyncio.StreamWriter, request: Any) -> None:
        device, client = request.headers.get("device-id", ""), request.headers.get("client-id", "")
        if not device or not client:
            respond(writer, 400, {"error": "Device-Id and Client-Id are needed."})
            return
        version = request.headers.get("user-agent", "").rpartition("/")[2] or "0"
        host = request.headers.get("host", "")
        answer: dict[str, Any] = {
            "server_time": server_time(),
            "firmware": {"version": version, "url": ""},  # the Pod keeps its own firmware
            "websocket": {"url": f"ws://{host}/xiaozhi/v1/", "token": "iris", "version": 1},
        }
        if self.pods.known(device, client):
            self.pods.seen(device)
        else:
            code = self.pods.offer(device, client)
            answer["activation"] = {"code": code, "message": f"IRIS code\n{code}\nType it in IRIS Settings", "challenge": secrets.token_hex(16), "timeout_ms": 30000}
            self.hub.publish("pod", self.hub.pod_state())
            self.hub.publish("notice", {"text": "A new IRIS Pod shows a code. Type it in Settings, IRIS Pod."})
        respond(writer, 200, answer)

    def _activate(self, writer: asyncio.StreamWriter, request: Any) -> None:
        known = self.pods.known(request.headers.get("device-id", ""), request.headers.get("client-id", ""))
        respond(writer, 200 if known else 202, {})

    # The conversation

    async def _conversation(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, request: Any) -> None:
        pod = self.pods.known(request.headers.get("device-id", ""), request.headers.get("client-id", ""))
        answer = handshake(request.headers)
        if not pod or not answer:
            respond(writer, 401 if not pod else 400, {"error": "Pair this Pod in IRIS Settings."})
            await writer.drain()
            writer.close()
            return
        writer.write(answer)
        await writer.drain()
        self.pods.seen(pod["device"])
        self.hub.audit.write("pod_connected", pod=pod["name"])
        print(f"IRIS Pod: {pod['name']} connected.", flush=True)
        self.hub.publish("pod", self.hub.pod_state())
        session = PodSession(self, WebSocket(reader, writer), pod)
        try:
            await session.run()
        finally:
            await session.socket.close()

    # Hearing and speaking, shared with Telegram

    def transcribe(self, samples: np.ndarray) -> str:
        return self.hub.speech.transcribe(samples)

    def synthesize(self, text: str) -> Iterator[tuple[np.ndarray, int]]:
        return self.hub.speech.synthesize(text)


class PodSession:
    def __init__(self, server: PodServer, socket: WebSocket, pod: dict[str, Any]) -> None:
        self.server = server
        self.hub = server.hub
        self.socket = socket
        self.pod = pod
        self.session_id = uuid.uuid4().hex
        self.listening = False
        self.ear = SpeechEnd()
        self.decoder: OpusDecoder | None = None
        self.stop_speaking = threading.Event()
        self.turn: asyncio.Task[None] | None = None
        self.leaving = False

    async def send(self, **message: Any) -> None:
        await self.socket.send_text(json.dumps({"session_id": self.session_id, **message}))

    async def run(self) -> None:
        kind, data = await asyncio.wait_for(self.socket.receive(), timeout=10)
        if kind != TEXT or json.loads(data).get("type") != "hello":
            return
        await self.socket.send_text(json.dumps({
            "type": "hello", "transport": "websocket", "session_id": self.session_id,
            "audio_params": {"format": "opus", "sample_rate": REPLY_RATE, "channels": 1, "frame_duration": FRAME_MS},
        }))
        self.decoder = await asyncio.to_thread(OpusDecoder)
        try:
            while not self.leaving:
                kind, data = await self.socket.receive()
                if kind == TEXT:
                    await self._message(json.loads(data))
                elif kind == BINARY and self.listening:
                    await self._hear(data)
        except (Closed, ValueError, asyncio.TimeoutError):
            pass
        finally:
            self.stop_speaking.set()
            if self.turn and not self.turn.done():
                self.turn.cancel()

    async def _message(self, message: dict[str, Any]) -> None:
        kind = message.get("type")
        if kind == "listen":
            state = message.get("state")
            if state == "start":
                self.stop_speaking.set()
                self.listening = True
                self.ear.reset()
            elif state == "stop" and self.listening:
                self._take_turn()
        elif kind == "abort":
            self.stop_speaking.set()

    async def _hear(self, packet: bytes) -> None:
        samples = self.decoder.decode(packet) if self.decoder else np.zeros(0, dtype=np.int16)
        verdict = self.ear.add(samples)
        if verdict == "done":
            self._take_turn()
        elif verdict == "nothing":
            print(f"IRIS Pod: heard no speech (loudest {self.ear.loudest:.0f}, room {self.ear.noise:.0f}, needed {self.ear.threshold:.0f}).", flush=True)
            self.listening = False
            self.leaving = True  # nobody spoke: the Pod goes back to waiting

    def _take_turn(self) -> None:
        self.listening = False
        if self.turn and not self.turn.done():
            return
        self.turn = asyncio.create_task(self._turn(self.ear.speech()))

    async def _turn(self, speech: np.ndarray) -> None:
        text = await asyncio.to_thread(self.server.transcribe, speech) if len(speech) else ""
        if not text:
            print("IRIS Pod: heard sound but no words.", flush=True)
            self.listening = True
            self.ear.reset()
            return
        print(f"IRIS Pod: heard \"{text}\"", flush=True)
        await self.send(type="stt", text=text)
        await self.send(type="llm", emotion="thinking", text="🤔")
        reply = await self._ask(text)
        await self.speak(reply)
        if GOODBYES.match(text):
            self.leaving = True
            await self.socket.close()

    async def _ask(self, text: str) -> str:
        from iris.ui.hub import Busy

        try:
            reply = await self.hub.send(text.lstrip("/"))  # commands stay on the computer
        except Busy:
            return "One moment, I am still on the last request."
        reply = reply or self.hub.last_spoken
        self.hub.last_spoken = ""
        return speakable(reply) or "Done."

    async def speak(self, text: str) -> None:
        self.stop_speaking.clear()
        await self.send(type="llm", emotion="neutral", text="🙂")
        await self.send(type="tts", state="start")
        await asyncio.sleep(START_GAP)  # the Pod plays sound only once it has switched to speaking
        loop = asyncio.get_running_loop()
        playing_until = time.monotonic()  # when the Pod will have played everything sent so far
        packets, problems = 0, []
        for sentence in sentences(text):
            if self.stop_speaking.is_set():
                break
            await self.send(type="tts", state="sentence_start", text=sentence)
            queue: asyncio.Queue[bytes | None] = asyncio.Queue()

            def produce(line: str = sentence) -> None:
                try:
                    encoder = OpusEncoder()
                    for samples, rate in self.server.synthesize(line):
                        if self.stop_speaking.is_set():
                            break
                        for packet in encoder.encode(samples, rate):
                            loop.call_soon_threadsafe(queue.put_nowait, packet)
                    for packet in encoder.finish():
                        loop.call_soon_threadsafe(queue.put_nowait, packet)
                except Exception as error:  # reported below; the Pod still gets the text
                    problems.append(f"{type(error).__name__}: {error}")
                finally:
                    loop.call_soon_threadsafe(queue.put_nowait, None)

            worker = threading.Thread(target=produce, daemon=True)
            worker.start()
            while True:
                packet = await queue.get()
                if packet is None or self.stop_speaking.is_set():
                    break
                await self.socket.send_binary(packet)
                packets += 1
                playing_until = max(playing_until, time.monotonic()) + FRAME_MS / 1000
                wait = playing_until - PREBUFFER * FRAME_MS / 1000 - time.monotonic()
                if wait > 0:
                    await asyncio.sleep(wait)
        # The Pod empties its sound queue when speaking ends, so let it finish first.
        playing_until += END_GAP
        while not self.stop_speaking.is_set() and time.monotonic() < playing_until:
            await asyncio.sleep(min(0.05, playing_until - time.monotonic()))
        await self.send(type="tts", state="stop")
        seconds = packets * FRAME_MS / 1000
        if problems:
            print(f"IRIS Pod: no sound for the reply ({problems[0]}).", flush=True)
            self.hub.audit.write("pod_sound_failed", error=problems[0][:300])
        else:
            print(f"IRIS Pod: spoke {seconds:.1f} s of sound ({packets} packets).", flush=True)
