"""IRIS Pod: the small IRIS speaker with a screen."""
