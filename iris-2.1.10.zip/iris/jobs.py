"""Background jobs: research, reports and follow-ups that run while the owner does other things.

A job is its own Claude session with the smart model, working in its own folder under
workspace\\jobs. It may search and read the web and read connected apps, and it writes a report.
It cannot run commands, change anything in a connected app, or touch files outside its folder,
because nobody is there to approve such steps while it works. When it ends, IRIS says so on the
screen, aloud and on Telegram.
"""
from __future__ import annotations

import asyncio
import dataclasses
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable

from claude_agent_sdk import tool

from iris.agent import Agent, budget_problem
from iris.gate import ToolGate
from iris.policy import CONNECTOR_PREFIX, Decision, Policy, Verdict

MAX_RUNNING = 2
REPORT = "report.md"
JOB_RULES = """You are IRIS working on a background job for the owner. The owner is not watching and
cannot answer questions, so decide sensibly on your own and say what you assumed.

Job: {goal}

Use web search and the pages you read. Write the result in English to {report} in the current folder:
a short title, the answer first, then the details, and the sources as links at the end. Never invent
figures, quotes or links. If something could not be found, say so in the report.
Finish your last message with two or three sentences that sum up the result."""


class JobPolicy(Policy):
    """What a job may do without anyone there to approve it: read, search, and write in its folder."""

    def __init__(self, folder: Path, level: int, connector_risks: dict[str, str] | None) -> None:
        super().__init__(folder, level, task_mode=True, connector_risks=connector_risks)

    def evaluate(self, tool: str, args: dict[str, Any]) -> Verdict:
        if tool == "Bash":
            return Verdict(Decision.DENY, "background jobs do not run commands")
        if tool == "WebFetch":
            return Verdict(Decision.ALLOW, "reads a public page")
        if tool.startswith(CONNECTOR_PREFIX):
            action = tool.removeprefix(CONNECTOR_PREFIX)
            if (self.connector_risks or {}).get(action) == "read":
                return Verdict(Decision.ALLOW, "reads a connected app")
            return Verdict(Decision.DENY, "background jobs only read connected apps")
        verdict = super().evaluate(tool, args)
        if verdict.decision is Decision.ASK:  # nobody is there to approve while a job works
            return Verdict(Decision.DENY, f"background jobs cannot wait for approval ({verdict.reason})")
        return verdict


class Jobs:
    def __init__(
        self,
        settings: Any,
        memory: Any,
        audit: Any,
        stop: Any,
        approver: Callable[..., Awaitable[bool]],
        finished: Callable[[dict[str, Any]], None],
        servers: Callable[[], dict[str, Any]] = dict,
        risks: Callable[[], dict[str, str] | None] = lambda: None,
    ) -> None:
        self.settings = settings
        self.memory = memory
        self.audit = audit
        self.stop = stop
        self.approver = approver
        self.finished = finished
        self.servers = servers
        self.risks = risks
        self.path = settings.data_dir / "jobs.json"
        self.lock = threading.Lock()
        self.running: dict[int, asyncio.Task[None]] = {}

    # The list of jobs

    def _load(self) -> list[dict[str, Any]]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            return []

    def _save(self, jobs: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(jobs[-100:], indent=2, ensure_ascii=False), encoding="utf-8")

    def _change(self, job_id: int, **fields: Any) -> dict[str, Any]:
        with self.lock:
            jobs = self._load()
            for job in jobs:
                if job["id"] == job_id:
                    job.update(fields)
                    self._save(jobs)
                    return job
        raise KeyError(job_id)

    def get(self, job_id: int) -> dict[str, Any] | None:
        return next((job for job in self._load() if job["id"] == job_id), None)

    def rows(self, limit: int = 8) -> list[dict[str, Any]]:
        fields = ("id", "goal", "status", "summary", "started", "finished")
        return [{key: job.get(key, "") for key in fields} for job in reversed(self._load()[-limit:])]

    def folder(self, job_id: int) -> Path:
        return self.settings.workspace / "jobs" / f"job-{job_id}"

    def report(self, job_id: int) -> str:
        path = self.folder(job_id) / REPORT
        return path.read_text(encoding="utf-8") if path.exists() else ""

    # Starting and stopping

    def start(self, goal: str) -> str:
        goal = " ".join(goal.split())[:1000]
        if not goal:
            return "Say what the job is."
        if self.settings.brain != "claude" or not self.settings.api_key:
            return "Background jobs need the Claude brain and its key."
        if self.stop.active:
            return "IRIS is stopped. Resume first."
        if len([task for task in self.running.values() if not task.done()]) >= MAX_RUNNING:
            return f"{MAX_RUNNING} jobs are already running. Wait for one to finish."
        problem = budget_problem(self.settings, self.memory)
        if problem:
            return problem
        with self.lock:
            jobs = self._load()
            job_id = max((job["id"] for job in jobs), default=0) + 1
            jobs.append({"id": job_id, "goal": goal, "status": "running", "summary": "",
                         "started": datetime.now().isoformat(timespec="minutes"), "finished": ""})
            self._save(jobs)
        self.audit.write("job_started", job=job_id, goal=goal[:200])
        self.running[job_id] = asyncio.create_task(self._run(job_id, goal))
        return f"Job {job_id} started in the background. I will tell you when it is done."

    def cancel(self, job_id: int) -> bool:
        task = self.running.get(job_id)
        if task is None or task.done():
            return False
        task.cancel()
        return True

    def cancel_all(self) -> None:
        for job_id in list(self.running):
            self.cancel(job_id)

    async def _run(self, job_id: int, goal: str) -> None:
        folder = self.folder(job_id)
        folder.mkdir(parents=True, exist_ok=True)
        settings = dataclasses.replace(
            self.settings,
            workspace=folder,
            windows_enabled=False,
            max_usd_per_message=self.settings.max_usd_per_task,
            max_turns=self.settings.max_turns_per_task,
        )
        gate = ToolGate(JobPolicy(folder, self.settings.level, self.risks()), self.audit, self.stop, self.approver)
        agent = Agent(settings, self.memory, self.audit, self.stop, gate, f"job:{job_id}", extra_mcp=self.servers())
        parts: list[str] = []
        status = "failed"
        try:
            await agent.start()
            try:
                result = await agent.ask(JOB_RULES.format(goal=goal, report=REPORT), parts.append)
            finally:
                await agent.close()
            if result and not result.is_error and not self.stop.active:
                status = "done"
        except asyncio.CancelledError:
            parts.append("Stopped.")
            status = "stopped"
        except Exception as error:
            parts.append(f"The job stopped with an error: {type(error).__name__}.")
        summary = (parts[-1] if parts else "").strip()[-600:] or "The job ended without a summary."
        if status == "done" and not (folder / REPORT).exists():
            (folder / REPORT).write_text("\n\n".join(parts).strip() + "\n", encoding="utf-8")
        job = self._change(job_id, status=status, summary=summary,
                           finished=datetime.now().isoformat(timespec="minutes"))
        self.running.pop(job_id, None)
        self.audit.write("job_finished", job=job_id, status=status)
        self.finished(job)


def _text(value: str) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": value}]}


def job_tools(jobs: Jobs) -> list[Any]:
    @tool(
        "start_job",
        "Start a background job: research, a report, a comparison or anything that takes a while and needs "
        "only reading the web or connected apps. It runs while you keep talking and reports when done. "
        "Use it when the owner asks for something long or says to do it in the background.",
        {"goal": str},
    )
    async def start_job(args: dict[str, Any]) -> dict[str, Any]:
        return _text(jobs.start(str(args.get("goal", ""))))

    @tool("list_jobs", "List recent background jobs and their state.", {})
    async def list_jobs(_args: dict[str, Any]) -> dict[str, Any]:
        rows = jobs.rows(10)
        if not rows:
            return _text("No background jobs yet.")
        return _text("\n".join(f"Job {row['id']} ({row['status']}): {row['goal']}" for row in rows))

    @tool("read_job", "Read the report of a finished background job.", {"job_id": int})
    async def read_job(args: dict[str, Any]) -> dict[str, Any]:
        job = jobs.get(int(args.get("job_id", 0)))
        if job is None:
            return _text("There is no job with that number.")
        report = jobs.report(job["id"])
        return _text(report[:8000] if report else f"Job {job['id']} is {job['status']}. {job['summary']}")

    @tool("stop_job", "Stop a running background job.", {"job_id": int})
    async def stop_job(args: dict[str, Any]) -> dict[str, Any]:
        stopped = jobs.cancel(int(args.get("job_id", 0)))
        return _text("Stopping it." if stopped else "That job is not running.")

    return [start_job, list_jobs, read_job, stop_job]
