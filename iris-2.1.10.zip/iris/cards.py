"""Topic cards that appear around the core while IRIS talks about something.

IRIS only fills in plain fields. Every link, picture and video is checked here, so a web page
cannot slip a script, a local address or an unknown player onto the screen.
"""
from __future__ import annotations

import ipaddress
import re
from typing import Any, Callable
from urllib.parse import parse_qs, urlsplit

from iris.connectors.base import READ, Tool

MAX_CARDS = 6
KINDS = ("article", "video", "number", "chart", "note")
YOUTUBE_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
MARKDOWN_LINK = re.compile(r"\[([^\]\n]{3,200})\]\((https://[^\s)]{4,600})\)")
YOUTUBE_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtube-nocookie.com"}

CARD_SCHEMA = {
    "type": "object",
    "properties": {
        "topic": {"type": "string", "description": "A few words naming the topic."},
        "cards": {
            "type": "array",
            "maxItems": MAX_CARDS,
            "description": "Up to 6 cards. An empty list clears the screen.",
            "items": {
                "type": "object",
                "properties": {
                    "kind": {"type": "string", "enum": list(KINDS)},
                    "title": {"type": "string"},
                    "text": {"type": "string", "description": "One or two short sentences."},
                    "source": {"type": "string", "description": "Site, app or file name."},
                    "url": {"type": "string", "description": "https link the card opens. For a video, its YouTube link."},
                    "image": {"type": "string", "description": "https picture address taken from a tool result."},
                    "value": {"type": "string", "description": "For number cards, such as 101,250 or 9 C."},
                    "change": {"type": "string", "description": "For number cards, such as +1.2%."},
                    "points": {"type": "array", "items": {"type": "number"}, "description": "For chart cards, 2 to 40 values."},
                },
                "required": ["kind", "title"],
            },
        },
    },
    "required": ["cards"],
}

DESCRIPTION = (
    "Show cards around the core on the owner's screen while you talk about a topic: articles, YouTube videos, "
    "numbers, small charts, or notes about the owner's own mail, events and files. Use only links, pictures and "
    "figures that a tool gave you in this conversation; never invent them. Show 2 to 6 cards when they help, "
    "and an empty list when the topic is over. Then answer in words as usual."
)


def _text(value: Any, limit: int) -> str:
    return " ".join(str(value or "").split())[:limit]


def safe_link(value: Any) -> str:
    """Only ordinary https addresses on the public internet."""
    link = str(value or "").strip()
    if len(link) > 600:
        return ""
    try:
        parts = urlsplit(link)
    except ValueError:
        return ""
    host = (parts.hostname or "").lower()
    if parts.scheme != "https" or not host or parts.username or parts.password or "." not in host:
        return ""
    if host == "localhost" or host.endswith((".local", ".lan", ".internal", ".home", ".localhost")):
        return ""
    try:
        if not ipaddress.ip_address(host).is_global:
            return ""
    except ValueError:
        pass
    return parts.geturl()


def youtube_id(link: str) -> str:
    parts = urlsplit(link)
    host = (parts.hostname or "").lower()
    if host not in YOUTUBE_HOSTS:
        return ""
    if host == "youtu.be":
        found = parts.path.strip("/").split("/")[0]
    elif parts.path == "/watch":
        found = parse_qs(parts.query).get("v", [""])[0]
    else:
        pieces = parts.path.strip("/").split("/")
        found = pieces[1] if len(pieces) > 1 and pieces[0] in ("shorts", "embed", "live") else ""
    return found if YOUTUBE_ID.match(found) else ""


def clean_card(raw: Any) -> dict[str, Any] | None:
    if not isinstance(raw, dict) or raw.get("kind") not in KINDS:
        return None
    card: dict[str, Any] = {
        "kind": raw["kind"],
        "title": _text(raw.get("title"), 110),
        "text": _text(raw.get("text"), 240),
        "source": _text(raw.get("source"), 40),
    }
    if not card["title"]:
        return None
    link = safe_link(raw.get("url"))
    if card["kind"] == "video":
        video = youtube_id(link) if link else ""
        if not video:
            return None
        card["video"] = video
        card["image"] = f"https://i.ytimg.com/vi/{video}/hqdefault.jpg"
        card["url"] = f"https://www.youtube.com/watch?v={video}"
        card["source"] = card["source"] or "YouTube"
        return card
    if link:
        card["url"] = link
    picture = safe_link(raw.get("image"))
    if picture and card["kind"] in ("article", "note"):
        card["image"] = picture
    if card["kind"] == "number":
        card["value"] = _text(raw.get("value"), 24)
        card["change"] = _text(raw.get("change"), 14)
        if not card["value"]:
            return None
    if card["kind"] == "chart":
        points = []
        for point in raw.get("points") or []:
            try:
                number = float(point)
            except (TypeError, ValueError):
                continue
            if number == number and abs(number) < 1e15:
                points.append(number)
        if len(points) < 2:
            return None
        card["points"] = points[:40]
        card["value"] = _text(raw.get("value"), 24)
    return card


def clean_cards(raw: Any) -> list[dict[str, Any]]:
    cards = [clean_card(item) for item in (raw if isinstance(raw, list) else [])[:MAX_CARDS]]
    return [card for card in cards if card]


def _plain(text: str) -> str:
    text = MARKDOWN_LINK.sub(lambda found: found.group(1), text)
    return " ".join(re.sub(r"[*_`#>]", "", text).split())


def cards_from_reply(text: str) -> list[dict[str, Any]]:
    """Cards built from the links IRIS wrote in her reply, for when she forgot to show them.

    Each link becomes an article card, or a video card for YouTube, with the words that follow
    it on the same line as its text. Links are checked exactly like cards IRIS shows herself.
    """
    cards: list[dict[str, Any]] = []
    seen: set[str] = set()
    for line in text.splitlines():
        for found in MARKDOWN_LINK.finditer(line):
            link = safe_link(found.group(2))
            if not link or link in seen:
                continue
            seen.add(link)
            host = (urlsplit(link).hostname or "").removeprefix("www.").removeprefix("m.")
            rest = re.sub(r"^[\s*_:;,.\u2013\u2014-]+", "", _plain(line[found.end():]))
            kind = "video" if youtube_id(link) else "article"
            card = clean_card({"kind": kind, "title": _plain(found.group(1)), "text": rest, "source": host, "url": link})
            if card:
                cards.append(card)
            if len(cards) == MAX_CARDS:
                return cards
    return cards


class TopicCards:
    def __init__(self, publish: Callable[[str, dict[str, Any]], None], enabled: Callable[[], bool]) -> None:
        self.publish = publish
        self.enabled = enabled
        self.current: dict[str, Any] = {"topic": "", "cards": []}
        self.calls = 0  # how often IRIS used show_cards herself

    def show(self, topic: str, cards: list[dict[str, Any]]) -> None:
        self.current = {"topic": _text(topic, 60), "cards": cards}
        self.publish("cards", self.current)

    def clear(self) -> None:
        if self.current["cards"]:
            self.show("", [])

    def from_reply(self, text: str, topic: str) -> bool:
        """Show the reply's links as cards. False when there were none or cards are off."""
        cards = cards_from_reply(text) if self.enabled() else []
        if cards:
            self.show(" ".join(topic.split()[:6]), cards)
        return bool(cards)

    def _tool(self, args: dict[str, Any]) -> str:
        self.calls += 1
        if not self.enabled():
            return "Cards are turned off on the owner's screen. Answer in words."
        given = args.get("cards") if isinstance(args.get("cards"), list) else []
        cards = clean_cards(given)
        self.show(str(args.get("topic", "")), cards)
        if not given:
            return "The cards are cleared."
        dropped = len(given[:MAX_CARDS]) - len(cards)
        note = f" {dropped} were left out because a link, video or number was missing or not allowed." if dropped else ""
        return f"Showing {len(cards)} cards.{note}"

    def tools(self) -> list[Tool]:
        return [Tool("show_cards", DESCRIPTION, CARD_SCHEMA, READ, self._tool, on_loop=True)]
