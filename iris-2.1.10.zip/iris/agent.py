"""Connects IRIS to Claude through the Claude Agent SDK."""
from __future__ import annotations

import asyncio
import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from claude_agent_sdk.types import StreamEvent
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    ClaudeSDKError,
    HookMatcher,
    PermissionResultAllow,
    PermissionResultDeny,
    ResultMessage,
    TextBlock,
)

from iris.audit import AuditLog, clean
from iris.config import Settings
from iris.gate import ToolGate
from iris.memory import Memory
from iris.openai_bridge import MODEL_LABEL
from iris.policy import ALLOWED_TOOLS
from iris.stop import EmergencyStop

APPROVAL_WAIT_SECONDS = 3600
LOCAL_TIMEOUT_MS = "600000"
LOCAL_FILE_TOOLS = ("Read", "Write", "Edit")
LONG_TOOL_TIMEOUT_MS = "1800000"  # transcribing a long video takes time
COST_SEEN = ":cost_seen"
LAST_USED = ":last_used"


def reply_cost(memory: Memory, session_key: str, session_total: float) -> float:
    """Claude reports what the whole conversation has cost so far, even after a restart.
    Only the growth since the last reply is new spending."""
    seen = float(memory.get_state(session_key + COST_SEEN) or 0)
    memory.set_state(session_key + COST_SEEN, repr(session_total))
    return session_total - seen if session_total >= seen else session_total


def forget_session(memory: Memory, session_key: str) -> None:
    for key in (session_key, session_key + COST_SEEN, session_key + LAST_USED):
        memory.set_state(key, None)


def rebuild_month_spending(memory: Memory, audit_file: Path, month: str) -> float | None:
    """Older versions added the running conversation total after every reply, so the month looked
    far more expensive than it was. This recounts the month once from the protected log."""
    if not audit_file.exists():
        return None
    total, seen = 0.0, 0.0
    with audit_file.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            if entry.get("event") == "session_start" and entry.get("brain") == "claude" and not entry.get("resumed"):
                seen = 0.0
            if entry.get("event") != "turn_finished" or entry.get("cost_usd") is None:
                continue
            cost = float(entry["cost_usd"])
            if "session_cost_usd" in entry:
                spent = cost
                seen = float(entry.get("session_cost_usd") or seen)
            else:
                spent = cost - seen if cost >= seen else cost
                seen = cost
            if str(entry.get("time", "")).startswith(month):
                total += spent
    memory.replace_month_spending(month, total)
    return total


SMART_WORDS = re.compile(
    r"\b(think (hard|harder|carefully|deeply|it through)|use (sonnet|the smart model|your best)|in[- ]depth|"
    r"deep research|research|analy[sz]e|analysis|step by step|in detail|detailed|compare|write (a|an|me a) "
    r"(report|essay|plan|proposal|article|document|letter|email))\b",
    re.I,
)


def wants_smart(text: str) -> bool:
    """Everyday messages go to the cheap model. These words ask for the stronger one."""
    return bool(SMART_WORDS.search(text))


def idle_too_long(memory: Memory, session_key: str, hours: float, now: datetime | None = None) -> bool:
    """A long pause starts a fresh conversation, so old messages stop being paid for again and again."""
    last = memory.get_state(session_key + LAST_USED)
    if not last or hours <= 0:
        return False
    try:
        then = datetime.fromisoformat(last)
    except ValueError:
        return True
    return (now or datetime.now(timezone.utc)) - then > timedelta(hours=hours)


def build_system_prompt(settings: Settings, memory: Memory) -> str:
    template = (settings.root / "config" / "system_prompt.md").read_text(encoding="utf-8")
    facts = "\n".join(f"- {text}" for _, text in memory.facts()) or "- (none yet)"
    profile = memory.get_state("profile") or "(not written yet)"
    return (
        template.replace("{address}", settings.address).replace("{memory}", facts).replace("{profile}", profile)
    )


def budget_problem(settings: Settings, memory: Memory) -> str | None:
    if settings.brain != "claude":
        return None
    spent = memory.month_spending()
    if spent >= settings.max_usd_per_month:
        return f"Monthly limit reached: ${spent:.2f} of ${settings.max_usd_per_month:.2f}."
    return None


def build_hooks(gate: ToolGate, audit: AuditLog) -> tuple[Any, Any]:
    async def pre_tool(data: Any, tool_use_id: str | None, _context: Any) -> dict[str, Any]:
        allowed, reason = await gate.check(data["tool_name"], data["tool_input"], tool_use_id)
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "allow" if allowed else "deny",
                "permissionDecisionReason": reason,
            }
        }

    async def after_tool(data: Any, tool_use_id: str | None, _context: Any) -> dict[str, Any]:
        audit.write(
            "tool_finished",
            tool=data.get("tool_name"),
            tool_use_id=tool_use_id,
            failed=data.get("hook_event_name") == "PostToolUseFailure",
        )
        return {}

    return pre_tool, after_tool


def build_options(
    settings: Settings,
    memory: Memory,
    gate: ToolGate,
    audit: AuditLog,
    resume: str | None,
    scrub_env: bool = True,
    extra_mcp: dict[str, Any] | None = None,
) -> ClaudeAgentOptions:
    pre_tool, after_tool = build_hooks(gate, audit)

    async def can_use_tool(tool: str, args: dict[str, Any], context: Any) -> Any:
        allowed, reason = await gate.check(tool, args, context.tool_use_id)
        if allowed:
            return PermissionResultAllow()
        return PermissionResultDeny(message=reason)

    def log_stderr(line: str) -> None:
        with (settings.data_dir / "claude-errors.log").open("a", encoding="utf-8") as handle:
            handle.write(clean(line) + "\n")

    env = {
        "ANTHROPIC_API_KEY": settings.api_key or "",
        "CLAUDE_CONFIG_DIR": str(settings.data_dir / "claude"),
        "CLAUDE_CODE_SUBPROCESS_ENV_SCRUB": "1" if scrub_env else "0",
        "MCP_TOOL_TIMEOUT": LONG_TOOL_TIMEOUT_MS,
    }
    tools = list(ALLOWED_TOOLS)
    model = settings.smart_model if gate.policy.task_mode else settings.model
    budget: float | None = settings.max_usd_per_message
    if settings.brain != "claude":
        model = settings.ollama_model if settings.local_brain else MODEL_LABEL
        budget = None
        tools.remove("WebSearch")  # these two go through Anthropic's servers
        tools.remove("WebFetch")
        if settings.local_brain:
            tools = [name for name in tools if name in LOCAL_FILE_TOOLS]  # fewer tools answer much faster here
        env.update({
            "ANTHROPIC_API_KEY": "",
            "ANTHROPIC_AUTH_TOKEN": "ollama" if settings.local_brain else settings.bridge_token,
            "CLAUDE_CODE_OAUTH_TOKEN": "",  # no Anthropic sign-in may reach another brain
            "ANTHROPIC_BASE_URL": settings.ollama_url if settings.local_brain else settings.bridge_url,
            "ANTHROPIC_SMALL_FAST_MODEL": model,
            "ANTHROPIC_DEFAULT_HAIKU_MODEL": model,
            "ANTHROPIC_DEFAULT_SONNET_MODEL": model,
            "ANTHROPIC_DEFAULT_OPUS_MODEL": model,
            "API_TIMEOUT_MS": LOCAL_TIMEOUT_MS,
            "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
        })
    mcp_servers: dict[str, Any] = dict(extra_mcp or {})
    if settings.windows_enabled and sys.platform == "win32" and gate.policy.task_mode is False and not settings.local_brain:
        mcp_servers["windows"] = {
            "type": "stdio",
            "command": sys.executable,
            "args": ["-m", "iris.windows_server"],
            "env": {"PYTHONPATH": str(settings.root)},
        }

    if gate.policy.task_mode is False:
        for server in settings.mcp_servers:
            mcp_servers[server["name"]] = {
                "type": "stdio",
                "command": server["command"],
                "args": list(server.get("args", [])),
            }

    return ClaudeAgentOptions(
        tools=tools,
        mcp_servers=mcp_servers,
        strict_mcp_config=True,
        system_prompt=build_system_prompt(settings, memory),
        model=model,
        cwd=settings.workspace,
        env=env,
        permission_mode="default",
        setting_sources=[],
        include_partial_messages=True,
        can_use_tool=can_use_tool,
        stderr=log_stderr,
        hooks={
            "PreToolUse": [HookMatcher(hooks=[pre_tool], timeout=APPROVAL_WAIT_SECONDS)],
            "PostToolUse": [HookMatcher(hooks=[after_tool])],
            "PostToolUseFailure": [HookMatcher(hooks=[after_tool])],
        },
        max_turns=settings.max_turns,
        max_budget_usd=budget,
        resume=resume,
    )


class Agent:
    def __init__(
        self,
        settings: Settings,
        memory: Memory,
        audit: AuditLog,
        stop: EmergencyStop,
        gate: ToolGate,
        session_key: str = "session_id",
        extra_mcp: dict[str, Any] | None = None,
    ) -> None:
        self.session_key = session_key
        self.extra_mcp = extra_mcp
        self.settings = settings
        self.memory = memory
        self.audit = audit
        self.stop = stop
        self.gate = gate
        self.client: ClaudeSDKClient | None = None

    async def start(self) -> None:
        if not self.memory.get_state("spending_recounted"):
            month = datetime.now(timezone.utc).strftime("%Y-%m")
            rebuild_month_spending(self.memory, self.settings.data_dir / "audit" / "audit.jsonl", month)
            self.memory.set_state("spending_recounted", "1")
        resume = self.memory.get_state(self.session_key)
        if not resume:
            forget_session(self.memory, self.session_key)
        (self.settings.data_dir / "claude").mkdir(exist_ok=True)
        scrub_env = True
        try:
            await self._connect(resume, scrub_env)
        except ClaudeSDKError:
            # Key scrubbing needs OS support that some machines lack. Commands still need approval.
            scrub_env = False
            await self._connect(resume, scrub_env)
            print("Warning: extra protection for the API key is unavailable on this machine.")
        self.audit.write(
            "session_start",
            resumed=bool(resume),
            brain=self.settings.brain,
            model=(
                self.settings.ollama_model if self.settings.local_brain
                else MODEL_LABEL if self.settings.openai_brain else self.settings.model
            ),
            scrub_env=scrub_env,
        )

    async def _connect(self, resume: str | None, scrub_env: bool) -> None:
        options = build_options(
            self.settings, self.memory, self.gate, self.audit, resume, scrub_env, self.extra_mcp
        )
        self.client = ClaudeSDKClient(options)
        await self.client.connect()

    async def close(self) -> None:
        if self.client:
            await self.client.disconnect()
            self.client = None
        self.audit.write("session_end")

    async def _watch_stop(self) -> None:
        while not self.stop.active:
            await asyncio.sleep(0.5)
        self.audit.write(self.stop.interrupt_event)
        if self.client:
            await self.client.interrupt()

    async def ask(
        self,
        prompt: str,
        on_text: Callable[[str], None],
        on_words: Callable[[str], None] = lambda _text: None,
        smart: bool = False,
    ) -> ResultMessage | None:
        if self.client is None:
            raise RuntimeError("agent is not started")
        self.audit.write("user_message", text=prompt)
        watcher = asyncio.create_task(self._watch_stop())
        result: ResultMessage | None = None
        switched = (
            smart and self.settings.brain == "claude" and self.settings.smart_model != self.settings.model
            and not self.gate.policy.task_mode
        )
        try:
            if switched:
                await self.client.set_model(self.settings.smart_model)
                self.audit.write("smart_model", model=self.settings.smart_model)
            await self.client.query(prompt)
            async for message in self.client.receive_response():
                if isinstance(message, StreamEvent):
                    delta = message.event.get("delta", {})
                    if delta.get("type") == "text_delta" and not message.parent_tool_use_id:
                        on_words(delta.get("text", ""))
                elif isinstance(message, AssistantMessage):
                    for block in message.content:
                        if isinstance(block, TextBlock):
                            on_text(block.text)
                elif isinstance(message, ResultMessage):
                    result = message
        finally:
            watcher.cancel()
            if switched and self.client is not None:
                try:
                    await self.client.set_model(self.settings.model)
                except ClaudeSDKError:
                    pass
        if result:
            self.memory.set_state(self.session_key, result.session_id)
            self.memory.set_state(self.session_key + LAST_USED, datetime.now(timezone.utc).isoformat())
            spent = None
            if self.settings.brain == "claude":
                spent = reply_cost(self.memory, self.session_key, result.total_cost_usd or 0.0)
                self.memory.add_spending(spent)
            self.audit.write(
                "turn_finished",
                subtype=result.subtype,
                is_error=result.is_error,
                cost_usd=spent,
                session_cost_usd=result.total_cost_usd if self.settings.brain == "claude" else None,
                turns=result.num_turns,
            )
        return result
