"""Text interface."""
from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any

from claude_agent_sdk import ClaudeSDKError

from iris.agent import Agent, budget_problem
from iris.audit import AuditLog
from iris.config import Settings, load_settings
from iris.gate import ToolGate, approval_preview
from iris.hotkey import HOTKEY_NAME, start_stop_hotkey
from iris.memory import Memory
from iris.monitor import build_briefing
from iris.policy import Policy
from iris.projects import TaskManager
from iris.task_tools import BackgroundTasks, build_task_server
from iris.stop import EmergencyStop

HELP = """Commands:
  /remember TEXT   save a fact
  /memory          list saved facts
  /forget ID       delete a fact
  /new             start a new conversation
  /project add NAME PATH [TEST COMMAND]
                   register a Git project
  /projects        list projects
  /task NAME GOAL  start a task on its own branch
  /continue NAME [NOTE]
                   continue the latest open task
  /tasks           list tasks
  /briefing        show open tasks, alerts and spending
  /review ID       show a task's changes and test result
  /merge ID        merge a reviewed task
  /discard ID      remove a task and its branch
  /spent           show this month's spending
  /stop            emergency stop
  /help            show this list
  /exit            leave IRIS"""


async def approve_in_terminal(tool: str, args: dict[str, Any], reason: str) -> bool:
    preview, cut = approval_preview(args)
    print(f"\n[APPROVAL NEEDED] {tool}: {reason}\n{preview}")
    if cut:
        print("Refused: this request is too long to show in full.")
        return False
    try:
        answer = await asyncio.to_thread(input, "Allow? Type yes to approve: ")
    except (EOFError, KeyboardInterrupt):
        return False
    return answer.strip().lower() == "yes"


def handle_command(line: str, memory: Memory, stop: EmergencyStop, settings: Settings) -> str:
    """Handle a slash command. /exit, /new and /stop are handled by the caller's loop."""
    command, _, rest = line.partition(" ")
    rest = rest.strip()
    if command == "/remember" and rest:
        return f"Saved as #{memory.remember(rest)}. It applies from the next start or /new."
    if command == "/memory":
        return "\n".join(f"#{fact_id}: {text}" for fact_id, text in memory.facts()) or "No saved facts."
    if command == "/forget" and rest.isdigit():
        return "Deleted." if memory.forget(int(rest)) else "No such fact."
    if command == "/spent":
        return f"${memory.month_spending():.2f} of ${settings.max_usd_per_month:.2f} this month."
    if command == "/help":
        return HELP
    return "Unknown command. Type /help."


async def chat(settings: Settings, memory: Memory, audit: AuditLog, stop: EmergencyStop) -> int:
    tasks = TaskManager(settings, memory, audit, stop, approve_in_terminal)
    runner = BackgroundTasks(tasks, lambda text: print(f"\nIRIS: {text}"))

    def make_agent() -> Agent:
        gate = ToolGate(Policy(settings.workspace, settings.level, settings.allowed_apps), audit, stop, approve_in_terminal)
        return Agent(settings, memory, audit, stop, gate, extra_mcp=build_task_server(tasks, runner))

    agent = make_agent()
    await agent.start()
    print("IRIS is ready. Type /help for commands.")
    try:
        while True:
            try:
                line = (await asyncio.to_thread(input, "\nYou: ")).strip()
            except (EOFError, KeyboardInterrupt):
                return 0
            if not line:
                continue
            if line == "/exit":
                return 0
            if line == "/stop":
                stop.trigger("owner typed /stop")
                print("Emergency stop is active. Run scripts\\clear-stop.ps1 to continue.")
                return 0
            if line == "/new":
                await agent.close()
                memory.set_state("session_id", None)
                agent = make_agent()
                await agent.start()
                print("New conversation started.")
                continue
            if line == "/briefing":
                print(build_briefing(settings, memory, tasks))
                continue
            task_reply = await tasks.handle_command(line)
            if task_reply is not None:
                print(task_reply)
                continue
            if line.startswith("/"):
                print(handle_command(line, memory, stop, settings))
                continue
            problem = budget_problem(settings, memory)
            if problem:
                print(problem)
                continue
            if stop.active:
                print("Emergency stop is active.")
                return 1
            result = await agent.ask(line, lambda text: print(f"\nIRIS: {text}"))
            if result and result.is_error:
                print(f"\n[IRIS stopped: {result.subtype}]")
            elif result and result.total_cost_usd is not None:
                print(f"\n[cost ${result.total_cost_usd:.4f}]")
            if stop.active:
                print("Emergency stop is active. Work was interrupted.")
                return 1
    finally:
        await agent.close()


def main() -> int:
    parser = argparse.ArgumentParser(prog="iris")
    parser.add_argument("--stop", action="store_true", help="activate the emergency stop")
    parser.add_argument("--clear-stop", action="store_true", help="clear the emergency stop")
    parser.add_argument("--verify-audit", action="store_true", help="check the audit log")
    options = parser.parse_args()

    settings = load_settings()
    stop = EmergencyStop(settings.data_dir)
    audit = AuditLog(settings.data_dir / "audit" / "audit.jsonl")

    if options.stop:
        stop.trigger("command line")
        audit.write("emergency_stop_set")
        print("Emergency stop activated.")
        return 0
    if options.clear_stop:
        stop.clear()
        audit.write("emergency_stop_cleared")
        print("Emergency stop cleared.")
        return 0
    if options.verify_audit:
        intact, count = audit.verify()
        print(f"Audit log {'intact' if intact else 'DAMAGED'}: {count} entries checked.")
        return 0 if intact else 1
    if stop.active:
        print("Emergency stop is active. Run scripts\\clear-stop.ps1 first.")
        return 1
    if not settings.brain_ready:
        print("No API key found. Copy .env.example to .env and add your key.")
        return 1

    ready = start_stop_hotkey(lambda: stop.trigger("hotkey"))
    if getattr(ready, "registered", False):
        print(f"Emergency stop: {HOTKEY_NAME}")
    else:
        print("Warning: the emergency stop shortcut is unavailable. Use scripts\\stop.ps1.")
    memory = Memory(settings.data_dir / "iris.db")
    try:
        return asyncio.run(chat(settings, memory, audit, stop))
    except ClaudeSDKError as error:
        print(f"Could not talk to Claude: {error}", file=sys.stderr)
        return 1
    finally:
        memory.close()
