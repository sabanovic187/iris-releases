"""MCP server for Windows apps, built on the UI Automation API that ships with Windows.

Runs as a separate process over stdio: one JSON message per line.
"""
from __future__ import annotations

import base64
import ctypes
import io
import json
import subprocess
import sys
import time
from typing import Any, Callable, Protocol

MAX_NODES = 400
MAX_DEPTH = 12
LAUNCH_WAIT_SECONDS = 8.0
MAX_IMAGE_SIDE = 1568

UIA_INVOKE_PATTERN = 10000
UIA_VALUE_PATTERN = 10002

HANDLE = {"type": "string", "description": "Window handle from windows_list_windows or windows_launch"}
REF = {"type": "string", "description": "Element ref from windows_snapshot, such as e5"}


def schema(required: list[str] | None = None, **properties: dict[str, Any]) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": required or []}


TOOLS = [
    ("windows_list_windows", "List open top-level windows.", schema()),
    ("windows_active_window", "Show the window the owner is using.", schema()),
    ("windows_screenshot", "Capture one window. Without a handle, captures the active window.",
     schema(handle=HANDLE)),
    ("windows_launch", "Start an allowed app and return its window handle.",
     schema(["app"], app={"type": "string", "description": "Executable name, such as notepad.exe"})),
    ("windows_snapshot", "Read the accessibility tree of a window. Returns element refs.",
     schema(["handle"], handle=HANDLE)),
    ("windows_click", "Activate an element.", schema(["ref"], ref=REF)),
    ("windows_fill", "Replace the value of an input element.",
     schema(["ref", "value"], ref=REF, value={"type": "string"})),
    ("windows_type", "Focus an element and type text.",
     schema(["ref", "text"], ref=REF, text={"type": "string"})),
    ("windows_get_text", "Read the value or name of an element.", schema(["ref"], ref=REF)),
    ("windows_focus", "Bring a window to the front.", schema(["handle"], handle=HANDLE)),
    ("windows_close", "Ask a window to close.", schema(["handle"], handle=HANDLE)),
]


class Backend(Protocol):
    def list_windows(self) -> list[tuple[int, str]]: ...
    def active_window(self) -> tuple[int, str]: ...
    def screenshot(self, handle: int | None) -> str: ...
    def launch(self, app: str) -> tuple[int, str]: ...
    def snapshot(self, handle: int) -> str: ...
    def click(self, ref: str) -> None: ...
    def fill(self, ref: str, value: str) -> None: ...
    def type_text(self, ref: str, text: str) -> None: ...
    def get_text(self, ref: str) -> str: ...
    def focus(self, handle: int) -> None: ...
    def close(self, handle: int) -> None: ...


class UiAutomation:
    """Real backend. Works only on Windows."""

    def __init__(self) -> None:
        import comtypes
        import comtypes.client

        comtypes.CoInitialize()
        comtypes.client.GetModule("UIAutomationCore.dll")
        from comtypes.gen import UIAutomationClient as client

        self.client = client
        self.uia = comtypes.client.CreateObject(
            "{ff48dba4-60ef-4201-aa87-54103eef594e}", interface=client.IUIAutomation
        )
        self.user32 = ctypes.windll.user32
        self.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))  # per-monitor v2
        self.refs: dict[str, Any] = {}

    def _children(self, element: Any) -> list[Any]:
        found = element.FindAll(self.client.TreeScope_Children, self.uia.ControlViewCondition)
        return [found.GetElement(index) for index in range(found.Length)] if found else []

    def _window(self, handle: int) -> Any:
        if not self.user32.IsWindow(handle):
            raise ValueError(f"no window with handle {handle}")
        return self.uia.ElementFromHandle(handle)

    def _element(self, ref: str) -> Any:
        if ref not in self.refs:
            raise ValueError(f"unknown ref {ref}; take a new snapshot")
        return self.refs[ref]

    def _pattern(self, element: Any, pattern_id: int, interface: Any) -> Any:
        pattern = element.GetCurrentPattern(pattern_id)
        return pattern.QueryInterface(interface) if pattern else None

    def list_windows(self) -> list[tuple[int, str]]:
        windows = []
        for element in self._children(self.uia.GetRootElement()):
            handle = int(element.CurrentNativeWindowHandle or 0)
            title = element.CurrentName or ""
            if handle and title:
                windows.append((handle, title))
        return windows

    def active_window(self) -> tuple[int, str]:
        handle = int(self.user32.GetForegroundWindow())
        if not handle:
            raise RuntimeError("no active window")
        return handle, self._window(handle).CurrentName or ""

    def screenshot(self, handle: int | None) -> str:
        from PIL import ImageGrab

        target = handle if handle is not None else self.active_window()[0]
        self._window(target)
        if self.user32.IsIconic(target):
            raise RuntimeError("the window is minimized")
        if handle is not None:
            self.user32.SetForegroundWindow(target)
            time.sleep(0.2)
        box = _Rect()
        if not self.user32.GetWindowRect(target, ctypes.byref(box)):
            raise RuntimeError("could not read the window position")
        image = ImageGrab.grab(bbox=(box.left, box.top, box.right, box.bottom), all_screens=True)
        return encode_png(image)

    def launch(self, app: str) -> tuple[int, str]:
        before = {handle for handle, _ in self.list_windows()}
        subprocess.Popen([app])
        deadline = time.monotonic() + LAUNCH_WAIT_SECONDS
        while time.monotonic() < deadline:
            for handle, title in self.list_windows():
                if handle not in before:
                    return handle, title
            time.sleep(0.2)
        raise RuntimeError("the app started, but no new window appeared")

    def snapshot(self, handle: int) -> str:
        self.refs = {}
        lines: list[str] = []

        def visit(element: Any, depth: int) -> None:
            if len(lines) >= MAX_NODES:
                return
            ref = f"e{len(lines) + 1}"
            self.refs[ref] = element
            kind = element.CurrentLocalizedControlType or "element"
            name = (element.CurrentName or "").replace("\n", " ")[:120]
            state = "" if element.CurrentIsEnabled else " disabled"
            lines.append(f'{"  " * depth}- {kind} "{name}" [ref={ref}]{state}')
            if depth < MAX_DEPTH:
                for child in self._children(element):
                    visit(child, depth + 1)

        visit(self._window(handle), 0)
        if len(lines) >= MAX_NODES:
            lines.append(f"[stopped at {MAX_NODES} elements]")
        return "\n".join(lines)

    def click(self, ref: str) -> None:
        element = self._element(ref)
        invoke = self._pattern(element, UIA_INVOKE_PATTERN, self.client.IUIAutomationInvokePattern)
        if invoke:
            invoke.Invoke()
            return
        box = element.CurrentBoundingRectangle
        self.user32.SetCursorPos((box.left + box.right) // 2, (box.top + box.bottom) // 2)
        self.user32.mouse_event(0x0002, 0, 0, 0, 0)
        self.user32.mouse_event(0x0004, 0, 0, 0, 0)

    def fill(self, ref: str, value: str) -> None:
        element = self._element(ref)
        pattern = self._pattern(element, UIA_VALUE_PATTERN, self.client.IUIAutomationValuePattern)
        if not pattern or pattern.CurrentIsReadOnly:
            raise RuntimeError("this element does not accept a value")
        pattern.SetValue(value)

    def type_text(self, ref: str, text: str) -> None:
        self._element(ref).SetFocus()
        time.sleep(0.1)
        send_unicode(self.user32, text)

    def get_text(self, ref: str) -> str:
        element = self._element(ref)
        pattern = self._pattern(element, UIA_VALUE_PATTERN, self.client.IUIAutomationValuePattern)
        return (pattern.CurrentValue if pattern else "") or element.CurrentName or ""

    def focus(self, handle: int) -> None:
        self._window(handle)
        self.user32.SetForegroundWindow(handle)

    def close(self, handle: int) -> None:
        self._window(handle)
        self.user32.PostMessageW(handle, 0x0010, 0, 0)


class _Rect(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long), ("top", ctypes.c_long),
        ("right", ctypes.c_long), ("bottom", ctypes.c_long),
    ]


def encode_png(image: Any) -> str:
    """Shrink a capture to a size Claude accepts and return base64 PNG data."""
    image.thumbnail((MAX_IMAGE_SIDE, MAX_IMAGE_SIDE))
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode("ascii")


class _KeyInput(ctypes.Structure):
    _fields_ = [
        ("vk", ctypes.c_ushort), ("scan", ctypes.c_ushort), ("flags", ctypes.c_ulong),
        ("time", ctypes.c_ulong), ("extra", ctypes.c_size_t),
    ]


class _MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long), ("dy", ctypes.c_long), ("data", ctypes.c_ulong),
        ("flags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("extra", ctypes.c_size_t),
    ]


class _Event(ctypes.Union):
    _fields_ = [("key", _KeyInput), ("mouse", _MouseInput)]


class _Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("event", _Event)]


def utf16_units(text: str) -> list[int]:
    data = text.encode("utf-16-le")
    return [int.from_bytes(data[index:index + 2], "little") for index in range(0, len(data), 2)]


def send_unicode(user32: Any, text: str) -> None:
    events = []
    for unit in utf16_units(text):
        for flags in (0x0004, 0x0004 | 0x0002):  # KEYEVENTF_UNICODE, then key up
            events.append(_Input(1, _Event(key=_KeyInput(0, unit, flags, 0, 0))))
    if events:
        array = (_Input * len(events))(*events)
        if user32.SendInput(len(events), array, ctypes.sizeof(_Input)) != len(events):
            raise RuntimeError("Windows refused the typed input")


class Server:
    def __init__(self, backend_factory: Callable[[], Backend]) -> None:
        self.backend_factory = backend_factory
        self._backend: Backend | None = None

    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = self.backend_factory()
        return self._backend

    def call_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        if name == "windows_screenshot":
            handle = int(args["handle"]) if args.get("handle") else None
            data = self.backend.screenshot(handle)
            return {"type": "image", "data": data, "mimeType": "image/png"}
        return {"type": "text", "text": self._call_text_tool(name, args)}

    def _call_text_tool(self, name: str, args: dict[str, Any]) -> str:
        backend = self.backend
        if name == "windows_active_window":
            handle, title = backend.active_window()
            return f"{handle}: {title}"
        if name == "windows_list_windows":
            windows = backend.list_windows()
            return "\n".join(f"{handle}: {title}" for handle, title in windows) or "No windows."
        if name == "windows_launch":
            handle, title = backend.launch(str(args["app"]))
            return f"Launched {args['app']}\nWindow handle: {handle}\nTitle: {title}"
        if name == "windows_snapshot":
            return backend.snapshot(int(args["handle"]))
        if name == "windows_click":
            backend.click(args["ref"])
            return "Clicked."
        if name == "windows_fill":
            backend.fill(args["ref"], args["value"])
            return "Filled."
        if name == "windows_type":
            backend.type_text(args["ref"], args["text"])
            return "Typed."
        if name == "windows_get_text":
            return backend.get_text(args["ref"])
        if name == "windows_focus":
            backend.focus(int(args["handle"]))
            return "Focused."
        if name == "windows_close":
            backend.close(int(args["handle"]))
            return "Close requested."
        raise ValueError(f"unknown tool {name}")

    def handle(self, message: dict[str, Any]) -> dict[str, Any] | None:
        if "id" not in message:
            return None
        method = message.get("method")
        params = message.get("params") or {}
        reply: dict[str, Any] = {"jsonrpc": "2.0", "id": message["id"]}
        if method == "initialize":
            reply["result"] = {
                "protocolVersion": params.get("protocolVersion", "2024-11-05"),
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "iris-windows", "version": "0.1.0"},
            }
        elif method == "tools/list":
            reply["result"] = {
                "tools": [
                    {"name": name, "description": description, "inputSchema": input_schema}
                    for name, description, input_schema in TOOLS
                ]
            }
        elif method == "tools/call":
            try:
                content = self.call_tool(params["name"], params.get("arguments") or {})
                reply["result"] = {"content": [content]}
            except Exception as error:
                reply["result"] = {
                    "content": [{"type": "text", "text": f"{type(error).__name__}: {error}"}],
                    "isError": True,
                }
        elif method == "ping":
            reply["result"] = {}
        else:
            reply["error"] = {"code": -32601, "message": f"unknown method {method}"}
        return reply


def serve(server: Server) -> None:
    for line in sys.stdin:
        if not line.strip():
            continue
        reply = server.handle(json.loads(line))
        if reply is not None:
            sys.stdout.write(json.dumps(reply) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    serve(Server(UiAutomation))
