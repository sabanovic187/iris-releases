"""Local monitoring and daily briefing. Uses no AI service."""
from __future__ import annotations

import csv
import io
import json
import shutil
import subprocess
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from iris.config import ROOT, Settings, load_settings, read_raw
from iris.memory import Memory

Check = tuple[str, Callable[[], str | None]]
ALERT_WINDOW_HOURS = 24


def disk_check(path: str, minimum_percent: float) -> Check:
    def check() -> str | None:
        usage = shutil.disk_usage(path)
        free = usage.free / usage.total * 100
        return f"{path} has {free:.0f}% free space" if free < minimum_percent else None

    return f"disk {path}", check


def running_processes() -> set[str]:
    output = subprocess.run(
        ["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, errors="replace", check=True
    ).stdout
    return {row[0].lower() for row in csv.reader(io.StringIO(output)) if row}


def process_check(name: str, running: Callable[[], set[str]] = running_processes) -> Check:
    def check() -> str | None:
        return None if name.lower() in running() else f"{name} is not running"

    return f"process {name}", check


class Monitor:
    """Reports only changes, so a lasting problem produces a single alert."""

    def __init__(self, checks: list[Check], log_path: Path, notify: Callable[[str], None]) -> None:
        self.checks = checks
        self.log_path = log_path
        self.notify = notify
        self.active: set[str] = set()

    def _alert(self, kind: str, name: str, message: str) -> None:
        entry = {
            "time": datetime.now(timezone.utc).isoformat(),
            "kind": kind,
            "check": name,
            "message": message,
        }
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
        self.notify(f"{kind}: {message}")

    def tick(self) -> None:
        for name, check in self.checks:
            try:
                problem = check()
            except Exception as error:
                problem = f"{name} could not be checked ({type(error).__name__})"
            if problem and name not in self.active:
                self.active.add(name)
                self._alert("alert", name, problem)
            elif not problem and name in self.active:
                self.active.remove(name)
                self._alert("resolved", name, f"{name} is back to normal")


def recent_alerts(path: Path, now: datetime | None = None) -> list[str]:
    if not path.exists():
        return []
    cutoff = (now or datetime.now(timezone.utc)) - timedelta(hours=ALERT_WINDOW_HOURS)
    alerts = []
    for line in path.read_text(encoding="utf-8").splitlines():
        entry = json.loads(line)
        if datetime.fromisoformat(entry["time"]) >= cutoff:
            alerts.append(f"{entry['kind']}: {entry['message']}")
    return alerts


def build_briefing(settings: Settings, memory: Memory, tasks: Any = None) -> str:
    alerts = recent_alerts(settings.data_dir / "alerts.jsonl")
    lines = [f"Spending this month: ${memory.month_spending():.2f} of ${settings.max_usd_per_month:.2f}."]
    if tasks is not None:
        lines.append(f"Recent tasks:\n{tasks.list_tasks()}")
    lines.append("Alerts in the last 24 hours:\n" + ("\n".join(alerts) or "None."))
    return "\n".join(lines)


def briefing_due(last_date: str | None, briefing_time: str, now: datetime) -> bool:
    return last_date != now.date().isoformat() and now.strftime("%H:%M") >= briefing_time


def build_checks(config: dict[str, Any]) -> list[Check]:
    checks = [disk_check(path, float(config["min_free_disk_percent"])) for path in config["disks"]]
    checks += [process_check(name) for name in config["processes"]]
    return checks


def main() -> int:
    settings = load_settings()
    config = read_raw(ROOT)["monitor"]
    memory = Memory(settings.data_dir / "iris.db")
    monitor = Monitor(
        build_checks(config),
        settings.data_dir / "alerts.jsonl",
        lambda text: print(f"[{datetime.now():%H:%M}] {text}", flush=True),
    )
    print("IRIS monitor is running. Press Ctrl+C to stop.", flush=True)
    try:
        while True:
            monitor.tick()
            now = datetime.now()
            if briefing_due(memory.get_state("briefing_date"), config["briefing_time"], now):
                text = build_briefing(settings, memory)
                (settings.data_dir / "briefing.txt").write_text(text, encoding="utf-8")
                memory.set_state("briefing_date", now.date().isoformat())
                print(f"[{now:%H:%M}] Daily briefing:\n{text}", flush=True)
            time.sleep(int(config["interval_seconds"]))
    except KeyboardInterrupt:
        return 0
    finally:
        memory.close()


if __name__ == "__main__":
    raise SystemExit(main())
