"""Notes that let a routine remember a topic between runs. They hold only text for IRIS to read."""
from __future__ import annotations

import re
from datetime import date
from pathlib import Path
from typing import Any

from iris.audit import redact
from iris.connectors.base import READ, UNTRUSTED_NOTE, ConnectorError, Tool, require_text

MAX_NOTES = 8000


class Monitors:
    def __init__(self, folder: Path) -> None:
        self.folder = folder

    def _path(self, topic: str) -> Path:
        topic = topic.strip().lower()
        if not re.fullmatch(r"[a-z0-9 _-]{1,60}", topic):
            raise ConnectorError("Use a short topic name with letters and numbers.")
        return self.folder / f"{topic.replace(' ', '-')}.md"

    def _read(self, args: dict[str, Any]) -> str:
        path = self._path(require_text(args, "topic", 60))
        if not path.exists():
            return "No notes yet."
        return UNTRUSTED_NOTE + path.read_text(encoding="utf-8")

    def _note(self, args: dict[str, Any]) -> str:
        path = self._path(require_text(args, "topic", 60))
        self.folder.mkdir(parents=True, exist_ok=True)
        old = path.read_text(encoding="utf-8") if path.exists() else ""
        line = f"{date.today().isoformat()}: {redact(require_text(args, 'update', 1000))}\n"
        path.write_text((old + line)[-MAX_NOTES:], encoding="utf-8")
        return "Noted."

    def tools(self) -> list[Tool]:
        return [
            Tool("monitor_read", "Read your notes on a followed topic.", {"topic": str}, READ, self._read),
            Tool("monitor_note", "Add a short dated update to your notes on a followed topic.", {"topic": str, "update": str}, READ, self._note),
        ]
