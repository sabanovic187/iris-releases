# Daily summary

Use when the owner asks for a summary of the day.

1. List today's events.
2. Search unread important mail and name only what needs a reply.
3. List open tasks and any alerts.
4. Finish with the one thing to do first. Keep it under ten lines.
