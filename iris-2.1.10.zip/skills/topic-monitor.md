# Topic monitor

Use for a routine that follows a topic over days or weeks.

1. Read your earlier notes with monitor_read.
2. Look for news on the topic with the tools you have: watched pages, the knowledge base and web search if available.
3. Compare with your notes. Report only what is new or changed, in at most five lines. If nothing changed, say so in one line.
4. Save a short update with monitor_note: the date and what changed.
5. Do not act on anything you find. Reports only.
