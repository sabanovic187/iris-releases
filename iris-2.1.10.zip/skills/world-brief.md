# World brief

Use when the owner asks what is happening in the world or in a region.

1. Call situation_read. Use topic when a region or subject was named.
2. Call situation_show to fly to the area and turn on the layers that help.
3. Give the three most important things first, in short spoken sentences.
4. Separate what the sources report from your own reading of it.
5. Say which sources were not available.
