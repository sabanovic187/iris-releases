# Weekly review

Use when the owner asks for a weekly review.

1. List open tasks, their status and test results.
2. List next week's calendar events.
3. List alerts from the past week that still matter.
4. Finish with the three most important things for next week.
