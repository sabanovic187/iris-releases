"""Self-care: IRIS watches her own parts, repairs what she can, and says what she could not.

- Parts that run all the time (the ticker, Telegram, update checks) are restarted if they stop.
- The tablet and Pod listeners are opened again if they close.
- Voice is started again if its thread died while it should be on.
- World Monitor is brought back up in Docker if it should run and does not answer.
- Free disk space and the memory database are checked.
- If the main loop stops answering for minutes, IRIS ends herself and the start script starts
  her again; after any crash she says on the next start what happened.
Problems are told once (screen and Telegram) and again only when they are solved.
"""
from __future__ import annotations

import asyncio
import os
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable

CHECK_SECONDS = 300
FIRST_CHECK_SECONDS = 90
STUCK_SECONDS = 180
HEARTBEAT_SECONDS = 5
RETRY_SECONDS = 15
MIN_FREE_DISK = 0.05
REPAIR_EVERY_SECONDS = 900
DOCKER_WAIT_SECONDS = 600  # Docker Desktop can take minutes after Windows starts
CRASH_NOTE = "crash.txt"


@dataclass
class Part:
    name: str
    ok: bool = True
    detail: str = ""
    since: str = ""
    told: bool = False
    strikes: int = 0  # checks in a row that found it not working
    last_repair: float = field(default=float("-inf"))  # never repaired yet


class Supervisor:
    """Keeps long-running coroutines alive: one that fails is logged and started again."""

    def __init__(self, on_problem: Callable[[str, str], None]) -> None:
        self.on_problem = on_problem
        self.tasks: dict[str, asyncio.Task[None]] = {}

    def keep(self, name: str, factory: Callable[[], Awaitable[None]]) -> None:
        async def guarded() -> None:
            while True:
                try:
                    await factory()
                    return  # it ended by itself, as it should
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    self.on_problem(name, f"{type(error).__name__}: {error}"[:300])
                    await asyncio.sleep(RETRY_SECONDS)

        self.tasks[name] = asyncio.create_task(guarded())

    def cancel(self) -> None:
        for task in self.tasks.values():
            task.cancel()


class Watchdog:
    """A thread outside the main loop. If the loop has not beaten for minutes, IRIS ends herself
    so the start script can start her again."""

    def __init__(self, data_dir: Path, stuck_seconds: float = STUCK_SECONDS,
                 end: Callable[[int], None] = os._exit) -> None:
        self.data_dir = data_dir
        self.stuck_seconds = stuck_seconds
        self.end = end
        self.last = time.monotonic()
        self.stopped = threading.Event()

    async def beat(self) -> None:
        while True:
            self.last = time.monotonic()
            await asyncio.sleep(HEARTBEAT_SECONDS)

    def check_once(self) -> bool:
        if time.monotonic() - self.last > self.stuck_seconds:
            write_crash(self.data_dir, "IRIS stopped responding, so she started again.")
            self.end(4)
            return False
        return True

    def start(self) -> None:
        def watch() -> None:
            while not self.stopped.wait(10):
                if not self.check_once():
                    return

        threading.Thread(target=watch, name="iris-watchdog", daemon=True).start()

    def stop(self) -> None:
        self.stopped.set()


def write_crash(data_dir: Path, text: str) -> None:
    try:
        (data_dir / CRASH_NOTE).write_text(f"{datetime.now():%d.%m. %H:%M} {text}", encoding="utf-8")
    except OSError:
        pass


def record_exception(data_dir: Path, error: BaseException) -> None:
    """Called when IRIS ends with an error: the details go to crash.log, a short line to crash.txt."""
    try:
        with (data_dir / "crash.log").open("a", encoding="utf-8") as handle:
            handle.write(f"\n--- {datetime.now():%Y-%m-%d %H:%M:%S}\n")
            handle.write("".join(traceback.format_exception(error)))
    except OSError:
        pass
    write_crash(data_dir, f"IRIS stopped with an error ({type(error).__name__}) and started again.")


def take_crash_note(data_dir: Path) -> str:
    path = data_dir / CRASH_NOTE
    try:
        text = path.read_text(encoding="utf-8").strip()
        path.unlink()
        return text
    except OSError:
        return ""


def docker_desktop() -> Path | None:
    """Docker Desktop's program, wherever Windows has it."""
    places = [os.environ.get(name, "") for name in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)")]
    candidates = [Path(base) / "Docker" / "Docker" / "Docker Desktop.exe" for base in places if base]
    if os.environ.get("LOCALAPPDATA"):
        candidates.append(Path(os.environ["LOCALAPPDATA"]) / "Programs" / "Docker" / "Docker" / "Docker Desktop.exe")
    return next((path for path in candidates if path.exists()), None)


class Health:
    def __init__(self, hub: Any, listeners: dict[str, tuple[Any, Callable[[], Awaitable[Any]]]] | None = None,
                 run: Callable[..., Any] = subprocess.run) -> None:
        self.hub = hub
        self.listeners = listeners or {}  # name -> (asyncio.Server or None, opener)
        self.run = run
        self.parts: dict[str, Part] = {}
        self.checked = ""

    # Reporting

    def state(self) -> dict[str, Any]:
        return {
            "checked": self.checked,
            "parts": [{"name": part.name, "ok": part.ok, "detail": part.detail, "since": part.since}
                      for part in self.parts.values()],
        }

    def set(self, name: str, ok: bool, detail: str = "", tell_after: int = 1) -> None:
        """tell_after: how many checks in a row must find a problem before the owner hears of it,
        for parts that IRIS usually repairs by herself in the meantime."""
        part = self.parts.setdefault(name, Part(name))
        changed = part.ok != ok
        part.ok, part.detail = ok, detail
        part.strikes = 0 if ok else part.strikes + 1
        if changed or not part.since:
            part.since = datetime.now().strftime("%d.%m. %H:%M")
        if not ok and not part.told and part.strikes >= tell_after:
            part.told = True
            self.hub.tell_owner(f"{name}: {detail}")
            self.hub.audit.write("health_problem", part=name, detail=detail[:200])
        elif ok and part.told:
            part.told = False
            self.hub.tell_owner(f"{name} works again.")
            self.hub.audit.write("health_recovered", part=name)

    def problem(self, name: str, detail: str) -> None:
        """A part that stopped by itself. The supervisor is already starting it again."""
        self.hub.audit.write("part_restarted", part=name, error=detail[:200])
        self.set(name, False, f"stopped ({detail}); starting it again")

    # Checks

    async def check(self) -> None:
        await self._listeners()
        await asyncio.to_thread(self._disk)
        await asyncio.to_thread(self._database)
        self._voice()
        await self._world_monitor()
        for name, task in getattr(self.hub, "supervised", {}).items():
            if name in self.parts and not self.parts[name].ok and not task.done():
                self.set(name, True)
        self.checked = datetime.now().strftime("%d.%m. %H:%M")
        self.hub.publish("health", self.state())

    async def _listeners(self) -> None:
        for name, (server, opener) in list(self.listeners.items()):
            if server is not None and server.is_serving():
                self.set(name, True)
                continue
            try:
                self.listeners[name] = (await opener(), opener)
                self.set(name, True)
            except OSError as error:
                self.set(name, False, f"cannot listen ({type(error).__name__}); another program may use its port")

    def _disk(self) -> None:
        usage = shutil.disk_usage(self.hub.settings.data_dir)
        free = usage.free / usage.total if usage.total else 1
        if free < MIN_FREE_DISK:
            self.set("Disk", False, f"only {free:.0%} free; IRIS may stop saving")
        else:
            self.set("Disk", True)

    def _database(self) -> None:
        try:
            path = self.hub.settings.data_dir / "iris.db"
            connection = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
            try:
                result = connection.execute("PRAGMA quick_check").fetchone()[0]
            finally:
                connection.close()
            self.set("Memory", result == "ok", "" if result == "ok" else f"the database reports: {result}")
        except sqlite3.Error as error:
            self.set("Memory", False, f"the database cannot be read ({type(error).__name__})")

    def _voice(self) -> None:
        voice = getattr(self.hub, "voice", None)
        if voice is None or not hasattr(voice, "running"):
            return
        wanted = voice.running.is_set()
        alive = bool(voice.thread and voice.thread.is_alive())
        if not wanted or alive:
            self.set("Voice", True)
            return
        part = self.parts.get("Voice")
        if time.monotonic() - (part.last_repair if part else float("-inf")) > REPAIR_EVERY_SECONDS:
            self.parts.setdefault("Voice", Part("Voice")).last_repair = time.monotonic()
            voice.turn_on()
        self.set("Voice", False, "the voice stopped; starting it again")

    def _world_monitor_folder(self) -> Path | None:
        settings = self.hub.settings
        folder = settings.root / "worldmonitor"
        return folder if settings.worldmonitor_port > 0 and folder.is_dir() else None

    async def _world_monitor(self) -> None:
        folder = self._world_monitor_folder()
        if folder is None:
            return
        from iris.worldmonitor import reachable

        if await asyncio.to_thread(reachable, self.hub.settings.worldmonitor_port):
            self.set("World Monitor", True)
            return
        part = self.parts.setdefault("World Monitor", Part("World Monitor"))
        if time.monotonic() - part.last_repair > REPAIR_EVERY_SECONDS:
            part.last_repair = time.monotonic()
            await asyncio.to_thread(self._start_world_monitor, folder)
        # Told only if it is still down about ten minutes after IRIS started it again.
        self.set("World Monitor", False, "not answering; starting Docker and World Monitor again", tell_after=3)

    async def start_world_monitor(self) -> None:
        """Right when IRIS starts, however she was started: Docker Desktop, then World Monitor."""
        folder = self._world_monitor_folder()
        if folder is None:
            return
        from iris.worldmonitor import reachable

        if await asyncio.to_thread(reachable, self.hub.settings.worldmonitor_port):
            return
        self.parts.setdefault("World Monitor", Part("World Monitor")).last_repair = time.monotonic()
        await asyncio.to_thread(self._start_world_monitor, folder, DOCKER_WAIT_SECONDS)

    def _docker_ready(self) -> bool:
        try:
            return self.run(["docker", "info"], capture_output=True, timeout=30).returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False

    def _start_docker(self) -> None:
        app = docker_desktop()
        if app is not None:
            subprocess.Popen([str(app)], creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))
            return
        try:  # Docker Desktop 4.37 and later also start from the command line
            self.run(["docker", "desktop", "start", "--detach"], capture_output=True, timeout=60)
        except (OSError, subprocess.SubprocessError):
            pass

    def _start_world_monitor(self, folder: Path, wait: float = 0) -> None:
        ready = self._docker_ready()
        if not ready and sys.platform == "win32":
            self._start_docker()
        deadline = time.monotonic() + wait
        while not ready and time.monotonic() < deadline:
            time.sleep(5)
            ready = self._docker_ready()
        if not ready:
            return  # Docker needs longer; the next check starts World Monitor
        try:
            self.run(["docker", "compose", "up", "-d"], cwd=folder, capture_output=True, timeout=600)
        except (OSError, subprocess.SubprocessError):
            pass

    async def run_forever(self) -> None:
        await asyncio.sleep(FIRST_CHECK_SECONDS)
        while True:
            try:
                await self.check()
            except Exception as error:  # a check must never end self-care itself
                self.hub.audit.write("health_check_failed", error=type(error).__name__)
            await asyncio.sleep(CHECK_SECONDS)
