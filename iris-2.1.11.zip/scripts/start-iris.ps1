# Starts IRIS with one click: Docker Desktop (for World Monitor), Ollama and IRIS itself.
# The desktop icon made by scripts\make-shortcut.ps1 runs this. If IRIS is already running,
# it only opens her window again.
$ErrorActionPreference = "Continue"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root
$Host.UI.RawUI.WindowTitle = "IRIS"

function Port-Open([int]$port) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $wait = $client.BeginConnect("127.0.0.1", $port, $null, $null)
        return ($wait.AsyncWaitHandle.WaitOne(400) -and $client.Connected)
    } catch { return $false } finally { $client.Close() }
}

function Setting([string]$section, [string]$name, [string]$fallback) {
    # The owner's own settings (data\settings.toml) come before IRIS's defaults.
    foreach ($file in @((Join-Path $root "data\settings.toml"), (Join-Path $root "config\settings.toml"))) {
        if (-not (Test-Path $file)) { continue }
        $inside = $false
        foreach ($line in Get-Content $file) {
            if ($line -match '^\s*\[(.+)\]\s*$') { $inside = ($Matches[1] -eq $section); continue }
            if ($inside -and $line -match ("^\s*" + $name + "\s*=\s*(\S+)")) { return $Matches[1].Trim('"') }
        }
    }
    return $fallback
}

# Already running: open the window again and stop here.
if (Port-Open 8765) {
    $saved = Join-Path $root "data\open-url.txt"
    if (Test-Path $saved) {
        $url = (Get-Content $saved -Raw).Trim()
        $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
        if ($edge) { Start-Process $edge -ArgumentList "--app=$url", "--user-data-dir=$(Join-Path $root 'data\ui-profile')", "--no-first-run" }
        else { Start-Process $url }
    }
    exit
}

# Ollama, the local brain
if (-not (Port-Open 11434)) {
    $ollama = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama app.exe"
    if (Test-Path $ollama) { "Starting Ollama..."; Start-Process $ollama -WindowStyle Hidden }
}

# Docker Desktop and World Monitor. IRIS does not wait for them; World Monitor appears in
# Situation when Docker is ready, usually within a minute.
$worldPort = [int](Setting "worldmonitor" "port" "3000")
$worldFolder = Join-Path $root "worldmonitor"
if ($worldPort -ne 0 -and (Test-Path $worldFolder)) {
    # Started whenever its engine does not answer, even if its window is already open.
    docker info *> $null
    if ($LASTEXITCODE -ne 0) {
        $dockerApp = @($env:ProgramFiles, $env:ProgramW6432, (Join-Path $env:LOCALAPPDATA "Programs")) |
            Where-Object { $_ } | ForEach-Object { Join-Path $_ "Docker\Docker\Docker Desktop.exe" } |
            Where-Object { Test-Path $_ } | Select-Object -First 1
        "Starting Docker Desktop for World Monitor..."
        if ($dockerApp) { Start-Process $dockerApp -WindowStyle Minimized }
        else { docker desktop start --detach *> $null }
    }
    # Keep IRIS's own World Monitor settings current (they let the tablet show it too).
    $conf = Join-Path $worldFolder "iris-nginx.conf"
    $before = if (Test-Path $conf) { (Get-FileHash $conf).Hash } else { "" }
    & (Join-Path $root ".venv\Scripts\python.exe") -m iris.worldmonitor --port $worldPort *> $null
    $changed = (Test-Path $conf) -and ((Get-FileHash $conf).Hash -ne $before)
    Start-Job -Name "worldmonitor" -ArgumentList $worldFolder, $changed -ScriptBlock {
        param($folder, $changed)
        for ($i = 0; $i -lt 200; $i++) {  # up to ten minutes
            docker info *> $null
            if ($LASTEXITCODE -eq 0) {
                Set-Location $folder
                if ($changed) { docker compose up -d --force-recreate worldmonitor *> $null }
                docker compose up -d *> $null
                return
            }
            Start-Sleep -Seconds 3
        }
    } | Out-Null
}

"Starting IRIS..."
# Exit code 3 means IRIS installed an update. Any other code but 0 means she stopped by accident:
# she is started again (and says so), unless that keeps happening.
$crashes = @()
while ($true) {
    & (Join-Path $root ".venv\Scripts\python.exe") -m iris.ui
    $code = $LASTEXITCODE
    if ($code -eq 0) { break }
    if ($code -eq 3) { continue }
    $crashes = @($crashes | Where-Object { $_ -gt (Get-Date).AddMinutes(-10) }) + (Get-Date)
    if ($crashes.Count -ge 5) {
        "IRIS stopped five times in ten minutes, so she is not started again. See data\crash.log."
        Read-Host "Press Enter to close"
        break
    }
    "IRIS stopped unexpectedly (code $code). Starting her again in 5 seconds..."
    Start-Sleep -Seconds 5
}
Get-Job -Name "worldmonitor" -ErrorAction SilentlyContinue | Remove-Job -Force
